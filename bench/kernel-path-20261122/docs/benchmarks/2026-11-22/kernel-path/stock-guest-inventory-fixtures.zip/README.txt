Offline Micropod stock-baseline regression fixtures

All worker observations are simulated. Bulk client output and host counters come from saved rounds.
This archive contains zero live measurements.

v1-mixed contains the old producer's completed baseline. It accepted the stock config from boot
retired and the live boot ID B from the second inventory. The second digest is all f characters.
v2-control contains a single inventory with CRLF line endings. Its owner export was removed at the
first simulated kernel read. The producer captured the original bytes and completed both attempts.
v2-mixed-stop contains the new producer's first stop before it started a client invocation.
v2-resealed-mixed replaces the valid inventory with the mixed one and recomputes both the fixture
and completion hashes. The independent identity-field check rejects it.
v2-detached changes only CRLF to LF after completion. The raw file digest catches the substitution.

Run the study checkout's scripts/gamma_path_study.py cpu-attribution --pilot-dir DIRECTORY for
each case. To reconstruct the producer cases, extract this archive to a fresh directory and set
REPRO to that directory. From the study checkout run

    DATA=docs/benchmarks/2026-11-22/kernel-path
    mkdir "$REPRO/parent"
    git archive 2be5d09197ec853983e4a40af53210b15c2c4beb scripts "$DATA/index.json" "$DATA/rounds.jsonl" | tar -xf - -C "$REPRO/parent"
    python3 -B "$REPRO/capture.py" v1
    python3 -B "$REPRO/capture.py" v2

The harness uses the checkout's existing offline integration fixtures and the pinned relay source
in the sibling worker-performance checkout. The parent run uses its real kernel reader with a
mocked guest response for boot B. Reconstructed producer directories appear under $REPRO/cases.
