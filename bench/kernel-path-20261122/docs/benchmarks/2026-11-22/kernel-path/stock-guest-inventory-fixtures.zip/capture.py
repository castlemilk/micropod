import contextlib
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

work = Path(__file__).resolve().parent
repo = Path.cwd()
version = sys.argv[1]
tree = work / "parent" if version == "v1" else repo
sys.path.insert(0, str(tree / "scripts"))
os.environ["MICROPOD_RELAY_SOURCE"] = str(repo.parent / "worker-performance")
import test_gamma_path as tests

cases = work / "cases"
cases.mkdir(exist_ok=True)
original_temp = tempfile.TemporaryDirectory
original_run = tests.pilot.run
original_kernel_facts = tests.pilot.kernel_facts
mixed = (repo / "docs/benchmarks/2026-11-22/kernel-path/stock-guest-mixed.txt").read_bytes()

@contextlib.contextmanager
def retain_cases(*args, **kwargs):
    with original_temp(*args, **kwargs) as td:
        yield td
        outputs = {"baseline": "v1-mixed"} if version == "v1" else {
            "baseline": "v2-control", "mixed-guest": "v2-mixed-stop"}
        for name, label in outputs.items():
            source = Path(td) / name
            if (source / "plan.json").is_file():
                shutil.copytree(source, cases / label)

def run_parent_case(args, helpers, plan):
    if args.mode != "baseline" or args.out.name != "baseline":
        return original_run(args, helpers, plan)
    args.facts_a.write_bytes(mixed)
    fixture_command = helpers.command
    def observe(*argv):
        if argv[0] == "curl":
            guest = Path(argv[argv.index("--unix-socket") + 1]).parent
            return json.dumps({"boot": guest.name, "sched_ext": None})
        return fixture_command(*argv)
    with patch.object(tests.pilot, "kernel_facts", original_kernel_facts), patch.object(helpers, "command", side_effect=observe):
        return original_run(args, helpers, plan)

case = tests.GammaPathTests("test_full_dry_crossover_writes_each_attempt_and_stops_on_first_dirty_arm")
with contextlib.ExitStack() as stack:
    stack.enter_context(patch.object(tempfile, "TemporaryDirectory", retain_cases))
    stack.enter_context(patch("socket.socket.connect", side_effect=AssertionError("offline check opened a socket")))
    if version == "v1":
        stack.enter_context(patch.object(tests.pilot, "run", side_effect=run_parent_case))
    result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([case]))
raise SystemExit(not result.wasSuccessful())
