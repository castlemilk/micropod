# Micropod relay alignment and VMM scheduling evidence

Reconciliation of the November 23, 2026 report against its original local Git objects. The alignment receipts identify the operating system and architecture. The VMM receipts identify Gamma by model and host. The studies use different workloads and denominators. All results come from retained observations. The accompanying Python replay reads files only.

## #230 · Relay buffer alignment

**Decision.** Keep the inline allocation change experimental. The marked bulk workload gave a paired throughput change of −1.6% (95% interval −9.0% to +2.6%). None of the four stock comparisons established a throughput gain.

**Workload and controls.** Both trials report macOS 26.5.1 on arm64 and Apple clang 21.0.0 (clang-2100.1.1.101). They record neither the Mac model nor its host ID. Sources for the fixture reference commit `a1e7965b277943dba589b8937c3de5a8121f4db7`. One background thread drove producer, relay and consumer over established Darwin AF_UNIX sockets. Wall time includes payload generation, forwarding and verification. Owner CPU times native drains. No guest or TCP connection setup participates.

The first trial placed scratch at four different addresses in a single binary, including three positions in one external allocation. Eight streams carried 64 MiB per timed arm. All 192 expected arm rows are present and byte-verified (16 blocks × 3 cap/offer cells × 4 arms, seed 88129). Eight sanitizer qualification rows are separate. At 256 KiB cap and offer, page-aligned versus offset-matched external storage gained 17.0% in paired throughput (95% interval +1.4% to +26.7%). The external matched control’s median was 2,929 MiB/s versus 3,238 MiB/s embedded. That contrast cannot establish the effect of changing the stock allocation.

The independent holdout compiled the original C and the aligned C separately. It used sixteen established streams, the ordinary 256 KiB cap, a flat queue with a 128-event budget, equal 262,200-byte objects and 16 KiB host pages. The patch moves the embedded scratch to offset zero, allocates the relay object with page alignment and zeros it. Each workload contains 24/24 verified stock arms and 24/24 verified candidate arms, split 12/12 by run order (seed 94673). All 192 expected timed arm rows are present, plus four separate sanitizer qualification rows. Earlier failed invocations, if any, have no separate attempt ledger in these receipts. Warm-up samples outside the saved blocks do not enter the estimates.

| Workload | Stock median MiB/s | Aligned median MiB/s | Median paired change | 95% paired interval |
|---|---:|---:|---:|---:|
| 256 KiB writes | 3,106 | 3,299 | +9.4% | −2.4% to +20.0% |
| 256 KiB plus marker | 3,184 | 3,163 | −1.6% | −9.0% to +2.6% |
| 4 KiB writes | 1,129 | 1,125 | +2.3% | −6.0% to +13.7% |
| 4 KiB plus marker | 1,047 | 1,122 | −2.1% | −17.1% to +12.2% |

Bulk owner CPU/GiB changed −7.5% (−18.7% to +5.9%). In marked bulk runs, paired marker p95 changed +2.2% (−8.0% to +12.0%) and p99 +3.7% (−28.9% to +69.6%). The holdout delivered all 15,360 timed one-byte markers in the expected order. The fixture verified payloads, reverse traffic and both half-closes. The intervals use 10,000 paired bootstrap resamples of the median. Production fresh-request loss and tails, host runnable time, VM throughput, and a paired OrbStack effect were unmeasured for this change. The stock relay remains the reference for the released two-versus-four-worker trial.

**Proof.** The source SHA-256 is `f35e0245ebc1d394f748ea31ef03df180c70ad4a979925037ea063f7a2a08cee` for stock and `af68d06d9d9ad55115a21ab8f7fb01ee4ef2eef55c14dd73bf72a19afb621aaf` for the aligned candidate, as recorded at build time. The stock and aligned timed binaries were identified by SHA-256 `b307645a96eac45d995f6e389c40a0bc9fa53b7a0bf1d1c1e38e71d008d730c5` and `89ddd77aacb7273706955bf8fc6ef9a449997187152bf44e24212ab3c1f146ee` respectively. The binary bytes were temporary. All build flags, marked and sanitizer digests and individual observations are in the two receipts. [Four-arm screen](docs/benchmarks/2026-11-23/relay-scratch-alignment.json) · [Stock holdout](docs/benchmarks/2026-11-23/relay-scratch-inline.json) · [Exact candidate patch](scripts/relaybench/scratch_inline.patch)

## #228 · Host scheduling in archived four-vCPU VM rounds

**Decision.** Retain VMM CPU time and runnable wait as observations in the worker comparison. These data cannot attribute a speedup to launchd QoS, relay alignment, worker count or another scheduling policy. Each quarter is selected by its observed throughput, and faster transfers can demand more CPU.

Gamma was an 18-core M5 Max running macOS 26.5.1. The three series used four-vCPU, four-GiB-class Micropod guests, a 7.3.5 Micropod kernel release, a four-CPU service and the same arm64 image config `sha256:80996a25c9c753fcaf3f421a3f61557497b8ab539bdd68076074d181cfa71889`. The pinned client `a1e2609f9d052b2765dc717fac1b227a8247aa9e73364bf3962168c30c8ffc53` kept 32 bulk connections open and offered 240 fresh requests in six seconds. Compare quartiles within each worker lifetime.

| Micropod series | Attempted / clean / in replay | Slow → fast quarter size | Median MiB/s | VMM host cores | VMM runnable wait, thread-s/s | VMM instructions per scored byte |
|---|---:|---|---:|---:|---:|---:|
| Peer holdout | 16 / 16 / 16 | 4 each | 2,056 → 3,800 | 1.19 → 2.10 | 2.66 → 1.22 | 2.119 → 2.072 |
| Full-Reno confirmation | 12 / 12 / 12 | 3 each | 1,677 → 4,500 | 0.83 → 1.93 | 2.80 → 1.59 | 1.649 → 1.482 |
| Full-Reno kernel holdout | 12 / 12 / 12 | 3 each | 2,060 → 5,074 | 0.88 → 2.14 | 2.60 → 1.34 | 1.511 → 1.464 |

The original report prints 1.20 for the slow peer quartile. The original JSON gives 1.1949809022950961 host cores, which rounds to **1.19** at two decimal places. The table preserves the forty distinct Micropod rounds. All forty met the archived clean-client criteria. Other engine populations qualify independently. In the peer holdout, OrbStack completed 15 of 16 cleanly. The fresh identity request in round 12 ended in EOF. Of the other diagnostic arms in the Full-Reno confirmation, full-bridge completed 12/12 cleanly and OrbStack 10/12 (identity EOF in rounds 2 and 8). All three other diagnostic arms in the kernel holdout completed 12/12 cleanly. The forty-round process replay includes only the selected Micropod arms.

**End-to-end reference.** The independent clean medians were 2,709.83 MiB/s on Micropod (16 attempts scored clean) and 3,010.38 MiB/s on OrbStack (15 clean). Their difference is 300.55 MiB/s, or 300.6 to one decimal. Restricting both to the same 15 clean pairs gives medians of 2,854.06 and 3,010.38 MiB/s. The median of the 15 within-pair OrbStack-minus-Micropod differences is 266.93 MiB/s. Micropod won 7/15 pairs. The median paired Micropod/OrbStack throughput ratio was 0.854 (95% interval 0.709–1.259). On those pairs the median per-round fresh p95 was 33.456 ms versus 220.325 ms, and p99 was 57.482 ms versus 1,027.418 ms. These are historical end-to-end observations across engines. They do not test the alignment candidate.

The host snapshots bracketed setup, scoring and drain. Mean host cores divide process CPU time by observer wall time. Wait sums runnable off-CPU thread time across the process. Instructions per byte divide whole-observation counters by the client's scored payload bytes. Full-invocation bytes, exact scoring-boundary CPU, per-vCPU thread QoS or placement, causal scheduling effects and an aligned-versus-stock VM trial are unavailable here. The next live measurement in the report is the stock four-vCPU, two-worker baseline after owner handoff and effective disk clearance. A separate worker-count comparison holds four vCPUs fixed. A fresh paired holdout would establish the current end-to-end gap. [Replayed process rows](docs/benchmarks/2026-11-23/gap-process-work.json) · [Peer raw archive](docs/benchmarks/2026-11-21/gamma-vcpu-priority.json.gz) · [Full-Reno raw archive](docs/benchmarks/2026-11-21/gamma-direct-macvlan.json.gz)

## Provenance and verification

| Local object | Full Git commit | SHA-256 of input or report |
|---|---|---|
| Original report | `97323524e714dc00528faee5cc4bee443a9ae627` | `36ad3933b5398610b1060319a18486261212bffa6dcfcb751e369cec8e9d9268` |
| Four-arm receipt | Same as original report | `4f7344a4571155468d304e02523de8a55ca1d53d9debe68fca23bb7c6bbae2a3` |
| Inline holdout receipt | Same as original report | `172547133244c3848ffa39f38eaaa5d3fa8e69861dd3d9a2384650d9494c4823` |
| Process replay receipt | `c232965a49baad87b30b89f531522532205d20d8` | `8ffaec66053da54544457d16915e797d6ea0ad0fd7a7ca699a0fe12a4ee1e034` |
| Peer archive | `ad0646d6292076b6ddf7647f2dc806d785d8f8fb` | `066cd4071f3f926a228d87310f6d7b6f361c38f07c7a8240aa09a57f03f201e4` |
| Full-Reno archive | `7a4eb51a04b51f6332ed49561b3dd0bb42ffacd9` | `cc3b9e5c365383a3353423ce1f7fc443c8d858a1af24bb082117bcec24ffa976` |

After unpacking, run the two commands below from the bundle root. The first checks every packaged file. The second checks the input hashes, recomputes both alignment summaries from the individual observations, byte-compares the historical VMM replay, and verifies the peer attempt and pair denominators. It does not build the relay or start a benchmark.

```sh
shasum -a 256 -c SHA256SUMS
python3 -B verify.py
```

Read-only GitHub retrieval succeeded for #228, #230 and the #221 disk-preparation example pinned at `bed1ca355ae875b1634a08f4ddd00435f17ef40e`. GitHub returned 404 for the two study refs, both historic input refs and the report path on the default branch. The measured artifacts are therefore supplied here by exact local Git object and file digest. Repository-file links inside this bundle resolve after extraction. [Pinned #221 example](https://github.com/castlemilk/micropod/blob/bed1ca355ae875b1634a08f4ddd00435f17ef40e/docs/benchmarks/2026-11-19/sandbox-disk-cache/README.md) · [Issue #228](https://github.com/castlemilk/micropod/issues/228) · [Issue #230](https://github.com/castlemilk/micropod/issues/230) · [File-level provenance](PROVENANCE.json)
