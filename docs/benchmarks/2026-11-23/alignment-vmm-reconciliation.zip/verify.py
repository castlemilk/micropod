"""Recompute the saved results from their archived measurements using only local files."""
import gzip
import hashlib
import json
import subprocess
import sys
from collections import Counter
from pathlib import Path
from statistics import median

root = Path(__file__).resolve().parent
scripts = root / 'scripts/relaybench'
sys.path.insert(0, str(scripts))
import gamma_contrasts
import scratch_alignment
import scratch_inline

def read(path):
    return json.loads(path.read_bytes())

def sha(data):
    return hashlib.sha256(data).hexdigest()

def check(condition, message):
    if not condition:
        raise ValueError(message)

for name, src in read(root / 'PROVENANCE.json')['files'].items():
    check(sha((root / name).read_bytes()) == src['sha256'], f'file digest mismatch: {name}')

d = root / 'docs/benchmarks/2026-11-23'
screen = read(d / 'relay-scratch-alignment.json')
holdout = read(d / 'relay-scratch-inline.json')
for report in (screen, holdout):
    for name, digest in report['source_sha256'].items():
        if name.startswith(('Sources/', 'scripts/')):
            src = root / name
        elif name.endswith(('.c', '.py', '.patch')):
            src = scripts / name
        else:
            continue
        check(sha(src.read_bytes()) == digest, f'fixture input hash mismatch: {name}')

check(len(screen['blocks']) == 16, 'incomplete screen')
for cap, offer in scratch_alignment.CELLS:
    cell = f'cap{cap}_offer{offer}'
    for block in screen['blocks']:
        rows = block[cell]
        check(sorted(row['arm'] for row in rows) == sorted(scratch_alignment.ARMS), 'missing screen arm')
        for row in rows:
            check(row['verified_bytes'] == 64 * 2**20 and row['piece'] == offer*1024 and row['cap'] == cap*1024
                  and min(row['wall_ns'], row['owner_ns']) > 0, 'screen work mismatch')
    check(scratch_alignment.score(screen['blocks'], cell) == screen['summary'][cell], 'screen summary mismatch')
print('External scratch screen: 16 blocks x 3 cells x 4 arms = 192/192 verified timed arm rows.')

check(len(holdout['blocks']) == 24, 'incomplete alignment holdout')
markers = 0
for cell, (offer, waves, marked) in scratch_inline.CELLS.items():
    check(Counter(tuple(b[cell]) for b in holdout['blocks']) == {('stock','aligned'): 12, ('aligned','stock'): 12}, 'unexpected arm ordering')
    for b in holdout['blocks']:
        for arm, row in b[cell].items():
            check(row['verified_bytes'] == 16*waves*offer*1024 and row['piece'] == offer*1024 and min(row['wall_ns'],row['owner_ns']) > 0, 'holdout work mismatch')
            check(row['allocation_bytes'] == 262200 and row['page_bytes'] == 16384 and (arm == 'stock' or row['offset'] == 0), 'allocation mismatch')
            times = row.get('fresh_ns', [])
            check(len(times) == (waves if marked else 0) and all(t > 0 for t in times), 'missing marker')
            if marked:
                check(row['bytes_ahead_per_reply'] == 15*offer*1024, 'marker ordering mismatch')
            markers += len(times)
    check(scratch_inline.stats(holdout['blocks'], cell) == holdout['summary'][cell], 'holdout summary mismatch')
check(markers == 15360, 'wrong marker count')
print('Inline stock comparison: 24 pairs x 4 cells x 2 arms = 192/192 verified timed arm rows, 15,360 markers.')

out = subprocess.check_output([sys.executable, '-B', str(scripts / 'gap_process_work.py')])
check(out == (d/'gap-process-work.json').read_bytes(), 'VMM archive replay differs from saved bytes')
print('VMM archive replay matches gap-process-work.json byte for byte (40 Micropod rounds).')

vm = json.loads(gzip.decompress(gamma_contrasts.VM.read_bytes()))
runs = vm['phases']['grace-holdout']['runs']
mp, orb = runs['confirm-micropod'], runs['confirm-orb']
check(len(mp) == len(orb) == 16 and set(mp) == set(orb), 'incomplete peer schedule')
for arm in (mp, orb):
    for row in arm.values():
        check(row['clean'] == gamma_contrasts.clean_client(row['client']), 'wrong stored clean flag')
clean_pairs = [n for n in mp if mp[n]['clean'] and orb[n]['clean']]
check(len(clean_pairs) == 15 and '12' not in clean_pairs and len(orb['12']['client']['errors']) == 1, 'unexpected failed peer attempts')
rates = {arm:median(r['client']['mib_s'] for r in series.values() if r['clean']) for arm, series in runs.items()}
delta = median(orb[n]['client']['mib_s']-mp[n]['client']['mib_s'] for n in clean_pairs)
print(f"Original holdout: 16/16 Micropod, 15/16 OrbStack, 15/16 common pairs. Independent clean-median gap {rates['confirm-orb']-rates['confirm-micropod']:.2f} MiB/s. Median paired difference {delta:.2f} MiB/s.")
