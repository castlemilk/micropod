"""Build, measure and replay a one-vCPU HVF notification comparison on Gamma."""
import argparse
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
import random
from statistics import median
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
SRC = ROOT / "scripts/relaybench/hvf_notify"
BRIDGE = SRC.parent / "hvf_tx_probe/apple.c"
sys.path.insert(0, str(HERE.parent / "gamma-local-peer"))
from run import Admission
from score import load, receiver, require
import local_terminal as terminal
from gamma_contrasts import paired_median_interval

SEED = 34225
BLOCKS = 16
TOTAL = 65537
MODES = (("mmio", 1), ("hvc", 1), ("mmio", 8), ("hvc", 8))


def schedule():
    # Williams design. Every condition occupies each position once per quartet.
    rows = [(0, 1, 3, 2), (1, 2, 0, 3), (2, 3, 1, 0), (3, 0, 2, 1)]
    rng = random.Random(SEED)
    plan = [list(range(4))]
    for _ in range(BLOCKS // 4):
        plan.extend(rng.sample(rows, len(rows)))
    return [[dict(block=n, transport=MODES[i][0], batch=MODES[i][1]) for i in indices]
            for n, indices in enumerate(plan)]


def assess(folder):
    status = load(folder / "status.json")
    require(status["complete"] and status["action"] == "run" and status["process_exit"] == 0
            and status["temporary_build_removed"], "hardware run incomplete")
    plan = load(folder / "plan.json")
    orders = schedule()
    require(plan["order"] == orders and plan["seed"] == SEED and plan["total"] == TOTAL, "changed schedule")
    idle = load(folder / "idle.json")
    if plan["load"] == "controlled":
        require(idle["idle_gate_passed"] and all(s["eligible"] and s["idle_pct"] >= 90
                for s in idle["idle_observations"][-2:]) and len(idle["idle_observations"]) >= 2,
                "host admission failed")
    else:
        require(plan["load"] == "ambient" and len(idle["idle_observations"]) == 1
                and 0 <= idle["idle_pct"] <= 100, "missing natural-load sample")
    raw = (folder / "windows.jsonl").read_bytes()
    require(hashlib.sha256(raw).hexdigest() == status["raw_sha256"], "changed measurements")
    records = [json.loads(line) for line in raw.splitlines()]
    expected = [config for block in orders for config in block]
    require(len(records) == len(expected), "missing first attempt")
    measured = {}
    for config,r in zip(expected, records, strict=True):
        require(all(r[k] == v for k,v in config.items()) and r["descriptors"] == TOTAL
                and r["data_exits"] == (TOTAL+r["batch"]-1)//r["batch"] and r["completion_exits"] == 1
                and all(type(r[k]) is int and r[k] > 0 for k in ("wall_ns","thread_cpu_ns","vcpu_ns")),
                "unverified guest work, exit count or time")
        measured[r["block"],r["transport"],r["batch"]] = r
    result = {}
    for batch in (1, 8):
        pairs = [(measured[n,"mmio",batch],measured[n,"hvc",batch]) for n in range(1,BLOCKS+1)]
        ratios = [h["wall_ns"]/m["wall_ns"] for m,h in pairs]
        deltas = [(m["wall_ns"]-h["wall_ns"])/m["data_exits"] for m,h in pairs]
        arm = {}
        for side, name in enumerate(("mmio","hvc")):
            rows = [p[side] for p in pairs]
            arm[name] = {k:median(r[k]/r["data_exits"] for r in rows)
                         for k in ("wall_ns","thread_cpu_ns","vcpu_ns")}
        result[str(batch)] = dict(blocks=BLOCKS,hvc_faster=sum(r < 1 for r in ratios),ratio=median(ratios),
                                  ratio_ci95=paired_median_interval(ratios),wall_ns_saved_per_kick=median(deltas),
                                  saving_ci95_ns=paired_median_interval(deltas),ns_per_data_notification=arm)
    return result


def run(folder, check, load_policy, status):
    order = schedule()
    if check:
        order = order[:1]
    sources = [HERE/"hardware.py", SRC/"guest.S", SRC/"notify.c", BRIDGE]
    pins = {str(p.relative_to(ROOT)):terminal.digest(p) for p in sources}
    compiler = ["xcrun","clang","-arch","arm64","-O2","-std=c11","-Wall","-Wextra","-Werror"]
    with tempfile.TemporaryDirectory(prefix="mp-hvf-notify-") as tmp:
        build = Path(tmp)
        exe = build/"notify"
        subprocess.run([*compiler,SRC/"notify.c",SRC/"guest.S",BRIDGE,"-framework","Hypervisor","-o",exe],check=True)
        ent = build/"entitlements.plist"
        ent.write_text('<plist version="1.0"><dict><key>com.apple.security.hypervisor</key><true/></dict></plist>')
        terminal.invoke("codesign","--force","--sign","-","--entitlements",ent,exe)
        terminal.invoke("codesign","--verify","--strict",exe)
        require(all(terminal.digest(ROOT/key)==digest for key,digest in pins.items()),"source changed during build")
        terminal.save(folder/"plan.json", dict(seed=SEED,order=order,total=TOTAL,page_bytes=16384,vcpus=1,load=load_policy,
               host=terminal.invoke("hostname").stdout.strip(),os=terminal.invoke("sw_vers").stdout.strip(),
               cpu=terminal.invoke("sysctl","-n","machdep.cpu.brand_string").stdout.strip(),
               hv_support=terminal.invoke("sysctl","-n","kern.hv_support").stdout.strip(),sources=pins,
               compiler=terminal.invoke("xcrun","clang","--version").stdout.strip(),flags=compiler,
               sdk=terminal.invoke("xcrun","--show-sdk-version").stdout.strip(),binary_sha256=terminal.digest(exe)))
        with terminal.terminal_lock():
            admission = Admission(folder)
            admission.check(force=True)
            row = {}
            diagnostic = check or load_policy == "ambient"
            receiver.await_idle(row,None,diagnostic,0 if diagnostic else 180,receiver.path_pilot.cpu_idle,admission.check,
                                lambda:terminal.save(folder/"idle.json",row))
            stdin = "".join(f"{r['block']} {int(r['transport'] == 'hvc')} {r['batch']}\n"
                            for block in order for r in block)
            with (folder/"windows.jsonl").open("x") as out, (folder/"stderr.txt").open("x") as err:
                proc = subprocess.run([exe],input=stdin,text=True,stdout=out,stderr=err,timeout=60)
            status.update(process_exit=proc.returncode,raw_sha256=terminal.digest(folder/"windows.jsonl"))
            require(proc.returncode == 0, "HVF probe failed: " + (folder/"stderr.txt").read_text().strip())
            admission.check(force=True)
    status["temporary_build_removed"] = not build.exists()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--check",action="store_true")
    group.add_argument("--run",action="store_true")
    group.add_argument("--replay",type=Path)
    parser.add_argument("--load",choices=("controlled","ambient"),default="controlled")
    args = parser.parse_args()
    if args.replay:
        print(json.dumps(assess(args.replay),indent=2))
        sys.exit(0)
    action = "check" if args.check else "run"
    folder = Path(tempfile.mkdtemp(prefix=datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ-hvf-")+action+"-",dir=HERE))
    print(folder,flush=True)
    status = dict(action=action,complete=False,start=terminal.now())
    try:
        run(folder,args.check,args.load,status)
        status["complete"] = True
    except (Exception, KeyboardInterrupt) as exc:
        status["error"] = str(exc) or type(exc).__name__
        raise
    finally:
        terminal.save(folder/"status.json",dict(status,ended=terminal.now()))
    if not args.check:
        summary = assess(folder)
        terminal.save(folder/"summary.json",summary)
        print(json.dumps(summary,indent=2))
