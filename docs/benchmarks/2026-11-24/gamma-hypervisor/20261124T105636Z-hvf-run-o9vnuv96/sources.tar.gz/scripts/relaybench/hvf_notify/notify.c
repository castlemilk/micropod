// Compare two public HVF guest-exit paths at fixed notification count.
#include <Hypervisor/Hypervisor.h>
#include <mach/mach_time.h>
#include <stdbool.h>
#include <stdatomic.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

// Reuse the existing probe's SDK bridge for code installation, mapping and EL1 setup.
int mp_tx_install(void *, size_t);
hv_return_t mp_tx_map(void *, uint64_t, size_t, int);
hv_return_t mp_tx_boot(hv_vcpu_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);

enum { PAGE = 16384, TOTAL = 65537, SLOTS = 8 };
static const uint64_t CODE = 0x40000000, DATA = 0x40004000, BELL = 0x40008000;
static mach_timebase_info_data_t timebase;
struct queue {
    _Atomic uint64_t head, ack;
    uint64_t reserved[6], slots[SLOTS];
};
_Static_assert(offsetof(struct queue, ack) == 8 && offsetof(struct queue, slots) == 64, "guest ABI");

static bool checked(hv_return_t rc, const char *operation) {
    if (rc == HV_SUCCESS) return true;
    fprintf(stderr, "%s: 0x%x\n", operation, rc);
    return false;
}

static uint64_t nanoseconds(uint64_t ticks) {
    return (uint64_t)((__uint128_t)ticks * timebase.numer / timebase.denom);
}

// HVC resumes at the next guest instruction. A trapped store resumes at the faulting
// instruction. The control has a fixed queue per address and needs no payload register.
static int doorbell(hv_vcpu_t cpu, const hv_vcpu_exit_t *exit, unsigned hypercall) {
    if (exit->reason != HV_EXIT_REASON_EXCEPTION) return -1;
    uint64_t syndrome = exit->exception.syndrome;
    unsigned kind = (unsigned)((syndrome >> 26) & 63);
    if (hypercall) {
        if (kind != 0x16) return -1;
        switch (syndrome & 0xffff) {
        case 0x41: return 0;
        case 0x42: return 1;
        default: return -1;
        }
    }
    if (kind != 0x24 || !(syndrome & (1u << 24)) || !(syndrome & (1u << 6)) ||
        ((syndrome >> 22) & 3) != 2 || ((syndrome >> 16) & 31) != 31) return -1;
    uint64_t ipa = exit->exception.physical_address;
    if (ipa == BELL + 4) return 1;
    if (ipa != BELL) return -1;
    uint64_t pc;
    if (!checked(hv_vcpu_get_reg(cpu, HV_REG_PC, &pc), "get PC") ||
        !checked(hv_vcpu_set_reg(cpu, HV_REG_PC, pc + 4), "advance MMIO PC")) return -1;
    return 0;
}

static bool window(hv_vcpu_t cpu, const hv_vcpu_exit_t *exit, struct queue *q,
                   unsigned block, unsigned hypercall, unsigned batch) {
    memset(q, 0, sizeof(*q));
    if (!checked(mp_tx_boot(cpu, CODE, DATA, BELL, TOTAL, batch), "EL1 setup") ||
        !checked(hv_vcpu_set_reg(cpu, HV_REG_X4, hypercall), "set transport")) return false;
    uint64_t guest_start, guest_end;
    if (!checked(hv_vcpu_get_exec_time(cpu, &guest_start), "guest start time")) return false;
    uint64_t consumed = 0;
    unsigned exits = 0, expected = (TOTAL + batch - 1) / batch;
    uint64_t thread_start = clock_gettime_nsec_np(CLOCK_THREAD_CPUTIME_ID);
    uint64_t start = mach_absolute_time();
    for (;;) {
        if (!checked(hv_vcpu_run(cpu), "guest entry")) return false;
        int event = doorbell(cpu, exit, hypercall);
        if (event < 0) {
            fprintf(stderr, "unexpected exit reason=%u, syndrome=0x%llx\n", (unsigned)exit->reason,
                    (unsigned long long)exit->exception.syndrome);
            return false;
        }
        if (event == 1) break;
        if (++exits > expected) return false;
        uint64_t head = atomic_load_explicit(&q->head, memory_order_acquire);
        uint64_t count = TOTAL - consumed < batch ? TOTAL - consumed : batch;
        if (!count || head != consumed + count) return false;
        for (uint64_t slot = 0; slot < count; ++slot) {
            if (q->slots[slot] != consumed + slot + 1) return false;
        }
        consumed = head;
        atomic_store_explicit(&q->ack, consumed, memory_order_release);
    }
    uint64_t elapsed = nanoseconds(mach_absolute_time() - start);
    uint64_t thread_ns = clock_gettime_nsec_np(CLOCK_THREAD_CPUTIME_ID) - thread_start;
    if (!checked(hv_vcpu_get_exec_time(cpu, &guest_end), "guest end time") ||
        guest_end < guest_start || consumed != TOTAL || exits != expected || !elapsed) return false;
    printf("{\"block\":%u,\"transport\":\"%s\",\"batch\":%u,\"descriptors\":%u,"
           "\"data_exits\":%u,\"completion_exits\":1,\"wall_ns\":%llu,\"vcpu_ns\":%llu,"
           "\"thread_cpu_ns\":%llu}\n", block, hypercall ? "hvc" : "mmio", batch, TOTAL, exits,
           (unsigned long long)elapsed, (unsigned long long)nanoseconds(guest_end - guest_start),
           (unsigned long long)thread_ns);
    fflush(stdout);
    return true;
}

int main(void) {
    if (getpagesize() != PAGE || mach_timebase_info(&timebase) != KERN_SUCCESS) return 2;
    void *code = NULL, *data = NULL;
    hv_vcpu_t cpu = 0;
    hv_vcpu_exit_t *exit = NULL;
    bool vm = false, vcpu = false, ok = false;
    if (!checked(hv_vm_allocate(&code, PAGE, HV_ALLOCATE_DEFAULT), "allocate code") ||
        !checked(hv_vm_allocate(&data, PAGE, HV_ALLOCATE_DEFAULT), "allocate data")) goto done;
    if (mp_tx_install(code, PAGE) != 0 || !checked(hv_vm_create(NULL), "create VM")) goto done;
    vm = true;
    if (!checked(mp_tx_map(code, CODE, PAGE, 1), "map code") || !checked(mp_tx_map(data, DATA, PAGE, 0), "map ring") ||
        !checked(hv_vcpu_create(&cpu, &exit, NULL), "create vCPU")) goto done;
    vcpu = true;
    unsigned block, mode, batch;
    int parsed;
    while ((parsed = scanf("%u %u %u", &block, &mode, &batch)) == 3) {
        if (mode > 1 || (batch != 1 && batch != 8) || !window(cpu, exit, data, block, mode, batch)) goto done;
    }
    ok = parsed == EOF && !ferror(stdin);
done:
    if (vcpu && !checked(hv_vcpu_destroy(cpu), "destroy vCPU")) ok = false;
    if (vm && !checked(hv_vm_destroy(), "destroy VM")) return 2;
    if (data && !checked(hv_vm_deallocate(data, PAGE), "free data")) ok = false;
    if (code && !checked(hv_vm_deallocate(code, PAGE), "free code")) ok = false;
    return ok ? 0 : 2;
}
