# Micropod guest networking performance evidence

Start with [the research report](docs/benchmarks/2026-11-24/orbstack-rea/README.md). The report identifies the installed OrbStack 2.2.5 helper, the measured Micropod kernel, the hardware device study and the independent VM and relay experiments.

The two completed VM comparisons include all 24 scored receiver records, run plans, fixture identities and native summaries. The failed Interactive-first replication includes its startup and cleanup records. The legacy TX study includes the guest snapshots and six extracted receiver records. The full historical receiver archive is identified by digest in the Micropod performance checkout.

The extracted tree includes the complete microbenchmark source for the Rust hardware device and the Darwin handshake, plus the guest Linux syscall probe. The VM launcher and legacy replay use the original Micropod performance checkout and its local inputs. The SHA-256 manifest covers each bundled file except the manifest itself.
