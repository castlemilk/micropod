import signal
import sys
import time
import unittest

from qualify_docker_exec import attached, winsize


class AttachedExecTests(unittest.TestCase):
    def test_pipe_drains_both_outputs_before_eof(self):
        command = [sys.executable, "-c", """
import sys
sys.stdout.buffer.write(b'x' * 131072)
sys.stdout.buffer.flush()
sys.stderr.buffer.write(b'y' * 131072)
sys.stderr.buffer.flush()
sys.stdout.buffer.write(sys.stdin.buffer.read())
sys.exit(19)
"""]
        payload = bytes(range(256)) * 1025
        expected = b"x" * 131072 + payload
        with attached(command, limits=(len(expected), 131072)) as session:
            until = time.monotonic() + 5
            session.send(payload, until, eof=True)
            session.finish(until, 19, expected, b"y" * 131072)

    def test_pty_initial_size_live_size_and_normalized_output(self):
        command = [sys.executable, "-c", r"""
import os
import sys
assert os.isatty(0) and os.isatty(1) and not os.isatty(2)
size = os.get_terminal_size(0)
print(f'{size.lines} {size.columns}\r', flush=True)
assert sys.stdin.buffer.readline() == b'size\n'
size = os.get_terminal_size(1)
print(f'{size.lines} {size.columns}\r', flush=True)
sys.exit(7)
"""]
        with attached(command, size=(31, 97)) as session:
            until = time.monotonic() + 5
            session.expect_line(b"31 97", until)
            winsize(session.master, (42, 113))
            session.send(b"size\n", until)
            session.expect_line(b"42 113", until)
            session.finish(until, 7)
            self.assertEqual(session.stdout, b"31 97\r\n42 113\r\n")

    def test_output_cap_kills_and_reaps_child(self):
        command = [sys.executable, "-c", "import time; print('x' * 100, flush=True); time.sleep(60)"]
        with self.assertRaisesRegex(RuntimeError, "stdout exceeded 64 bytes"):
            with attached(command, limits=(64, 64)) as session:
                session.finish(time.monotonic() + 5, 0)
        self.assertEqual(session.process.returncode, -signal.SIGKILL)
        self.assertTrue(session.process.stdout.closed)

    def test_timeout_kills_and_reaps_child(self):
        command = [sys.executable, "-c", "import time; time.sleep(60)"]
        with self.assertRaisesRegex(RuntimeError, "Timed out waiting for stdout"):
            with attached(command) as session:
                session.expect_line(b"ready", time.monotonic() + 0.1)
        self.assertEqual(session.process.returncode, -signal.SIGKILL)
        self.assertTrue(session.process.stdin.closed)


if __name__ == "__main__":
    unittest.main()
