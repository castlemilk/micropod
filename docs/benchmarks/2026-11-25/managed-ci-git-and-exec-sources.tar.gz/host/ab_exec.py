"""Run complete stock-client exec qualifiers in alternating order against a single managed worker."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys
import time
p=argparse.ArgumentParser()
for opt in ("host","name","old","new"):
    p.add_argument("--"+opt,required=True)
p.add_argument("--pairs",type=int,required=True)
a=p.parse_args();s=Path(__file__).resolve().parent
out=s/(a.name+'-ab-cases');out.mkdir()
drivers={"original":Path(a.old),"prospective":Path(a.new)}
assert drivers["original"].read_bytes()!=drivers["prospective"].read_bytes()
result={"endpoint":a.host,"driver_sha256":{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in drivers.items()},
        "planned_pairs":a.pairs,"rounds":[]}
for i in range(a.pairs):
    order=list(drivers) if i%2==0 else list(reversed(drivers))
    for arm in order:
        started=time.monotonic_ns()
        r=subprocess.run([sys.executable,"-B",drivers[arm],"--host",a.host],capture_output=True,text=True,timeout=90)
        dest=out/(f"{i+1:02}-{arm}.log");dest.write_text(r.stdout+'\n'+r.stderr)
        reader=json.loads(r.stdout)
        assert not reader['cleanup']['remaining_container_ids'] and reader['cleanup']['container_name_removed']
        result["rounds"].append({"pair":i+1,"arm":arm,"elapsed_ms":(time.monotonic_ns()-started)/1e6,
             "rc":r.returncode,"passed":reader['passed'],"failures":reader['failures'],"checks":list(reader['checks']),
             "logs":str(dest.relative_to(s))})
        print(i+1,arm,r.returncode,file=sys.stderr,flush=True)
result["passed_by_arm"]={arm:sum(row["passed"] for row in result['rounds'] if row['arm']==arm) for arm in drivers}
print(json.dumps(result))
