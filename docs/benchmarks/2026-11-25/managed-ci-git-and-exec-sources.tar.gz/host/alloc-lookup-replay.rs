
#[cfg(test)]
mod lookup_replay {
    use super::*;
    use std::alloc::{GlobalAlloc, Layout, System};
    use std::cell::Cell;
    use std::hint::black_box;

    thread_local! {
        static ALLOCATIONS: Cell<Option<usize>> = const { Cell::new(None) };
    }

    struct Allocator;

    fn count_alloc() {
        let _ = ALLOCATIONS.try_with(|count| {
            if let Some(value) = count.get() {
                count.set(Some(value + 1));
            }
        });
    }

    unsafe impl GlobalAlloc for Allocator {
        unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
            count_alloc();
            unsafe { System.alloc(layout) }
        }
        unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
            count_alloc();
            unsafe { System.realloc(ptr, layout, new_size) }
        }
        unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
            unsafe { System.dealloc(ptr, layout) }
        }
    }

    #[global_allocator]
    static ALLOCATOR: Allocator = Allocator;

    fn lookup_request(parent: u64, name: &str) -> Vec<u8> {
        let mut req = vec![0u8; 40 + name.len() + 1];
        let len = req.len() as u32;
        req[0..4].copy_from_slice(&len.to_le_bytes());
        req[4..8].copy_from_slice(&FUSE_LOOKUP.to_le_bytes());
        req[8..16].copy_from_slice(&1u64.to_le_bytes());
        req[16..24].copy_from_slice(&parent.to_le_bytes());
        req[40..40 + name.len()].copy_from_slice(name.as_bytes());
        req
    }
    
    fn lookup_dir(core: &mut FsCore, parent: u64, name: &str) -> u64 {
        assert!(core.handle_fuse_into(&lookup_request(parent, name)));
        assert_eq!(core.resp_buf.len(), 144);
        u64::from_le_bytes(core.resp_buf[16..24].try_into().unwrap())
    }

    #[test]
    fn warm_lookup_replay() {
        let root = PathBuf::from(std::env::var_os("MP_LOOKUP_REPLAY_FIXTURE").unwrap());
        let fs = VirtioFs::new("replay", root, false, Arc::new(FsMetrics::default())).unwrap();
        let mut core = fs.shared.core.lock().unwrap();
        let mut ram = vec![0; 512 * 1024];
        let mem = unsafe { GuestMemory::new(ram.as_mut_ptr(), 0, ram.len()) };
        let response_at = (ram.len() - 256) as u64;
        let mut desc = Vec::with_capacity(1058);
        let mut parents = HashMap::new();
        for i in 0..1058 {
            let dirname = format!("package-{:04}", i / 6);
            let grandparent = format!("vendor-module-{:02}", i / 120);
            let parent = *parents.entry((grandparent.clone(), dirname.clone())).or_insert_with(|| {
                let grandparent = lookup_dir(&mut core, FUSE_ROOT_ID, &grandparent);
                lookup_dir(&mut core, grandparent, &dirname)
            });
            let name = format!("source-file-{i:04}-reference.go");
            let req = lookup_request(parent, &name);
            let at = (i * 256) as u64;
            mem.write_slice(at, 40).unwrap().copy_from_slice(&req[..40]);
            mem.write_slice(at + 128, req.len() - 40).unwrap().copy_from_slice(&req[40..]);
            desc.push([
                DescBuf { addr: at, len: 40, is_write: false },
                DescBuf { addr: at + 128, len: (req.len() - 40) as u32, is_write: false },
                DescBuf { addr: response_at, len: 144, is_write: true },
            ]);
        }
        let mut scratch = Vec::with_capacity(4096);
        let mut pass = || {
            for bufs in &desc {
                assert_eq!(black_box(core.handle_fuse_chain(black_box(bufs), &mem, &mut scratch)), 144);
            }
        };
        for _ in 0..10 { pass(); }
        ALLOCATIONS.with(|count| count.set(Some(0)));
        pass();
        let allocations = ALLOCATIONS.with(|count| count.replace(None).unwrap());
        let start = Instant::now();
        for _ in 0..50 { pass(); }
        println!("LOOKUP_REPLAY alloc_per_1058={allocations} mean_scan_ns={}", start.elapsed().as_nanos() / 50);
    }
}
