import argparse
import gzip
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('component', choices=['base', 'vmm', 'job'])
p.add_argument('name')
args = p.parse_args()
s = Path(__file__).resolve().parent
a = s / 'home/artifacts'
w = Path.cwd()
assert a.parent.is_mount() and args.name.isalnum()
def sha(path):
    with path.open('rb') as fp:
        return hashlib.file_digest(fp, 'sha256').hexdigest()
def manifest(path):
    return {str(f.relative_to(path)):sha(f) for f in sorted(path.rglob('*')) if f.is_file() and 'target' not in f.relative_to(path).parts}
def go(directory, output, pkg='.'):
    env = {**os.environ, 'CGO_ENABLED':'0', 'GOOS':'linux', 'GOARCH':'arm64'}
    env.pop('GOROOT',None)
    subprocess.run(['go','build','-trimpath','-ldflags=-s -w','-o',output,pkg],cwd=directory,env=env,check=True)
    return sha(output)
def save(name, record):
    (s / name).write_text(json.dumps(record,indent=2)+'\n')
if args.component == 'base':
    installed = json.load(gzip.open(w / 'docs/benchmarks/2026-11-21/gamma-vcpu-priority.json.gz','rt'))['installation']
    base = Path(installed['path']) / 'micropod-oci-tools'
    assert not any(f.is_symlink() for f in base.rglob('*')) and manifest(base) == installed['tools']
    bank = a/'tools'
    shutil.copytree(base,bank)
    for shell in ['start.sh','published-ports.sh']:
        shutil.copy2(w/'ci/runner'/shell,bank/'runner'/shell)
    job = go(a/'runner-cp4',bank/'runner/bin/job')
    previous = json.loads((w/'docs/benchmarks/2026-11-25/phase-b5-managed-checkout-and-archive.json').read_bytes())
    assert job == previous['native_archive_runner_sha256'], job
    shutil.copy2(w/'.build/local-kernel-pages/20261125-b5-16k/full-16k/Image',a/'Image')
    init = a/'guest'
    init.mkdir()
    go(a/'baseline-source/guest-init',init/'init')
    with (a/'initrd').open('xb') as out:
        subprocess.run(['cpio','-o','-H','newc','--quiet'],cwd=init,input=b'init\n',stdout=out,check=True)
    go(w/'scripts/workspacebench',a/'fsprobe','main.go')
    save('bank-base.json',{'installed':manifest(base),'original_runner':job,'private':manifest(bank),'kernel':sha(a/'Image'),'initrd':sha(a/'initrd'),'init':sha(init/'init')})
elif args.component == 'vmm':
    source = a / (args.name+'-source')
    if not source.exists():
        shutil.copytree(w.parent.parent/'vmm',source,ignore=shutil.ignore_patterns('target','.git','__pycache__'))
    frozen=manifest(source)
    rust=Path.home()/'.rustup/toolchains/1.99.1-aarch64-apple-darwin/bin'
    env={**os.environ,'RUSTC':str(rust/'rustc'),'RUSTDOC':str(rust/'rustdoc')}
    for command in [['test','--workspace','--lib'],['test','-p','micropod-vmm','--test','parent_pid'],['build','--release']]:
        subprocess.run([rust/'cargo',*command,'--offline','--locked'],cwd=source,env=env,check=True)
    binary = a / (args.name+'-vmm')
    shutil.copy2(source/'target/release/micropod-vmm',binary)
    subprocess.run(['codesign','--force','--sign','-','--entitlements',source/'entitlements.plist',binary],check=True)
    subprocess.run(['codesign','--verify','--strict',binary],check=True)
    assert manifest(source)==frozen
    save(args.name+'-vmm.json',{'source':frozen,'binary':sha(binary)})
else:
    source = a/(args.name+'-runner')
    shutil.copytree(w/'guest/runner',source,ignore=shutil.ignore_patterns('.git','__pycache__'))
    bank = a/('tools-'+args.name)
    shutil.copytree(a/'tools',bank)
    frozen=manifest(source)
    job=go(source,bank/'runner/bin/job')
    env={**os.environ, 'CGO_ENABLED':'0','GOOS':'linux','GOARCH':'arm64'}
    env.pop('GOROOT',None)
    subprocess.run(['go','test','-trimpath','-c','-o',a/(args.name+'-runner.test'),'.'],cwd=source,env=env,check=True)
    assert frozen==manifest(source)
    save(args.name+'-job.json',{'binary':job,'source':frozen,'tests':sha(a/(args.name+'-runner.test'))})
