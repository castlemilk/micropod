#!/usr/bin/env python3
"""Time the stock detached Docker exec fixture and observe any missing acknowledgment."""

import argparse
from contextlib import closing, nullcontext
import json
from pathlib import Path
import signal
import socket
import subprocess
import sys
from tempfile import TemporaryDirectory
from threading import Event, Thread, Timer
import time
from urllib.parse import urlencode

sys.path.insert(0, str(Path(__file__).resolve().parent / "home/artifacts/final-harness/scripts"))
import qualify_docker_exec as q

CLI_TIMEOUT = 5
SCRIPT = r"""
printf '%s\n%s\n' "$(pwd -P)" "$MP_EXEC_BACKGROUND" >"$1.tmp"
mv "$1.tmp" "$1"
for attempt in $(seq 1 100); do
    test ! -e "$1.release" || exit 39
    sleep 0.1
done
exit 91
"""


def ms(start):
    return round((time.monotonic_ns() - start) / 1e6, 3)


def api(host, method, path, body=None, *, timeout=1):
    started = time.monotonic_ns()
    reply = {}
    try:
        with closing(q.UnixHTTP(host.removeprefix("unix://"))) as conn:
            conn.timeout = timeout
            payload = None if body is None else json.dumps(body)
            headers = {} if body is None else {"Content-Type": "application/json"}
            conn.request(method, "/v1.44" + path, body=payload, headers=headers)
            with conn.getresponse() as response:
                reply.update(status=response.status, headers_ms=ms(started))
                data = response.read(32769)
                q.require(len(data) < 32769, "diagnostic response exceeded 32 KiB")
                if data:
                    try:
                        reply["body"] = json.loads(data)
                    except ValueError:
                        reply["body"] = data.decode(errors="replace")
    except Exception as err:
        reply["error"] = f"{type(err).__name__}: {err}"
    return {**reply, "total_ms": ms(started)}


def observe(host, cid, key, records, ready, stop, observer):
    filters = {"type": {"container": True}, "container": {cid: True}, "label": {f"{q.LABEL}={key}": True},
               "event": {name: True for name in ("exec_create", "exec_start", "exec_die")}}
    with closing(q.UnixHTTP(host.removeprefix("unix://"))) as conn:
        try:
            conn.timeout = 7
            conn.connect()
            observer["socket"] = conn.sock
            conn.request("GET", "/v1.44/events?" + urlencode({"filters": json.dumps(filters)}))
            with conn.getresponse() as response:
                observer["status"] = response.status
                ready.set()
                if response.status != 200:
                    return
                while not stop.is_set() and len(records) < 128:
                    line = response.readline(8193)
                    q.require(0 < len(line) <= 8192, "event stream EOF or oversized row")
                    event = json.loads(line)
                    actor = event["Actor"]
                    attrs = actor.get("Attributes", {})
                    records.append({"arrival_ns": time.monotonic_ns(), "host_unix_ns": time.time_ns(),
                                    "guest_unix_ns": event.get("timeNano"), "action": event["Action"],
                                    "exec_id": attrs.get("execID"), "exit": attrs.get("exitCode")})
        except Exception as err:
            if not stop.is_set():
                observer["error"] = f"{type(err).__name__}: {err}"
        finally:
            ready.set()


def events_for(records, marker, started):
    snapshot = tuple(records)
    exec_ids = {row["exec_id"] for row in snapshot if marker in row["action"] and row["exec_id"]}
    return [{**row, "since_spawn_ms": round((row["arrival_ns"] - started) / 1e6, 3)} for row in snapshot
            if row["exec_id"] in exec_ids]


def inspect_state(host, cid, marker, started, records):
    timeline = events_for(records, marker, started)
    exec_ids = list(dict.fromkeys(row["exec_id"] for row in timeline))
    state = {"since_spawn_ms": ms(started), "events": timeline}
    for exec_id in exec_ids:
        state.setdefault("exec_inspect", {})[exec_id] = api(host, "GET", f"/exec/{exec_id}/json")
    path = urlencode({"path": "/tmp/" + marker})
    state["process_marker"] = api(host, "HEAD", f"/containers/{cid}/archive?{path}")
    container = api(host, "GET", f"/containers/{cid}/json")
    if isinstance(container.get("body"), dict) and isinstance(container["body"].get("State"), dict):
        container["body"] = container["body"]["State"]
    state["container_inspect"] = container
    return state


def wait_for_exit(host, cid, marker, started, records):
    deadline = time.monotonic() + 2
    while time.monotonic() < deadline:
        timeline = events_for(records, marker, started)
        exits = [row for row in timeline if row["action"].partition(":")[0] == "exec_die"]
        if exits:
            return timeline, api(host, "GET", f"/exec/{exits[-1]['exec_id']}/json")
        time.sleep(0.035)
    return events_for(records, marker, started), None


def stock_attempt(fixture, cid, index, records, samples):
    host = fixture.cli[-1]
    marker = f"{fixture.key}-detached-{index:02}"
    started = time.monotonic_ns()
    replay = index % 2 == 0
    row = {"attempt": index, "marker": marker, "idle_replay_stream": replay}
    samples.append(row)

    def snapshot():
        row["near_deadline"] = inspect_state(host, cid, marker, started, records)

    filters = {"type": {"container": True}, "container": {cid: True}, "label": {f"{q.LABEL}={fixture.key}": True},
               "event": {"exec_create": True}}
    query = urlencode({"since": int(time.time()) - 60, "filters": json.dumps(filters)})
    replay_stream = q.engine_response(host, "GET", "/events?" + query) if replay else nullcontext()
    watchdog = Timer(4, snapshot)
    watchdog.daemon = True
    with replay_stream:
        row["replay_setup_ms"] = ms(started)
        started = time.monotonic_ns()
        watchdog.start()
        try:
            result = fixture.docker("exec", "--detach", "-w", "/tmp", "-e", "MP_EXEC_BACKGROUND=detached value",
                                    cid, "/bin/sh", "-ec", SCRIPT, "sh", marker, timeout=CLI_TIMEOUT, check=False)
        except subprocess.TimeoutExpired as err:
            row.update(timeout=True, cli_ms=ms(started), stdout=(err.stdout or b"").decode(errors="replace"),
                       stderr=(err.stderr or b"").decode(errors="replace"))
        else:
            row.update(timeout=False, cli_ms=ms(started), cli_exit=result.returncode,
                       stdout=result.stdout, stderr=result.stderr)
        finally:
            watchdog.cancel()
            watchdog.join(3.2)
            row["events"] = events_for(records, marker, started)
    if row["timeout"] or row.get("cli_exit") != 0:
        row["after_cli"] = inspect_state(host, cid, marker, started, records)
        return False

    # Keep the detached shell alive briefly and release it through a separate
    # stock exec, as in the qualifier.
    marker_path = "/tmp/" + marker
    release = fixture.docker("exec", cid, "/bin/sh", "-ec",
                             'for n in $(seq 1 40); do test ! -f "$1" || break; sleep 0.05; done; '
                             'test "$(cat "$1")" = "$(printf "/tmp\\ndetached value")"; touch "$1.release"',
                             "sh", marker_path, timeout=CLI_TIMEOUT, check=False)
    row["release"] = {"exit_code": release.returncode, "ms": ms(started), "stderr": release.stderr}
    row["events"], row["finished"] = wait_for_exit(host, cid, marker, started, records)
    final = row["finished"] or {}
    info = final.get("body") or {}
    row["passed"] = (release.returncode == 0 and not row["stdout"] and not row["stderr"]
                     and info.get("Running") is False and info.get("ExitCode") == 39)
    if not row["passed"]:
        row["after_cli"] = inspect_state(host, cid, marker, started, records)
    return row["passed"]


def raw_control(host, cid):
    create = api(host, "POST", f"/containers/{cid}/exec", {"Cmd": ["/bin/true"], "WorkingDir": "/tmp",
                 "Env": ["MP_EXEC_BACKGROUND=detached value"]}, timeout=CLI_TIMEOUT)
    result = {"create": create}
    if create.get("status") == 201:
        exec_id = create["body"]["Id"]
        result["start"] = api(host, "POST", f"/exec/{exec_id}/start", {"Detach": True, "Tty": False}, timeout=CLI_TIMEOUT)
        result["inspect"] = api(host, "GET", f"/exec/{exec_id}/json")
    return result


def run(fixture, report, attempts):
    host = fixture.cli[-1]
    cid = fixture.docker("run", "--detach", "--rm", "--pull=never", "--network", "none", "--name", fixture.key,
                         "--label", f"{q.LABEL}={fixture.key}", "--workdir", "/usr", "--user", "65534:65534",
                         "--entrypoint", "/bin/sleep", fixture.image, "120", timeout=20).stdout.strip()
    q.require(fixture.inspect(fixture.key)["Id"] == cid, "fixture identity changed")
    report["container_id"] = cid
    records, observer = [], {}
    ready, stop = Event(), Event()
    worker = Thread(target=observe, args=(host, cid, fixture.key, records, ready, stop, observer), daemon=True)
    worker.start()
    try:
        q.require(ready.wait(8) and observer.get("status") == 200, "cannot subscribe to exec events")
        for index in range(1, attempts + 1):
            if not stock_attempt(fixture, cid, index, records, report["attempts"]):
                break
        report["raw_control"] = raw_control(host, cid)
    finally:
        stop.set()
        sock = observer.pop("socket", None)
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
        worker.join(1)
        report["event_observer"] = observer


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True)
    parser.add_argument("--image", default="alpine:3.23")
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--attempts", default=8, type=int, choices=range(1, 9))
    args = parser.parse_args()
    if not args.host.startswith("unix:///") or not Path(args.host[7:]).is_socket():
        parser.error("--host must be an explicit Unix socket")
    args.context = None
    signal.signal(signal.SIGTERM, q.interrupted)
    report = {"schema": 1, "target": args.host, "cli_timeout_s": CLI_TIMEOUT, "attempts": []}
    with TemporaryDirectory(prefix="micropod-detached-probe-") as work:
        fixture = q.Qualification(Path(work), args, prefix="mp-detach-probe-")
        fixture.env.update(DOCKER_CONFIG=work, DOCKER_CLI_HINTS="false")
        report["cli_otel_configured"] = bool(fixture.env.get("DOCKER_CLI_OTEL_EXPORTER_OTLP_ENDPOINT"))
        for key in ("DOCKER_TLS", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH", "DOCKER_DEFAULT_PLATFORM", "DOCKER_CUSTOM_HEADERS"):
            fixture.env.pop(key, None)
        try:
            run(fixture, report, args.attempts)
        except (Exception, KeyboardInterrupt) as err:
            report["error"] = f"{type(err).__name__}: {err}"
        finally:
            try:
                report["cleanup"] = fixture.cleanup(diagnose=False)
            except Exception as err:
                report["cleanup_error"] = f"{type(err).__name__}: {err}"
    report["passed"] = ("error" not in report and "cleanup_error" not in report
                        and len(report["attempts"]) == args.attempts
                        and all(attempt.get("passed") for attempt in report["attempts"]))
    with args.out.open("x") as destination:
        json.dump(report, destination, indent=2)
        destination.write("\n")
    print(json.dumps({"passed": report["passed"], "attempts": len(report["attempts"]), "out": str(args.out)}))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
