"""Write and byte-verify the frozen source or raw evidence artifact for the Gamma study."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile

stage = Path(__file__).resolve().parent
assets = stage / "home/artifacts"
work = Path("/Users/benebsworth/projects/micropod/bench/phase0-host-scheduling")
reports = work / "docs/benchmarks/2026-11-25"
args = argparse.ArgumentParser()
args.add_argument("kind", choices=("sources", "receipts"))
kind = args.parse_args().kind
output = reports / ("managed-ci-git-and-exec-" + kind + ".tar.gz")
members = {}

def collect(path, name):
    if not path.exists():
        raise FileNotFoundError(path)
    if path.is_dir():
        for file in sorted(path.iterdir()):
            if file.name not in (".git", "target", "__pycache__", ".DS_Store", ".build"):
                collect(file, name + "/" + file.name)
        return
    assert path.is_file() and not path.is_symlink() and name not in members, path
    members[name] = path

if kind == "sources":
    assert assets.parent.is_mount()
    for root, key in (("metadata-source", "metadata-vmm"), ("baseline-source", "baseline-vmm"),
                      ("integrated-source", "integrated-vmm"), ("final-runner", "final-job"),
                      ("managed-swift-source", "swift-final")):
        record = json.loads((stage / (key + ".json")).read_text())
        expected = record.get("source", record.get("sources"))
        for name, checksum in expected.items():
            path = assets / root / name
            assert hashlib.sha256(path.read_bytes()).hexdigest() == checksum, path
            collect(path, root + "/" + name)
    for name in ("final-harness", "paired-harness", "trace-proof", "runner-vendored", "runner-cp4", "exec-prospective-harness"):
        collect(assets/name, name)
    helper = "docs/benchmarks/2026-11-24/gamma-ci-concurrency/worker_apfs_drive.py"
    collect(work/helper, "final-harness/"+helper)
    collect(work/"scripts/workspacebench", "final-harness/scripts/workspacebench")
    for name in ("test_bench_workspace_runner.py","test_bench_snapshot_fork.py","test_bench_workspace_edits.py"):
        collect(work/"scripts"/name, "final-harness/scripts/"+name)
    for bank in ("tools","tools-trace","tools-final","tools-final-audit"):
        for name in ("start.sh","published-ports.sh","exec-observer.sh","trace-observer.sh"):
            p=assets/bank/"runner"/name
            if p.exists(): collect(p, bank+"/runner/"+name)
    for name in ("alloc-lookup-replay.rs","alloc-virtiofs-candidate.patch","gen-probe.c","fixture-observability.yaml","exec-observer.sh"):
        collect(stage/name, "host/"+name)
    for file in sorted(stage.glob("*.py")):
        collect(file, "host/"+file.name)
    if (assets/"updated-harness").exists():
        collect(assets/"updated-harness","updated-harness")
    if (assets/"restore-guard-source").exists():
        collect(assets/"restore-guard-source","restore-guard-source")
    for name in ("outer-machine-source", "outer-detached-source", "vz-diagnostic-source"):
        if (assets/name).is_dir(): collect(assets/name,name)
    outer=json.loads((assets/"outer-machine-source/manifest.json").read_bytes())
    for relative,checksum in outer["files"].items():
        assert hashlib.sha256((assets/"outer-machine-source"/relative).read_bytes()).hexdigest()==checksum, relative
    patch=json.loads((assets/"outer-detached-source/source.json").read_bytes())
    assert hashlib.sha256((assets/"outer-detached-source/outer-detached.patch").read_bytes()).hexdigest()==patch["patch_sha256"]
    for relative,row in patch["files"].items():
        assert hashlib.sha256((assets/"outer-detached-source"/relative).read_bytes()).hexdigest()==row["snapshot_sha256"], relative
    trace=json.loads((stage/"vz-trace.json").read_bytes())
    for relative,checksum in trace["sources"].items():
        assert hashlib.sha256((assets/"vz-diagnostic-source"/relative).read_bytes()).hexdigest()==checksum, relative
    assert hashlib.sha256((assets/"exec-prospective-harness/qualify_docker_exec.py").read_bytes()).hexdigest()==json.loads((stage/"qualifier-vz-audit.json").read_bytes())["abnative"]["driver_sha256"]["prospective"]
    for file in sorted(stage.glob("outer*.sh")):
        collect(file,"host/"+file.name)
else:
    for file in sorted(stage.iterdir()):
        if file.is_file() and file.suffix in (".log",".stderr",".json",".jsonl"):
            if file.name not in ("sources-package.json","receipts-package.json"):
                collect(file,"raw/"+file.name)
        elif file.is_dir() and (file.name.startswith(("managed-fork-","managed-regression-")) and file.name.endswith("-logs") or file.name.startswith("repeat-") and file.name.endswith("-repeat-cases") or file.name.startswith("qualifier-") and file.name.endswith("-ab-cases")):
            collect(file,"raw/"+file.name)
checks = {}
pending = output.with_suffix(".pending")
with tarfile.open(pending, "w:gz", compresslevel=6, format=tarfile.PAX_FORMAT) as archive:
    for name, file in sorted(members.items()):
        data = file.read_bytes()
        checks[name] = hashlib.sha256(data).hexdigest()
        member = tarfile.TarInfo(name)
        member.mode = stat.S_IMODE(file.stat().st_mode) & 0o755
        member.size = len(data)
        archive.addfile(member, io.BytesIO(data))
    data = (json.dumps(checks, indent=2, sort_keys=True) + "\n").encode()
    member = tarfile.TarInfo("MANIFEST.sha256.json"); member.mode=0o644; member.size=len(data)
    archive.addfile(member,io.BytesIO(data))
with tarfile.open(pending,"r:gz") as archive:
    observed={}
    for member in archive:
        assert member.isfile() and member.name not in observed
        data=archive.extractfile(member).read()
        if member.name=="MANIFEST.sha256.json": assert json.loads(data)==checks
        else: observed[member.name]=hashlib.sha256(data).hexdigest()
    assert observed==checks
pending.replace(output)
with output.open("rb") as file: digest=hashlib.file_digest(file,"sha256").hexdigest()
result={"path":output.name,"manifest_entries":len(checks),"bytes":output.stat().st_size,"sha256":digest}
(stage/(kind+"-package.json")).write_text(json.dumps(result,indent=2)+"\n")
print(result)
