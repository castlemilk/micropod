#!/bin/sh
set -eu
root=${MICROPOD_ENGINE_WORKSPACE:?}
ctr=/opt/micropod-oci/runner/bin/ctr
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
for phase in before after; do
    marker=$root/.exec-$phase
    for _ in $(seq 1 2000); do
        [ ! -f "$marker.request" ] || break
        sleep .25
    done
    [ -f "$marker.request" ] || exit 0
    token=$(cat "$marker.request")
    if [ "$phase" = before ]; then
        set +e
        /opt/micropod-oci/runner/bin/exec-regressions -test.v -test.timeout 60s -test.run '^TestDocker(NativeExec|Exec|Archive)' > "$marker.tests" 2>&1
        test_rc=$?
        set -e
        printf '%s\n' "$test_rc" > "$marker.rc"
    fi
    for attempt in $(seq 1 60); do
        "$ctr" --timeout 5s --namespace k8s.io tasks list -q > "$scratch/task-list"
        sort "$scratch/task-list" > "$scratch/tasks"
        test -d /run/micropod-oci/exec
        find /run/micropod-oci/exec -mindepth 1 -print > "$scratch/pipes"
        [ "$phase" = after ] || break
        if cmp -s "$scratch/initial" "$scratch/tasks" && [ ! -s "$scratch/pipes" ]; then break; fi
        sleep .25
    done
    cp "$scratch/tasks" "$marker.tasks"
    cp "$scratch/pipes" "$marker.pipes"
    if [ "$phase" = before ]; then cp "$scratch/tasks" "$scratch/initial"; fi
    printf '%s %s\n' "$token" "$attempt" > "$marker.tmp"
    mv "$marker.tmp" "$marker.done"
done
