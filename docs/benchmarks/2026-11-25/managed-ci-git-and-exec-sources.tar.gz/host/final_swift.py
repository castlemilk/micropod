from pathlib import Path
import hashlib,os,shutil,subprocess,json
s=Path(__file__).resolve().parent;w=Path.cwd();a=s/'home/artifacts';src=a/'managed-swift-source';assert a.parent.is_mount()
paths=['Package.swift','Package.resolved','Sources','Tests','sdk/swift/Sources','signing']
def sha(f):
 with f.open('rb') as fp:return hashlib.file_digest(fp,'sha256').hexdigest()
def files(d):
 out={}
 for part in paths:
  p=d/part
  for fid in p.rglob('*') if p.is_dir() else [p]:
   if fid.is_file():out[str(fid.relative_to(d))]=sha(fid)
 return out
pre=files(w);src.mkdir()
for part in paths:
 p=w/part;q=src/part;q.parent.mkdir(exist_ok=True,parents=True)
 if p.is_dir():shutil.copytree(p,q)
 else:shutil.copy2(p,q)
assert files(src)==pre
subprocess.run(['swift','build','--product','micropod','--jobs','4'],cwd=w,check=True);built=subprocess.check_output(['swift','build','--show-bin-path'],cwd=w,text=True).strip();cli=a/'hardened-cli';shutil.copy2(Path(built)/'micropod',cli);subprocess.run(['codesign','--sign','-','--force','--entitlements',src/'signing/micropod-cli.entitlements',cli],check=True);subprocess.run(['codesign','--verify','--strict',cli],check=True);assert files(w)==pre,'Swift source moved while building';(s/'swift-final.json').write_text(json.dumps({'sha256':sha(cli),'sources':pre,'linked_product':str(Path(built)/'micropod')},indent=2)+'\n');print(sha(cli),flush=True)
