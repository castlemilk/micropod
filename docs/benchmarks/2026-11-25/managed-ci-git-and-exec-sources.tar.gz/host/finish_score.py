"""Verify retired worker volumes, add guarded regressions and close the archived scorecard."""
from pathlib import Path
import json
import hashlib
import plistlib
import subprocess
import sys
from score import results,read,s,w,dst,write_report

def store(name,obj):
    (s/(name+".json")).write_text(json.dumps(obj,indent=2)+"\n")
def audit(name,created,live,detached):
    verify=detached["persisted_policy"]
    for x in (created,verify) if live is None else (created,live,verify):
        assert x["volume"]["uuid"]==created["volume"]["uuid"]
        assert x["fsevents"]["journal"]==[] and x["fsevents"]["journal_bytes"]==0
        assert x["spotlight"]["disabled"] and x["markers"]["no_log"]["name"]=="no_log"
        assert x["markers"]["metadata_never_index"]["name"]==".metadata_never_index"
    assert verify["mounted_read_only"] and verify["journal_unchanged"] and verify["markers_unchanged"]
    assert detached["image_absent"] and detached["mount_restored"] and not Path(created["image"]).exists()
    if "raw_disk_before_detach" in verify and verify["raw_disk_before_detach"] is not None:
        assert verify["raw_disk_unchanged"]
    return {"name":name,"uuid":created["volume"]["uuid"],"image":created["image"],"spotlight_disabled":True,
            "no_log_marker":True,"verified_at_worker_readiness":live is not None,"journal_files":0,"verified_on_read_only_remount":True,"image_removed":True}
rows=[]
for name in ("base-host","metadata-first","tty-first","metadata-quiet","baseline-quiet","metadata-repeat",
             "baseline-repeat","managed-final","vz-final","installed-ci","old-exec","direct-forks","installed-dense",
             "installed-dense-final","guarded-hvf","guarded-vz","guarded-vz-final","repeat-vz","repeat-hvf",
             "targeted-hvf","detach-vz","detach-hvf","qualifier-vz","qualifier-hvf",
             "qualifier-vz-final","qualifier-hvf-final","qualifier-vz-pinned","qualifier-vz-audit","qualifier-hvf-audit","vz-trace"):
    d=read(name)
    for k in ("drive","vz_drive"):
        if k in d:
            v=d[k];row=audit(name if k=="drive" else name+"-vz",v["created"],v.get("live"),v["detached"])
            if "recovery" in v: row["verified_after_holder_query_timeout_s"]=v["recovery"]["lsof_seconds"]
            else:
                if name=="qualifier-vz-final":
                    assert not v.get("live") and set(d["errors"])=={"worker"}
                    assert 'is not supported' in d["errors"]["worker"]
                    shutdown=v["shutdown"]
                    assert shutdown["process_exit_code"]==-9 and shutdown["process_group_absent"] and shutdown["disk_holders"]==[]
                    results["vz_default_kernel_macvlan"]={"standalone_resource_discovery":True,"reached_docker_readiness":False,
                        "cause":"Default VZ kernel rejected nft netdev filter egress while configuring macvlan",
                        "shutdown":shutdown}
                else:
                    assert not v.get("shutdown") or v["shutdown"]["process_exit_code"]==0
                if v.get("shutdown"):row["shutdown_code"]=v["shutdown"]["process_exit_code"]
            rows.append(row)
guard=read("restore-guard-build");results["restore_guard"]={k:guard[k] for k in ("binary_sha256","changed_sources")}
for name in ("guarded-hvf","guarded-vz","guarded-vz-final"):
    d=read(name);assert d["cli_sha256"]==guard["binary_sha256"]
    assert len(d["copy"]["checks"])==13 and d["restart"]["passed"] and not d["copy"]["failures"]
    expected={"guarded-hvf":set(),"guarded-vz":{"telemetry"},"guarded-vz-final":{"exec","events"}}[name]
    assert set(d["errors"])==expected
    results["restore_guard"][name]={"exec_checks_passed":len(d["exec"]["checks"]),"archive_checks":len(d["copy"]["checks"]),
        "restart":True,"events":"events" not in d["errors"],"health":"telemetry" not in d["errors"],
        "standalone":d["standalone_resource_discovery"],"shutdown_code":d["drive"]["shutdown"]["process_exit_code"],
        "failed_groups":list(d["errors"]),"failed_exec_cases":d["exec"]["failures"]}
for name in ("repeat-hvf","repeat-vz"):
    d=read(name);t=d["repeatnative"]
    assert t["clock_witness_removed"] and all(not d[x][y] for x in ("io-before","io-after") for y in ("tasks","pipes"))
    results["restore_guard"][name]={k:t[k] for k in ("rounds","exec_passes","event_passes","cases","host_clock_observations","guest_clock_observations")}
    results["restore_guard"][name]["detached_probe"]=d.get("detachedprobe")
    results["restore_guard"][name]["errors"]=d["errors"]
for name in ("detach-hvf","detach-vz"):
    d=read(name);t=d["detachedprobe"]
    results["restore_guard"][name]={"errors":d["errors"],"passed":t["passed"],"samples":[{k:q.get(k) for k in ("attempt","idle_replay_stream","cli_ms","timeout","passed")} for q in t["attempts"]],"raw_controls":t["raw_controls"]}
    assert not d["errors"] and len(t["attempts"])==8 and t["passed"] and d["events"]["released_before_deadline"]
for name in ("reference-prospective","reference-prospective-final"):
    d=read(name)
    assert d["passed"] and len(d["checks"])==5 and d["cleanup"]["container_name_removed"] and not d["cleanup"]["remaining_container_ids"]
    results["restore_guard"][name]={"passed":d["passed"],"checks":list(d["checks"]),"cleanup":d["cleanup"]}
for name in ("qualifier-vz","qualifier-hvf","qualifier-hvf-final","qualifier-vz-pinned","qualifier-vz-audit","qualifier-hvf-audit"):
    d=read(name);results["restore_guard"][name]=d["abnative"]
    assert d["events"]["released_before_deadline"]
    if name in ("qualifier-hvf-final","qualifier-vz-pinned"):
        assert set(d["errors"])=={"io-before","io-after"}
        results["restore_guard"][name]["observer"]="Uninstrumented guest bundle. Observer files absent. Each stock fixture verified container deletion."
    else:
        assert not d["errors"] and all(not d[q][z] for q in ("io-before","io-after") for z in ("tasks","pipes"))
    t=d["abnative"]
    assert len(t["rounds"]) == 2*t["planned_pairs"]
    assert t["driver_sha256"]["prospective"]==("791edca7415cab2d837fbd882bd3624f9a9b76e6ec6fb87dec3d362e23abf05c" if name not in ("qualifier-vz","qualifier-hvf") else "59b5524d8825acdd4d39fe9ec8d3200ec09a787e2fae12f78112b8a5898e63c4")
    for arm, count in t["passed_by_arm"].items():
        assert count == sum(r["passed"] for r in t["rounds"] if r["arm"]==arm)
partial=read("targeted-vz")
assert not partial["drive"] and set(partial["errors"])=={"worker"}
assert not Path("/private/tmp/mp-tune-ws-2bxvvxd2").exists()
results["rolled_back_before_worker_creation"]={"name":"targeted-vz","reason":partial["errors"]["worker"],"directory_absent":True}
d=read("managed-fork-v4")
assert d["workload_completed"] and d["private_scope_removed"] and d["all_worker_and_job_exits_zero"]
assert d["same_name_rootfs_and_named_volume_isolation"] and d["host_workspace_isolation"] and d["distinct_vmm_pids_and_raw_disk_inodes"]
assert not d["compatibility_qualification_passed"] and not d["per_job_identity_ready"] and not d["per_job_workspace_api_ready"]
results["managed_snapshot_original"]={k:d[k] for k in ("identity_collisions","parallel_restore","same_name_rootfs_and_named_volume_isolation","host_workspace_isolation","per_job_identity_ready","per_job_workspace_api_ready","all_worker_and_job_exits_zero","distinct_vmm_pids_and_raw_disk_inodes","private_scope_removed")}
results["managed_snapshot_original"]["forks"]=[{"role":v["role"],"docker_ping_ms":v["docker_ping_ms"],"session_ms":v["managed_session_ready_ms"],"accepts_configured_workspace":v["workspace_probe"]["accepted_configured_path"],"physical_private_workspace_seen":v["workspace_probe"]["physical_private_workspace_observed"],"vmm_exit":v["retirement"]["vmm_exit_event"]["exit_code"],"supervisor_exit":v["retirement"]["supervisor_exit"]} for v in d["workers"]]
r=read("managed-fork-corrected")
assert r["passed"] and r["verified_regression"] and r["private_scope_removed"] and r["successful_worker_and_job_exits_zero"]
assert r["preflight"]["artifacts"]["micropod"]["sha256"]==guard["binary_sha256"]
results["restore_guard"]["hardware_regression"]={key:r[key] for key in ("verified_regression","source_markers_after_rejections","successful_worker_and_job_exits_zero","private_scope_removed")}
assert r["stopped_source_disk_before_restore"] == r["stopped_source_disk_after_restore_writes"]
results["restore_guard"]["hardware_regression"]["source_disk_digest_unchanged"] = True
results["restore_guard"]["hardware_regression"]["restored_session_ready_ms"] = next(v["managed_session_ready_ms"] for v in r["workers"] if v["role"]=="1")
results["restore_guard"]["rejections"]={v["role"]:v["rejection"] for v in r["workers"] if "rejection" in v}
results["restore_guard"]["swift_test_count"]=26
if (s/"outer-machine-final.json").is_file():
    machine=read("outer-machine-final")
    assert machine["passed"] and machine["clean_shutdown"] and machine["scope_removed"]
    assert machine["supervisor_lock_released"] and machine["socket_removed"] and not machine["scoped_processes_after_stop"]
    assert machine["defaults_unchanged"] and machine["base_input_unchanged"] and machine["outside_processes_unchanged"]
    original=machine["checks"]
    docker_check=json.loads(original["stock Docker exec qualification"]["stdout"])
    assert docker_check["passed"] and len(docker_check["checks"])==5 and machine["stock_docker_archive_roundtrip"]
    assert original["native CLI detached exec boundary"]["exit"]==1
    assert original["native CLI exec exit status boundary"]["exit"]==1 and "exit 23" in original["native CLI exec exit status boundary"]["stderr"]
    ops={k:original[k] for k in ("native CLI noninteractive run","native CLI noninteractive exec","native CLI container logs",
                                "native CLI detached exec boundary","native CLI exec exit status boundary",
                                "native CLI interactive exec boundary","native CLI copy boundary","native CLI export boundary")}
    results["outer_hvf_machine"]={"source":machine["root_head_before"],"provenance":machine["provenance"],
        "original_cli_operations":ops,"stock_docker_exec_checks":list(docker_check["checks"]),
        "stock_docker_copy_roundtrip":machine["stock_docker_archive_roundtrip"],
        "retirement":{k:machine[k] for k in ("clean_shutdown","scope_removed","defaults_unchanged","base_input_unchanged","socket_removed","supervisor_lock_released","outside_processes_unchanged")}}
    for name in ("outer-adapter-stock","outer-adapter-final"):
        d=read(name)
        assert d["passed"] and d["owned_container_removed"] and d["attached_guest_status_and_utf8_streams"]
        assert d["rejected_start"]["cli_exit"]!=0 and d["immediate_exit"]["guest_exit"]==71
        assert d["detached_release_gate"]["exit_code"]==39
        results["outer_hvf_machine"][name]={k:d[k] for k in ("client_sha256","attached_guest_status_and_utf8_streams","detached_release_gate","immediate_exit","rejected_start","owned_container_removed")}
build=read("outer-detached-build");test=read("outer-detached-tests")
assert test["source_patch_sha256"]==build["source_patch_sha256"] and build["base"]==results["outer_hvf_machine"]["source"]
assert results["outer_hvf_machine"]["outer-adapter-final"]["client_sha256"]==build["sha256"]["micropod"]
assert build["returncode"]==test["returncode"]==test["failures"]==0 and test["selected_tests"]==72
results["outer_hvf_machine"]["corrected_build"]={k:build[k] for k in ("base","sha256","source_patch_sha256","strict_codesign","source_manifest_sha256")}
retained=read("outer-retained-cli")
assert retained["sha256"]==build["sha256"] and retained["strict_codesign"] and retained["machine_help"]
with Path(retained["binary"]).open("rb") as f:
    assert hashlib.file_digest(f,"sha256").hexdigest()==build["sha256"]["micropod"]
results["outer_hvf_machine"]["retained_cli"]={"path":retained["binary"],"sha256":build["sha256"]["micropod"],"strict_codesign":True}
results["outer_hvf_machine"]["swift_tests"]={k:test[k] for k in ("selected_tests","failures","docker_exec_cases")}
t=read("vz-trace")
assert not t["errors"] and t["worker_scope_absent"] and t["private_scratch_absent"] and t["guest_observer_finished"]["ctr_alive"]
assert len(t["rounds"])==8 and t["group_checks"]["remaining_containers"]==[]
assert all(not t["group_checks"][key][field] for key in ("before","after") for field in ("tasks","pipes"))
misses=[x for x in t["rounds"] if x["detached_cli"]["cli_timeout"]]
assert len(misses)==1
miss=misses[0]
before=miss["detached_cli"]["guest_before_cleanup"];after=miss["guest_after_cleanup"];ident=miss["mapped_exec_id"]
assert ident==before["exec_id"]==after["exec_id"]
seen=before["guest_inspect"]; assert seen["status"]==200
view=seen["body"]
if isinstance(view,str): view=json.loads(view)
assert not view["Running"] and view["Pid"]==0 and view["ID"]==ident and not before.get("task_events_for_exec")
events=[{"action":e["Action"].partition(":")[0],"possible_ms_since_cli_start":e["possible_ms_since_cli_start"]} for e in after["docker_events_for_exec"]]
assert [e["action"] for e in events]==["exec_create","exec_start"]
assert events[-1]["possible_ms_since_cli_start"][0]>miss["detached_cli"]["cli_elapsed_ms"]
results["vz_detached_trace"]={"recorded":t["recorded_group"],"passed":t["passed_by_arm"],"id":ident,
    "cli_deadline_s":miss["detached_cli"]["cli_limit_s"],"cli_elapsed_ms":miss["detached_cli"]["cli_elapsed_ms"],
    "guest_inspect_immediately_after_deadline":{"Running":view["Running"],"Pid":view["Pid"]},
    "containerd_events_by_deadline":before.get("task_events_for_exec") or [],"correlated_engine_events":events,
    "unresolved":"Delay between guest exec-create and native start. Its cause within the guest handler or transport remains unknown.",
    "group_checks_clean":True,"owned_worker_retired":True}
results["protected_volumes"]=rows
if sys.argv[1:] == ["preflight"]:
    store("worker-volume-audit",rows)
    assert not list((s/'home').glob("mf-*")) and not list((s/'home').glob("mr-*"))
    print("Worker volumes retired",len(rows))
    sys.exit(0)
rows.append(audit("fixture",read("fixture-created"),read("fixture-final-live"),read("fixture-detached")))
assert len(set(row["uuid"] for row in rows))==len(rows)
info=plistlib.loads(subprocess.check_output(["/usr/bin/hdiutil","info","-plist"]))
attached={v.get("image-path","") for v in info["images"]}
assert all(row["image"] not in attached for row in rows)
assert not (s/'home').is_mount() and not any((s/'home').iterdir())
assert all(not Path(row["image"]).exists() for row in rows)
assert not Path(read("alloc-paired-host-timing")["fixture_root"]).parent.exists()
pres=read("preservation");assert pres["original_sha256"]==pres["preserved_sha256"] and len(pres["original_sha256"])==24
def digest(path):
    with path.open("rb") as f: return hashlib.file_digest(f,"sha256").hexdigest()
manifest_path=w/pres["manifest"]
baseline_manifest=json.loads(manifest_path.read_bytes())
assert baseline_manifest["sha256"]==pres["original_sha256"]
for name,expected in baseline_manifest["sha256"].items():
    assert digest(Path(baseline_manifest["source"])/name)==expected
    assert digest(manifest_path.parent/name)==expected
qualified=pres["qualified"]
qualified_path=Path(qualified["path"])
assert digest(qualified_path/"micropod")==qualified["host_sha256"]
assert digest(qualified_path/"micropod-oci")==qualified["oci_sha256"]
assert {str(f.relative_to(qualified_path/"micropod-oci-tools")):digest(f) for f in (qualified_path/"micropod-oci-tools").rglob("*") if f.is_file()}==qualified["tools_sha256"]
clean={"protected_volume_count":len(rows),"protected_volumes":rows,"staging_mount_restored_empty":True,
       "all_backing_images_absent":True,"no_owned_disk_images_attached":True,
       "original_baseline_files":len(pres["original_sha256"]),"verified_copies":len(pres["preserved_sha256"]),
       "qualified_host_binaries":2,"qualified_tool_files":len(pres["qualified"]["tools_sha256"]),
       "orbstack_image_removed":read("orbstack-cleanup")["ref"],"private_host_replay_directory_absent":True}
store("final-cleanup",clean)
results["preservation_and_cleanup"]={k:v for k,v in clean.items() if k!="protected_volumes"}
results["evidence"]={"sources":read("sources-package")}
if (s/"receipts-package.json").exists():results["evidence"]["raw"]=read("receipts-package")
write_report()
print("Verified protected volumes",len(rows))
