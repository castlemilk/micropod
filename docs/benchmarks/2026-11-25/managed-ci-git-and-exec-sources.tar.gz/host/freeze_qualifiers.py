from pathlib import Path
import hashlib,json,shutil
s=Path(__file__).resolve().parent;w=Path('/Users/benebsworth/projects/micropod/bench/phase0-host-scheduling')
a=s/'home/artifacts';dst=a/'updated-harness/scripts';dst.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=("qualify_docker_exec.py","qualify_docker_events.py","qualify_docker_restart.py","qualify_engine_api.py","ci_benchmark_store.py",
       "test_qualify_docker_exec.py","test_qualify_docker_events.py")
for n in files:
    shutil.copy2(w/'scripts'/n,dst/n)
check={n:sha(dst/n) for n in files};assert check=={n:sha(w/'scripts'/n) for n in files}
(s/'updated-harness.json').write_text(json.dumps(check,indent=2)+'\n');print(check["qualify_docker_exec.py"])
