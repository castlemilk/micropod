from itertools import combinations
import json
from pathlib import Path

stage = Path(__file__).resolve().parent
rows = [json.loads(line) for line in (stage / "gen-probe.jsonl").read_text().splitlines()]
data = {row["step"]: row for row in rows if "step" in row}
observations = [row for row in rows if row["kind"] == "observation"]
volume, = [row for row in rows if row["kind"] == "volume"]
cleanup = json.loads((stage / "gen-cleanup.json").read_text())
assert volume["volume_cap_gen_count"] and volume["volume_cap_gen_count_valid"]
assert all(row["uniform"] and row["expected_byte"] == row["read_byte"] for row in observations)
assert all(row["gen_open_supported"] and row["gen_release_supported"] for row in observations)
assert all(row["gen_open"] == row["gen_release"] for row in observations)
assert volume["peer_pid"] != volume["writer_pid"]
assert cleanup["exit_code"] == 0 and cleanup["private_scratch_removed"]
assert not cleanup["leftovers_before_runner_cleanup"]

fingerprint = ("dev", "ino", "size", "mtime", "ctime", "birthtime")
def equal(a, b, fields):
    return all(a[field] == b[field] for field in fields)

pairs = [(a, b) for a, b in combinations(observations, 2)
         if equal(a, b, fingerprint) and a["hash_fnv64"] != b["hash_fnv64"]]
nonzero_collisions = [(a["step"], b["step"]) for a, b in pairs
                      if a["gen_open"] != 0 and a["gen_open"] == b["gen_open"]]
zero_collisions = [(a["step"], b["step"]) for a, b in pairs
                   if a["gen_open"] == 0 and b["gen_open"] == 0]
assert not nonzero_collisions
assert zero_collisions

before, valid_at_open, first_read = [data[name] for name in (
    "after-open-prior-cache-fill",
    "after-open-reopened-with-no-read",
    "after-open-first-read-after-peer-mapped-write",
)]
assert before["gen_release"] == valid_at_open["gen_open"] > 0
assert equal(before, valid_at_open, fingerprint)
assert equal(valid_at_open, first_read, fingerprint)
assert first_read["gen_open"] == 0 and first_read["gen_release"] == 0
assert before["hash_fnv64"] != first_read["hash_fnv64"]

pwrite = [data[name] for name in (
    "write-fd-held-before", "write-fd-held-restored-mtime", "write-fd-held-restored-mtime-again",
)]
assert all(equal(row, pwrite[0], ("dev", "ino", "size", "mtime")) for row in pwrite)
assert pwrite[0]["gen_open"] < pwrite[1]["gen_open"] < pwrite[2]["gen_open"]

hardlink = [data[name] for name in (
    "alias-before", "alias-after-write", "original-after-alias-write",
)]
assert equal(hardlink[1], hardlink[2], fingerprint + ("gen_open", "hash_fnv64"))
assert hardlink[0]["gen_open"] < hardlink[1]["gen_open"]

mmap_steps = [row for name, row in data.items() if
              name.startswith("map-") and name not in {
                  "map-before", "map-unmapped", "map-held-reader-unmapped", "map-unmapped-fsynced",
              }]
assert all(row["gen_open"] == 0 for row in mmap_steps)
assert data["short-map-before"]["gen_open"] < data["short-map-after-all-closed"]["gen_open"]
assert all(data[step]["gen_open"] == 0 for step in (
    "protect-shared-readonly", "protect-shared-made-writable", "protect-shared-written-no-msync",
))
assert data["protect-unmapped"]["gen_open"] > data["protect-before"]["gen_open"]

old, new, held = [data[name] for name in (
    "replace-held-before", "replacement-path-after", "replace-held-after",
)]
assert equal(old, held, ("dev", "ino", "gen_open", "hash_fnv64"))
assert old["dev"] == new["dev"] and old["ino"] != new["ino"] and old["hash_fnv64"] != new["hash_fnv64"]

summary = {
    "volume": volume,
    "observations": len(observations),
    "expected_full_file_bytes_observed": len(observations),
    "same_stat_different_bytes_both_invalid_generation": zero_collisions,
    "same_stat_different_bytes_same_nonzero_generation": nonzero_collisions,
    "pwrite_with_fd_held_generations": [row["gen_open"] for row in pwrite],
    "hardlink_generations": [row["gen_open"] for row in hardlink],
    "live_shared_mapping_generation": [row["gen_open"] for row in mmap_steps],
    "short_mapping_generation_before_and_after": [
        data["short-map-before"]["gen_open"], data["short-map-after-all-closed"]["gen_open"]
    ],
    "ordered_fresh_open_then_mapped_write": {
        "inference": "An unchanged valid stamp at OPEN cannot justify retaining guest pages for a later first read on generic mutable shares. The peer changes the bytes after OPEN and before that first read without changing the stat metadata used for Linux automatic invalidation.",
        "first_read_on_native_fd_measured": True,
        "guest_keep_cache_variant_tested": False,
        "same_dev_ino_size_mtime_ctime_birthtime": True,
        "prior_read": before,
        "valid_at_open": valid_at_open,
        "first_read_after_ordered_mutation": first_read,
    },
    "replace_old_and_new_inodes": [old["ino"], new["ino"]],
    "replace_old_before_new_path_held_old_first_bytes": [old["read_byte"], new["read_byte"], held["read_byte"]],
    "cleanup": cleanup,
    "references": {
        "xnu_generation_contract": "https://github.com/apple-oss-distributions/xnu/blob/main/bsd/man/man2/getattrlist.2",
        "linux_open_flags": "https://github.com/torvalds/linux/blob/master/include/uapi/linux/fuse.h",
        "linux_auto_invalidation": "https://github.com/torvalds/linux/blob/master/fs/fuse/inode.c",
    },
}
(stage / "gen-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(f"{len(observations)} expected reads. {len(zero_collisions)} mmap stat collisions with invalid gen. Zero observed valid-gen collisions before OPEN. Ordered post-OPEN counterexample confirmed.")
