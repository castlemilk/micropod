#include <err.h>
#include <fcntl.h>
#include <inttypes.h>
#include <signal.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/attr.h>
#include <sys/mman.h>
#include <sys/mount.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

enum { FILE_SIZE = 16384 };

static const struct timespec fixed_times[2] = {
    { .tv_sec = 1600000001, .tv_nsec = 234567890 },
    { .tv_sec = 1600000002, .tv_nsec = 345678901 },
};

struct witness {
    uint32_t len;
    attribute_set_t returned;
    uint32_t generation;
};

struct volume_reply {
    uint32_t len;
    attribute_set_t returned;
    vol_capabilities_attr_t capabilities;
};

static int leaf_open(int dir, const char *name, int flags)
{
    int fd = openat(dir, name, flags | O_NOFOLLOW | O_CLOEXEC, 0600);
    if (fd == -1)
        err(1, "openat %s", name);
    return fd;
}

static void must_close(int fd)
{
    if (close(fd))
        err(1, "close");
}

static void write_file(int fd, unsigned char pattern)
{
    unsigned char buf[FILE_SIZE];
    memset(buf, pattern, sizeof(buf));
    if (pwrite(fd, buf, sizeof(buf), 0) != sizeof(buf))
        err(1, "pwrite");
    if (futimens(fd, fixed_times))
        err(1, "futimens");
}

static void create_file(int dir, const char *name, unsigned char pattern)
{
    int fd = leaf_open(dir, name, O_CREAT | O_EXCL | O_RDWR);
    write_file(fd, pattern);
    must_close(fd);
}

static uint32_t get_generation(int fd, int *supported)
{
    struct attrlist attrs = {
        .bitmapcount = ATTR_BIT_MAP_COUNT,
        .commonattr = ATTR_CMN_RETURNED_ATTRS | ATTR_CMN_GEN_COUNT,
    };
    struct witness value = { 0 };
    if (fgetattrlist(fd, &attrs, &value, sizeof(value), FSOPT_ATTR_CMN_EXTENDED))
        err(1, "fgetattrlist generation");
    *supported = (value.returned.commonattr & ATTR_CMN_GEN_COUNT) != 0;
    if (*supported && value.len < sizeof(value))
        errx(1, "truncated generation reply");
    return value.generation;
}

static void observe(int dir, const char *name, int held, const char *step, unsigned char expected)
{
    int fd = held == -1 ? leaf_open(dir, name, O_RDONLY) : held;
    struct stat st;
    int support_open, support_release;
    uint32_t at_open = get_generation(fd, &support_open);
    if (fstat(fd, &st))
        err(1, "fstat");
    unsigned char bytes[FILE_SIZE];
    ssize_t n = pread(fd, bytes, sizeof(bytes), 0);
    if (n != sizeof(bytes))
        err(1, "pread %s", step);
    uint32_t at_release = get_generation(fd, &support_release);

    int uniform = 1;
    uint64_t hash = UINT64_C(14695981039346656037);
    for (size_t i = 0; i < (size_t)n; ++i) {
        uniform &= bytes[i] == bytes[0];
        hash = (hash ^ bytes[i]) * UINT64_C(1099511628211);
    }
    printf("{\"kind\":\"observation\",\"step\":\"%s\",\"name\":\"%s\","
           "\"peer_pid\":%jd,\"held_reader\":%s,\"monotonic_ns\":%" PRIu64 ","
           "\"gen_open\":%" PRIu32 ",\"gen_release\":%" PRIu32 ","
           "\"gen_open_supported\":%s,\"gen_release_supported\":%s,"
           "\"dev\":%ju,\"ino\":%ju,\"size\":%jd,\"nlink\":%ju,"
           "\"mode\":%ju,\"uid\":%ju,\"gid\":%ju,"
           "\"mtime\":[%jd,%ld],\"ctime\":[%jd,%ld],\"birthtime\":[%jd,%ld],"
           "\"expected_byte\":%u,\"read_byte\":%u,\"uniform\":%s,\"hash_fnv64\":\"%016" PRIx64 "\"}\n",
           step, name, (intmax_t)getpid(), held == -1 ? "false" : "true",
           clock_gettime_nsec_np(CLOCK_MONOTONIC_RAW),
           at_open, at_release, support_open ? "true" : "false", support_release ? "true" : "false",
           (uintmax_t)st.st_dev, (uintmax_t)st.st_ino, (intmax_t)st.st_size,
           (uintmax_t)st.st_nlink, (uintmax_t)st.st_mode, (uintmax_t)st.st_uid, (uintmax_t)st.st_gid,
           (intmax_t)st.st_mtimespec.tv_sec, st.st_mtimespec.tv_nsec,
           (intmax_t)st.st_ctimespec.tv_sec, st.st_ctimespec.tv_nsec,
           (intmax_t)st.st_birthtimespec.tv_sec, st.st_birthtimespec.tv_nsec,
           expected, bytes[0], uniform ? "true" : "false", hash);
    fflush(stdout);
    if (held == -1)
        must_close(fd);
}

enum opcode { OPEN, PWRITE, MAP, MAPPED_WRITE, MSYNC, RESTORE_TIMES, UNMAP, CLOSE, RENAME, FSYNC, PROTECT, QUIT };
struct command {
    enum opcode op;
    unsigned char pattern;
    char name[32];
};

static void writer(int dir, int conn)
{
    int fd = -1;
    unsigned char *map = NULL;
    struct command cmd;
    for (;;) {
        if (recv(conn, &cmd, sizeof(cmd), MSG_WAITALL) != sizeof(cmd))
            errx(1, "writer command disconnected");
        switch (cmd.op) {
        case OPEN:
            if (fd != -1)
                errx(1, "writer FD still held");
            fd = leaf_open(dir, cmd.name, O_RDWR);
            break;
        case PWRITE:
            write_file(fd, cmd.pattern);
            break;
        case MAP:
            if (map)
                errx(1, "old mapping still live");
            map = mmap(NULL, FILE_SIZE, cmd.pattern, MAP_SHARED, fd, 0);
            if (map == MAP_FAILED)
                err(1, "mmap");
            break;
        case MAPPED_WRITE:
            memset(map, cmd.pattern, FILE_SIZE);
            break;
        case MSYNC:
            if (msync(map, FILE_SIZE, MS_SYNC))
                err(1, "msync");
            break;
        case RESTORE_TIMES:
            if (futimens(fd, fixed_times))
                err(1, "futimens mapped");
            break;
        case UNMAP:
            if (munmap(map, FILE_SIZE))
                err(1, "munmap");
            map = NULL;
            break;
        case CLOSE:
            must_close(fd);
            fd = -1;
            break;
        case FSYNC:
            if (fsync(fd))
                err(1, "fsync");
            break;
        case PROTECT:
            if (mprotect(map, FILE_SIZE, PROT_READ | PROT_WRITE))
                err(1, "mprotect");
            break;
        case RENAME:
            if (renameat(dir, "pending", dir, cmd.name))
                err(1, "renameat");
            break;
        case QUIT:
            if (fd != -1 || map)
                errx(1, "writer did not retire");
            must_close(conn);
            must_close(dir);
            _exit(0);
        }
        if (send(conn, "K", 1, 0) != 1)
            err(1, "writer ack");
    }
}

static void send_command(int conn, enum opcode op, const char *name, unsigned char pattern)
{
    struct command cmd = { .op = op, .pattern = pattern };
    if (name && strlcpy(cmd.name, name, sizeof(cmd.name)) >= sizeof(cmd.name))
        errx(1, "long command pathname");
    if (send(conn, &cmd, sizeof(cmd), 0) != sizeof(cmd))
        err(1, "send command");
    if (op != QUIT) {
        char ack;
        if (recv(conn, &ack, 1, 0) != 1 || ack != 'K')
            errx(1, "writer did not acknowledge opcode %d", op);
    }
}

int main(int argc, char **argv)
{
    if (argc != 3)
        errx(2, "usage: gen-probe PRIVATE_DIR PROTECTED_APFS_MOUNT");
    int dir = open(argv[1], O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    if (dir == -1)
        err(1, "open test directory");
    struct statfs mount_info;
    if (fstatfs(dir, &mount_info))
        err(1, "fstatfs");
    if (strcmp(mount_info.f_fstypename, "apfs") || strcmp(mount_info.f_mntonname, argv[2]))
        errx(1, "unexpected file system %s mounted at %s", mount_info.f_fstypename, mount_info.f_mntonname);
    struct attrlist attrs = {
        .bitmapcount = ATTR_BIT_MAP_COUNT,
        .commonattr = ATTR_CMN_RETURNED_ATTRS,
        .volattr = ATTR_VOL_INFO | ATTR_VOL_CAPABILITIES,
    };
    struct volume_reply reply = { 0 };
    if (fgetattrlist(dir, &attrs, &reply, sizeof(reply), 0))
        err(1, "fgetattrlist capabilities");
    if (!(reply.returned.volattr & ATTR_VOL_CAPABILITIES) || reply.len < sizeof(reply))
        errx(1, "truncated volume capabilities");
    uint32_t caps = reply.capabilities.capabilities[VOL_CAPABILITIES_FORMAT];
    uint32_t valid = reply.capabilities.valid[VOL_CAPABILITIES_FORMAT];
    uint32_t mask = VOL_CAP_FMT_WRITE_GENERATION_COUNT;

    int conn[2];
    if (socketpair(AF_UNIX, SOCK_STREAM, 0, conn))
        err(1, "socketpair");
    pid_t child = fork();
    if (child < 0)
        err(1, "fork");
    if (!child) {
        must_close(conn[0]);
        writer(dir, conn[1]);
    }
    must_close(conn[1]);
    printf("{\"kind\":\"volume\",\"type\":\"%s\",\"device\":\"%s\",\"mount\":\"%s\","
           "\"volume_cap_gen_count\":%s,\"volume_cap_gen_count_valid\":%s,"
           "\"peer_pid\":%jd,\"writer_pid\":%jd}\n",
           mount_info.f_fstypename, mount_info.f_mntfromname, mount_info.f_mntonname,
           (caps & mask) ? "true" : "false", (valid & mask) ? "true" : "false",
           (intmax_t)getpid(), (intmax_t)child);
    fflush(stdout);

    int channel = conn[0];
    create_file(dir, "write", 'A');
    observe(dir, "write", -1, "write-before", 'A');
    observe(dir, "write", -1, "write-repeat-unchanged", 'A');
    send_command(channel, OPEN, "write", 0);
    observe(dir, "write", -1, "write-fd-held-before", 'A');
    send_command(channel, PWRITE, NULL, 'B');
    observe(dir, "write", -1, "write-fd-held-restored-mtime", 'B');
    send_command(channel, PWRITE, NULL, 'C');
    observe(dir, "write", -1, "write-fd-held-restored-mtime-again", 'C');
    send_command(channel, CLOSE, NULL, 0);
    observe(dir, "write", -1, "write-fd-closed", 'C');

    if (linkat(dir, "write", dir, "alias", 0))
        err(1, "linkat");
    observe(dir, "alias", -1, "alias-before", 'C');
    send_command(channel, OPEN, "alias", 0);
    send_command(channel, PWRITE, NULL, 'D');
    observe(dir, "alias", -1, "alias-after-write", 'D');
    observe(dir, "write", -1, "original-after-alias-write", 'D');
    send_command(channel, CLOSE, NULL, 0);

    create_file(dir, "live-map", 'E');
    observe(dir, "live-map", -1, "map-before", 'E');
    int held_reader = leaf_open(dir, "live-map", O_RDONLY);
    send_command(channel, OPEN, "live-map", 0);
    send_command(channel, MAP, NULL, PROT_READ | PROT_WRITE);
    observe(dir, "live-map", -1, "map-open-no-write", 'E');
    send_command(channel, MAPPED_WRITE, NULL, 'F');
    observe(dir, "live-map", -1, "map-without-msync", 'F');
    observe(dir, "live-map", held_reader, "map-held-reader-without-msync", 'F');
    send_command(channel, MAPPED_WRITE, NULL, 'G');
    observe(dir, "live-map", -1, "map-second-write-same-page-no-msync", 'G');
    send_command(channel, MSYNC, NULL, 0);
    observe(dir, "live-map", -1, "map-after-msync-still-mapped", 'G');
    send_command(channel, MAPPED_WRITE, NULL, 'H');
    observe(dir, "live-map", -1, "map-after-msync-dirtied-again", 'H');
    send_command(channel, RESTORE_TIMES, NULL, 0);
    observe(dir, "live-map", -1, "map-mtime-restored-still-mapped", 'H');
    send_command(channel, MAPPED_WRITE, NULL, 'I');
    observe(dir, "live-map", -1, "map-after-restoring-mtime-no-msync", 'I');
    send_command(channel, CLOSE, NULL, 0);
    send_command(channel, MAPPED_WRITE, NULL, 'J');
    observe(dir, "live-map", -1, "map-writer-closed-still-mapped", 'J');
    send_command(channel, MSYNC, NULL, 0);
    observe(dir, "live-map", -1, "map-writer-closed-msync-still-mapped", 'J');
    send_command(channel, MAPPED_WRITE, NULL, 'K');
    observe(dir, "live-map", -1, "map-writer-closed-dirtied-again", 'K');
    send_command(channel, UNMAP, NULL, 0);
    observe(dir, "live-map", -1, "map-unmapped", 'K');
    observe(dir, "live-map", held_reader, "map-held-reader-unmapped", 'K');
    must_close(held_reader);
    send_command(channel, OPEN, "live-map", 0);
    send_command(channel, FSYNC, NULL, 0);
    send_command(channel, CLOSE, NULL, 0);
    observe(dir, "live-map", -1, "map-unmapped-fsynced", 'K');

    create_file(dir, "short-map", 'L');
    observe(dir, "short-map", -1, "short-map-before", 'L');
    send_command(channel, OPEN, "short-map", 0);
    send_command(channel, MAP, NULL, PROT_READ | PROT_WRITE);
    send_command(channel, MAPPED_WRITE, NULL, 'M');
    send_command(channel, UNMAP, NULL, 0);
    send_command(channel, RESTORE_TIMES, NULL, 0);
    send_command(channel, CLOSE, NULL, 0);
    observe(dir, "short-map", -1, "short-map-after-all-closed", 'M');

    create_file(dir, "protect", 'N');
    observe(dir, "protect", -1, "protect-before", 'N');
    send_command(channel, OPEN, "protect", 0);
    send_command(channel, MAP, NULL, PROT_READ);
    observe(dir, "protect", -1, "protect-shared-readonly", 'N');
    send_command(channel, PROTECT, NULL, 0);
    observe(dir, "protect", -1, "protect-shared-made-writable", 'N');
    send_command(channel, MAPPED_WRITE, NULL, 'O');
    observe(dir, "protect", -1, "protect-shared-written-no-msync", 'O');
    send_command(channel, UNMAP, NULL, 0);
    send_command(channel, CLOSE, NULL, 0);
    observe(dir, "protect", -1, "protect-unmapped", 'O');

    // A valid reopened-file witness can precede a later ordered host
    // write. The fresh peer's first read occurs only after the writer acks.
    create_file(dir, "after-open", 'R');
    observe(dir, "after-open", -1, "after-open-prior-cache-fill", 'R');
    int first_reader = leaf_open(dir, "after-open", O_RDONLY);
    struct stat first_stat;
    if (fstat(first_reader, &first_stat))
        err(1, "first-reader fstat");
    int first_supported;
    uint32_t first_gen = get_generation(first_reader, &first_supported);
    printf("{\"kind\":\"open_witness\",\"step\":\"after-open-reopened-with-no-read\","
           "\"gen_open\":%" PRIu32 ",\"gen_open_supported\":%s,"
           "\"dev\":%ju,\"ino\":%ju,\"size\":%jd,"
           "\"mtime\":[%jd,%ld],\"ctime\":[%jd,%ld],\"birthtime\":[%jd,%ld]}\n",
           first_gen, first_supported ? "true" : "false",
           (uintmax_t)first_stat.st_dev, (uintmax_t)first_stat.st_ino, (intmax_t)first_stat.st_size,
           (intmax_t)first_stat.st_mtimespec.tv_sec, first_stat.st_mtimespec.tv_nsec,
           (intmax_t)first_stat.st_ctimespec.tv_sec, first_stat.st_ctimespec.tv_nsec,
           (intmax_t)first_stat.st_birthtimespec.tv_sec, first_stat.st_birthtimespec.tv_nsec);
    send_command(channel, OPEN, "after-open", 0);
    send_command(channel, MAP, NULL, PROT_READ | PROT_WRITE);
    send_command(channel, MAPPED_WRITE, NULL, 'S');
    observe(dir, "after-open", first_reader, "after-open-first-read-after-peer-mapped-write", 'S');
    must_close(first_reader);
    send_command(channel, UNMAP, NULL, 0);
    send_command(channel, CLOSE, NULL, 0);

    create_file(dir, "replace", 'P');
    create_file(dir, "pending", 'Q');
    held_reader = leaf_open(dir, "replace", O_RDONLY);
    observe(dir, "replace", held_reader, "replace-held-before", 'P');
    observe(dir, "pending", -1, "replacement-before", 'Q');
    send_command(channel, RENAME, "replace", 0);
    observe(dir, "replace", -1, "replacement-path-after", 'Q');
    observe(dir, "replace", held_reader, "replace-held-after", 'P');
    must_close(held_reader);

    send_command(channel, QUIT, NULL, 0);
    must_close(channel);
    int status;
    if (waitpid(child, &status, 0) != child || !WIFEXITED(status) || WEXITSTATUS(status))
        errx(1, "writer did not exit cleanly");
    const char *names[] = { "write", "alias", "live-map", "short-map", "protect", "after-open", "replace" };
    for (size_t i = 0; i < sizeof(names) / sizeof(names[0]); ++i)
        if (unlinkat(dir, names[i], 0))
            err(1, "unlink %s", names[i]);
    must_close(dir);
    printf("{\"kind\":\"cleanup\",\"writer_exit\":0,\"removed_files\":7}\n");
    return 0;
}
