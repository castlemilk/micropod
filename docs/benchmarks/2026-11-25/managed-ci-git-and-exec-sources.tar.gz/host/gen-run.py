from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys

stage = Path("/private/tmp/mp-git-Ypw3sjPL")
mount = stage / "home"
probe = mount / "artifacts" / "genproof"
source = stage / "gen-probe.c"
exe = stage / "gen-probe-bin"
output = stage / "gen-probe.jsonl"
summary = stage / "gen-cleanup.json"

os.umask(0o077)
probe.mkdir(mode=0o700)
identity_before = probe.stat()
argv = [str(exe), str(probe), str(mount)]
run = subprocess.Popen(argv, start_new_session=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
timed_out = False
try:
    stdout, stderr = run.communicate(timeout=8)
except subprocess.TimeoutExpired:
    timed_out = True
    os.killpg(run.pid, signal.SIGKILL)
    stdout, stderr = run.communicate(timeout=3)
output.write_text(stdout)
(stage / "gen-probe.stderr").write_text(stderr)
leftovers = sorted(path.name for path in probe.iterdir())
if run.returncode:
    allowed = {"write", "alias", "live-map", "short-map", "protect", "after-open", "replace", "pending"}
    for name in leftovers:
        if name in allowed:
            (probe / name).unlink()
removed = False
if probe.stat().st_ino == identity_before.st_ino and not tuple(probe.iterdir()):
    probe.rmdir()
    removed = True
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
summary.write_text(json.dumps({
    "argv": argv,
    "build_argv": ["clang", "-std=c11", "-D_DARWIN_C_SOURCE", "-Wall", "-Wextra", "-Werror", "-O2", str(source), "-o", str(exe)],
    "source_sha256": digest(source),
    "probe_sha256": digest(exe),
    "raw_sha256": digest(output),
    "scratch": str(probe),
    "scratch_identity": {"dev": identity_before.st_dev, "ino": identity_before.st_ino},
    "exit_code": run.returncode,
    "timed_out": timed_out,
    "leftovers_before_runner_cleanup": leftovers,
    "private_scratch_removed": removed,
    "os": subprocess.check_output(["sw_vers"], text=True).splitlines(),
    "darwin_release": subprocess.check_output(["uname", "-r"], text=True).strip(),
}, indent=2) + "\n")
if stderr:
    print(stderr, end="", file=sys.stderr)
print(f"Probe exit {run.returncode}, {len(stdout.splitlines())} rows, scratch removed {removed}")
sys.exit(bool(run.returncode or not removed))
