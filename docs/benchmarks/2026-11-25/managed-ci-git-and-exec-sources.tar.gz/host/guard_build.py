"""Rebuild the guarded Swift CLI, verify source stability and stage every required sibling."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
s=Path(__file__).resolve().parent
w=Path.cwd()
a=s/'home/artifacts'
old=a/'managed-swift-source'
new=a/'restore-guard-source'
release=a/'guard-standalone'
assert a.parent.is_mount() and not release.exists() and not new.exists()
def sha(f):
    with f.open('rb') as file: return hashlib.file_digest(file,'sha256').hexdigest()
def inventory():
    result={}
    for path in ('Package.swift','Package.resolved','Sources','Tests','sdk/swift/Sources','signing'):
        source=w/path
        for file in source.rglob('*') if source.is_dir() else [source]:
            if file.is_file():
                result[str(file.relative_to(w))]=sha(file)
    return result
pre=inventory()
prior=json.loads((s/'swift-final.json').read_bytes())['sources']
changes=sorted(key for key,val in pre.items() if prior.get(key)!=val)
assert changes and set(pre)==set(prior), changes
new.mkdir()
for key in changes:
    dest=new/key
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(w/key,dest)
    assert sha(dest)==pre[key]
subprocess.run(['swift','build','--product','micropod','--jobs','4'],cwd=w,check=True)
bin_path=Path(subprocess.check_output(['swift','build','--show-bin-path'],cwd=w,text=True).strip())
assert pre==inventory()
release.mkdir()
for original in (a/'standalone').iterdir():
    if original.name=='micropod':continue
    subprocess.run(['/bin/cp','-cR',original,release/original.name],check=True)
cli=release/'micropod'
shutil.copy2(bin_path/'micropod',cli)
subprocess.run(['codesign','--sign','-','--force','--entitlements',w/'signing/micropod-cli.entitlements',cli],check=True)
for f in ('micropod','micropod-vmm'):
    subprocess.run(['codesign','--verify','--strict',release/f],check=True)
r={'binary_sha256':sha(cli),'sources':pre,'changed_sources':changes,'unchanged_swift_parent':'swift-final.json',
   'resources':{str(f.relative_to(release)):sha(f) for f in release.rglob('*') if f.is_file()}}
assert r['binary_sha256']!=json.loads((s/'swift-final.json').read_bytes())['sha256']
assert all(sha(a/'standalone'/key)==val for key,val in r['resources'].items() if key!='micropod')
(s/'restore-guard-build.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'binary_sha256':r['binary_sha256'],'changed_sources':changes}),flush=True)
