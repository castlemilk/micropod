from pathlib import Path
import os,shutil,json,hashlib,subprocess,time
s=Path(__file__).resolve().parent;w=Path.cwd();a=s/'home/artifacts';src=w.parent.parent/'vmm';stage=a/'hardened-source';assert a.parent.is_mount()
def sha(f):
 with f.open('rb') as fd:return hashlib.file_digest(fd,'sha256').hexdigest()
def manifest(p):
 out={}
 for root,dirs,files in os.walk(p):
  dirs[:]=[v for v in dirs if v not in ['target','.git','__pycache__']]
  for v in sorted(files):
   f=Path(root)/v;assert not f.is_symlink();out[str(f.relative_to(p))]=sha(f)
 return out
before=manifest(src);shutil.copytree(src,stage,ignore=shutil.ignore_patterns('target','.git','__pycache__'));assert before==manifest(stage)==manifest(src)
r=Path.home()/'.rustup/toolchains/1.99.1-aarch64-apple-darwin/bin';env={**os.environ,'RUSTC':str(r/'rustc'),'RUSTDOC':str(r/'rustdoc')}
for args in [['test','--workspace','--lib'],['test','-p','micropod-vmm','--test','parent_pid'],['build','--release']]:
 subprocess.run([r/'cargo',*args,'--locked','--offline'],cwd=stage,env=env,check=True)
vm=a/'hardened-vmm';shutil.copy2(stage/'target/release/micropod-vmm',vm);subprocess.run(['codesign','--force','--sign','-','--entitlements',stage/'entitlements.plist',vm],check=True);subprocess.run(['codesign','--verify','--strict',vm],check=True)
init=a/'hardened-guest';init.mkdir();go={**os.environ,'GOOS':'linux','GOARCH':'arm64','CGO_ENABLED':'0'};go.pop('GOROOT',None);subprocess.run(['go','build','-trimpath','-ldflags=-s -w','-o',init/'init','.'],cwd=stage/'guest-init',env=go,check=True)
with (a/'hardened-initrd').open('xb') as out:subprocess.run(['cpio','-o','-H','newc','--quiet'],cwd=init,input=b'init\n',stdout=out,check=True)
rec={'vmm_sha256':sha(vm),'guest_init_sha256':sha(init/'init'),'initrd_sha256':sha(a/'hardened-initrd'),'source':before};(s/'hardened-build.json').write_text(json.dumps(rec,indent=2)+'\n');print(rec['vmm_sha256'],rec['initrd_sha256'],flush=True)
