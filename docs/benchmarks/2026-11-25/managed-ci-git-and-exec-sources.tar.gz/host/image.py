from pathlib import Path
import hashlib,json,subprocess,sys,uuid

s=Path(__file__).resolve().parent
art=s/'home/artifacts'
stageid=s.name.lower().removeprefix('mp-wci-')
tag=f'micropod-qa/checkout:{stageid}'
name=f'mp-checkout-image-{stageid}'
label='io.micropod.checkout-image='+stageid
base='micropod-gamma-bench:20261120'
docker=['docker','--context','orbstack']
def call(*args,check=True,timeout=150):
    p=subprocess.run([*docker,*map(str,args)],text=True,capture_output=True,timeout=timeout)
    if check and p.returncode:raise RuntimeError((args,p.stderr[-1500:],p.stdout[-350:]))
    return p
def absent(kind,name):
    p=call(kind,'inspect',name,check=False)
    return p.returncode!=0 and ('no such' in p.stderr.lower() or 'not found' in p.stderr.lower())
assert absent('container',name) and absent('image',tag)
rc=call('image','inspect','--format','{{.Id}}',base)
assert rc.stdout.strip()=='sha256:c197a3a1748f629fcccda258ebffb2f7c1a1d3b05828e2fc2f24ff13e6f904f9'
info={'source_config':rc.stdout.strip(),'tag':tag,'label':label}
(s/'image.json').write_text(json.dumps(info))
try:
    rc=call('create','--name',name,'--label',label,'--pull=never','--entrypoint','/bin/sh',base,
            '-ec','apt-get -qq update && DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends git && git --version && go version && python3 --version')
    info['container_id']=rc.stdout.strip()
    out=call('start','--attach',info['container_id'],timeout=230);(s/'image-build.log').write_text(out.stdout+out.stderr)
    assert call('inspect','--format','{{.State.ExitCode}}',info['container_id']).stdout.strip()=='0'
    cc=call('commit','--change','ENTRYPOINT []','--change','CMD ["/bin/sh"]',info['container_id'],tag)
    info['config']=cc.stdout.strip()
    versions=call('run','--rm','--pull=never','--network','none','--label',label,'--entrypoint','sh',tag,
                  '-ec','go version && git --version && python3 --version && uname -m')
    info['versions']=versions.stdout.splitlines()
    image=art/'seed.tar'
    call('image','save','--output',image,tag,'alpine:3.23','registry.k8s.io/pause:3.10.2',timeout=150)
    with image.open('rb') as f:info['seed_sha256']=hashlib.file_digest(f,'sha256').hexdigest()
    print(tag,info['versions'],flush=True)
finally:
    if 'container_id' in info:
        c=call('rm','-f',info['container_id'],check=False)
        info['builder_removed']=c.returncode==0 and absent('container',name)
    (s/'image.json').write_text(json.dumps(info,indent=2)+'\n')
