#!/usr/bin/env python3
"""Qualify two parallel managed HVF restores on an already mounted private APFS volume."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import ctypes
import errno
import fcntl
import hashlib
import http.client
import json
import os
from pathlib import Path
import plistlib
import re
import select
import shutil
import signal
import socket
import stat
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import uuid

STAGE = Path("/private/tmp/mp-git-Ypw3sjPL")
MOUNT = STAGE / "home"
ARTIFACTS = MOUNT / "artifacts"
STANDALONE = ARTIFACTS / "standalone"
CLI = STANDALONE / "micropod"
VMM = STANDALONE / "micropod-vmm"
IMAGE_TAR = ARTIFACTS / "minimal.tar"
IMAGE = "alpine:3.23"
PAUSE = "registry.k8s.io/pause:3.10.2"
BOOT_INDEX = "sha256:469c9ea410b9215eaee7976ba6c0639039b444be8e5d638f7abbada189971eb2"
BOOT_REFERENCE = "docker.io/library/alpine@" + BOOT_INDEX
PATH = "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
BASE_ENV = {"PATH": PATH, "LC_ALL": "C", "TZ": "UTC"}
CPUS, MEMORY_MIB, DISK_GIB = 4, 4096, 4
MIB = 1 << 20
LABEL = "io.micropod.managed-fork-proof"
ROLE_LABEL = LABEL + ".role"
NOTE_EXITSTATUS = 0x04000000
CID = re.compile(r"[0-9a-f]{64}\Z")
OBS_CONFIG = "schema: 1\nprometheus:\n  enabled: false\notlp:\n  enabled: false\ntracing:\n  enabled: false\n"
FOUNDATION_HOME = """
import ctypes as c, os
foundation = c.CDLL("/System/Library/Frameworks/Foundation.framework/Foundation")
objc = c.CDLL("libobjc.A.dylib")
objc.objc_getClass.argtypes = [c.c_char_p]
objc.objc_getClass.restype = c.c_void_p
objc.sel_registerName.argtypes = [c.c_char_p]
objc.sel_registerName.restype = c.c_void_p
send = c.CFUNCTYPE(c.c_void_p, c.c_void_p, c.c_void_p)(("objc_msgSend", objc))
manager = send(objc.objc_getClass(b"NSFileManager"), objc.sel_registerName(b"defaultManager"))
home = send(manager, objc.sel_registerName(b"homeDirectoryForCurrentUser"))
fs = send(home, objc.sel_registerName(b"fileSystemRepresentation"))
print(os.path.realpath(os.fsdecode(c.string_at(fs))))
"""


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def ns():
    return time.monotonic_ns()


def ms(start, end):
    return round((end - start) / 1_000_000, 3)


def sha(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()


def text_sha(text):
    return hashlib.sha256(os.fsencode(text)).hexdigest()


def record(path, device, kind=stat.S_ISREG):
    info = path.lstat()
    require(kind(info.st_mode) and info.st_dev == device and info.st_uid == os.getuid(),
            f"unexpected owner, type or device: {path}")
    if kind == stat.S_ISREG:
        require(info.st_nlink == 1, f"expected single-link file: {path}")
    return {"path": str(path), "dev": info.st_dev, "ino": info.st_ino,
            "bytes": info.st_size, "allocated_bytes": info.st_blocks * 512,
            "mtime_ns": info.st_mtime_ns, "mode": stat.S_IMODE(info.st_mode)}


def identity(row):
    return row["dev"], row["ino"]


def read_json(path):
    return json.loads(path.read_bytes())


def write_json(path, row):
    with path.open("x") as output:
        json.dump(row, output, indent=2, sort_keys=True)
        output.write("\n")


def command(argv, *, env=BASE_ENV, cwd=STAGE, timeout=15, check=True):
    argv = list(map(str, argv))
    started = ns()
    completed = subprocess.run(argv, stdin=subprocess.DEVNULL, capture_output=True,
                               text=True, encoding="utf-8", errors="replace",
                               timeout=timeout, env=env, cwd=cwd)
    row = {"argv": argv, "rc": completed.returncode, "stdout": completed.stdout,
           "stderr": completed.stderr, "start_ns": started, "end_ns": ns()}
    if check:
        require(row["rc"] == 0, f"{argv!r} exited {row['rc']}: {row['stderr'][-1800:]}")
    return row


def json_command(row):
    return json.loads(row["stdout"])


def same_uuid(*values):
    return len({uuid.UUID(value) for value in values}) == 1


def private_dir(path):
    path.mkdir(mode=0o700)
    return path


def tail(path, limit=12_000):
    with path.open("rb") as stream:
        stream.seek(max(stream.seek(0, os.SEEK_END) - limit, 0))
        return stream.read().decode(errors="replace")


def mount_preflight():
    require(STAGE.resolve(strict=True) == STAGE and MOUNT.resolve(strict=True) == MOUNT,
            "staging path must be the canonical protected volume")
    stage = record(STAGE, STAGE.stat().st_dev, stat.S_ISDIR)
    require(stage["mode"] & 0o077 == 0, "stage must be private")
    mounted = subprocess.run(["/usr/sbin/diskutil", "info", "-plist", str(MOUNT)],
                             check=True, capture_output=True, timeout=10, env=BASE_ENV)
    info = plistlib.loads(mounted.stdout)
    require(info["FilesystemType"] == "apfs" and info["MountPoint"] == str(MOUNT)
            and (31 << 30) < info["TotalSize"] <= (33 << 30)
            and not info.get("APFSSnapshot", False), "expected the writable protected 32-GiB APFS volume")
    device = MOUNT.stat().st_dev
    require(device != stage["dev"], "protected path was not a separate mounted file system")
    for marker in (MOUNT / ".metadata_never_index", MOUNT / ".fseventsd" / "no_log"):
        record(marker, device)
    return {"device": device, "mount": str(MOUNT), "volume_uuid": info["VolumeUUID"],
            "device_identifier": info["DeviceIdentifier"], "bytes": info["TotalSize"],
            "mount_identity": record(MOUNT, device, stat.S_ISDIR)}


def preflight():
    mount = mount_preflight()
    device = mount["device"]
    for directory in (ARTIFACTS, STANDALONE, STANDALONE / "micropod-oci-tools"):
        record(directory, device, stat.S_ISDIR)
        require(directory.resolve(strict=True) == directory, "artifact directory was redirected")
    files = (CLI, VMM, STANDALONE / "mp-hvf-init.cpio", STANDALONE / "vmlinux-hvf", IMAGE_TAR)
    artifacts = {file.name: {**record(file, device), "sha256": sha(file)} for file in files}
    for binary in (CLI, VMM):
        require(os.access(binary, os.X_OK), f"{binary} is not executable")
        command(["/usr/bin/codesign", "--verify", "--strict", binary])
    tools = {}
    for item in sorted((STANDALONE / "micropod-oci-tools").rglob("*")):
        require(not item.is_symlink(), f"standalone tools cannot use symlinks: {item}")
        if not item.is_dir():
            record(item, device)
            tools[str(item.relative_to(STANDALONE))] = sha(item)
    with tarfile.open(IMAGE_TAR, "r:*") as archive:
        manifest = json.load(archive.extractfile("manifest.json"))
        image_ids = {}
        for image in (IMAGE, PAUSE):
            item, = [entry for entry in manifest if image in entry.get("RepoTags", [])]
            config = archive.extractfile(item["Config"]).read()
            image_id = hashlib.sha256(config).hexdigest()
            require(json.loads(config)["architecture"] == "arm64", f"wrong image architecture for {image}")
            image_ids[image] = "sha256:" + image_id
    docker = shutil.which("docker", path=PATH)
    require(docker is not None, "stock Docker CLI missing from the host executable path")
    docker = Path(docker).resolve(strict=True)
    cli_version = command([docker, "--version"])
    return {"protected_volume": mount, "artifacts": artifacts, "tools": tools, "image_ids": image_ids,
            "docker_cli": {"path": str(docker), "version": cli_version["stdout"].strip()}}


def seed_private_boot_store(store, expected_image):
    # ImageStore in this Swift build reads state.json and content/blobs/sha256.
    # Stage the exact production reference from the fixture before starting ci serve.
    # No Docker image is loaded into the template VM by this host-only provisioning.
    started = ns()
    with tarfile.open(IMAGE_TAR, "r:*") as archive:
        def blob(descriptor):
            digest = descriptor["digest"]
            require(re.fullmatch(r"sha256:[0-9a-f]{64}", digest), "invalid bootstrap image digest")
            name = digest.removeprefix("sha256:")
            entry = archive.getmember("blobs/sha256/" + name)
            require(entry.isfile() and entry.size == descriptor["size"] and entry.size <= IMAGE_TAR.stat().st_size,
                    "unexpected bootstrap image blob size or type")
            content = archive.extractfile(entry).read()
            require(hashlib.sha256(content).hexdigest() == name, "bootstrap image blob digest mismatch")
            return name, content

        index_entry = archive.getmember("index.json")
        require(index_entry.isfile(), "bootstrap archive index is not a regular file")
        root_index = json.load(archive.extractfile(index_entry))
        descriptor, = [item for item in root_index["manifests"] if item["digest"] == BOOT_INDEX]
        idx_name, idx_data = blob(descriptor)
        arm, = [item for item in json.loads(idx_data)["manifests"]
                if item.get("platform", {}).get("architecture") == "arm64"
                and item["platform"].get("os") == "linux"]
        man_name, man_data = blob(arm)
        manifest = json.loads(man_data)
        require(manifest["config"]["digest"] == expected_image, "bootstrap differs from the pinned Alpine fixture")
        objects = [(idx_name, idx_data), (man_name, man_data), *(blob(item) for item in
                   [manifest["config"], *manifest["layers"]])]
    target = store / "content" / "blobs" / "sha256"
    target.mkdir(parents=True, mode=0o700)
    for name, content in objects:
        with (target / name).open("xb") as path:
            path.write(content)
    write_json(store / "state.json", {BOOT_REFERENCE: {field: descriptor[field]
                                                       for field in ("mediaType", "size", "digest")}})
    return {"reference": BOOT_REFERENCE, "home": str(store), "copied_verified_blobs": [name for name, _ in objects],
            "wall_ms_excluded_from_worker_start": ms(started, ns())}


class UnixHTTP(http.client.HTTPConnection):
    def connect(self):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(self.timeout)
        self.sock.connect(self.host)


def request_unix(sock, path, timeout=1):
    connection = UnixHTTP(str(sock), timeout=timeout)
    try:
        connection.request("GET", path, headers={"Host": "localhost", "Connection": "close"})
        response = connection.getresponse()
        return response.status, response.read(1 << 20)
    finally:
        connection.close()


def socket_json(sock, path):
    status, data = request_unix(sock, path, timeout=3)
    require(status == 200, f"{sock} {path} returned {status}: {data[:500]!r}")
    return json.loads(data)


class ProcessInfo(ctypes.Structure):
    _fields_ = ([(name, ctypes.c_uint32) for name in
                 ("flags", "status", "xstatus", "pid", "ppid", "uid", "gid", "ruid", "rgid", "svuid", "svgid", "reserved")]
                + [("comm", ctypes.c_char * 16), ("name", ctypes.c_char * 32)]
                + [(name, ctypes.c_uint32) for name in ("nfiles", "pgid", "jobc", "tdev", "tpgid", "nice")]
                + [("seconds", ctypes.c_uint64), ("microseconds", ctypes.c_uint64)])


LIBPROC = ctypes.CDLL("libproc.dylib", use_errno=True)
LIBPROC.proc_pidinfo.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint64, ctypes.c_void_p, ctypes.c_int]
LIBPROC.proc_pidinfo.restype = ctypes.c_int
LIBPROC.proc_pidpath.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
LIBPROC.proc_pidpath.restype = ctypes.c_int
SYSCALL = ctypes.CDLL(None, use_errno=True)
SYSCALL.sysctl.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_uint, ctypes.c_void_p,
                          ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p, ctypes.c_size_t]
SYSCALL.sysctl.restype = ctypes.c_int


def process(pid, *, executable=None, parent=None):
    info = ProcessInfo()
    n = LIBPROC.proc_pidinfo(pid, 3, 0, ctypes.byref(info), ctypes.sizeof(info))
    if n <= 0:
        err = ctypes.get_errno()
        if err == errno.ESRCH:
            return None
        raise OSError(err, f"proc_pidinfo({pid})")
    require(n == ctypes.sizeof(info) and info.pid == pid and info.uid == os.getuid(),
            f"unexpected process identity for PID {pid}")
    path = ctypes.create_string_buffer(4096)
    require(LIBPROC.proc_pidpath(pid, path, len(path)) > 0, f"could not resolve executable for PID {pid}")
    program = Path(os.fsdecode(path.value)).resolve()
    require(executable is None or program == executable, f"unexpected executable for PID {pid}: {program}")
    require(parent is None or info.ppid == parent, f"PID {pid} was not a child of supervisor {parent}")
    return {"pid": pid, "ppid": info.ppid, "uid": info.uid, "pgid": info.pgid,
            "seconds": info.seconds, "microseconds": info.microseconds, "program": str(program)}


def process_argv(pid):
    mib = (ctypes.c_int * 3)(1, 49, pid)  # CTL_KERN, KERN_PROCARGS2, owned child pid
    size = ctypes.c_size_t(1 << 20)
    buffer = ctypes.create_string_buffer(size.value)
    if SYSCALL.sysctl(mib, 3, buffer, ctypes.byref(size), None, 0) != 0:
        raise OSError(ctypes.get_errno(), f"reading argv for PID {pid}")
    frame = buffer.raw[:size.value]
    argc = int.from_bytes(frame[:4], sys.byteorder, signed=True)
    end_of_exec_path = frame.find(b"\0", 4)
    require(0 < argc <= 256 and end_of_exec_path >= 4, "invalid Darwin argv header")
    # The executable path is followed by NUL padding. Decode exactly argc
    # strings after it. The unrelated process environment is never returned.
    values = frame[end_of_exec_path + 1:].lstrip(b"\0").split(b"\0", argc)
    require(len(values) == argc + 1, "truncated Darwin argv")
    return [os.fsdecode(value) for value in values[:argc]]


def options(argv, opt):
    positions = [index for index, arg in enumerate(argv[1:], 1) if arg == opt]
    require(all(index + 1 < len(argv) for index in positions), f"missing value for {opt}")
    return [argv[index + 1] for index in positions]


def path_option(argv, opt, expected):
    values = options(argv, opt)
    return len(values) == 1 and Path(values[0]).resolve(strict=True) == expected.resolve(strict=True)


def watch_exit(pid):
    queue = select.kqueue()
    try:
        event = select.kevent(pid, filter=select.KQ_FILTER_PROC,
                             flags=select.KQ_EV_ADD | select.KQ_EV_ENABLE | select.KQ_EV_ONESHOT,
                             fflags=select.KQ_NOTE_EXIT | NOTE_EXITSTATUS)
        queue.control([event], 0, 0)
    except BaseException:
        queue.close()
        raise
    return queue


def exit_event(queue, pid):
    event, = queue.control(None, 1, 2)
    require(event.ident == pid and event.fflags & NOTE_EXITSTATUS, f"missing exit status for VMM {pid}")
    return {"pid": pid, "filter_flags": event.fflags, "raw_wait_status": event.data & 0xffff,
            "exit_code": os.waitstatus_to_exitcode(event.data & 0xffff)}


def exclusive_lock(path, expected_identity):
    fd = os.open(path, os.O_RDWR | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        st = os.fstat(fd)
        require((st.st_dev, st.st_ino) == expected_identity, f"lock test opened a different inode: {path}")
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return False
        fcntl.flock(fd, fcntl.LOCK_UN)
        return True
    finally:
        os.close(fd)


def holder_map(paths):
    paths = tuple(Path(path).resolve(strict=True) for path in paths)
    if not paths:
        return {}
    deadline = time.monotonic() + 45
    limit = 5
    while True:
        try:
            row = command(["/usr/sbin/lsof", "-nP", "-Fpn", *paths],
                          timeout=limit, check=False)
            result = {path: set() for path in paths}
            pid = None
            for line in row["stdout"].splitlines():
                if line.startswith("p"):
                    pid = int(line[1:])
                elif line.startswith("n"):
                    path = Path(line[1:]).resolve(strict=True)
                    require(path in result and pid is not None, f"unexpected lsof path: {path}")
                    result[path].add(pid)
            # lsof returns 1 when any requested file has no holder, including
            # a mixed result with valid records for other requested files.
            complete = (row["rc"] == 0 and any(result.values())) or (row["rc"] == 1 and not all(result.values()))
            if not row["stderr"].strip() and complete:
                return {path: sorted(pids) for path, pids in result.items()}
            failure = row["stderr"].strip() or f"exit {row['rc']}"
        except subprocess.TimeoutExpired as error:
            failure = str(error)
        require(time.monotonic() < deadline, f"could not verify holders for {paths}: {failure}")
        time.sleep(0.1)
        limit = max(0.1, deadline - time.monotonic())


def holders(path):
    return holder_map([path])[Path(path).resolve(strict=True)]


def group_alive(pgid):
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False


def uri_path(uri):
    require(uri.startswith("unix:///"), f"unexpected endpoint: {uri}")
    return Path(uri.removeprefix("unix://")).resolve()


class Worker:
    def __init__(self, run_dir, logs, role, token, pre, *, capture=None, restore=None):
        self.pre, self.role, self.token = pre, role, token
        self.device = pre["protected_volume"]["device"]
        self.dir = private_dir(run_dir / ("s" + role))
        self.workspace = private_dir(run_dir / ("w" + role))
        self.home = private_dir(run_dir / ("h" + role))
        self.config = private_dir(self.home / "d")
        apple_store = self.home / "Library" / "Application Support" / "com.apple.container"
        apple_store.mkdir(parents=True, mode=0o700)
        self.host_seed = f"host-{token}-{role}"
        self.marker = f"guest-{token}-{role}"
        self.name = f"mp-fork-{token}"
        self.volume = self.name + "-state"
        (self.workspace / "host-seed").write_text(self.host_seed)
        self.disk = self.dir / "worker.ext4"
        self.docker_sock = self.dir / "docker.sock"
        self.oci_sock = self.dir / "oci.sock"
        self.buildkit = self.dir / "buildkit.sock"
        self.telemetry = self.dir / "telemetry.sock"
        self.log = logs / f"{role}-serve.log"
        self.capture, self.restore = capture, restore
        self.proc, self.vmm, self.watch = None, None, None
        self.cid, self.ready, self.job_stopped = None, False, False
        self.env = {
            **BASE_ENV,
            "HOME": str(self.home), "CFFIXED_USER_HOME": str(self.home),
            "TMPDIR": str(private_dir(self.home / "t")),
            "DOCKER_CONFIG": str(self.config),
            "MICROPOD_OBSERVABILITY_CONFIG": str(run_dir / "o.yaml"),
            "MICROPOD_CI_HOME": str(self.dir),
            "MICROPOD_CI_ENGINE": "containerd", "MICROPOD_CI_VMM": "hvf",
            "MICROPOD_CI_WORKSPACE": str(self.workspace), "MICROPOD_CI_CPUS": str(CPUS),
            "MICROPOD_CI_MEMORY_MIB": str(MEMORY_MIB), "MICROPOD_CI_DISK_GIB": str(DISK_GIB),
        }
        if capture:
            self.env["MICROPOD_CI_HVF_CAPTURE_SNAPSHOT"] = str(capture)
        if restore:
            self.env["MICROPOD_CI_HVF_RESTORE_FROM"] = str(restore)
        home = command([sys.executable, "-I", "-c", FOUNDATION_HOME], env=self.env, cwd=self.home)
        require(Path(home["stdout"].strip()) == self.home, "Foundation home did not resolve inside the private scope")
        for path in (self.dir, self.workspace, self.home):
            info = record(path, self.device, stat.S_ISDIR)
            require(info["mode"] & 0o077 == 0 and path.resolve(strict=True) == path, f"unowned worker path: {path}")
        require(max(len(os.fsencode(sock)) for sock in (self.docker_sock, self.oci_sock, self.buildkit, self.telemetry)) < 104,
                f"worker socket path is too long: {self.dir}")
        self.receipt = {
            "role": role, "state": str(self.dir), "workspace": str(self.workspace), "home": str(self.home),
            "foundation_home": home["stdout"].strip(), "observability": self.env["MICROPOD_OBSERVABILITY_CONFIG"],
            "environment_keys": sorted(self.env), "serve_log": str(self.log),
            "capture": str(capture) if capture else None, "restore": str(restore) if restore else None,
        }
        if capture:
            self.receipt["private_boot_provisioning"] = seed_private_boot_store(apple_store, pre["image_ids"][IMAGE])

    def cli(self, *args, **kw):
        return command([CLI, "ci", *args], env=self.env, cwd=self.home, **kw)

    def docker(self, *args, **kw):
        return command([self.pre["docker_cli"]["path"], "--config", self.config, "--host",
                        "unix://" + str(self.docker_sock), *args], env=self.env, cwd=self.home, **kw)

    def launch(self, barrier=None):
        require(not self.disk.exists() and not self.disk.is_symlink(), f"prior disk present: {self.disk}")
        argv = [str(CLI), "ci", "serve"]
        if barrier is not None:
            barrier.wait(timeout=5)
        with self.log.open("xb") as log:
            self.receipt["spawn_ns"] = ns()
            self.proc = subprocess.Popen(argv, env=self.env, cwd=self.home, stdin=subprocess.DEVNULL,
                                         stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        self.receipt.update({"serve_argv": argv, "supervisor_pid": self.proc.pid, "disk_existed_before_launch": False})
        # Avoid a trust decision based on the PID alone, including the fallback stop path.
        self.supervisor = process(self.proc.pid, executable=CLI, parent=os.getpid())
        require(self.supervisor["pgid"] == self.proc.pid, "supervisor did not get its own process group")
        self.receipt["supervisor_birth"] = self.supervisor

    def wait_ready(self):
        started = self.receipt["spawn_ns"]
        ping_ns = ready_ns = None
        deadline = time.monotonic() + (140 if self.capture else 105)
        while time.monotonic() < deadline:
            require(self.proc.poll() is None, f"{self.role} exited during startup: {tail(self.log, 2800)}")
            if self.watch is None and self.telemetry.is_socket():
                try:
                    health_status, health_body = request_unix(self.telemetry, "/healthz", timeout=0.1)
                except (OSError, http.client.HTTPException):
                    pass
                else:
                    if health_status == 200:
                        health = json.loads(health_body)
                        pid = health["pid"]
                        self.vmm = process(pid, executable=VMM, parent=self.proc.pid)
                        self.watch = watch_exit(pid)
                        self.receipt["vmm_birth"] = self.vmm
                        self.receipt["first_health"] = health
            if ping_ns is None and self.docker_sock.is_socket():
                try:
                    if request_unix(self.docker_sock, "/_ping", timeout=0.12) == (200, b"OK"):
                        ping_ns = ns()
                        self.receipt["docker_ping_ms"] = ms(started, ping_ns)
                except (OSError, http.client.HTTPException):
                    pass
            try:
                session = read_json(self.dir / "session.json")
            except FileNotFoundError:
                session = {}
            if ready_ns is None and session.get("started") is True:
                ready_ns = ns()
                self.receipt["managed_session_ready_ns"] = ready_ns
                self.receipt["managed_session_ready_ms"] = ms(started, ready_ns)
            if (ping_ns and ready_ns and self.watch is not None
                    and (self.capture is None or (self.capture / "READY").is_file())):
                break
            time.sleep(0.005)
        require(ping_ns and ready_ns and self.watch is not None, f"{self.role} did not become ready: {tail(self.log, 2800)}")
        # Both aliases traverse the same native status code path. Keep one in the timing.
        status = json_command(self.cli("status", timeout=10))
        status_ns = ns()
        self.receipt.update({"status": status, "managed_status_verified_ns": status_ns,
                             "managed_status_verified_ms": ms(started, status_ns)})
        self.ready = True
        runner = socket_json(self.oci_sock, "/oci/v1/runner")
        stock = json_command(self.docker("info", "--format", "{{json .}}"))
        health = socket_json(self.telemetry, "/healthz")
        manifest = read_json(self.dir / "worker.json")
        session = read_json(self.dir / "session.json")
        self.receipt.update({"session": session, "manifest": manifest, "oci_identity": runner,
                             "docker_info": {key: stock.get(key) for key in
                                             ("ID", "Labels", "ServerVersion", "KernelVersion", "Containers",
                                              "ContainersRunning", "Images", "NCPU", "Architecture")},
                             "vmm_health": health})
        own = session["owner"]
        for key in ("pid", "uid", "seconds", "microseconds"):
            require(own[key] == self.supervisor[key], f"{self.role} session owner disagrees with the real process")
        require(session["vmm"] == status["vmm"] == "hvf" and session["started"] is True
                and status["engine"] == runner["engine"] == "containerd"
                and status["cpus"] == stock["NCPU"] == health["vcpus_online"] == CPUS
                and health["memory_mib"] == manifest["memoryMiB"] == MEMORY_MIB
                and stock["ServerVersion"] == "micropod" and health["pid"] == self.vmm["pid"]
                and uri_path(status["endpoint"]) == self.oci_sock
                and Path(manifest["workspace"]).resolve(strict=True) == self.workspace, f"{self.role} runtime attestation mismatch")
        require(same_uuid(manifest["worker"], status["worker"], runner["worker"], stock["ID"])
                and same_uuid(session["instance"], status["instance"], runner["instance"])
                and same_uuid(status["boot"], runner["boot"]), f"{self.role} worker, instance or boot attestation mismatch")
        instance_labels = [item.removeprefix("io.micropod.instance=") for item in stock["Labels"]
                           if item.startswith("io.micropod.instance=")]
        require(len(instance_labels) == 1 and same_uuid(instance_labels[0], status["instance"]),
                f"{self.role} stock Docker has a different instance")
        disk = record(self.disk, self.device)
        lock = record(self.dir / "worker.lock", self.device)
        self.receipt["disk"] = disk
        pid = health["pid"]
        require(process(pid, executable=VMM, parent=self.proc.pid) == self.vmm, "VMM process birth changed during launch")
        argv = process_argv(pid)
        self.receipt["vmm_argv"] = argv
        shares = sorted((fields[0], str(Path(fields[1]).resolve(strict=True)), fields[2:])
                        for fields in (spec.split(":") for spec in options(argv, "--share")))
        expected_shares = [("oci-tools", str(STANDALONE / "micropod-oci-tools"), ["ro"]),
                           ("workspace", str(self.workspace), [])]
        kernel = Path("/dev/null") if self.restore else STANDALONE / "vmlinux-hvf"
        resources_match = (Path(argv[0]).resolve(strict=True) == VMM and shares == expected_shares
                           and path_option(argv, "--disk", self.disk)
                           and path_option(argv, "--kernel", kernel)
                           and path_option(argv, "--initrd", STANDALONE / "mp-hvf-init.cpio")
                           and options(argv, "--parent-pid") == [str(self.proc.pid)]
                           and path_option(argv, "--telemetry-socket", self.telemetry)
                           and (path_option(argv, "--restore-from", self.restore)
                                if self.restore else not options(argv, "--restore-from")))
        if self.capture:
            resources_match &= path_option(argv, "--snapshot-out", self.capture)
        self.receipt.update({"workspace_and_tools_shares": shares, "resource_arguments_verified": resources_match})
        require(resources_match, f"{self.role} VMM did not use the staged resource and disk paths: {argv!r}")
        live_holders = holder_map([self.disk, self.dir / "worker.lock"])
        disk_locked = not exclusive_lock(self.disk, identity(disk))
        supervisor_locked = not exclusive_lock(self.dir / "worker.lock", identity(lock))
        self.receipt.update({"disk_holders": live_holders[self.disk], "disk_lock_contended": disk_locked,
                             "supervisor_lock_holders": live_holders[self.dir / "worker.lock"],
                             "supervisor_lock_contended": supervisor_locked})
        require(live_holders[self.disk] == [pid] and live_holders[self.dir / "worker.lock"] == [self.proc.pid]
                and disk_locked and supervisor_locked, f"{self.role} files lack their expected live owners")
        return self.receipt

    def labels(self):
        return ["--label", f"{LABEL}={self.token}", "--label", f"{ROLE_LABEL}={self.role}"]

    def assert_cold_images(self):
        found_containers = self.docker("ps", "-aq")["stdout"].strip()
        found_volumes = self.docker("volume", "ls", "-q")["stdout"].splitlines()
        images = {image: self.docker("image", "inspect", image, check=False) for image in (IMAGE, PAUSE)}
        target_absent = all(row["rc"] != 0 and re.search(r"no such (image|object)|not found",
                            row["stderr"].lower()) for row in images.values())
        self.receipt["cold_snapshot"] = {"target_images_absent": target_absent,
                                         "image_inspects": images, "containers": found_containers,
                                         "same_named_volume_absent": self.volume not in found_volumes}
        require(not found_containers and self.volume not in found_volumes,
                f"{self.role}: unexpected container or post-capture source volume in the snapshot")

    def load_images(self):
        loaded = self.docker("load", "-i", IMAGE_TAR, timeout=60)
        image_ids = {}
        for image in (IMAGE, PAUSE):
            (item,) = json_command(self.docker("image", "inspect", image))
            image_ids[image] = item["Id"]
        require(image_ids == self.pre["image_ids"], f"{self.role}: loaded a different image fixture")
        self.receipt["image_load"] = {**loaded, "verified_ids": image_ids,
                                      "wall_ms": ms(loaded["start_ns"], loaded["end_ns"])}

    def mount_probe(self, path):
        return self.docker("run", "--rm", "--pull=never", "--network", "none",
                           *self.labels(), "--mount", f"type=bind,source={path},target=/work,readonly",
                           IMAGE, "/bin/cat", "/work/host-seed", timeout=30, check=False)

    def attest_workspace(self, captured):
        tag = "io.micropod.workspace-sha256="
        labels = [value.removeprefix(tag) for value in self.receipt["docker_info"]["Labels"] if value.startswith(tag)]
        configured = self.mount_probe(self.workspace)
        accurate = configured["rc"] == 0 and configured["stdout"] == self.host_seed
        fallback = None
        if self.workspace != captured and not accurate:
            fallback = self.mount_probe(captured)
        physical = accurate or (fallback is not None and fallback["rc"] == 0 and fallback["stdout"] == self.host_seed)
        mount_source = self.workspace if accurate else captured if physical else None
        self.receipt["workspace_probe"] = {
            "expected_host_bytes": self.host_seed, "labels": labels,
            "host_configured_hash": text_sha(str(self.workspace)), "captured_hash": text_sha(str(captured)),
            "guest_attests_configured_workspace": labels == [text_sha(str(self.workspace))],
            "guest_attests_captured_workspace": labels == [text_sha(str(captured))],
            "accepted_configured_path": accurate, "configured_path_attempt": configured,
            "captured_path_attempt": fallback, "physical_private_workspace_observed": physical,
            "selected_guest_mount_source": str(mount_source) if mount_source else None,
        }
        return mount_source

    def start_job(self, mount_source):
        self.docker("volume", "create", *self.labels(), self.volume)
        mounts = ["--mount", f"type=volume,source={self.volume},target=/state"]
        if mount_source is not None:
            mounts += ["--mount", f"type=bind,source={mount_source},target=/work"]
        script = ('set -eu\n'
                  'test ! -e /managed-root\n'
                  'test ! -e /state/managed-volume\n'
                  'if [ -n "$2" ]; then\n'
                  '  test "$(cat /work/host-seed)" = "$2"\n'
                  '  test ! -e /work/guest-written\n'
                  '  printf %s "$1" > /work/guest-written\n'
                  'fi\n'
                  'printf %s "$1" > /managed-root\n'
                  'printf %s "$1" > /state/managed-volume\n'
                  'while [ ! -e /managed-stop ]; do sleep 1; done')
        row = self.docker("run", "-d", "--pull=never", "--network", "none", "--name", self.name,
                          *self.labels(), *mounts, IMAGE, "/bin/sh", "-c", script, "proof",
                          self.marker, self.host_seed if mount_source else "", timeout=35)
        self.cid = row["stdout"].strip()
        require(CID.fullmatch(self.cid), f"{self.role} Docker did not return a full container ID")
        (info,) = json_command(self.docker("inspect", "--type", "container", self.cid))
        require(info["Id"] == self.cid and info["Image"] == self.pre["image_ids"][IMAGE]
                and info["Name"] == "/" + self.name and info["Config"]["Labels"][LABEL] == self.token
                and info["Config"]["Labels"][ROLE_LABEL] == self.role
                and info["HostConfig"]["NetworkMode"] == "none", f"{self.role} retained container identity mismatch")
        self.receipt["job"] = {"run": row, "id": self.cid, "inspect": info,
                               "run_wall_ms": ms(row["start_ns"], row["end_ns"]),
                               "managed_status_to_container_started_ms":
                                   ms(self.receipt["managed_status_verified_ns"], row["end_ns"])}
        self.read_job(self.marker, self.host_seed if mount_source else None, timeout=10)

    def read_job(self, marker, seed, *, timeout=5):
        deadline = time.monotonic() + timeout
        script = ('set -eu\n'
                  'printf "%s\\n" "$(cat /proc/sys/kernel/random/boot_id)" "$(cat /managed-root)" "$(cat /state/managed-volume)"\n'
                  'if [ -d /work ]; then printf "%s\\n" "$(cat /work/host-seed)" "$(cat /work/guest-written)"; fi')
        while True:
            row = self.docker("exec", self.cid, "/bin/sh", "-c", script, timeout=5, check=False)
            values = row["stdout"].splitlines()
            outputs = [marker, marker] + ([seed, self.marker] if seed is not None else [])
            if row["rc"] == 0 and len(values) == 1 + len(outputs) and values[1:] == outputs:
                require(same_uuid(values[0], self.receipt["status"]["boot"]), f"{self.role} actual guest boot differs")
                self.receipt.setdefault("readbacks", []).append({"values": values, "argv": row["argv"]})
                return values
            require(time.monotonic() < deadline, f"{self.role} roots did not yield their own markers: {row}")
            time.sleep(0.03)

    def retire_job(self):
        if not self.ready or self.proc.poll() is not None:
            return {"checked": False}
        if self.cid is not None:
            (info,) = json_command(self.docker("inspect", "--type", "container", self.cid))
            require(info["Config"]["Labels"][LABEL] == self.token
                    and info["Config"]["Labels"][ROLE_LABEL] == self.role, "refusing to retire a foreign container")
            if info["State"]["Running"]:
                self.docker("exec", self.cid, "/bin/touch", "/managed-stop")
            waited = self.docker("wait", self.cid, timeout=18)
            self.receipt["retained_container_wait"] = waited
            require(waited["stdout"].strip() == "0", f"{self.role} retained test workload did not exit zero")
        ids = self.docker("ps", "-aq", "--no-trunc", "--filter", f"label={LABEL}={self.token}",
                          "--filter", f"label={ROLE_LABEL}={self.role}")["stdout"].splitlines()
        for cid in ids:
            require(CID.fullmatch(cid), f"invalid owned cleanup ID: {cid!r}")
            (item,) = json_command(self.docker("inspect", "--type", "container", cid))
            labels = item["Config"]["Labels"]
            require(labels.get(LABEL) == self.token and labels.get(ROLE_LABEL) == self.role,
                    f"foreign container under {self.role} socket")
            self.docker("rm", "-f", cid)
        volume = self.docker("volume", "inspect", self.volume, check=False)
        if volume["rc"] == 0:
            (item,) = json_command(volume)
            labels = item["Labels"]
            require(labels.get(LABEL) == self.token and labels.get(ROLE_LABEL) == self.role,
                    f"foreign named volume under {self.role} socket")
            self.docker("volume", "rm", self.volume)
        require(not self.docker("ps", "-aq", "--filter", f"label={LABEL}={self.token}")["stdout"].strip()
                and self.docker("volume", "inspect", self.volume, check=False)["rc"] != 0,
                f"{self.role} owned Docker resources were left after cleanup")
        return {"checked": True, "container_id": self.cid, "clean_container_exit": self.cid is not None,
                "removed_owned_containers": ids, "owned_volume_absent": True}

    def retire(self):
        if self.proc is None:
            return {"launched": False}
        result = {"launched": True, "pid": self.proc.pid, "forced": [], "errors": []}
        started = ns()
        try:
            result["docker_cleanup"] = self.retire_job()
        except Exception as error:
            result["errors"].append("Docker cleanup: " + str(error))
        if self.proc.poll() is None and (self.dir / "session.json").is_file():
            try:
                active = read_json(self.dir / "session.json")
                require(active["owner"]["pid"] == self.proc.pid, "refusing to stop an unowned session")
                result["managed_stop"] = self.cli("stop", timeout=50)
                self.proc.wait(timeout=8)
            except Exception as error:
                result["errors"].append("Managed stop: " + str(error))
        if self.proc.poll() is None:
            self.proc.terminate()
            result["forced"].append("supervisor TERM")
            try:
                self.proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                result["forced"].append("supervisor KILL")
                self.proc.wait(timeout=5)
        result["supervisor_exit"] = self.proc.returncode
        if self.watch is not None:
            try:
                try:
                    result["vmm_exit_event"] = exit_event(self.watch, self.vmm["pid"])
                except ValueError:
                    # Let the supervisor's parent watchdog finish naturally before a verified orphan signal.
                    current = process(self.vmm["pid"], executable=VMM)
                    require(current is not None and
                            all(current[key] == self.vmm[key] for key in ("pid", "uid", "seconds", "microseconds")),
                            "missing VMM exit event, and original VMM identity could not be verified")
                    os.kill(current["pid"], signal.SIGTERM)
                    result["forced"].append("verified VMM TERM")
                    result["vmm_exit_event"] = exit_event(self.watch, current["pid"])
            except Exception as error:
                result["errors"].append("VMM exit: " + str(error))
            finally:
                self.watch.close()
        result["group_absent"] = not group_alive(self.proc.pid)
        result["tail"] = tail(self.log)
        exitline = re.search(r"\[micropod-vmm\] exit=(\S+) code=(-?\d+)", result["tail"])
        if exitline:
            result["vmm_terminal_report"] = {"reason": exitline[1], "code": int(exitline[2])}
        stopped = self.dir / "stopped"
        if stopped.is_file():
            result["managed_stopped"] = stopped.read_text()
        if self.ready and "managed_stopped" in result:
            result["stopped_matches_instance"] = same_uuid(result["managed_stopped"], self.receipt["status"]["instance"])
        files = {target: record(target, self.device) for target in
                 (self.disk, self.dir / "worker.lock", self.dir / "unpacking.ext4")
                 if target.exists() or target.is_symlink()}
        final_holders = holder_map(files)
        result["final_file_state"] = {
            target.name: {"file": info, "holders": final_holders[target],
                          "lock_available": exclusive_lock(target, identity(info))} for target, info in files.items()
        }
        result["owned_resources_released"] = (
            result["group_absent"] and all(not row["holders"] and row["lock_available"]
                                          for row in result["final_file_state"].values())
            and not any(p.is_socket() for p in (self.docker_sock, self.oci_sock, self.buildkit, self.telemetry)))
        result["all_exits_zero"] = (self.ready and result["supervisor_exit"] == 0
                                    and result.get("vmm_exit_event", {}).get("exit_code") == 0
                                    and result.get("docker_cleanup", {}).get("clean_container_exit") is True
                                    and result.get("stopped_matches_instance") is True
                                    and not result["forced"] and not result["errors"])
        result["retirement_ms"] = ms(started, ns())
        return result


def snapshot_info(path, source, device):
    files = {name: record(path / name, device) for name in
             ("micropod-snapshot.json", "READY", "disk.ext4", "ram.bin", "vmstate.bin")}
    meta = read_json(path / "micropod-snapshot.json")
    ready = read_json(path / "READY")
    require(meta["schema"] == 1 and meta["cpus"] == ready["num_vcpus"] == CPUS
            and meta["memoryMiB"] == ready["memory_mib"] == MEMORY_MIB
            and Path(meta["workspace"]).resolve(strict=True) == source.workspace
            and same_uuid(meta["workerID"], source.receipt["status"]["worker"])
            and same_uuid(meta["instanceID"], source.receipt["status"]["instance"]),
            "snapshot metadata does not identify the live managed source")
    # Containerization's journal is additive to usable capacity and final ext4
    # layout rounds up to block groups. The pinned 4-GiB Alpine fixture produces
    # a 4-GiB + 128-MiB raw file. Compare both template and live writer exactly.
    usable_bytes = source.receipt["manifest"]["diskGiB"] * (1 << 30)
    expected_file_bytes = usable_bytes + 128 * MIB
    with (path / "disk.ext4").open("rb") as disk:
        disk.seek(1024)
        superblock = disk.read(1024)
    require(superblock[56:58] == b"\x53\xef" and int.from_bytes(superblock[92:96], "little") & 4,
            "template does not have an ext4 journal")
    require(ready["ram_total_bytes"] == files["ram.bin"]["bytes"] == MEMORY_MIB * MIB
            and 0 < ready["ram_written_bytes"] <= ready["ram_total_bytes"]
            and files["disk.ext4"]["bytes"] == source.receipt["disk"]["bytes"] == expected_file_bytes
            and identity(files["disk.ext4"]) != identity(source.receipt["disk"])
            and files["vmstate.bin"]["bytes"] > 0, "snapshot data files do not match template topology")
    return {"metadata": meta, "ready": ready, "files": files,
            "provisioned_disk": {"usable_bytes": usable_bytes, "expected_raw_ext4_bytes": expected_file_bytes,
                                 "journal_present": True},
            "disk_sha256_at_capture": sha(path / "disk.ext4"),
            "capture_scope": "Automatic capture on managed Docker readiness, before any measured guest image load or container."}


def label_collisions(workers):
    result = {}
    for field in ("worker", "instance", "boot"):
        values = {worker.role: str(uuid.UUID(worker.receipt["status"][field])) for worker in workers}
        result[field] = {"values": values, "all_distinct": len(set(values.values())) == len(workers)}
    return result


def exercise(run_dir, logs, pre, report, workers):
    snapshot = run_dir / "sn"
    token = report["token"]
    device = pre["protected_volume"]["device"]
    source = Worker(run_dir, logs, "0", token, pre, capture=snapshot)
    workers.append(source)
    source.launch()
    source.wait_ready()
    snap = snapshot_info(snapshot, source, device)
    report["snapshot"] = snap
    source.assert_cold_images()
    source.load_images()
    source_mount = source.attest_workspace(source.workspace)
    require(source_mount == source.workspace, "source did not bind its isolated workspace")
    source.start_job(source_mount)
    forks = [Worker(run_dir, logs, role, token, pre, restore=snapshot) for role in ("1", "2")]
    workers.extend(forks)
    barrier = threading.Barrier(len(forks))

    def boot(worker):
        worker.launch(barrier)
        return worker.wait_ready()

    with ThreadPoolExecutor(max_workers=len(forks)) as pool:
        futures = [pool.submit(boot, worker) for worker in forks]
        for future in futures:
            future.result()
    starts = [worker.receipt["spawn_ns"] for worker in forks]
    ready = [worker.receipt["managed_session_ready_ns"] for worker in forks]
    report["parallel_restore"] = {
        "forks": len(forks), "confirmed_overlapping_spawn_to_ready_windows": max(starts) < min(ready),
        "spawn_spread_ms": ms(min(starts), max(starts)), "earliest_spawn_to_all_sessions_ready_ms": ms(min(starts), max(ready)),
        "storage_route": "Fresh target disks are created by the VMM's native APFS clonefile path from the same-volume snapshot. The measured interval includes cloning and guest readiness, while the original cold provisioning, snapshot save, snapshot hashing and image loads are outside it.",
    }
    require(report["parallel_restore"]["confirmed_overlapping_spawn_to_ready_windows"], "restore windows did not overlap")
    report["identity_collisions"] = label_collisions(workers)
    vmm_pids = {worker.vmm["pid"] for worker in workers}
    disk_ids = {identity(worker.receipt["disk"]) for worker in workers} | {identity(snap["files"]["disk.ext4"])}
    require(len(vmm_pids) == len(workers) and len(disk_ids) == len(workers) + 1,
            "the managed source and forks did not have distinct VMMs and disk inodes")
    report["distinct_vmm_pids_and_raw_disk_inodes"] = True

    def start_fork(worker):
        worker.assert_cold_images()
        worker.load_images()
        worker.start_job(worker.attest_workspace(source.workspace))

    with ThreadPoolExecutor(max_workers=len(forks)) as pool:
        futures = [pool.submit(start_fork, worker) for worker in forks]
        for future in futures:
            future.result()
    require(len({worker.cid for worker in workers}) == len(workers), "retained containers have duplicate IDs")
    report["cold_images_observed"] = all(worker.receipt["cold_snapshot"]["target_images_absent"] for worker in workers)

    first, second = forks
    seed = first.host_seed + "-atomic"
    pending = first.workspace / ".new-seed"
    pending.write_text(seed)
    os.replace(pending, first.workspace / "host-seed")
    changed = second.marker + "-sibling-write"
    second.docker("exec", second.cid, "/bin/sh", "-ec",
                  'printf %s "$1" > /managed-root; printf %s "$1" > /state/managed-volume', "proof", changed)
    for worker in workers:
        mount_seen = worker.receipt["workspace_probe"]["physical_private_workspace_observed"]
        worker.read_job(changed if worker is second else worker.marker,
                        (seed if worker is first else worker.host_seed) if mount_seen else None, timeout=6)
        if mount_seen:
            require((worker.workspace / "guest-written").read_text() == worker.marker,
                    f"{worker.role} guest write landed in a different host workspace")
        require((worker.workspace / "host-seed").read_text() == (seed if worker is first else worker.host_seed),
                f"{worker.role} physical host seed did not stay isolated")
    report["same_name_rootfs_and_named_volume_isolation"] = True
    report["host_workspace_isolation"] = all(worker.receipt["workspace_probe"]["physical_private_workspace_observed"]
                                              for worker in workers)
    report["per_job_workspace_api_ready"] = all(
        worker.receipt["workspace_probe"]["accepted_configured_path"]
        and worker.receipt["workspace_probe"]["guest_attests_configured_workspace"] for worker in workers)
    report["per_job_identity_ready"] = all(data["all_distinct"] for data in report["identity_collisions"].values())
    snap["disk_sha256_after_fork_writes"] = sha(snapshot / "disk.ext4")
    snap["disk_after_fork_writes"] = record(snapshot / "disk.ext4", device)
    require(snap["disk_sha256_at_capture"] == snap["disk_sha256_after_fork_writes"]
            and identity(snap["files"]["disk.ext4"]) == identity(snap["disk_after_fork_writes"]),
            "template disk changed after fork writes")
    report["workload_completed"] = True


def cleanup(run_dir, report, workers):
    all_clear = True
    for worker in reversed(workers):
        try:
            result = worker.retire()
            worker.receipt["retirement"] = result
            all_clear &= not result["launched"] or result["owned_resources_released"]
        except Exception as error:
            worker.receipt["retirement"] = {"error": str(error)}
            all_clear = False
    snapshot = run_dir / "sn"
    try:
        files = [snapshot / name for name in ("disk.ext4", "ram.bin", "vmstate.bin")
                 if (snapshot / name).exists() or (snapshot / name).is_symlink()]
        for path in files:
            record(path, report["preflight"]["protected_volume"]["device"])
        final_holders = holder_map(files)
        report["snapshot_final_holders"] = {path.name: pids for path, pids in final_holders.items()}
        all_clear &= not any(final_holders.values())
    except Exception as error:
        report.setdefault("cleanup_errors", []).append(str(error))
        all_clear = False
    current = record(run_dir, report["preflight"]["protected_volume"]["device"], stat.S_ISDIR)
    require(identity(current) == identity(report["scoped_directory"]) and run_dir.parent == MOUNT,
            "refusing to delete a replaced scope")
    if all_clear:
        shutil.rmtree(run_dir)
    report["private_scope_removed"] = all_clear and not run_dir.exists()
    report["all_worker_and_job_exits_zero"] = len(workers) == 3 and all(
        worker.receipt.get("retirement", {}).get("all_exits_zero") is True for worker in workers)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preflight", action="store_true", help="verify signed staged artifacts and mount without launching VMs")
    parser.add_argument("--out", type=Path, help="fresh JSON receipt within the private stage (default is unique)")
    args = parser.parse_args()
    os.umask(0o077)
    pre = preflight()
    if args.preflight:
        print(json.dumps(pre, indent=2, sort_keys=True))
        return 0
    token = uuid.uuid4().hex[:12]
    output = args.out or STAGE / f"managed-fork-{token}.json"
    require(output.absolute().parent.resolve(strict=True) == STAGE and output.suffix == ".json"
            and not output.exists() and not output.is_symlink(), "receipt must be a fresh JSON in the private stage")
    logs = private_dir(STAGE / f"managed-fork-{token}-logs")
    run_dir = Path(tempfile.mkdtemp(prefix="mf-", dir=MOUNT))
    device = pre["protected_volume"]["device"]
    report = {"schema": 1, "token": token, "preflight": pre, "logs": str(logs), "workers": [],
              "scoped_directory": record(run_dir, device, stat.S_ISDIR),
              "commands": "Actual micropod ci serve and ci status, stock Docker CLI against explicit per-worker sockets."}
    (run_dir / "o.yaml").write_text(OBS_CONFIG)
    workers = []

    def interrupted(number, _frame):
        raise InterruptedError(f"received signal {number}")

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        exercise(run_dir, logs, pre, report, workers)
    except BaseException as error:
        report["workload_error"] = f"{type(error).__name__}: {error}"
        try:
            write_json(output.with_name(output.stem + "-before-cleanup.json"),
                       {**report, "workers": [worker.receipt for worker in workers], "cleanup_pending": True})
        except Exception as diagnostic_error:
            report["pre_cleanup_diagnostics_error"] = str(diagnostic_error)
    finally:
        # A second operator interrupt should not strand a VMM halfway through lock verification.
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        try:
            cleanup(run_dir, report, workers)
        except Exception as error:
            report.setdefault("cleanup_errors", []).append(str(error))
        report["workers"] = [worker.receipt for worker in workers]
        report["compatibility_qualification_passed"] = all(
            report.get(field) is True for field in ("workload_completed", "private_scope_removed",
                                                   "host_workspace_isolation", "per_job_workspace_api_ready",
                                                   "per_job_identity_ready", "all_worker_and_job_exits_zero"))
        write_json(output, report)
        print(output, flush=True)

    operational = report.get("workload_completed") and report.get("private_scope_removed") \
        and report.get("all_worker_and_job_exits_zero")
    if not operational:
        print(report.get("workload_error", "Managed lifecycle or cleanup failed; see the receipt."), file=sys.stderr)
        return 1
    if not report["compatibility_qualification_passed"]:
        print("Managed restore completed with a workspace or identity compatibility limit. See the receipt.", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
