#!/usr/bin/env python3
"""Verify that the corrected managed HVF rejects workspace mismatches before native startup."""
import argparse
import hashlib
import os
from pathlib import Path
import runpy
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time
import uuid

STAGE = Path("/private/tmp/mp-git-Ypw3sjPL")
ORIGINAL = STAGE / "managed-fork-proof-v4.py"
ORIGINAL_SHA = "e553fd0b0d892d060833c12905897164028e2281ad702e5295b274662b82ee76"
if hashlib.sha256(ORIGINAL.read_bytes()).hexdigest() != ORIGINAL_SHA:
    raise RuntimeError("the frozen original qualification driver changed")
original = runpy.run_path(str(ORIGINAL))
harness = original["preflight"].__globals__
Worker = original["Worker"]
require = original["require"]
ns = original["ns"]
ms = original["ms"]
sha = original["sha"]
record = original["record"]
identity = original["identity"]
holders = original["holders"]
same_uuid = original["same_uuid"]
MOUNT = original["MOUNT"]
ARTIFACTS = original["ARTIFACTS"]


class PreparedWorker(Worker):
    def retire(self):
        if "retirement" not in self.receipt:
            self.receipt["retirement"] = super().retire()
        return self.receipt["retirement"]

    def use_captured_workspace(self, source):
        unused = self.workspace
        (unused / "host-seed").unlink()
        unused.rmdir()
        self.workspace = source.workspace
        self.host_seed = source.host_seed
        self.env["MICROPOD_CI_WORKSPACE"] = str(self.workspace)
        self.receipt["workspace"] = str(self.workspace)


def reject(worker, *, omit):
    if omit:
        worker.env.pop("MICROPOD_CI_WORKSPACE")
        worker.receipt["workspace"] = None
        worker.receipt["environment_keys"] = sorted(worker.env)
    args = [str(harness["CLI"]), "ci", "serve"]
    started = ns()
    with worker.log.open("xb") as log:
        worker.proc = subprocess.Popen(args, env=worker.env, cwd=worker.home, stdin=subprocess.DEVNULL,
                                       stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    worker.receipt.update({"serve_argv": args, "supervisor_pid": worker.proc.pid, "spawn_ns": started})
    paths = (worker.docker_sock, worker.oci_sock, worker.buildkit, worker.telemetry)
    seen_sockets = set()
    seen_disk = False
    deadline = time.monotonic() + 12
    while True:
        seen_sockets.update(path.name for path in paths if path.exists() or path.is_symlink())
        seen_disk |= worker.disk.exists() or worker.disk.is_symlink()
        if worker.proc.poll() is not None:
            break
        if worker.telemetry.is_socket() and worker.watch is None:
            try:
                health = original["socket_json"](worker.telemetry, "/healthz")
                worker.vmm = original["process"](health["pid"], executable=harness["VMM"], parent=worker.proc.pid)
                worker.watch = original["watch_exit"](health["pid"])
            except (OSError, RuntimeError):
                pass
        require(time.monotonic() < deadline, "the mismatched restore did not promptly reject")
        time.sleep(0.002)
    log_text = original["tail"](worker.log)
    evidence = {
        "case": "omitted-workspace" if omit else "different-workspace",
        "rc": worker.proc.returncode, "wall_ms": ms(started, ns()), "sockets_observed": sorted(seen_sockets),
        "fresh_disk_created": seen_disk, "persisted_manifest": (worker.dir / "worker.json").is_file(),
        "live_session_left": (worker.dir / "session.json").is_file(), "output": log_text,
    }
    worker.receipt["rejection"] = evidence
    message = log_text.lower()
    # The VMM creates worker.ext4 from the template before any listener.
    # Its absence after exit therefore also excludes a transient bound socket.
    require(evidence["rc"] == 1 and not seen_sockets and not seen_disk
            and not evidence["live_session_left"] and not evidence["persisted_manifest"] and "workspace" in message
            and ("restore" in message or "snapshot" in message), f"restore did not reject the workspace safely: {evidence}")
    retired = worker.retire()
    require(retired["owned_resources_released"] and not retired["forced"], "restore rejection leaked resources")


def exercise(root, logs, pre, report, workers):
    snapshot_path = root / "sn"
    token = report["token"]
    device = pre["protected_volume"]["device"]
    source = PreparedWorker(root, logs, "0", token, pre, capture=snapshot_path)
    workers.append(source)
    source.launch()
    source.wait_ready()
    snap = original["snapshot_info"](snapshot_path, source, device)
    require(snap["metadata"].get("diskBytes") == snap["files"]["disk.ext4"]["bytes"],
            "corrected capture did not attest the raw disk size")
    report["snapshot"] = snap
    source.assert_cold_images()
    source.load_images()
    require(source.attest_workspace(source.workspace) == source.workspace, "source workspace was not admitted")
    source.start_job(source.workspace)

    for role, omitted in (("x", False), ("y", True)):
        invalid = PreparedWorker(root, logs, role, token, pre, restore=snapshot_path)
        workers.append(invalid)
        reject(invalid, omit=omitted)
        source.read_job(source.marker, source.host_seed)
        require(record(source.disk, device)["ino"] == source.receipt["disk"]["ino"]
                and holders(source.disk) == [source.vmm["pid"]]
                and not original["exclusive_lock"](source.disk, identity(source.receipt["disk"])),
                "rejecting the restore changed the source disk owner")
    require((source.workspace / "guest-written").read_text() == source.marker,
            "rejecting a restore changed the source workspace marker")
    report["source_markers_after_rejections"] = True
    stopped = source.retire()
    require(stopped["all_exits_zero"] and stopped["owned_resources_released"],
            "the managed capture source did not retire cleanly")
    source_after_stop = record(source.disk, device)
    report["stopped_source_disk_before_restore"] = {**source_after_stop, "sha256": sha(source.disk)}

    restored = PreparedWorker(root, logs, "1", token, pre, restore=snapshot_path)
    restored.use_captured_workspace(source)
    workers.append(restored)
    restored.launch()
    restored.wait_ready()
    require(same_uuid(restored.receipt["status"]["worker"], snap["metadata"]["workerID"])
            and same_uuid(restored.receipt["status"]["instance"], snap["metadata"]["instanceID"])
            and same_uuid(restored.receipt["status"]["boot"], source.receipt["status"]["boot"]),
            "same-workspace restore no longer attests the captured guest identity")
    require(len({identity(source_after_stop), identity(restored.receipt["disk"]),
                 identity(snap["files"]["disk.ext4"])}) == 3,
            "source, snapshot and same-workspace restore lack independent disk inodes")
    restored.assert_cold_images()
    restored.load_images()
    require(restored.attest_workspace(source.workspace) == source.workspace
            and restored.receipt["workspace_probe"]["guest_attests_configured_workspace"],
            "same-workspace restore did not advertise or admit its configured workspace")

    # The stopped source and restore intentionally address one workspace.
    # This read-only bind exercises it without overwriting the source marker.
    readonly = restored.docker("run", "--rm", "--pull=never", "--network", "none",
                               *restored.labels(), "--read-only", "--mount",
                               f"type=bind,source={source.workspace},target=/work,readonly",
                               original["IMAGE"], "/bin/sh", "-ec",
                               'cat /work/host-seed; printf "\\n"; cat /work/guest-written')
    require(readonly["stdout"].splitlines() == [source.host_seed, source.marker],
            "restored same-workspace job did not read the original source marker")
    report["same_workspace_readonly_job"] = readonly
    restored.start_job(None)
    restored.read_job(restored.marker, None)
    report["stopped_source_disk_after_restore_writes"] = {**record(source.disk, device), "sha256": sha(source.disk)}
    require(report["stopped_source_disk_before_restore"]["sha256"] ==
            report["stopped_source_disk_after_restore_writes"]["sha256"]
            and identity(source_after_stop) == identity(report["stopped_source_disk_after_restore_writes"])
            and (source.workspace / "guest-written").read_text() == source.marker,
            "the same-workspace restore changed the retired source disk or its host marker")
    snap["disk_sha256_after_restore"] = sha(snapshot_path / "disk.ext4")
    require(snap["disk_sha256_after_restore"] == snap["disk_sha256_at_capture"], "snapshot input disk changed")
    report["verified_regression"] = True


def cleanup(root, report, workers):
    clear = True
    for worker in reversed(workers):
        try:
            result = worker.retire()
            worker.receipt["retirement"] = result
            clear &= not result["launched"] or result["owned_resources_released"]
        except Exception as error:
            worker.receipt["retirement"] = {"error": str(error)}
            clear = False
    try:
        items = [root / "sn" / name for name in ("disk.ext4", "ram.bin", "vmstate.bin")]
        items = [item for item in items if item.exists() or item.is_symlink()]
        for item in items:
            record(item, report["preflight"]["protected_volume"]["device"])
        pids = original["holder_map"](items)
        report["snapshot_final_holders"] = {item.name: pids[item] for item in items}
        clear &= not any(pids.values())
    except Exception as error:
        report.setdefault("cleanup_errors", []).append(str(error))
        clear = False
    require(identity(record(root, report["preflight"]["protected_volume"]["device"], stat.S_ISDIR))
            == identity(report["private_scope"]) and root.parent == MOUNT, "private scope was replaced")
    if clear:
        shutil.rmtree(root)
    report["private_scope_removed"] = clear and not root.exists()
    report["successful_worker_and_job_exits_zero"] = len(workers) == 4 and all(
        worker.receipt.get("retirement", {}).get("all_exits_zero") is True
        for worker in workers if worker.role in {"0", "1"})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--standalone", type=Path, required=True,
                        help="corrected signed standalone layout inside the private artifacts directory")
    parser.add_argument("--out", type=Path, required=True, help="new JSON receipt directly in the private stage")
    args = parser.parse_args()
    os.umask(0o077)
    standalone = args.standalone.absolute()
    require(standalone.resolve(strict=True) == standalone and standalone.is_relative_to(ARTIFACTS)
            and standalone != ARTIFACTS / "standalone", "select a separate corrected standalone layout")
    output = args.out.absolute()
    require(output.parent == STAGE and output.suffix == ".json"
            and not output.exists() and not output.is_symlink(), "receipt must be a fresh JSON in the private stage")
    require(sha(standalone / "micropod") != sha(ARTIFACTS / "standalone" / "micropod"),
            "the corrected qualification needs a distinct Swift executable from the original")
    harness.update({"STANDALONE": standalone, "CLI": standalone / "micropod", "VMM": standalone / "micropod-vmm"})
    pre = original["preflight"]()
    token = uuid.uuid4().hex[:12]
    logs = original["private_dir"](STAGE / f"managed-regression-{token}-logs")
    root = Path(tempfile.mkdtemp(prefix="mr-", dir=MOUNT))
    report = {"schema": 1, "token": token, "original_driver_sha256": ORIGINAL_SHA, "preflight": pre,
              "logs": str(logs), "private_scope": record(root, pre["protected_volume"]["device"], stat.S_ISDIR)}
    (root / "o.yaml").write_text(original["OBS_CONFIG"])
    workers = []

    def interrupted(number, _frame):
        raise InterruptedError(f"received signal {number}")

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        exercise(root, logs, pre, report, workers)
    except BaseException as error:
        report["error"] = f"{type(error).__name__}: {error}"
        try:
            original["write_json"](output.with_name(output.stem + "-before-cleanup.json"),
                                   {**report, "workers": [worker.receipt for worker in workers], "cleanup_pending": True})
        except Exception as diagnostic_error:
            report["pre_cleanup_diagnostics_error"] = str(diagnostic_error)
    finally:
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        try:
            cleanup(root, report, workers)
        except Exception as error:
            report.setdefault("cleanup_errors", []).append(str(error))
        report["workers"] = [worker.receipt for worker in workers]
        report["passed"] = all(report.get(key) is True for key in
                               ("verified_regression", "private_scope_removed", "successful_worker_and_job_exits_zero"))
        original["write_json"](output, report)
        print(output, flush=True)
    if not report["passed"]:
        print(report.get("error", "Managed regression did not retire cleanly."), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
