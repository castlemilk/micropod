from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

root = Path("/private/tmp/mp-git-Ypw3sjPL")
repo = Path("/Users/benebsworth/projects/micropod")
source = root / "home/artifacts/outer-detached-source"
snapshot = root / "outer-detached-worktree"
log = root / "outer-detached-tests.log"
receipt = json.loads((source / "source.json").read_text())
output = log.read_text()
test_bin = snapshot / ".build/debug/MicropodPackageTests.xctest/Contents/MacOS/MicropodPackageTests"

def hash_file(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()

matches = re.findall(r"Executed (\d+) tests?, with (\d+) failures? \((\d+) unexpected\)", output)
exec_cases = re.findall(r"Test Case '-\[MicropodRuntimeTests\.DockerExecTests (test[^ ]+)\]' passed", output)
case_count = len(set(exec_cases))
result = {
    "source_manifest_sha256": hash_file(source / "source.json"),
    "source_patch_sha256": hash_file(source / "outer-detached.patch"),
    "snapshot": str(snapshot),
    "command": "swift test --jobs 8 --filter 'DockerExecTests|HVFMachineTests|RuntimeEngineTests|ArgParserTests'",
    "returncode": int(sys.argv[1]),
    "selected_tests": int(matches[-1][0]) if matches else None,
    "failures": int(matches[-1][1]) if matches else None,
    "docker_exec_cases": exec_cases,
    "test_binary_sha256_before_cleanup": hash_file(test_bin) if test_bin.exists() else None,
    "log": str(log),
    "log_sha256": hash_file(log),
    "completed_at_utc": datetime.now(timezone.utc).isoformat(),
}
for name, versions in receipt["files"].items():
    assert hash_file(snapshot / name) == hash_file(source / name) == versions["snapshot_sha256"], name
assert hash_file(Path(receipt["patch"])) == receipt["patch_sha256"]
subprocess.run(["git", "diff", "--check"], cwd=repo, check=True)
(root / "outer-detached-tests.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
assert result["returncode"] == 0 and result["failures"] == 0 and case_count == 5
