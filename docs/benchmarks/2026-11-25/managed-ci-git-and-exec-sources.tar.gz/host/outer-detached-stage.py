from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import plistlib
import re
import shutil
import subprocess
import tempfile

ROOT = Path("/private/tmp/mp-git-Ypw3sjPL")
REPO = Path("/Users/benebsworth/projects/micropod")
SOURCE = ROOT / "home/artifacts/outer-detached-source"
STANDALONE = ROOT / "home/artifacts/outer-detached-standalone"
BUILD_LOG = ROOT / "outer-detached-build.log"
BUILD_JSON = ROOT / "outer-detached-build.json"
receipt = json.loads((SOURCE / "source.json").read_text())
snapshot = Path(receipt["snapshot"])
build = snapshot / ".build/debug"
assert re.search("Build of product 'micropod' complete!", BUILD_LOG.read_text())
assert not STANDALONE.exists()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def file_digest(path):
    return digest(path.read_bytes())

def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO)

assert file_digest(Path(receipt["patch"])) == receipt["patch_sha256"]
for name, versions in receipt["files"].items():
    assert file_digest(snapshot / name) == file_digest(SOURCE / name) == versions["snapshot_sha256"], name

# Verify every other source path against the archived base tree.
rows = git("ls-tree", "-rz", receipt["base"]).split(b"\0")
clean_files = 0
for row in rows:
    if not row:
        continue
    attrs, name_bytes = row.split(b"\t", 1)
    mode, obj_type, obj_hash = attrs.split()
    name = os.fsdecode(name_bytes)
    if name in receipt["files"] or obj_type != b"blob":
        continue
    path = snapshot / name
    contents = os.fsencode(os.readlink(path)) if mode == b"120000" else path.read_bytes()
    blob = b"blob %d\0" % len(contents) + contents
    assert hashlib.sha1(blob).hexdigest().encode() == obj_hash, name
    clean_files += 1

assert not (snapshot / "Sources/MicropodRuntime/HVF/HVFContainerIndex.swift").exists()
stage = Path(tempfile.mkdtemp(prefix=".outer-detached-standalone-", dir=STANDALONE.parent))
cli = stage / "micropod"
source_cli = build / "micropod"
shutil.copy2(source_cli, cli)
cli.chmod(0o700)
binary = cli.read_bytes()
bundles = []
for bundle in sorted(build.glob("*.bundle")):
    if os.fsencode(bundle.name) in binary:
        shutil.copytree(bundle, stage / bundle.name, symlinks=True)
        bundles.append(bundle.name)
assert bundles, "SwiftPM dependent bundles were not found"

entitlements = snapshot / "signing/micropod-cli.entitlements"
with BUILD_LOG.open("a") as log:
    subprocess.run(
        ["/usr/bin/codesign", "--force", "--sign", "-", "--timestamp=none", "--entitlements", entitlements, cli],
        stdout=log, stderr=subprocess.STDOUT, check=True,
    )
    subprocess.run(
        ["/usr/bin/codesign", "--verify", "--strict", "--verbose=4", cli],
        stdout=log, stderr=subprocess.STDOUT, check=True,
    )
entitlements_out = subprocess.check_output(
    ["/usr/bin/codesign", "--display", "--entitlements", "-", "--xml", cli], stderr=subprocess.DEVNULL,
)
assert plistlib.loads(entitlements_out) == plistlib.loads(entitlements.read_bytes())
help_probe = subprocess.run(
    [cli, "machine", "help"],
    env={"PATH": "/usr/bin:/bin", "MICROPOD_HVF_ROOT": str(stage / "unused-machine")},
    capture_output=True, check=True,
)
assert b"machine docker-endpoint" in help_probe.stdout and not help_probe.stderr
with BUILD_LOG.open("a") as log:
    log.write("Standalone CLI help smoke check passed.\n")

def status():
    return [row for row in git("status", "--short", "--untracked-files=normal").decode().splitlines()
            if row[3:] not in receipt["files"]]

before = json.loads((ROOT / "outer-detached-source-before.json").read_text())
outside_index = [path for path in git("diff", "--name-only", "-z", "HEAD").decode().split("\0")
                 if path and path not in receipt["files"]]
outside_hashes = {path: file_digest(REPO / path) if (REPO / path).exists() else None for path in outside_index}
source_after = {
    "head": git("rev-parse", "HEAD").decode().strip(),
    "shared_owned": {name: file_digest(REPO / name) for name in receipt["files"]},
    "other_status": status(),
    "other_tracked_file_sha256": outside_hashes,
    "concurrent_changes_observed": status() != before["other_status"]
        or outside_hashes != before["other_tracked_file_sha256"]
        or any(file_digest(REPO / name) != data["snapshot_sha256"] for name, data in receipt["files"].items()),
    "source_inputs_with_original_git_blob": clean_files,
}
(ROOT / "outer-detached-source-after.json").write_text(json.dumps(source_after, indent=2) + "\n")
assert source_after["head"] == receipt["base"]

stage.rename(STANDALONE)
proc = subprocess.run(
    ["/usr/bin/codesign", "--verify", "--strict", "--verbose=4", STANDALONE / "micropod"],
    capture_output=True, text=True, check=True,
)
build_receipt = {
    "base": receipt["base"],
    "snapshot": str(snapshot),
    "command": "swift build --product micropod",
    "swift": subprocess.check_output(["/usr/bin/swift", "--version"], text=True).strip(),
    "returncode": 0,
    "source_manifest": str(SOURCE / "source.json"),
    "source_manifest_sha256": file_digest(SOURCE / "source.json"),
    "source_patch_sha256": receipt["patch_sha256"],
    "source_inputs_with_original_git_blob": clean_files,
    "signed_cli": str(STANDALONE / "micropod"),
    "strict_codesign": {"returncode": proc.returncode, "output": proc.stdout + proc.stderr},
    "entitlements": plistlib.loads(entitlements_out),
    "sha256": {str(path.relative_to(STANDALONE)): file_digest(path)
               for path in sorted(STANDALONE.rglob("*")) if path.is_file()},
    "resource_bundles": bundles,
    "build_log": str(BUILD_LOG),
    "build_log_sha256": file_digest(BUILD_LOG),
    "completed_at_utc": datetime.now(timezone.utc).isoformat(),
}
BUILD_JSON.write_text(json.dumps(build_receipt, indent=2) + "\n")
print(build_receipt["signed_cli"])
print(build_receipt["sha256"]["micropod"])
