"""Prove exit status and detached dispatch on the outer machine's private Docker endpoint."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import time

stage = Path(__file__).resolve().parent
sys.path.insert(0, str(stage / "home/artifacts/exec-prospective-harness"))
from qualify_docker_exec import LABEL, CONTAINER_ID, detached_options, exec_inspect_row, start_detached_with_event

p = argparse.ArgumentParser()
p.add_argument("--cli", type=Path)
p.add_argument("--out", required=True, type=Path)
p.add_argument("--hold", type=Path, default=stage / "outer-machine-final-hold.json")
args = p.parse_args()
assert args.out.parent.resolve() == stage and not args.out.exists()
hold = json.loads(args.hold.read_text())
scope = Path(hold["scope"]).resolve(strict=True)
assert scope.parent == stage / "home" and scope.name.startswith("outer-machine-") and scope.parent.is_mount()
env = hold["environment"].copy()
host = env["DOCKER_HOST"]
assert Path(host.removeprefix("unix://")).resolve(strict=True) == scope / "machine/run/docker.sock"
client = args.cli.resolve(strict=True) if args.cli else Path("/opt/homebrew/bin/docker")
if args.cli:
    assert client.is_relative_to(stage / "home/artifacts") and os.access(client, os.X_OK)
    env["MICROPOD_CLI"] = str(client)
key = "outer-adapter-" + secrets.token_hex(9)
result = {"arm": "micropod" if args.cli else "docker", "host": host, "name": key, "operations": []}
with client.open("rb") as f:
    result["client_sha256"] = hashlib.file_digest(f, "sha256").hexdigest()
docker_cmd = ["/opt/homebrew/bin/docker", "--host", host]

def run(argv, timeout=12):
    t = time.monotonic_ns()
    q = subprocess.run(argv, env=env, cwd=scope, capture_output=True, text=True, timeout=timeout)
    result["operations"].append({"argv":[str(v) for v in argv], "rc":q.returncode, "stdout":q.stdout,
                                 "stderr":q.stderr,"wall_ms":(time.monotonic_ns()-t)/1e6})
    return q

def checked(q):
    if q.returncode:
        raise RuntimeError(f"command exited {q.returncode}: {q.stderr[:250]}")
    return q

def stock(*args):
    return run([*docker_cmd, *args])

def invoke(flags, cid, command, timeout=12):
    if args.cli:
        argv = [client, "exec", *flags, cid, "--", *command]
    else:
        argv = [*docker_cmd, "exec", *flags, cid, *command]
    return run(argv, timeout=timeout)

class Dispatch:
    def __init__(self, cid):
        self.cid, self.key, self.cli = cid, key, docker_cmd
    def docker(self, verb, *params, timeout):
        assert verb == "exec"
        where = params.index(self.cid)
        return checked(invoke(params[:where], self.cid, params[where+1:], timeout))
    def exec(self, cid, script, file):
        assert cid == self.cid
        return checked(stock("exec", cid, "/bin/sh", "-ec", script, "sh", file)).stdout.rstrip("\n")

cid = None
try:
    cid = checked(stock("run", "-d", "--pull=never", "--network", "none", "--name", key,
                        "--label", LABEL+"="+key, "alpine:3.23", "/bin/sleep", "600")).stdout.strip()
    assert CONTAINER_ID.fullmatch(cid)
    result["container_id"] = cid
    q = invoke([], cid, ["/bin/sh","-c","printf '%s' out-without-newline; printf 'err-first\\nerr-second' >&2; exit 23"])
    assert (q.returncode,q.stdout,q.stderr)==(23,"out-without-newline","err-first\nerr-second"), result["operations"][-1]
    q = invoke([], cid, ["/bin/sh","-c","printf 'two\\n\\n'"])
    assert (q.returncode,q.stdout,q.stderr)==(0,"two\n\n",""), result["operations"][-1]
    q = invoke([], cid, ["/bin/true"])
    assert (q.returncode,q.stdout,q.stderr)==(0,"",""), result["operations"][-1]
    result["attached_guest_status_and_utf8_streams"] = True
    fixture = Dispatch(cid)
    result["detached_release_gate"] = detached_options(fixture,cid)
    fast_id = start_detached_with_event(fixture,cid,"exit 71",key+"-fast")
    until = time.monotonic()+5
    while True:
        row = exec_inspect_row(host,cid,fast_id)
        if not row["Running"]:
            break
        assert time.monotonic()<until
        time.sleep(.025)
    assert row["ExitCode"]==71 and not any(row[z] for z in ("OpenStdin","OpenStdout","OpenStderr"))
    result["immediate_exit"]={"exec_id":fast_id,"client_exit":0,"guest_exit":row["ExitCode"]}
    bad = "/this-directory-does-not-exist-"+key
    q = invoke(["-d","-w",bad],cid,["/bin/sh","-c","exit 0"],timeout=5)
    assert q.returncode!=0 and q.stdout=="" and bad in q.stderr, result["operations"][-1]
    result["rejected_start"]={"cli_exit":q.returncode,"workdir_in_error":True}
    assert checked(stock("inspect","--format","{{.State.Running}}",cid)).stdout.strip()=="true"
except Exception as exc:
    result["failure"] = f"{type(exc).__name__}: {exc}"
finally:
    if cid:
        rows=json.loads(checked(stock("inspect",cid)).stdout)
        assert len(rows)==1 and rows[0]["Id"]==cid and rows[0]["Config"]["Labels"][LABEL]==key
        checked(stock("rm","-f",cid))
    remain=checked(stock("ps","-aq","--no-trunc","--filter","label="+LABEL+"="+key)).stdout.strip()
    assert not remain
    result["owned_container_removed"]=True
    result["passed"]="failure" not in result
    args.out.write_text(json.dumps(result,indent=2)+"\n")
print(result["arm"], "passed" if result["passed"] else result["failure"])
sys.exit(0 if result["passed"] else 1)
