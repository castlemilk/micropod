"""Retire an owned, stopped worker whose original lsof scan timed out."""
import fcntl
import json
import os
import shutil
import stat
import subprocess
import sys
import time
from pathlib import Path

s = Path(__file__).resolve().parent
w = Path.cwd()
sys.path.insert(0,str(w/'scripts'))
import bench_engine_tuning as bench
from importlib.util import spec_from_file_location, module_from_spec
spec = spec_from_file_location('fixture_apfs',bench.DRIVE_HELPER)
apfs = module_from_spec(spec)
spec.loader.exec_module(apfs)
name = sys.argv[1]
assert name.isascii() and name.replace('-','').isalnum()
receipt = s/(name+'.json')
j = json.loads(receipt.read_bytes())
assert 'teardown' in j['errors'] and 'disk holders' in j['errors']['teardown']
backup=s/(name+'-before-recovery.json')
if not backup.exists():shutil.copy2(receipt,backup)
c=j['drive']
home=Path(c['created']['mount'])
directory=home.parent
assert directory.parent==Path('/private/tmp') and directory.name.startswith('mp-tune-ws-')
assert home.name=='home' and home.is_mount() and not home.is_symlink()
assert directory.stat().st_uid==os.getuid() and directory.stat().st_mode & 0o077==0
assert {p.name for p in directory.iterdir()}=={'serve.log','home','worker.sparseimage'}
assert c['created']['image']==str(directory/'worker.sparseimage')
config=json.loads((home/'worker.json').read_bytes())
assert (home/'stopped').read_text().strip()==j['status']['instance'] and config['worker']==j['status']['worker']
assert Path(config['workspace']).resolve()==(s/'home/share'/name).resolve()
assert not any(p.is_socket() for p in home.iterdir())
log=(directory/'serve.log').read_text(errors='replace')
assert ('[micropod-vmm] exit=poweroff' in log) if j['engine']=='hvf' else (home/'stopped').is_file()
for pid in j['disk_users_during_measurement']:
    try: os.kill(int(pid),0)
    except ProcessLookupError:continue
    raise RuntimeError(f'previous disk holder {pid} still exists')
live=apfs.verify(c['created'])
raw=c['raw_disk']
disk=Path(raw['path'])
st=disk.lstat()
assert stat.S_ISREG(st.st_mode) and (st.st_dev,st.st_ino,st.st_size)==(raw['device'],raw['inode'],raw['bytes'])
assert raw['device']==live['volume']['dev']
start=time.monotonic()
listing=subprocess.run(['/usr/sbin/lsof','-nP','-t',disk],capture_output=True,text=True,timeout=60)
assert (listing.returncode,listing.stdout,listing.stderr)==(1,'',''),(listing.returncode,listing.stdout,listing.stderr)
with (home/'worker.lock').open('rb') as lock, disk.open('rb') as f:
    for stream in (lock,f):fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
evidence={'lsof_seconds':time.monotonic()-start,'disk_holders':[],'locks_acquired':True,
          'previous_pids_absent':list(j['disk_users_during_measurement']),
          'stopped_instance':j['status']['instance'],'poweroff_log':log.splitlines()[-2:]}
detached=apfs.detach(c['created'],remove_image=True,inspect_history=True,expected_raw_identity=(st.st_ino,st.st_size))
assert detached['removed_image'] and detached['image_absent'] and detached['persisted_policy']['raw_disk_unchanged']
home.rmdir()
(directory/'serve.log').unlink()
directory.rmdir()
c.update(recovery=evidence,detached=detached)
del j['errors']['teardown']
receipt.write_text(json.dumps(j,indent=2)+'\n')
print('Recovered',name,detached['image_absent'],evidence['lsof_seconds'])
