#!/usr/bin/env python3
"""Record Docker event checks against a pre-existing, private VZ worker."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

QUALIFIER = Path.home() / "projects/micropod/bench/phase0-host-scheduling/scripts/qualify_docker_events.py"


def host_time():
    return {"wall_ns": time.time_ns(), "monotonic_ns": time.monotonic_ns()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True, help="explicit unix:// Docker socket for the VZ worker")
    parser.add_argument("--out", required=True, type=Path, help="new JSON Lines receipt")
    parser.add_argument("--image", default="alpine:3.23", help="preloaded Alpine image")
    parser.add_argument("--rounds", type=int, default=8)
    parser.add_argument("--start-delay", type=float, default=0, help="seconds before the first fixture")
    args = parser.parse_args()
    if not args.host.startswith("unix:///") or not Path(args.host[7:]).is_socket():
        parser.error("--host must identify a live Unix socket")
    if not 1 <= args.rounds <= 24 or not 0 <= args.start_delay <= 45:
        parser.error("use 1–24 rounds and a start delay of 0–45 seconds")

    command = [sys.executable, str(QUALIFIER), "--host", args.host, "--image", args.image]
    environ = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
    with args.out.open("x", encoding="utf-8") as receipt:
        receipt.write(json.dumps({"host": args.host, "image": args.image, "start": host_time(),
                                  "qualifier_sha256": hashlib.sha256(QUALIFIER.read_bytes()).hexdigest()}) + "\n")
        receipt.flush()
        if args.start_delay:
            time.sleep(args.start_delay)
        for attempt in range(1, args.rounds + 1):
            started = host_time()
            process = subprocess.run(command, env=environ, stdin=subprocess.DEVNULL, capture_output=True, text=True)
            finished = host_time()
            try:
                result = json.loads(process.stdout)
            except ValueError:
                result = {"uncaptured_stdout": process.stdout}
            engine = result.get("diagnostics", {}).get("engine", {})
            row = {"round": attempt, "start": started, "end": finished, "exit_code": process.returncode,
                   "stderr": process.stderr, "result": result}
            receipt.write(json.dumps(row, separators=(",", ":")) + "\n")
            receipt.flush()
            print(json.dumps({"round": attempt, "exit_code": process.returncode,
                              "timestamp_regressions": engine.get("timestamp_regressions"),
                              "duplicate_rows": engine.get("duplicate_rows")}), flush=True)
            if process.returncode:
                return process.returncode
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
