"""Repeat the stock-client exec and events checks with an independent wall-clock witness."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import threading
import time
import uuid

CLOCK = """
import json, time
first = time.time_ns() - time.monotonic_ns()
before=first
print(json.dumps({"initial_offset_ns":first}), flush=True)
while True:
    mono=time.monotonic_ns();wall=time.time_ns();offset=wall-mono;delta=offset-before
    if abs(delta)>500000 or abs(offset-first)>5000000:
        print(json.dumps({"wall_ns":wall,"mono_ns":mono,"offset_ns":offset,"step_ns":delta}),flush=True)
        first=offset
    before=offset
    time.sleep(.05)
"""
def run(argv,timeout=60):
    start=time.monotonic_ns()
    p=subprocess.run(list(map(str,argv)),capture_output=True,text=True,timeout=timeout)
    return {"rc":p.returncode,"stdout":p.stdout,"stderr":p.stderr,"wall_ms":(time.monotonic_ns()-start)/1e6}
def checked(argv,timeout=60):
    record=run(argv,timeout)
    if record["rc"]:raise RuntimeError(str(record)[-1400:])
    return record["stdout"]
def main():
    p=argparse.ArgumentParser()
    for flag in ('host','image','name','workspace','exec-driver','events-driver'):
        p.add_argument('--'+flag,required=True)
    p.add_argument('--rounds',type=int,required=True)
    a=p.parse_args()
    stage=Path(__file__).resolve().parent;directory=Path(a.workspace).resolve()
    assert stage/'home' in directory.parents and re.fullmatch('[a-z0-9-]{1,32}',a.name) and 1<=a.rounds<=16
    token=uuid.uuid4().hex
    label='io.micropod.exec-repeat='+token
    cli=['docker','--host',a.host];subdir=stage/(a.name+'-repeat-cases');subdir.mkdir()
    cid=checked(cli+['create','--label',label,'--name','mp-clock-'+token,'--pull=never','--network','none',
                     '--entrypoint','python3',a.image,'-u','-c',CLOCK]).strip()
    assert re.fullmatch('[0-9a-f]{64}',cid)
    def host_sample():
        orig=prev=time.time_ns()-time.monotonic_ns()
        host_steps.append({'initial_offset_ns':orig})
        while not stop.wait(.05):
            mono=time.monotonic_ns();wall=time.time_ns();offset=wall-mono
            if abs(offset-prev)>500000 or abs(offset-orig)>5000000:
                host_steps.append({'wall_ns':wall,'mono_ns':mono,'offset_ns':offset,'step_ns':offset-prev});orig=offset
            prev=offset
    host_steps=[];stop=threading.Event();thread=threading.Thread(target=host_sample); thread.start()
    report={'rounds':a.rounds,'exec_passes':0,'event_passes':0,'cases':[],'clock_witness_container':cid}
    try:
        checked(cli+['start',cid])
        for i in range(1,a.rounds+1):
            for mode in (('exec','events') if i%2 else ('events','exec')):
                driver = Path(a.exec_driver if mode=='exec' else a.events_driver)
                args=[sys.executable,'-B',driver,'--host',a.host]
                rec=run(args,timeout=100)
                stem=f'{i:02}-{mode}';(subdir/(stem+'.log')).write_text(rec['stdout']+'\n'+rec['stderr'])
                row={'round':i,'test':mode,'wall_ms':rec['wall_ms'],'rc':rec['rc'],'raw_file':str(subdir.name+'/'+stem+'.log'),
                     'driver_sha256': hashlib.sha256(driver.read_bytes()).hexdigest()}
                if rec['rc']:
                    row['error']=rec['stderr'][-700:]
                    if mode=='exec':
                        try:row['failed_checks']=json.loads(rec['stdout']).get('failures',{})
                        except ValueError:pass
                else:report['exec_passes' if mode=='exec' else 'event_passes']+=1
                report['cases'].append(row)
                print(i,mode,rec['rc'],round(rec['wall_ms']),flush=True,file=sys.stderr)
    finally:
        stop.set();thread.join()
        (info,)=json.loads(checked(cli+['inspect',cid]))
        assert info['Id']==cid and info['Config']['Labels']['io.micropod.exec-repeat']==token
        report['guest_clock_observations']=checked(cli+['logs',cid]).splitlines()
        checked(cli+['rm','-f',cid])
        report['clock_witness_removed']=not checked(cli+['ps','-a','-q','--filter','label='+label]).strip()
        report['host_clock_observations']=host_steps
        (stage/(a.name+'-repeat-samples.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
    return 0 if len(report['cases'])==2*a.rounds and report['exec_passes']==report['event_passes']==a.rounds else 1
if __name__=='__main__':
    sys.exit(main())
