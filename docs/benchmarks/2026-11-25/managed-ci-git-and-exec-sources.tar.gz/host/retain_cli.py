from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tempfile

stage=Path(__file__).resolve().parent
receipt=json.loads((stage/"outer-detached-build.json").read_bytes())
src=Path(receipt["signed_cli"]).parent
assert src.parent==stage/"home/artifacts" and src.parent.parent.is_mount()
root=Path("/Users/benebsworth/projects/micropod/.build")
assert root.resolve()==root and root.is_dir()
dest=root/"qualified"/("micropod-exec-"+receipt["sha256"]["micropod"][:12])
dest.parent.mkdir(exist_ok=True)
assert dest.parent.resolve()==dest.parent and not dest.exists()
def check(path):
    actual={}
    for f in path.rglob("*"):
        assert not f.is_symlink()
        if f.is_file():
            with f.open("rb") as fp: actual[str(f.relative_to(path))]=hashlib.file_digest(fp,"sha256").hexdigest()
    assert actual==receipt["sha256"]
    subprocess.run(["/usr/bin/codesign","--verify","--strict",path/"micropod"],check=True)
check(src)
with tempfile.TemporaryDirectory(dir=dest.parent,prefix=".candidate-") as temp:
    held=Path(temp)/"payload"
    shutil.copytree(src,held)
    check(held)
    held.rename(dest)
check(dest)
subprocess.run([dest/"micropod","machine","help"],stdout=subprocess.DEVNULL,check=True)
(stage/"outer-retained-cli.json").write_text(json.dumps({"binary":str(dest/"micropod"),"sha256":receipt["sha256"],
    "cli_only":True,"strict_codesign":True,"machine_help":True},indent=2)+"\n")
print(dest/"micropod")
