from pathlib import Path
from statistics import median
import hashlib
import json
import re

s = Path(__file__).resolve().parent
w = Path("/Users/benebsworth/projects/micropod/bench/phase0-host-scheduling")
dst=w/"docs/benchmarks/2026-11-25"
def read(name):
    return json.loads((s/(name+".json")).read_bytes())
def compact(name):
    return {key:val for key,val in name.items() if key!="samples"}
def compare(rows,metric):
    assert rows
    return {"pairs":len(rows),"hvf_wins":sum(row["hvf"][metric]<row["orbstack"][metric] for row in rows),
            "median_ms":{name:median(row[name][metric] for row in rows)/1e6 for name in ("hvf","orbstack")},
            "median_paired_ratio":median(row["hvf"][metric]/row["orbstack"][metric] for row in rows)}
def performance(data,metric):
    return {phase:compare([pair[phase] for pair in data["pairs"]],metric) for phase in ("warm","incremental")}

results={"host":"Gamma-128GB.local","date_utc":"2026-11-25","date_melbourne":"2026-11-26",
         "measurement":"Ambient host load. The two quiet admission attempts each observed 90 samples."}
results["quiet_admission"]={}
for name in ("baseline-quiet","metadata-quiet"):
    d=read(name); a=d["idle_admission"]
    assert len(a)==90 and not any(min(p)>=90 for p in zip(a,a[1:]))
    results["quiet_admission"][name]={"samples":len(a),"min_idle_pct":min(a),"max_idle_pct":max(a),"threshold_pct":90}
results["native_exec"]={}
for name in ("managed-final","vz-final","reference-options","old-exec"):
    d=read(name); t=d.get("exec",d)
    assert t["passed"]==(name!="old-exec") and not t["cleanup"]["remaining_container_ids"]
    assert len(t["checks"] if t["passed"] else t["failures"])==5
    row={"passed":t["passed"],"docker":t["docker"],"image":t["image"],"checks":list(t["checks"]),"failures":t["failures"],"cleanup":t["cleanup"]}
    if t["passed"]:row.update(t["checks"])
    if name in ("managed-final","vz-final"):
        tests=d["io-before"]["tests"]
        assert not d["errors"] and not d["copy"]["failures"] and d["restart"]["passed"]
        assert len(d["copy"]["checks"])==13 and d["events"]["released_before_deadline"]
        assert not any(d[key][field] for key in ("io-before","io-after") for field in ("tasks","pipes"))
        assert "SKIP" not in tests and "FAIL" not in tests
        row["other_native_checks"]={"archive_checks":d["copy"]["checks"],"restart_passed":True,"events_listener_released":True,
            "linux_test_functions":len(re.findall(r"^--- PASS: Test",tests,flags=re.M)),
            "before_and_after":{"tasks":[],"exec_fifo_files":[]}}
    results["native_exec"][name]=row
results["integrated_artifacts"]={k:read("installed-ci")[k] for k in ("vmm_sha256","runner_sha256","kernel_sha256","cli_sha256","initrd_sha256")}
results["virtiofs"]={"timing":{k:read("alloc-paired-host-timing")[k] for k in ("fixture_files","scored_passes_per_sample","candidate_wins","median_scan_ns","paired_median_candidate_over_baseline","paired_candidate_over_baseline")},
    "allocation_calls":{r["arm"]:r["allocation_or_reallocation_calls"] for r in read("alloc-replay")["results"]}}
results["mounted_runner_by_build"]={}
for name in ("base-host","metadata-first","metadata-repeat","baseline-repeat","installed-ci"):
    data=read(name+"-runner-samples"); r=performance(data,"sum_ns")
    results["mounted_runner_by_build"][name]={"idle_pct":read(name)["idle_admission"][-1],"sum_of_guest_work":r}
results["mutable_git"]={}
for name in ("metadata-first","metadata-repeat","baseline-repeat"):
    d=read(name+"-gitstudy-samples"); assert d["complete"] and not d["failures"]
    rows=[r for block in d["pairs"] for r in block]
    assert len(rows)==36 and all(r[e]["correct"] for r in rows for e in ("hvf","orbstack"))
    by_mode={}
    for mode in ("host-index","guest-index","guest-clone"):
        by_mode[mode]={("changed" if edited else "warm"):compare([r for r in rows if r["mode"]==mode and r["edited"]==edited],"elapsed_ns") for edited in (False,True)}
        by_mode[mode]["git_refresh_file_scans"]={engine:next((int(r["value"]) for r in d["diagnostics"][engine][mode]["trace2"] if r.get("key")=="refresh/sum_scan"),0) for engine in ("hvf","orbstack")}
        trace=d["diagnostics"]["hvf"][mode].get("ftrace")
        if trace:
            assert trace["complete"] and not trace["problems"]
            by_mode[mode]["hvf_trace"]={"completed_fuse_operations":{k:v["count"] for k,v in trace["fuse_send_to_end"].items()},"operations_with_paired_work":trace["workspace_completions_with_paired_work_by_opcode"],"trace_loss":trace["trace_loss"]}
    results["mutable_git"][name]=by_mode
g=read("gen-summary")
results["apfs_coherency"]={"observations":g["observations"],"expected_contents_seen":g["expected_full_file_bytes_observed"],"equal_stat_pairs_with_different_bytes":len(g["same_stat_different_bytes_both_invalid_generation"]),"mapped_generations":g["live_shared_mapping_generation"],"reopen_and_first_read":g["ordered_fresh_open_then_mapped_write"]}
d=read("installed-ci-joblocal-samples")
results["job_local_runner"]={"idle_pct":read("installed-ci")["idle_admission"][-1],"source":d["source"],"commit":d["git_commit"],"cpus":d["cpus"],"memory_mib":d["memory_mib"],"host_wall":performance(d,"host_wall_ns"),"guest_work":performance(d,"sum_ns"),"transfer_plus_work":performance(d,"work_with_transfer_ns"),"host_preparation":d["host_preparation"],"initial_by_engine":{e:{k:v for k,v in d["preparation"][e].items() if k in ("clone_ns","initial_transfer_ns","checkout_ready_wall_ns","bundle_bytes")} for e in d["preparation"]},"guest_prime_ns":{e:r["sum_ns"] for e,r in d["prime"].items()},"timing":d["timing_scope"],"cleanup":d["cleanup"]}
d=read("installed-dense-final-checkout-samples")
assert d["jobs_per_engine"]==8
for p in d["pairs"]:
    for phase in ("warm","incremental"):
        for name in ("hvf","orbstack"):
            assert p[phase][name]["peak_scored_parallelism"]==8 and p[phase][name]["all_jobs_overlap_ns"]>0
results["eight_mounted_jobs"]={"idle_pct":read("installed-dense-final")["idle_admission"][-1],"jobs":d["jobs_per_engine"],"cpus_per_job":d["cpus"],"memory_mib_per_job":d["memory_mib"],"commit":d["fixture_git_commit"],"source_files":len(d["fixture_source_sha256"]),"batch_makespan":performance(d,"makespan_ns"),"priming_ms":{e:r["makespan_ns"]/1e6 for e,r in d["priming"].items()},"minimum_common_overlap_ms":{phase:{e:min(p[phase][e]["all_jobs_overlap_ns"] for p in d["pairs"])/1e6 for e in ("hvf","orbstack")} for phase in ("warm","incremental")},"timing":d["timing_scope"]}
d=read("direct-forks")
assert d["complete"] and d["parallel_fanout"]["cow_disk_isolation_verified"] and all(p["clean_exit"] and p["process_group_absent"] for p in d["teardown"]["processes"])
results["direct_forks"]={"serial":compact(d["serial_fork"]),"parallel":compact(d["parallel_fanout"]),"clean_vmm_exits":len(d["teardown"]["processes"]),"snapshot_save_ms":d["snapshot_save"]["wall_ms"],"fresh_restore":{k:v for k,v in d["fresh_restore"].items() if k in ("delay_s","clock","original_volume_verified")},"timing_scope":d["timing_scope"]}
def write_report():
    (dst/"managed-ci-git-and-exec.json").write_text(json.dumps(results,indent=2)+"\n")
if __name__=="__main__": write_report()
