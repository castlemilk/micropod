from pathlib import Path
from datetime import datetime,timezone
import argparse,json,os,re,subprocess,sys,time,shutil,hashlib,secrets,signal
s=Path(__file__).resolve().parent;w=Path.cwd();a=s/'home/artifacts'
sys.path.insert(0,str(w/'scripts'))
import bench_engine_tuning as b
p=argparse.ArgumentParser()
p.add_argument('name');p.add_argument('--sync',action='store_true');p.add_argument('--pairs',type=int,default=4)
p.add_argument('--tests',nargs='+',choices=['edits','orb-edits','checkout','copy','runner','audit','diag','events','restart','trace','telemetry','gitstudy','exec','exectests','io-before','io-after','joblocal'],default=['edits','checkout'])
p.add_argument('--tools',default='tools');p.add_argument('--ambient',action='store_true')
p.add_argument('--idle-us',type=int,default=150);p.add_argument('--jobs',type=int,default=1)
p.add_argument('--period-us',type=int);p.add_argument('--engine',choices=['hvf','vz'],default='hvf')
p.add_argument('--checkout-driver',type=Path,default=w/'scripts/bench_workspace_checkout.py')
p.add_argument('--cli',default='micropod');p.add_argument('--initrd',default='initrd');p.add_argument('--vmm',default='vmm-read');p.add_argument('--extra-copy-image',action='store_true')
p.add_argument('--native-retirement',action='store_true')
p.add_argument('--trace-mode',choices=['host-index','guest-index','guest-clone'])
p.add_argument('--git-driver',type=Path,default=w/'scripts/bench_workspace_git.py')
p.add_argument('--runner-driver',type=Path,default=w/'scripts/bench_workspace_runner.py')
p.add_argument('--exec-driver',type=Path,default=w/'scripts/qualify_docker_exec.py')
p.add_argument('--standalone',action='store_true')
args=p.parse_args()
vmm_path=a/args.vmm;diag_token=secrets.token_hex(8)
def interrupted(signum,_frame):raise InterruptedError(f'received signal {signum}')
signal.signal(signal.SIGTERM,interrupted)
assert re.fullmatch('[a-z0-9-]{1,32}',args.name)
output=s/(args.name+'.json');assert not output.exists() and (s/'home').is_mount()
work=s/'home/share'/args.name;work.mkdir(mode=0o700)
def sha(file):
    with file.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
image=json.load((s/'image.json').open()); cmdline='idle_poll_us='+str(args.idle_us)
data={'at':datetime.now(timezone.utc).isoformat(),'name':args.name,'sync':args.sync,'ambient':args.ambient,
      'vmm_sha256':sha(vmm_path) if args.engine=='hvf' else None,'runner_sha256':sha(a/args.tools/'runner/bin/job'),
      'image':image['tag'],'engine':args.engine,'period_us':args.period_us,'idle_poll_us':args.idle_us,'jobs':args.jobs,'kernel_sha256':sha(a/'Image'),'cli_sha256':sha(a/args.cli),'initrd_sha256':sha(a/args.initrd)}
def save():
    tmp=output.with_suffix('.partial');tmp.write_text(json.dumps(data,indent=2)+'\n');tmp.replace(output)
def call(argv,timeout=160,check=True,env=None):
    result=subprocess.run(list(map(str,argv)),capture_output=True,text=True,timeout=timeout,check=False,env=env)
    if check and result.returncode:raise RuntimeError((argv,result.returncode,result.stdout[-800:],result.stderr[-2000:]))
    return result
def idle():
    out=call(['top','-l','2','-s','1','-n','0']).stdout
    return [float(x) for x in re.findall(r'([0-9.]+)% idle',out)][-1]
class Managed(b.WorkerHandle):
    def env(self):
        e=super().env();e.pop('MICROPOD_VMM_FUSE_SYNC_READ',None)
        if args.sync:e['MICROPOD_VMM_FUSE_SYNC_READ']='1'
        if args.cli=='hardened-cli':e.update(MICROPOD_OBSERVABILITY_CONFIG=str(s/'fixture-observability.yaml'),MICROPOD_TRACE='0')
        if 'diag' in args.tests:e['MICROPOD_VMM_FUSE_DIAG_TOKEN']=diag_token
        e.update(MICROPOD_CI_VMM=args.engine,MICROPOD_CI_DISK_GIB='8',MICROPOD_CI_HVF_BIN=str(vmm_path),MICROPOD_CI_HVF_INITRD=str(a/args.initrd),MICROPOD_OBSERVABILITY_CONFIG=str(s/'fixture-observability.yaml'),MICROPOD_TRACE='0')
        if args.standalone:
            for key in ('MICROPOD_CI_HVF_BIN','MICROPOD_CI_HVF_INITRD','MICROPOD_CI_KERNEL','MICROPOD_CI_OCI_TOOLS'):
                e.pop(key,None)
        return e
worker=Managed('ws',a/args.cli,a/args.tools,a/'Image',cmdline,work)
def audit(stage):
    target=work/('.archive-'+stage)
    Path(str(target)+'.request').touch(exist_ok=False)
    status=Path(str(target)+'.status');deadline=time.monotonic()+52
    while not status.exists() and time.monotonic()<deadline:time.sleep(.1)
    record=data.setdefault('archive_observer',{}).setdefault(stage,{})
    for ext in ('status','leases','snapshots','tests'):
        f=Path(str(target)+'.'+ext)
        if f.exists():record[ext]=f.read_text()
    assert record.get('status','').strip()=='0 0 0',record
    assert 'KEY' in record['snapshots'] and 'ID' in record['leases'] and 'mp-archive-view-' not in record['leases']+record['snapshots'],record
    if stage=='before':
        assert record['tests'].rstrip().endswith('PASS') and '--- SKIP' not in record['tests'] and record['tests'].count('--- PASS: TestDockerArchive')>=10,record['tests']
data['standalone_resource_discovery']=args.standalone
if args.standalone:
    assert all(k not in worker.env() for k in ('MICROPOD_CI_HVF_BIN','MICROPOD_CI_HVF_INITRD','MICROPOD_CI_KERNEL','MICROPOD_CI_OCI_TOOLS'))
errors={};save()
try:
    data['boot_s']=worker.start();data['drive']=worker.drive.receipts;save();u='unix://'+str(worker.sock)
    data['status']=json.loads(call([a/args.cli,'ci','runner-status'],env=worker.env()).stdout)
    assert data['status']['vmm']==args.engine
    b.load_images(worker.sock,a/'seed.tar')
    data['image_on_guest']=b.docker(worker.sock,'image','inspect','--format','{{.Id}}',image['tag']).stdout.strip()
    data['cmdline']=b.docker(worker.sock,'run','--rm','--pull=never','--network','none','alpine:3.23','cat','/proc/cmdline').stdout.strip()
    assert cmdline in data['cmdline'].split()
    import ctypes
    procpath=ctypes.CDLL('/usr/lib/libproc.dylib').proc_pidpath
    vmm=[];holders={}
    for pid in call(['/usr/sbin/lsof','-nP','-t',worker.drive.disk]).stdout.split():
        buf=ctypes.create_string_buffer(4096)
        if procpath(int(pid),buf,len(buf))>0:
            exe=Path(os.fsdecode(buf.value));holders[pid]=str(exe)
            if exe.exists() and exe.samefile(vmm_path):vmm.append(pid)
    data['disk_users_during_measurement']=holders
    if args.engine=='hvf':assert len(vmm)==1,(vmm,holders,vmm_path)
    def cpu():
        raw=call(['ps','-p',vmm[0],'-o','time=']).stdout.strip().split(':')
        seconds=0
        for part in raw:seconds=seconds*60+float(part)
        return [time.monotonic_ns(),seconds]
    if len(vmm)==1:
        first=cpu();time.sleep(5);last=cpu()
        data['idle_vmm_cpu']={'pid':int(vmm[0]),'start':first,'end':last,'pct_of_one_core':100*(last[1]-first[1])/((last[0]-first[0])/1e9)}
    data['idle_admission']=[]
    for i in range(90):
        data['idle_admission'].append(idle())
        if args.ambient or (len(data['idle_admission'])>=2 and min(data['idle_admission'][-2:])>=90):break
    else:raise RuntimeError('No two consecutive idle samples at 90 percent')
    save()
    for test in args.tests:
        try:
            stem=args.name+'-'+test
            print(stem,'started',flush=True)
            if test in ('edits','orb-edits'):
                host=u if test=='edits' else 'unix://'+str(b.ORB_SOCK)
                r=call([sys.executable,'-B',w/'scripts/bench_workspace_edits.py','--host',host,'--workspace',work,'--probe',a/'fsprobe','--rounds','4'],timeout=185,check=False)
                (s/(stem+'.log')).write_text(r.stderr)
                result=json.loads(r.stdout)
                if test=='edits':
                    assert r.returncode==0 and result['complete'], (r.returncode,result.get('error'),result.get('edits'))
                else:
                    assert r.returncode in (0,1) and (r.returncode==0)==result['complete']
                data[test]=result
            elif test=='checkout':
                receipt=s/(stem+'-samples.json')
                extra=[] if args.jobs==1 else ['--jobs',str(args.jobs),'--job-cpus',str(4/args.jobs),'--job-memory-mib',str(3072//args.jobs)]
                if args.period_us:extra+=['--job-cpu-period-us',str(args.period_us)]
                r=call([sys.executable,'-B',args.checkout_driver,'--hvf-socket',worker.sock,'--orbstack-socket',b.ORB_SOCK,'--workspace',work,'--image',image['tag'],'--image-manifest',s/'image-manifest.json','--go-version','1.26.11','--pairs',str(args.pairs),'--out',receipt,*extra],timeout=1200,check=False)
                (s/(stem+'.log')).write_text(r.stdout+'\n'+r.stderr)
                assert r.returncode==0,r.stderr[-2200:]
                data[test]=json.loads(receipt.read_bytes())
            elif test=='gitstudy':
                out=s/(stem+'-samples.json')
                more=['--trace-mode',args.trace_mode,'--trace-helper',a/'trace-proof/trace_proof.py'] if args.trace_mode else []
                try:
                    res=call([sys.executable,'-B',args.git_driver,'--hvf-socket',worker.sock,'--orbstack-socket',b.ORB_SOCK,'--workspace',work,'--source',a/'runner-vendored','--image',image['tag'],'--image-manifest',s/'image-manifest.json','--pairs',str(args.pairs),'--out',out,*more],timeout=450,check=False)
                    (s/(stem+'.log')).write_text(res.stdout+res.stderr)
                    if out.is_file():data[test]=json.loads(out.read_bytes())
                    assert res.returncode==0,(res.stderr[-1300:], [(f['engine'],f['mode'],f['edited'],f['pair']) for f in data.get(test,{}).get('failures',[])])
                finally:
                    for trace in work.glob('.trace-*'):
                        if trace.is_file():shutil.copy2(trace,s/(stem+trace.name+'.log'))
            elif test=='exec':
                res=call([sys.executable,'-B',args.exec_driver,'--host',u],timeout=420,check=False)
                (s/(stem+'.log')).write_text(res.stdout+res.stderr)
                data[test]=json.loads(res.stdout);assert res.returncode==0,(res.stdout[-1700:],res.stderr[-800:])
            elif test in ('io-before','io-after'):
                phase=test.removeprefix('io-')
                key=work/('.exec-'+phase)
                token=secrets.token_hex(8);Path(str(key)+'.request').write_text(token+'\n')
                done=Path(str(key)+'.done');end=time.monotonic()+90
                while not done.is_file() and time.monotonic()<end:time.sleep(.15)
                ans=done.read_text().split();assert ans[0]==token
                record={'tasks':Path(str(key)+'.tasks').read_text().splitlines(),'pipes':Path(str(key)+'.pipes').read_text().splitlines(),'queries':int(ans[1])};data[test]=record
                assert not record['pipes'],record
                if phase=='before':
                    tests=Path(str(key)+'.tests').read_text();(s/(stem+'.log')).write_text(tests);rc=Path(str(key)+'.rc').read_text().strip();record['tests']=tests
                    assert rc=='0' and tests.rstrip().endswith('PASS') and '--- SKIP:' not in tests,tests[-2000:]
                else:assert record['tasks']==data['io-before']['tasks'],record
            elif test=='exectests':
                dest=work/'runner.test';shutil.copy2(a/(args.tools.removeprefix('tools-')+'-runner.test'),dest)
                res=call(['docker','--host',u,'run','--rm','--pull=never','--network','none','--mount','type=bind,source='+str(work)+',target=/mp-tests,readonly','alpine:3.23','/mp-tests/runner.test','-test.v','-test.run','^TestDocker.*(Exec|Terminal|Console|TTY|Resize|Stdin|Hijack)'],timeout=200,check=False)
                (s/(stem+'.log')).write_text(res.stdout+res.stderr);assert res.returncode==0 and '--- PASS: Test' in res.stdout,(res.stdout[-1200:],res.stderr[-1200:])
                data[test]={'output':res.stdout}
            elif test in ('runner','joblocal'):
                receipt=s/(stem+'-samples.json')
                r=call([sys.executable,'-B',args.runner_driver,'--hvf-socket',worker.sock,
                        '--orbstack-socket',b.ORB_SOCK,'--workspace',work,'--image',image['tag'],'--image-manifest',s/'image-manifest.json',
                        '--source',a/'runner-vendored','--pairs',str(args.pairs),'--out',receipt,*(['--job-local'] if test=='joblocal' else [])],timeout=1400,check=False)
                (s/(stem+'.log')).write_text(r.stdout+'\n'+r.stderr)
                assert r.returncode==0,r.stderr[-2200:]
                data[test]=json.loads(receipt.read_bytes())
            elif test=='audit':
                audit('before')
            elif test=='telemetry':
                socket=worker.home/'telemetry.sock';assert socket.is_socket();health=json.loads(call(['curl','--silent','--show-error','--fail','--max-time','2','--unix-socket',socket,'http://localhost/healthz']).stdout);metrics=call(['curl','--silent','--show-error','--fail','--max-time','2','--unix-socket',socket,'http://localhost/metrics']).stdout
                assert health['num_vcpus']==4 and health['vcpus_online']==4 and health['fs_requests']>0 and health['pid']==int(vmm[0]) and 'micropod_vmm_vcpu_exits_total' in metrics
                data[test]={'health':health,'metrics':metrics,'managed_cli':json.loads(call([a/args.cli,'ci','runner-health'],env=worker.env()).stdout)}
            elif test=='trace':
                token=secrets.token_hex(8);data[test]={'token':token}
                def req(name):
                    stage=work/(name+'.tmp');stage.write_text(token+'\n');stage.replace(work/name)
                def marker(name,seconds):
                    deadline=time.monotonic()+seconds
                    while time.monotonic()<deadline:
                        path=work/name
                        if path.is_file():return path.read_text()
                        if name=='.trace-started' and (work/'.trace-done').is_file():raise RuntimeError((work/'.trace-done').read_text())
                        time.sleep(.05)
                    raise TimeoutError('missing guest marker '+name)
                req('.trace-start.request')
                try:
                    start=marker('.trace-started',15);assert token in start;data[test]['start']=start
                    r=call([sys.executable,'-B',w/'scripts/bench_workspace_edits.py','--host',u,'--workspace',work,'--probe',a/'fsprobe','--rounds','1'],timeout=22,check=False)
                    data[test]['scan']=json.loads(r.stdout);assert r.returncode==0 and data[test]['scan']['complete'],r.stderr[-500:]
                finally:
                    req('.trace-finished.request')
                    done=marker('.trace-done',15);data[test]['done']=done
                    for n in ('.trace-started','.trace-events','.trace-stats','.trace-done','.trace-observer.log'):
                        f=work/n
                        if f.is_file():shutil.copyfile(f,s/(args.name+n+'.log'))
                assert 'status=ok' in done and token in done,done
            elif test=='diag':
                folder=a/'diagnostic';driver=folder/'tools/probe.py';probe=folder/'workspace-fuse-probe-linux-arm64'
                argv=[sys.executable,'-B',driver,'run','--host',u,'--workspace',work,'--probe',probe,'--token',diag_token]
                r=call(argv,timeout=140);guest=s/(stem+'-guest.json');guest.write_text(r.stdout)
                worker._log_file.flush();log=worker.dir/'serve.log'
                parsed=call([sys.executable,'-B',driver,'receipt','--guest',guest,'--host-log',log,'--vmm',vmm_path,'--read-mode','sync' if args.sync else 'async','--token',diag_token])
                data[test]=json.loads(parsed.stdout)
            elif test in ('restart','events'):
                cmd=[sys.executable,'-B',w/'scripts'/('qualify_docker_'+test+'.py'),'--host',u]
                if test=='restart':cmd+=['--json']
                r=call(cmd,timeout=240,check=False);(s/(stem+'.log')).write_text(r.stdout+'\n'+r.stderr)
                assert r.returncode==0,(r.stdout[-1500:],r.stderr[-1200:]);data[test]=json.loads(r.stdout)
            elif test=='copy':
                extra=['--overlay-image',image['tag']] if args.extra_copy_image else []
                if args.native_retirement:extra+=['--native-retirement']
                r=call([sys.executable,'-B',w/'scripts/qualify_docker_archive.py','--host',u,'--workspace',work,*extra],timeout=240,check=False)
                (s/(stem+'.log')).write_text(r.stdout+'\n'+r.stderr)
                data[test]=json.loads(r.stdout)
                assert r.returncode==0,(data[test].get('failures'),data[test].get('error'),r.stderr[-1400:])
            print(stem,'passed',flush=True)
        except Exception as ex:
            errors[test]=str(ex);print(stem,'failed',str(ex)[-1000:],flush=True)
        if test=='copy' and 'audit' in args.tests:
            try:audit('after')
            except Exception as ex:errors['post-audit']=str(ex)
        save()
except BaseException as ex:
    errors['worker']=str(ex)
finally:
    try:
        log=worker.dir/'serve.log'
        if log.exists():
            worker._log_file.flush()
            text=log.read_text(errors='replace');(s/(args.name+'-serve.log')).write_text(text)
            data['sync_init_observed']='workspace FUSE_INIT uses synchronous readahead' in text
            if args.sync!=data['sync_init_observed']:errors['toggle']='FUSE_INIT mode log differs'
        data['drive']=worker.stop()
    except Exception as ex:
        errors['teardown']=str(ex);data['drive']=worker.drive.receipts
    finally:
        data['errors']=errors;save()
if errors:print(json.dumps(errors,indent=2),flush=True);sys.exit(1)
