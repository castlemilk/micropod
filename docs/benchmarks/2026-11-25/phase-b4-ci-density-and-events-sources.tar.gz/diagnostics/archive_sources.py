from pathlib import Path
import gzip,hashlib,io,json,tarfile
s=Path(__file__).resolve().parent
w=Path.cwd()
base=w/'docs/benchmarks/2026-11-25/phase-b4-ci-density-and-events-sources.tar.gz'
files={}
def add(src,arc):
    for p in sorted(src.rglob('*')) if src.is_dir() else [src]:
        rel=p.relative_to(src) if src.is_dir() else Path()
        if p.is_file() and not p.is_symlink() and not any(part in ('target','.git','__pycache__','.DS_Store') for part in rel.parts):
            files[str(Path(arc)/rel)]=p
add(s/'vmm','initial/vmm')
add(s/'vmm-fs/crates/vmm-virtio/src/virtiofs.rs','packet-reuse/vmm/crates/vmm-virtio/src/virtiofs.rs')
if (s/'vmm-integrated').exists():
    add(s/'vmm-integrated','integrated/vmm')
if (s/'vmm-latest').exists():
    add(s/'vmm-latest/crates/vmm-virtio/src/virtiofs.rs','pre-durability/vmm/crates/vmm-virtio/src/virtiofs.rs')
add(s/'vmm-b5-current','snapshot-branch/vmm')
add(s/'vmm-8ms/crates/vmm-virtio/src/virtiofs.rs','attribute-8ms/virtiofs.rs')
for n in ('simd_hardware.rs','simd_shim.c','entitlements.plist'):
    add(s/'simd-probe'/n,'hardware-probe/'+n)
add(s/'source-final','integrated/managed')
add(s/'sources','initial/managed-subset')
for name in ['scripts/sibling_dense_load.py','scripts/bench_engine_tuning.py','scripts/bench_workspace_edits.py','scripts/qualify_docker_events.py','scripts/qualify_docker_restart.py','scripts/test_bench_engine_tuning_drive.py','scripts/netbench/main.go','scripts/netbench/quiet/main.go','scripts/workspacebench/main.go','ci/runner/start.sh']:
    add(w/name,'integrated/tooling/'+name)
add(s/'tools-final/runner/start.sh','integrated/diagnostic-start.sh')
for n in ('run.py','collect_density.py','build_probes_image.py','syncprobe.go','archive_sources.py','scheduler-observer.sh','mixed_workspace.py','report_density.py','report-template.md','hygiene.py'):
    add(s/n,'diagnostics/'+n)
if (s/'native-groups-run.py').exists():add(s/'native-groups-run.py','diagnostics/native-groups-run.py')
with base.open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    manifest={}
    for name,p in sorted(files.items()):
        data=p.read_bytes();i=tarfile.TarInfo(name);i.mode=p.stat().st_mode&0o777;i.size=len(data);tar.addfile(i,io.BytesIO(data));manifest[name]=hashlib.sha256(data).hexdigest()
    data=(json.dumps(manifest,indent=2)+'\n').encode();i=tarfile.TarInfo('sha256.json');i.size=len(data);tar.addfile(i,io.BytesIO(data))
print(base.name,len(files),base.stat().st_size)
