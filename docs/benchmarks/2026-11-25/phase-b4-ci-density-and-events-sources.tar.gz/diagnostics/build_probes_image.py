#!/usr/bin/env python3
"""Build and verify one native/Docker-loadable probe image from staged bytes."""

import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import struct
import tarfile
import tempfile


STAGE = Path(__file__).resolve().parent
BASE_TAG = "alpine:3.23"
BASE_NAME = "docker.io/library/" + BASE_TAG
PROBES = ("compile", "netbench-linux", "quiet-http")
OCI = "application/vnd.oci.image"
INDEX = OCI + ".index.v1+json"
MANIFEST = OCI + ".manifest.v1+json"
CONFIG = OCI + ".config.v1+json"
GZIP_LAYER = OCI + ".layer.v1.tar+gzip"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return "sha256:" + hashlib.sha256(data).hexdigest()


def blob_path(content_digest):
    algorithm, value = content_digest.split(":", 1)
    return f"blobs/{algorithm}/{value}"


def json_bytes(document):
    return json.dumps(document, sort_keys=True, separators=(",", ":")).encode()


def descriptor(media_type, data):
    return {"mediaType": media_type, "digest": digest(data), "size": len(data)}


def read_member(archive, name):
    member = archive.getmember(name)
    require(member.isfile(), f"{name} must be a regular file")
    with archive.extractfile(member) as payload:
        return payload.read()


def read_blob(archive, desc):
    content = read_member(archive, blob_path(desc["digest"]))
    require(
        len(content) == desc["size"] and digest(content) == desc["digest"],
        f"invalid blob {desc['digest']}",
    )
    return content


def add_member(archive, name, content=None, mode=0o644):
    info = tarfile.TarInfo(name)
    info.mode = mode
    if content is None:
        info.type = tarfile.DIRTYPE
        archive.addfile(info)
    else:
        info.size = len(content)
        archive.addfile(info, io.BytesIO(content))


def load_base():
    with tarfile.open(STAGE / "images.tar") as archive:
        docker = next(
            item for item in json.loads(read_member(archive, "manifest.json"))
            if BASE_TAG in item["RepoTags"]
        )
        oci = next(
            item for item in json.loads(read_member(archive, "index.json"))["manifests"]
            if item["annotations"].get("io.containerd.image.name") == BASE_NAME
        )
        for candidate in json.loads(read_blob(archive, oci))["manifests"]:
            platform = candidate.get("platform", {})
            if platform.get("os") != "linux" or platform.get("architecture") != "arm64":
                continue
            if blob_path(candidate["digest"]) not in archive.getnames():
                continue
            manifest = json.loads(read_blob(archive, candidate))
            if blob_path(manifest["config"]["digest"]) == docker["Config"]:
                break
        else:
            raise ValueError("staged Alpine Linux ARM64 manifest is absent")

        config = json.loads(read_blob(archive, manifest["config"]))
        require(
            config["os"] == "linux" and config["architecture"] == "arm64",
            "base config is not Linux ARM64",
        )
        require(config["config"]["Cmd"] == ["/bin/sh"], "base shell has changed")
        require(
            [blob_path(layer["digest"]) for layer in manifest["layers"]] == docker["Layers"],
            "staged Alpine OCI and Docker layers differ",
        )
        diff_ids = config["rootfs"]["diff_ids"]
        require(len(diff_ids) == len(manifest["layers"]), "base layer count differs")
        payloads = []
        shell_present = False
        for layer, diff_id in zip(manifest["layers"], diff_ids):
            require(layer["mediaType"] == GZIP_LAYER, "expected a gzip Alpine layer")
            payload = read_blob(archive, layer)
            raw = gzip.decompress(payload)
            require(digest(raw) == diff_id, "staged Alpine layer has wrong diff ID")
            with tarfile.open(fileobj=io.BytesIO(raw), mode="r:") as layer_tar:
                shell_present |= any(m.name.removeprefix("./") == "bin/sh" for m in layer_tar)
            payloads.append(payload)
        require(shell_present, "base layers do not contain /bin/sh")
        return candidate, manifest, config, payloads


def make_probe_layer():
    output = io.BytesIO()
    binaries = {}
    with tarfile.open(fileobj=output, mode="w:", format=tarfile.USTAR_FORMAT) as layer:
        add_member(layer, "mpw", mode=0o755)
        for name in PROBES:
            source = STAGE / "work" / name
            payload = source.read_bytes()
            require(
                payload[:6] == b"\x7fELF\x02\x01"
                and len(payload) >= 64
                and struct.unpack_from("<H", payload, 18)[0] == 183,
                f"{source} is not a little-endian ARM64 ELF executable",
            )
            add_member(layer, f"mpw/{name}", payload, 0o755)
            binaries[f"/mpw/{name}"] = {"sha256": digest(payload)[7:], "size": len(payload)}
    raw = output.getvalue()
    compressed = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", fileobj=compressed, mtime=0) as stream:
        stream.write(raw)
    return compressed.getvalue(), digest(raw), binaries


def verify(archive_path, tag, platform, base_payloads, base_shell, binaries):
    with tarfile.open(archive_path, "r:") as archive:
        require(
            json.loads(read_member(archive, "oci-layout")) == {"imageLayoutVersion": "1.0.0"},
            "invalid OCI layout",
        )
        index = json.loads(read_member(archive, "index.json"))
        (manifest_desc,) = index["manifests"]
        require(
            manifest_desc["annotations"]["io.containerd.image.name"] == "docker.io/" + tag
            and manifest_desc["platform"] == platform,
            "OCI index identifies a different image",
        )
        manifest = json.loads(read_blob(archive, manifest_desc))
        config = json.loads(read_blob(archive, manifest["config"]))
        require(
            config["config"]["Cmd"] == base_shell
            and config["os"] == platform["os"]
            and config["architecture"] == platform["architecture"],
            "image config changed Alpine shell or platform",
        )
        diff_ids = config["rootfs"]["diff_ids"]
        require(len(diff_ids) == len(manifest["layers"]), "image layer count differs")

        (docker,) = json.loads(read_member(archive, "manifest.json"))
        require(docker == {
            "Config": blob_path(manifest["config"]["digest"]),
            "RepoTags": [tag],
            "Layers": [blob_path(layer["digest"]) for layer in manifest["layers"]],
        }, "Docker manifest does not describe the same image")

        payloads = [read_blob(archive, layer) for layer in manifest["layers"]]
        require(payloads[:-1] == base_payloads, "archive changed the Alpine base layers")
        for payload, diff_id in zip(payloads, diff_ids):
            raw = gzip.decompress(payload)
            require(digest(raw) == diff_id, "invalid uncompressed layer digest")

        with tarfile.open(fileobj=io.BytesIO(raw), mode="r:") as layer_tar:
            require(
                layer_tar.getnames() == ["mpw", *[f"mpw/{name}" for name in PROBES]],
                "probe layer has unexpected paths",
            )
            directory = layer_tar.getmember("mpw")
            require(directory.isdir() and directory.mode == 0o755, "invalid /mpw directory")
            for image_path, expected in binaries.items():
                relative_path = image_path.removeprefix("/")
                member = layer_tar.getmember(relative_path)
                payload = read_member(layer_tar, relative_path)
                source_payload = (STAGE / "work" / member.name.removeprefix("mpw/")).read_bytes()
                require(
                    member.mode == 0o755
                    and payload == source_payload
                    and len(payload) == expected["size"]
                    and digest(payload)[7:] == expected["sha256"],
                    f"{image_path} does not match the staged executable",
                )
        return manifest_desc["digest"], manifest["config"]["digest"]


def main():
    base_desc, base_manifest, config, base_payloads = load_base()
    platform = base_desc["platform"]
    shell = config["config"]["Cmd"]
    layer_payload, diff_id, binaries = make_probe_layer()
    layers = [*base_manifest["layers"], descriptor(GZIP_LAYER, layer_payload)]
    config["rootfs"]["diff_ids"].append(diff_id)
    config["history"].append({"created_by": "Add staged Micropod probe executables"})
    config["config"].setdefault("Labels", {})["io.micropod.probes-fixture"] = STAGE.name
    config_payload = json_bytes(config)
    config_desc = descriptor(CONFIG, config_payload)
    variant = f"{STAGE.name.rsplit('-', 1)[-1]}-{config_desc['digest'][7:23]}"
    tag = f"micropod-qa/staged-probes:{variant}"

    manifest_payload = json_bytes({
        "schemaVersion": 2, "mediaType": MANIFEST, "config": config_desc, "layers": layers,
    })
    manifest_desc = descriptor(MANIFEST, manifest_payload)
    manifest_desc["annotations"] = {
        "io.containerd.image.name": "docker.io/" + tag,
        "org.opencontainers.image.ref.name": variant,
    }
    manifest_desc["platform"] = platform
    index = {"schemaVersion": 2, "mediaType": INDEX, "manifests": [manifest_desc]}
    docker = [{
        "Config": blob_path(config_desc["digest"]),
        "RepoTags": [tag],
        "Layers": [blob_path(layer["digest"]) for layer in layers],
    }]
    contents = {
        "oci-layout": json_bytes({"imageLayoutVersion": "1.0.0"}),
        "index.json": json_bytes(index),
        "manifest.json": json_bytes(docker),
        blob_path(manifest_desc["digest"]): manifest_payload,
        blob_path(config_desc["digest"]): config_payload,
    }
    for layer, payload in zip(layers, [*base_payloads, layer_payload]):
        contents[blob_path(layer["digest"])] = payload

    with tempfile.TemporaryDirectory(prefix=".build-probes-", dir=STAGE) as scratch:
        archive_path = Path(scratch) / "probes-image.tar"
        identity_path = Path(scratch) / "probes-identity.json"
        with tarfile.open(archive_path, "w:", format=tarfile.USTAR_FORMAT) as archive:
            add_member(archive, "blobs", mode=0o755)
            add_member(archive, "blobs/sha256", mode=0o755)
            for name, payload in sorted(contents.items()):
                add_member(archive, name, payload)

        manifest_digest, config_digest = verify(
            archive_path, tag, platform, base_payloads, shell, binaries,
        )
        identity = {
            "tag": tag,
            "config_digest": config_digest,
            "manifest_digest": manifest_digest,
            "archive_sha256": digest(archive_path.read_bytes())[7:],
            "platform": platform,
            "owner": STAGE.name,
            "base": {"tag": BASE_TAG, "config_digest": base_manifest["config"]["digest"]},
            "binaries": binaries,
            "layers": [
                {**layer, "diff_id": diff}
                for layer, diff in zip(layers, config["rootfs"]["diff_ids"])
            ],
        }
        identity_path.write_text(json.dumps(identity, indent=2, sort_keys=True) + "\n")
        os.replace(archive_path, STAGE / archive_path.name)
        os.replace(identity_path, STAGE / identity_path.name)
    print(f"{tag} {config_digest} (archive SHA-256 {identity['archive_sha256']})")


if __name__ == "__main__":
    main()
