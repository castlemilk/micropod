from pathlib import Path
from statistics import median
import datetime,gzip,hashlib,json,os,re,subprocess,sys,tarfile,io

s=Path(__file__).resolve().parent
w=Path.cwd()
out=w/'docs/benchmarks/2026-11-25'
outname='phase-b4-ci-density-and-events'
def sha(p):
    with p.open('rb') as fp: return hashlib.file_digest(fp,'sha256').hexdigest()
def read(path):return json.loads(path.read_bytes())
def mid(vals):return round(median(vals),3)
def direct_rows(members):
    rows=[]
    for n in members:
        run=runs[n]
        assert run['engines']['micropod']['NCPU']==run['engines']['orbstack']['NCPU']==4
        assert all(3.5*(1<<30)<=run['engines'][side]['MemTotal']<=4.25*(1<<30) for side in ('micropod','orbstack'))
        for pair in run['direct']['pairs']:
            row={'run':n,'order':pair['order'],'engines':{}}
            for side,arm in pair['arms'].items():
                load=arm['dense_compile']
                bulk,=arm['raw']['bulk_verification']; fg,=load['foreground']
                assert len(load['workers'])==32 and len({v['id'] for v in load['workers']})==32
                assert bulk['streams']==len(bulk['accepted_tcp_congestion'])==32
                assert bulk['reopened_connections']==0 and bulk['bytes']==32*(8<<20)*bulk['iterations']
                assert load['cpu_quota_us']*16==load['cpu_period_us'] and load['memory_limit_bytes']==128<<20
                assert all(x['tail'] >= x['after'] > x['before'] > x['ready'] and x['cpu_quota_us']==load['cpu_quota_us'] for x in load['workers'])
                if side=='cubic': assert set(bulk['accepted_tcp_congestion'])=={'cubic'}
                placement=load.get('compiler_placement')
                if placement=='native-cpu-group':
                    assert all(x['eth0_present'] is False for x in load['workers'])
                    assert list(sorted(load['compiler_workers_per_cpu'].values()))==[8,8,8,8]
                elapsed=bulk['elapsed_s']; assert fg['netbench_elapsed_s']==elapsed
                e={'mib_s':bulk['mib_s'],'bytes':bulk['bytes'],'algorithms':sorted(set(bulk['accepted_tcp_congestion'])),
                   'wall_s':elapsed,'quota_us':load['cpu_quota_us'],'period_us':load['cpu_period_us'],
                   'workers_with_confirmed_compiles':fg['workers_with_confirmed_completions'],
                   'placement':placement,'guest_boot_id':fg['guest_boot_id'],'affinities':sorted(set(x['allowed_cpus'] for x in load['workers'])),
                   'quiet_http_p50_us':arm['quiet_unrestricted_p50_us'],'quiet_http_p95_us':arm['quiet_unrestricted_p95_us'],
                   'dns32_p95_us':arm['dns32_p95_us']}
                for name,key,unit in [('cpu_cores','cpu_usage_ns_bounds',1e9),
                                      ('completed_compiles_per_s','completed_compiles_bounds',1),
                                      ('reported_compiles_per_s','reported_completions_bounds',1),
                                      ('throttle_periods_per_s','nr_throttled_bounds',1)]:
                    e[name]=[round(v/elapsed/unit,4) for v in fg[key]]
                row['engines']['hvf' if side=='cubic' else side]=e
            row['gain_pct']=round(100*(row['engines']['hvf']['mib_s']/row['engines']['orbstack']['mib_s']-1),4)
            rows.append(row)
    summary={}
    for name in ['hvf','orbstack']:
        a=[r['engines'][name] for r in rows]
        summary[name]={k:mid(x[k] for x in a) for k in ('mib_s','quiet_http_p50_us','quiet_http_p95_us','dns32_p95_us')}
        summary[name].update({k:[mid(x[k][i] for x in a) for i in (0,1)] for k in ('cpu_cores','completed_compiles_per_s','reported_compiles_per_s')})
        summary[name]['min_confirmed_workers']=min(x['workers_with_confirmed_compiles'] for x in a)
    return {'pairs':rows,'wins':sum(x['gain_pct']>0 for x in rows),'pair_count':len(rows),'median_paired_gain_pct':mid(x['gain_pct'] for x in rows),'summary':summary}
def dump_gz(path,obj):
    with path.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as gz:
        gz.write(json.dumps(obj,separators=(',',':')).encode())
runs={}
for p in sorted(s.glob('*.json')):
    if p.stat().st_size==0:continue
    d=read(p)
    if isinstance(d,dict) and d.get('name')==p.stem and d.get('workspace_drive',{}).get('detached'):runs[p.stem]=d
groups={'image-6g-default':['dense-default-short'],'image-60g-default':['dense-default-a','dense-default-b'],
        'image-60g-buddy-only':['dense-buddy-a'],'image-6g-32ms':['dense-32ms-short'],
        'image-60g-32ms':['dense-32ms-long'],'image-6g-spread':['dense-spread-short'],
        'image-60g-spread':['dense-spread-long'],'share-6g-default':['share-default-short'],
        'share-6g-spread':['share-spread-short-retry'],'share-6g-ambient':['share-spread-ambient'],
        'integrated-share-6g':['integrated-share'],'integrated-share-unpinned-6g':['integrated-share-default'],
        'integrated-60g':['integrated-long'],'integrated-6g':['integrated-short']}
scored={group:direct_rows(v) for group,v in groups.items() if all('direct' in runs.get(r,{}) for r in v)}
drives=[]
for n,d in runs.items():
    for key in ('drive','workspace_drive'):
        if key not in d: continue
        entry=d[key];z=entry['detached'];p=z['persisted_policy']
        assert z['detached'] and z['image_absent'] and z['mount_restored'] and p['mounted_read_only']
        assert p['markers']['no_log'] and p['spotlight']['disabled'] and p['fsevents']['journal_files']==0
        assert not Path(z['image']).exists() and not Path(z['mount']).exists()
        if key=='drive':
            assert entry['shutdown']['process_group_absent'] and entry['shutdown']['disk_holders']==[]
        drives.append({'run':n,'kind':key,'mount':z['mount'],'policy_validated':True})
    if 'image_fixture' in d: assert d['image_fixture']['reclaimed']==['micropod','orbstack']
fs={}
for kind in ['base','fs','orb','integrated','latest','recheck','8ms','20ms']:
    chosen=[d['workspace'] for n,d in runs.items() if n.startswith('ws-'+kind+'-') and 'workspace' in d]
    if not chosen:continue
    fs[kind]={'fixture_count':len(chosen),'complete_edits':[d['complete'] for d in chosen],
              'read_ms_per_fixture':[[p['read_ms'] for p in d['scans']] for d in chosen],
              'stat_ms_per_fixture':[[p['stat_ms'] for p in d['scans']] for d in chosen]}
    fs[kind]['read_ms']=mid(median(v) for v in fs[kind]['read_ms_per_fixture'])
    fs[kind]['stat_ms']=mid(median(v) for v in fs[kind]['stat_ms_per_fixture'])
    fs[kind]['edit_medians_ms']={k:[d['median_observed_ms'].get(k) for d in chosen] for k in ('size','held','replace','unlink')}
    for d in chosen:
        for p in d['scans']:
            assert p['files']==512 and p['bytes']==p['read_bytes']==20772
            assert p['path_sha256']=='e64b63c69253b0a44b1ec5b497335b3236faf52fc25743c761718b3f110ca878'
            assert p['sha256']=='760cda3100af7b8d352897b31f3cce28cff7ac936856b69c2464fd1d0090f99c'
if 'base' in fs and 'fs' in fs:
    fs['paired_read_reduction_pct']=[round(100*(1-median(b)/median(a)),3) for a,b in zip(fs['base']['read_ms_per_fixture'],fs['fs']['read_ms_per_fixture'])]
ev={}
for n,d in runs.items():
    if 'events' in d:
        e=d['events'];ev[n]={k:e[k] for k in ('listener_counts','listener_release_seconds','released_before_deadline','cleanup','completed_execs','replayed_exec_events') if k in e}
        ev[n]['live_actions']=[v['Action'] for v in e['live_engine']];ev[n]['workspace_roundtrip']=d.get('workspace_roundtrip')
        ev[n]['guest_tests']=d.get('guest_test_count')
        ev[n]['fsync']=d.get('fsync')
for p in (s/'orb-events3.json',s/'orb-events-final.json'):
    if p.exists() and p.stat().st_size:
        d=read(p);ev[p.stem]={k:d[k] for k in ('listener_counts','listener_release_seconds','released_before_deadline','completed_execs','replayed_exec_events') if k in d}
sys.path.insert(0,str(w/'docs/benchmarks/2026-11-24/gamma-ci-concurrency'))
import qualify
baseline=qualify.check_baseline()
report={'host':'Gamma-128GB.local','scored':scored,'workspace':fs,'events':ev,'baseline_files':baseline,
        'baseline_manifest_sha256':qualify.BASELINE_SHA,'protected_drives':drives,'qualified_installation':read(s/'installation-verified.json'),
        'source_identity':{n:r.get('artifacts',{}) for n,r in runs.items() if r.get('artifacts')},'attempts':{n:r.get('error') for n,r in runs.items()}}
report['hygiene']=read(s/'final-hygiene.json') if (s/'final-hygiene.json').exists() else None
report['hardware_simd_passed']='1 passed; 0 failed' in (s/'simd-hardware.log').read_text()
report['mixed_workspace_rejection']=runs.get('mixed-workspace-rejection',{}).get('diagnosis')
if '--save' in sys.argv:
    raw={'runs':runs,'orbstack':{p.stem:read(p) for p in s.glob('orb-events*.json') if p.stat().st_size},
         'harness_scripts':{k:(s/k).read_text() for k in ['run.py','collect_density.py','build_probes_image.py','scheduler-observer.sh','syncprobe.go','mixed_workspace.py']},
         'verification_logs':{p.name:p.read_text(errors='replace') for p in s.glob('*.log')},
         'hygiene':report['hygiene'],'fixture_identity':read(s/'probes-identity.json'),'macos_runtime':{'product':subprocess.check_output(['sw_vers'],text=True),'hardware':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip()},'hardware_simd_log':(s/'simd-hardware.log').read_text(),'qualified_installation':report['qualified_installation']}
    target=out/(outname+'-receipts.json.gz');dump_gz(target,raw);report['receipts_sha256']=sha(target)
    src=out/(outname+'-sources.tar.gz')
    if src.exists():report['sources_sha256']=sha(src)
    (out/(outname+'.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'scored':{n:[v['wins'],v['pair_count'],v['median_paired_gain_pct'],v['summary']['hvf'],v['summary']['orbstack']] for n,v in scored.items()},'files':fs,'events':ev,'volumes':len(drives),'attempts':{n:r.get('error') for n,r in runs.items() if r.get('error')}},indent=2))
