from pathlib import Path
import gzip,hashlib,json,plistlib,subprocess,sys
w=Path.cwd();s=Path(__file__).resolve().parent
target=w/'docs/benchmarks/2026-11-25'
def docker(*args,check=True):
    return subprocess.run(['docker','--context','orbstack',*args],capture_output=True,text=True,timeout=18,check=check)
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
expected=set();mounts=set();images=set();native_jobs=0
for p in s.glob('*.json'):
    if p.stat().st_size==0:continue
    d=json.loads(p.read_bytes())
    if not isinstance(d,dict) or d.get('name')!=p.stem or not d.get('workspace_drive',{}).get('detached'): continue
    for key in ('drive','workspace_drive'):
        if key not in d:continue
        info=d[key]['detached']
        mounts.add(info['mount']);images.add(info['image'])
        assert info['image_absent'] and not Path(info['mount']).exists() and not Path(info['image']).exists()
    for pair in d.get('direct',{}).get('pairs',[]):
        for arm in pair['arms'].values():
            expected.add(arm['scope'].split('=',1)[1])
            if 'dense_compile' in arm:
                expected.add(arm['dense_compile']['scope'].split('=',1)[-1])
                if arm['dense_compile'].get('compiler_placement')=='native-cpu-group':native_jobs+=len(arm['dense_compile']['workers'])
active=set()
for label in ('com.micropod.benchmark.dense','com.micropod.benchmark.scope'):
    vals=docker('ps','-a','--filter','label='+label,'--format','{{.Label "'+label+'"}}').stdout.splitlines()
    active.update(map(str.strip,vals))
result=docker('network','ls','-q','--filter','label=com.micropod.benchmark.scope').stdout.splitlines()
for network in result:
    labs=json.loads(docker('network','inspect','--format','{{json .Labels}}',network).stdout)
    active.add(labs.get('com.micropod.benchmark.scope',''))
assert not (expected & active),expected & active
spec=json.loads((s/'probes-identity.json').read_bytes());removed=docker('image','inspect',spec['tag'],check=False)
assert removed.returncode!=0 and any(msg in removed.stderr.lower() for msg in ('no such','not found'))
tagged=docker('ps','-a','--filter','label=io.micropod.qualification','--format','{{.Names}}').stdout.splitlines()
assert not [n for n in tagged if n.startswith('mp-events-')]
plist=plistlib.loads(subprocess.check_output(['hdiutil','info','-plist']))
assert all(a.get('image-path') not in images and not any(v.get('mount-point') in mounts for v in a.get('system-entities',[])) for a in plist.get('images',[]))
q=json.load(gzip.open(w/'docs/benchmarks/2026-11-21/gamma-vcpu-priority.json.gz','rt'))['installation']
root=Path(q['path'])
assert all(sha(root/'micropod-oci-tools'/k)==v for k,v in q['tools'].items())
assert sha(root/'micropod')==q['host_sha256'] and sha(root/'micropod-oci')==q['oci_sha256']
sys.path.insert(0,str(w/'docs/benchmarks/2026-11-24/gamma-ci-concurrency'));import qualify
baseline=qualify.check_baseline()
proof={'drives':len(images),'owned_container_and_network_scopes':len(expected),'owned_scopes_remaining':0,
       'unique_fixture_tag_absent':spec['tag'],'mounts_in_hdiutil':0,'native_group_placements_verified':native_jobs,
       'stock_events_listener_count_after':int(docker('info','--format','{{.NEventsListener}}').stdout),
       'verified_installed_guest_artifacts':len(q['tools']),'verified_installed_host_artifacts':2,
       'original_and_preserved_baseline_files_each':baseline}
(s/'final-hygiene.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
