from pathlib import Path
import json,os,subprocess,sys,tempfile,time,traceback
s=Path(__file__).parent
sys.path.insert(0,str(Path.cwd()/'scripts'))
import bench_engine_tuning as b
name='mixed-workspace-rejection'
class Managed(b.WorkerHandle):
    def env(self):
        return {**super().env(),'MICROPOD_CI_VMM':'hvf','MICROPOD_CI_DISK_GIB':'6',
                'MICROPOD_CI_HVF_BIN':str(s/'vmm-base'),'MICROPOD_CI_HVF_INITRD':str(s/'initrd')}
ws=b.BenchmarkWorkerDrive(Path(tempfile.mkdtemp(dir='/private/tmp',prefix='mp-mixed-ws-')))
m=None
d={'name':name,'engine':'hvf','action':'mixed-version workspace admission'}
try:
    ws.attach()
    ws.receipts['live']=ws.apfs.verify(ws.receipts['created'])
    work=ws.home/'source tree "v1"';work.mkdir()
    m=Managed('mixed',s/'micropod-final',s/'tools-negative',s/'Image','',work)
    m.drive.attach();m._log_file=m.drive.open_log('serve.log')
    m.proc=subprocess.Popen([str(m.micropod_bin),'ci','serve'],env=m.env(),stdin=subprocess.DEVNULL,stdout=m._log_file,stderr=subprocess.STDOUT,start_new_session=True)
    end=time.monotonic()+100
    while m.proc.poll() is None and time.monotonic()<end: time.sleep(.1)
    m._log_file.flush()
    log=m.drive.log[0].read_text(errors='replace')
    d['diagnosis']=[line for line in log.splitlines() if 'did not attest its workspace' in line]
    d['exit']=m.proc.poll()
    assert d['exit'] not in (None,0) and d['diagnosis'],(d['exit'],log[-1400:])
    if m.drive.disk.exists():m.drive.verify_live(6<<30)
    d['ok']=True
except BaseException as ex:
    d['error']=repr(ex);raise
finally:
    try:
        if m:d['drive']=m.stop()
    finally:
        try:d['workspace_drive']=ws.close()
        finally:(s/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n')
