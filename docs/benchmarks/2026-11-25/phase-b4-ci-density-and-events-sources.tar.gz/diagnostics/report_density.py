from pathlib import Path
from statistics import median
import json
s=Path(__file__).resolve().parent
out=Path.cwd()/'docs/benchmarks/2026-11-25';stem='phase-b4-ci-density-and-events'
j=json.loads((out/(stem+'.json')).read_bytes());sc=j['scored'];fs=j['workspace']
doc=(s/'report-template.md').read_text()
long_run=sc['integrated-60g']
share=sc['integrated-share-unpinned-6g']
doc=doc.replace('@@RESULT@@', (
    f"On the final 60 GiB run with the compiler inside the image, HVF led in {long_run['wins']} of {long_run['pair_count']} pairs "
    f"with a median paired change of {long_run['median_paired_gain_pct']:+.2f}%. "
    f"With the compiler on a host share and default CPU placement, the 6 GiB run recorded {share['median_paired_gain_pct']:+.2f}% "
    f"against OrbStack. A 512-file open/read/hash took {fs['8ms']['read_ms']:.2f} ms on the 8 ms HVF configuration "
    f"and {fs['orb']['read_ms']:.2f} ms on OrbStack."
))
def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','|'+'|'.join(['---']+['---:']*(len(headers)-1))+'|',*['| '+' | '.join(map(str,a))+' |' for a in rows]])
e=[]
for n,label in [('events-hvf-final','HVF'),('events-vz-final','VZ'),('events-b5-smoke','Full snapshot branch, normal HVF boot'),('orb-events-final','OrbStack')]:
    v=j['events'][n];e.append([label,' / '.join(map(str,v['listener_counts'])),f"{v['listener_release_seconds']:.3f} s",v.get('guest_tests') or '—'])
doc=doc.replace('@@EVENTS@@',table(['Final socket','Before / subscribed / closed','Time to release','Guest tests'],e))
names={'image-6g-default':'Initial image, default','image-60g-default':'Initial image, default','image-60g-buddy-only':'Image, wakeup co-location disabled','image-6g-32ms':'Image, 32 ms quota period','image-60g-32ms':'Image, 32 ms quota period','image-6g-spread':'Image, explicit round-robin','image-60g-spread':'Image, explicit round-robin','share-6g-default':'Initial host share, default','share-6g-spread':'Initial host share, explicit round-robin','integrated-6g':'Integrated image, CI groups','integrated-share-unpinned-6g':'Integrated host share, default','integrated-share-6g':'Integrated host share, CI groups','integrated-60g':'Snapshot branch on normal boot, image, default'}
net=[];work=[]
for n,label in names.items():
    v=sc[n];x=v['summary'];size=v['pairs'][0]['engines']['hvf']['bytes']>>30
    net.append([label,str(size)+' GiB',f"{x['hvf']['mib_s']:,.0f}",f"{x['orbstack']['mib_s']:,.0f}",f"{v['median_paired_gain_pct']:+.2f}%",f"{v['wins']}/{v['pair_count']}"])
    if n in ('image-60g-default','integrated-60g','integrated-share-unpinned-6g','integrated-share-6g'):
        row=[f"{label}, {size} GiB"]
        for side in ('hvf','orbstack'):
            lo,hi=x[side]['reported_compiles_per_s'];row.append(f'{lo:.1f}–{hi:.1f}')
        work.append(row)
doc=doc.replace('@@NETWORK@@',table(['Compiler and profile','Transfer','HVF MiB/s','OrbStack MiB/s','Change','HVF wins'],net))
doc=doc.replace('@@WORK@@',table(['Workload','HVF reported compiles/s','OrbStack reported compiles/s'],work))
labels={'base':'Initial HVF','fs':'Small-packet reuse candidate','recheck':'Initial HVF, later crossover','integrated':'Integrated HVF, 20 ms','20ms':'Fixed code, 20 ms','8ms':'Fixed code, 8 ms','orb':'OrbStack'}
r=[]
for k,label in labels.items():
    v=fs[k];r.append([label,v['fixture_count'],f"{v['read_ms']:.2f} ms",f"{sum(v['complete_edits'])}/{v['fixture_count']}"])
doc=doc.replace('@@WORKSPACE@@',table(['Source or reference','Completed scan fixtures','Median open/read/hash','All edit checks passed'],r))
a,b=fs['8ms'],fs['20ms']
def m(row,key):return median(row['edit_medians_ms'][key])
ttl=(f"On the same VMM code, the 8 ms attribute lifetime acknowledged a held-descriptor overwrite in {m(a,'held'):.2f} ms versus {m(b,'held'):.2f} ms at 20 ms. The corresponding 512-file read medians were {a['read_ms']:.2f} and {b['read_ms']:.2f} ms in two fixtures per setting. "
     "All 96 edit acknowledgements across the two settings passed. These measurements cover this source tree and this host.")
doc=doc.replace('@@TTL@@',ttl)
num=len(j['protected_drives'])
doc=doc.replace('@@CLEANUP@@', f"All {num} disposable APFS volumes in these receipts had Spotlight indexing disabled, the FSEvents no-log marker present and zero persistent journal files at read-only remount. Every measured worker released its process group and disk handles. The 24 original baseline files and their 24 preserved copies still match their recorded SHA-256 values. [Original controlled and ambient QoS and worker results](../2026-11-24/gamma-qos-and-workers/results.md)")
assert '@@' not in doc
(out/(stem+'.md')).write_text(doc)
