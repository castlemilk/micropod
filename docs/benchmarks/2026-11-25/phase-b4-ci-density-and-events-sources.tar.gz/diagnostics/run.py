from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,subprocess,sys,tempfile,time
root=Path.cwd()
stage=Path(__file__).parent
sys.path.insert(0,str(root/'scripts'))
import bench_engine_tuning as b
p=argparse.ArgumentParser()
p.add_argument('name');p.add_argument('engine');p.add_argument('action')
p.add_argument('--rounds',type=int,default=5);p.add_argument('--vmm',default='vmm-base');p.add_argument('--tools',default='tools')
p.add_argument('--kernel',default='Image');p.add_argument('--cli',default='micropod')
p.add_argument('--compiler-cpus')
p.add_argument('--kernel-args',default='')
p.add_argument('--period',type=int,default=100000)
p.add_argument('--bursts',type=int,default=24)
p.add_argument('--workspace-name',default='fixture')
p.add_argument('--spread-cpus')
p.add_argument('--native-groups', action='store_true')
p.add_argument('--initrd',default='initrd')
p.add_argument('--fsprobe',default='fsprobe');p.add_argument('--runner-test',default='runner.test')
p.add_argument('--admit-quiet',action='store_true')
p.add_argument('--image-probes',action='store_true');p.add_argument('--image-compiler',action='store_true')
a=p.parse_args()
receipt=stage/(a.name+'.json')
assert not receipt.exists()
def save():receipt.write_text(json.dumps(data,indent=2)+'\n')
def sha(file):
    with file.open('rb') as fp:return hashlib.file_digest(fp,'sha256').hexdigest()
def cmd(args,env=None,ok=True,timeout=120):
    ps=subprocess.run([str(x) for x in args],env=env,timeout=timeout,text=True,capture_output=True,stdin=subprocess.DEVNULL)
    if ok and ps.returncode: raise RuntimeError((args,ps.returncode,ps.stdout[-600:],ps.stderr[-1400:]))
    return ps
def system_idle():
    out=cmd(['top','-l','2','-s','1','-n','0']).stdout
    return [x.strip() for x in out.splitlines() if 'CPU usage:' in x][-1]
def image_id(sock,tag):
    inspected=b.docker(sock,'image','inspect','-f','{{.Id}}',tag,check=False,timeout=20)
    if not inspected.returncode:return inspected.stdout.strip()
    if 'not found' in inspected.stderr.lower() or 'no such' in inspected.stderr.lower():return None
    raise RuntimeError(('cannot inspect owned fixture',inspected.stderr))
data={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'name':a.name,'engine':a.engine,'action':a.action,'rounds':a.rounds,'host':cmd(['hostname']).stdout.strip()}
class Managed(b.WorkerHandle):
    def env(self):
        e=super().env()
        return {**e,'MICROPOD_CI_VMM':a.engine,'MICROPOD_CI_DISK_GIB':'6','MICROPOD_CI_HVF_BIN':str(stage/a.vmm),'MICROPOD_CI_HVF_INITRD':str(stage/a.initrd)}
store=b.BenchmarkWorkerDrive(Path(tempfile.mkdtemp(prefix='mp-wsf-',dir='/private/tmp')))
worker=None
snapshot_probe=None
fixture_targets=[]
sock=b.ORB_SOCK
try:
    store.attach()
    store.receipts['live']=store.apfs.verify(store.receipts['created'])
    # Only expose the benchmark workspace subdirectory to each guest.
    assert Path(a.workspace_name).name == a.workspace_name and a.workspace_name not in ('','.', '..')
    work=store.home/a.workspace_name;work.mkdir()
    for binary in ('netbench-linux','quiet-http'):shutil.copy2(stage/'work'/binary,work/binary)
    shutil.copy2(stage/'work'/a.fsprobe,work/'fsprobe')
    if a.engine!='orb':
        tools_dir=stage/a.tools
        if a.action=='snapshots':
            from snapshot_gate import SnapshotGate
            snapshot_probe=SnapshotGate(stage,tools_dir,work)
            tools_dir=snapshot_probe.tools
        worker=Managed('opt',stage/a.cli,tools_dir,stage/a.kernel,a.kernel_args,work)
        data['boot_s']=worker.start();sock=worker.sock;env=worker.env()
        data['status']=json.loads(cmd([stage/a.cli,'ci','runner-status'],env).stdout)
        assert data['status']['vmm']==a.engine
        ep=cmd([stage/a.cli,'ci','runner-docker-endpoint'],env).stdout.strip()
        assert Path(ep.removeprefix('unix://')).samefile(sock)
        b.load_images(sock,stage/'images.tar')
        data['artifacts']={str(k.relative_to(stage)):sha(k) for k in [stage/a.vmm,stage/a.kernel,stage/a.initrd,stage/a.tools/'runner/bin/job',stage/a.cli]}
    data['engine_info']=b.docker(sock,'info','--format','{{.NCPU}} {{.MemTotal}} {{.ServerVersion}}').stdout.strip()
    if a.engine!='orb':
        data['guest_network_policy']=b.docker(sock,'run','--rm','--network','none','--pull=never','alpine:3.23','sh','-ec','cat /proc/cmdline /proc/sys/net/ipv4/tcp_congestion_control /proc/sys/net/ipv4/tcp_available_congestion_control').stdout
        data['artifacts']['worker_start_script']=sha(tools_dir/'runner/start.sh')
        if a.engine=='hvf':
            features=(work/'qa-scheduler').read_text().splitlines()
            data['scheduler']={'features':features[0], 'base_slice_ns':int(features[1]),'cc':features[2], 'available_cc':features[3],'qdisc':features[4],'cfs_bandwidth_slice_us':int(features[5]), 'cmdline':features[6]}
            expect_sync='micropod.ci_wakeup=next-buddy' not in a.kernel_args.split()
            actual=set(features[0].split())
            assert ('SYNC_COLOCATE' if expect_sync else 'NO_SYNC_COLOCATE') in actual
            assert all(k in actual for k in ('HRTICK','NEXT_BUDDY','TTWU_QUEUE'))
            assert features[2]=='cubic' and features[1]=='250000'
            for selector in ('ci_sched','ci_wakeup','ci_cc'):
                assert sum(x.startswith('micropod.'+selector+'=') for x in features[6].split())==1
    if a.image_probes:
        spec=json.loads((stage/'probes-identity.json').read_text())
        tag=spec['tag'];expected=spec['config_digest']
        data['image_fixture']={'tag':tag,'id':expected,'archive_sha256':sha(stage/'probes-image.tar'),'reclaimed':[]}
        for side,endpoint in [('micropod',sock),('orbstack',b.ORB_SOCK)]:
            assert image_id(endpoint,tag) is None
            fixture_targets.append((side,endpoint))
            b.load_images(endpoint,stage/'probes-image.tar')
            loaded=image_id(endpoint,tag)
            assert loaded in (expected,spec['manifest_digest']), (side,loaded)
            data['image_fixture'][side+'_id']=loaded
    data['observed_load']=system_idle()
    data['reference_running_before_fixture']=len(b.docker(b.ORB_SOCK,'ps','-q',timeout=12).stdout.splitlines())

    save()
    if a.admit_quiet:
        import re
        observed=[]
        for attempt in range(100):
            observed.append(system_idle())
            if len(observed)>=2 and all(float(re.search(r'([0-9.]+)% idle',x)[1])>=90 for x in observed[-2:]):break
        else:
            data['idle_admission']=observed;save();raise RuntimeError('quiet admission window elapsed')
        data['idle_admission']=observed
        save()
    if a.action=='events':
        import csv,io,uuid
        def mount_flag(target,ro=False):
            out=io.StringIO(); fields=['type=bind','source='+str(work),'target='+target]
            if ro: fields+=['readonly']
            csv.writer(out,lineterminator='').writerow(fields)
            return out.getvalue()
        tok=uuid.uuid4().hex; (work/'host-marker').write_text(tok)
        check=b.docker(sock,'run','--rm','--pull=never','--network','none','--mount',mount_flag('/proof'),'alpine:3.23','sh','-ec','test "$(cat /proof/host-marker)" = "$1"; printf %s "$1" > /proof/guest-marker','sh',tok)
        assert (work/'guest-marker').read_text()==tok
        data['workspace_roundtrip']={'name':work.name,'host_to_guest_to_host':True,'marker_sha256':sha(work/'guest-marker')}
        data['api_labels']=json.loads(b.docker(sock,'info','--format','{{json .Labels}}').stdout)
        if a.cli=='micropod-final':
            if a.engine=='hvf' and ' ' in work.name:
                expect='io.micropod.workspace-sha256='+hashlib.sha256(os.fsencode(work)).hexdigest()
                assert expect in data['api_labels']
            shutil.copy2(stage/'work/syncprobe',work/'syncprobe')
            sync=b.docker(sock,'run','--rm','--network','none','--pull=never','--mount',mount_flag('/proof'),'alpine:3.23','/proof/syncprobe','/proof',tok)
            sync_receipt=json.loads(sync.stdout); leaf=sync_receipt['directory']
            assert Path(leaf).name==leaf and leaf.startswith('sync-')
            assert sync_receipt['file_synced'] and sync_receipt['directory_synced'] and sha(work/leaf/'committed')==sync_receipt['sha256']==sha(work/'host-marker')
            data['fsync']=sync_receipt
            bind=mount_flag('/proof',True)
            shutil.copy2(stage/'work/events.test',work/'events.test')
            out=b.docker(sock,'run','--rm','--pull=never','--network','none','--mount',bind,'alpine:3.23','/proof/events.test','-test.v','-test.run','TestDockerEvent|TestDockerExec.*Event|TestDockerInfoAttestsTheEffectiveWorkspace|TestDockerKillPublishesOnlyAnAcknowledgedRequest|TestDockerCPUGroup|TestDockerOfflineCPUGroup',timeout=60)
            data['linux_event_test_log']=out.stdout
            data['guest_test_count']=sum(x.startswith('--- PASS:') for x in out.stdout.splitlines())
            assert data['guest_test_count']>=8 and 'PASS: TestDockerInfoAttestsTheEffectiveWorkspace' in out.stdout


        ps=cmd([sys.executable,'-B',root/'scripts/qualify_docker_events.py','--host','unix://'+str(sock)],ok=False,timeout=135)
        data['events_run']={'rc':ps.returncode,'stderr':ps.stderr}
        if ps.stdout.strip(): data['events']=json.loads(ps.stdout)
        if ps.returncode: raise RuntimeError(ps.stderr[-1900:])
    elif a.action=='workspace':
        data['probe_sha256']=sha(stage/'work'/a.fsprobe)
        result=cmd([sys.executable,'-B',stage/'bench_workspace_final.py','--host','unix://'+str(sock),'--workspace',work,'--probe',stage/'work'/a.fsprobe,'--rounds',str(a.rounds)],ok=False,timeout=170)
        if not result.stdout.strip(): raise RuntimeError(result.stderr[-1900:])
        data['workspace']=json.loads(result.stdout)
        assert result.returncode in (0,1) and data['workspace']['complete']==(result.returncode==0)
    elif a.action=='snapshots':
        data['rootfs_reclaim']={}
        snapshot_probe.run(b.docker,sock,data['rootfs_reclaim'],save,expected_instance=data['status']['instance'])
    elif a.action=='recovery':
        import recovery
        data['recovery']={}
        recovery.run(worker,stage/a.cli,b,cmd,env,data['recovery'],save)
    elif a.action in ('qualified','storage'):
        if a.action=='qualified':
            shutil.copy2(stage/'work'/a.runner_test,work/'runner.test')
            tests=b.docker(sock,'run','--rm','--network','none','--pull','never','-v',str(work)+':/qa:ro','alpine:3.23','/qa/runner.test','-test.v','-test.run','TestDockerWritableRootFS|TestDockerRootFS|TestDockerRestart|TestDockerWaitReturnsTheOriginal|TestDockerInfoAdvertisesRestartCapability|TestDockerStopKeepsOriginal|TestDockerEntrypointOwnsPIDNamespace',timeout=75)
            data['linux_test_log']=tests.stdout
            assert 'PASS: TestDockerWritableRootFSDetachesOnlyOwnedScratch' in tests.stdout and 'PASS: TestDockerWaitReturnsTheOriginalExitAfterReplacement' in tests.stdout
            cfg=stage/'private-registry.json';cfg.write_text(json.dumps({'default':'ci','engines':{n:{'enabled':n=='ci'} for n in ('ci','sandbox','apple','docker')}}))
            apple=stage/'inert-apple';apple.write_text('#!/bin/sh\nprintf "[]\\n"\n');apple.chmod(0o700)
            menv={**env,'MICROPOD_RUNTIMES_CONFIG':str(cfg),'MICROPOD_CONTAINER_CLI_PATH':str(apple),'MICROPOD_RUNTIME':'cli','NO_COLOR':'1'}
            mp=[stage/a.cli]
            catalog=json.loads(cmd([*mp,'runtime','ls','--json'],menv).stdout)
            rows=catalog if isinstance(catalog,list) else catalog['runtimes']
            native=next(x for x in rows if x['name']=='ci');data['ci_catalog']=native
            assert native['available'] and 'restart' in native['capabilities']
            import uuid
            token='qa-restart-'+uuid.uuid4().hex[:12]
            try:
                cmd([*mp,'run','--runtime','ci','--name',token,'--label','io.micropod.qa='+token,'alpine:3.23','sleep','90'],menv)
                cid=b.docker(sock,'inspect','-f','{{.Id}}',token).stdout.strip()
                b.docker(sock,'exec',cid,'sh','-ec','printf %s "$1" >/root/verified','sh',token)
                before=b.docker(sock,'inspect','-f','{{.State.StartedAt}}',cid).stdout.strip()
                cmd([*mp,'restart',token],menv)
                after=b.docker(sock,'inspect','-f','{{.State.StartedAt}}',cid).stdout.strip()
                assert before!=after and b.docker(sock,'exec',cid,'cat','/root/verified').stdout==token
                data['micropod_restart']={'id':cid,'first':before,'second':after,'marker_retained':True}
            finally:
                ids=b.docker(sock,'ps','-aq','--filter','label=io.micropod.qa='+token).stdout.splitlines()
                if ids: b.docker(sock,'rm','-f',*ids)
            save()

        ps=cmd([sys.executable,'-B',root/'scripts/qualify_docker_restart.py','--host','unix://'+str(sock),'--json'],ok=False,timeout=150)
        data['restart']={'code':ps.returncode,'stdout':ps.stdout,'stderr':ps.stderr}
        save()
        if ps.returncode: raise RuntimeError(('restart gate',ps.stderr[-1400:]))
    elif a.action=='cpu-placement':
        snippet="""set -e
printf 'entrypoint PID: %s\\n' "$$"
printf 'PID1 command: '; cat /proc/1/comm
printf 'pid1 affinity: '; awk '/^Cpus_allowed_list:/ {print $2}' /proc/1/status
printf 'shell affinity: '; awk '/^Cpus_allowed_list:/ {print $2}' /proc/self/status
for f in /sys/fs/cgroup/cpuset.cpus /sys/fs/cgroup/cpuset.cpus.effective /sys/fs/cgroup/cpuset/cpuset.cpus /sys/fs/cgroup/cpu.max; do [ ! -r "$f" ] || { printf '%s ' "$f"; cat "$f"; }; done
printf 'taskset: '; taskset -p $$ || true
printf 'limit to CPU0: '; taskset -p 1 $$ || true
"""
        data['placement']={}
        for label,target in [('orbstack',b.ORB_SOCK),('micropod',sock)]:
            data['placement'][label]=b.docker(target,'run','--rm','--pull=never','--network','none','--cpuset-cpus','2-3','--cpu-quota','6250','--cpu-period','100000','alpine:3.23','sh','-c',snippet).stdout
    elif a.action in ('live-quiet','live-dense'):
        measured=stage/(a.name+'-direct.json')
        extras=[]
        if a.action=='live-dense':
            shutil.copy2(stage/'work/compile',work/'compile')
            extras=['--dense','--compiler-period-us',str(a.period),'--bulk-bursts',str(a.bursts)]
            if a.compiler_cpus:extras+=['--compiler-cpus',a.compiler_cpus]
            if a.spread_cpus:extras+=['--compiler-spread-cpus',a.spread_cpus]
            if a.native_groups:extras+=['--native-compiler-groups']
        if a.image_probes:extras+=['--probe-image',tag,'--probe-manifest',stage/'probes-manifest.json']
        if a.image_compiler:extras+=['--compiler-in-image']
        q=cmd([sys.executable,'-B',root/'scripts/bench_engine_tuning.py','live-siblings','--hvf-socket',sock,'--workspace',work,'--pairs',str(a.rounds),'--out',measured,*extras],timeout=420)
        result=json.loads(measured.read_text())
        data['engines']=result['engines'];data['direct']=result['direct']
        print(q.stdout,flush=True)
    elif a.action=='dense':
        shutil.copy2(stage/'work/compile',work/'compile')
        data['direct']=b.bench_live_sibling_pairs(sock,b.ORB_SOCK,work,net_driver='ipvlan',pairs=a.rounds,dense_compile=True,compiler_cpus=a.compiler_cpus)
    elif a.action=='buildx':
        check=cmd(['bash',root/'scripts/qualify_native_worker.sh','--buildx-ci'],env={**env,'MICROPOD_CLI':str(stage/a.cli)},ok=False,timeout=220)
        if check.returncode:raise RuntimeError(('Buildx CI',check.returncode,check.stderr[-1400:]))
        data['buildx_ci']=json.loads(check.stdout)
        assert data['buildx_ci']['passed']
    elif a.action=='published-pairs':
        data['published']=[]
        data['offered_sha256']=sha(stage/'work/offered-mac')
        for order in [('orbstack','hvf'),('hvf','orbstack')]:
            block={}
            for side in order:
                block[side]=b.bench_published_tcp(b.ORB_SOCK if side=='orbstack' else sock,side,stage/'work/offered-mac',rounds=1)
                assert not block[side].get('error'),block[side]
            data['published'].append(block)
            save()
    elif a.action=='direct':
        data['direct']=b.bench_live_sibling_pairs(sock,b.ORB_SOCK,work,net_driver='ipvlan',pairs=a.rounds)
    elif a.action=='cc':
        data['tuning']=b.inspect_guest_tuning(sock)
        data['congestion_pair']=b.bench_sibling_congestion_pair(sock,work,'ipvlan',a.rounds)
    elif a.action=='network':
        data['tuning']=b.inspect_guest_tuning(sock)
        data['in_guest']=b.bench_in_guest_suite(sock,a.engine,work,net_driver='ipvlan',rounds=a.rounds)
        data['churn']=b.bench_ephemeral_churn(sock,a.engine,rounds=a.rounds)
    else:
        raise ValueError(a.action)
    save()
    data['ok']=True
except BaseException as exc:
    data['error']=repr(exc);raise
finally:
    try:
        cleanup_problem=None
        try:
            for side,endpoint in fixture_targets:
                identity=image_id(endpoint,tag)
                if identity is not None:
                    assert identity in (expected,spec['manifest_digest']), (side,identity)
                    b.docker(endpoint,'image','rm',tag)
                assert image_id(endpoint,tag) is None
                data['image_fixture']['reclaimed'].append(side)
        except BaseException as exc:
            cleanup_problem=exc;data["fixture_cleanup_error"]=repr(exc)
        if worker:
            if worker.proc and worker.proc.poll() is None:
                stop=cmd([stage/a.cli,'ci','runner-stop'],worker.env(),ok=False,timeout=55)
                data['stop']={'code':stop.returncode,'stderr':stop.stderr.strip()}
            if worker.drive.log:data['log_tail']=worker.drive.log[0].read_text(errors='replace')[-700:]
            data['drive']=worker.stop()
        if snapshot_probe:snapshot_probe.close()
        data['workspace_drive']=store.close()
        if cleanup_problem:raise cleanup_problem
    finally:save()
    print(a.name,data.get('workspace',{}).get('median_observed_ms'),data.get('error'),flush=True)
