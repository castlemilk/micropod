(
    set -eu
    point=$(mktemp -d)
    mount -t debugfs -o ro,nosuid,nodev,noexec debugfs "$point"
    trap 'umount "$point" && rmdir "$point"' EXIT
    cat "$point/sched/features" "$point/sched/base_slice_ns" /proc/sys/net/ipv4/tcp_congestion_control /proc/sys/net/ipv4/tcp_available_congestion_control /proc/sys/net/core/default_qdisc /proc/sys/kernel/sched_cfs_bandwidth_slice_us /proc/cmdline > "$MICROPOD_ENGINE_WORKSPACE/qa-scheduler"
)
