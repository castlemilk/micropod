package main

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
)

func run(root, value string) error {
	dir, err := os.MkdirTemp(root, "sync-")
	if err != nil {
		return err
	}
	tmp := filepath.Join(dir, "before")
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	if _, err := f.WriteString(value); err != nil {
		f.Close()
		return err
	}
	if err := f.Sync(); err != nil {
		f.Close()
		return fmt.Errorf("file fsync: %w", err)
	}
	if err := f.Close(); err != nil {
		return err
	}
	path := filepath.Join(dir, "committed")
	if err := os.Rename(tmp, path); err != nil {
		return err
	}
	d, err := os.Open(dir)
	if err != nil {
		return err
	}
	if err := d.Sync(); err != nil {
		d.Close()
		return fmt.Errorf("directory fsync: %w", err)
	}
	if err := d.Close(); err != nil {
		return err
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	if string(b) != value {
		return fmt.Errorf("guest readback mismatch")
	}
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"file_synced": true, "directory_synced": true, "directory": filepath.Base(dir), "sha256": fmt.Sprintf("%x", sha256.Sum256(b))})
}
func main() {
	if len(os.Args) != 3 {
		os.Exit(2)
	}
	if err := run(os.Args[1], os.Args[2]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
