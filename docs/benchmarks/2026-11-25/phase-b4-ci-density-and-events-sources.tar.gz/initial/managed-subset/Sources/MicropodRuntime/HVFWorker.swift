import Darwin
import Foundation
import MicropodCore

/// Selects which macOS virtualization backend backs a native Micropod CI worker.
public enum CIWorkerVMM: String, Codable, Sendable {
    case vz
    case hvf

    public static func parse(_ raw: String?) throws -> CIWorkerVMM {
        guard let raw, !raw.isEmpty else { return .vz }
        guard let value = CIWorkerVMM(rawValue: raw.lowercased()) else {
            throw MicropodError.message("MICROPOD_CI_VMM must be 'vz' or 'hvf'")
        }
        return value
    }
}

struct HVFKernelArguments {
    static let environmentKey = "MICROPOD_SANDBOX_KERNEL_ARGS"

    private enum Selector: String {
        case scheduler = "micropod.ci_sched"
        case wakeup = "micropod.ci_wakeup"
        case congestion = "micropod.ci_cc"

        var supported: [String] {
            switch self {
            case .scheduler: ["hrtick", "hrtick-1ms", "hrtick-500us", "hrtick-250us", "hrtick-125us"]
            case .wakeup: ["next-buddy", "next-buddy,sync-colocate", "sync-colocate", "next-buddy,sync-colocate,no-ttwu-queue"]
            case .congestion: ["cubic", "bbr"]
            }
        }
    }

    var scheduler = "hrtick-250us"
    var wakeup = "next-buddy,sync-colocate"
    var congestion = "cubic"
    var extra: String?

    static func parse(_ raw: String?) throws -> Self {
        guard let raw else { return Self() }
        let reserved = ["--", "console", "panic", "mp.worker", "mp.instance", "mp.workspace", "mp.mtu",
                        "mp.boot_realtime_ns", "micropod.ci_sysctls"]
        var seen = Set<Selector>()
        var result = Self()
        var extra = ""
        var retainedStart = raw.startIndex
        for argument in raw.split(whereSeparator: \.isWhitespace) {
            let fields = argument.split(separator: "=", maxSplits: 1, omittingEmptySubsequences: false)
            let key = fields[0].trimmingCharacters(in: CharacterSet(charactersIn: "\""))
            if reserved.contains(key) {
                throw MicropodError.message("Kernel argument \(key) is reserved by the HVF worker")
            }
            guard let selector = Selector(rawValue: key) else { continue }
            guard seen.insert(selector).inserted else {
                throw MicropodError.message("Specify \(key) at most once in \(environmentKey)")
            }
            guard fields.count == 2, fields[0] == key, selector.supported.contains(String(fields[1])) else {
                let choices = selector.supported.map { "'\($0)'" }.joined(separator: ", ")
                throw MicropodError.message("\(key) must be one of \(choices)")
            }
            let value = String(fields[1])
            switch selector {
            case .scheduler: result.scheduler = value
            case .wakeup: result.wakeup = value
            case .congestion: result.congestion = value
            }
            extra += raw[retainedStart..<argument.startIndex]
            retainedStart = argument.endIndex
        }
        extra += raw[retainedStart...]
        result.extra = extra
        return result
    }
}

/// Deterministic command-line launch specification for the Rust Hypervisor.framework VMM (`micropod-vmm`).
public struct HVFWorkerLaunchSpec: Sendable, Equatable {
    public let vmmBinary: URL
    public let kernel: URL
    public let initrd: URL
    public let disk: URL
    public let ociTools: URL
    public let workspace: String?
    public let dockerSocket: URL
    public let ociSocket: URL
    public let buildkitSocket: URL
    public let workerID: UUID
    public let instanceID: UUID
    public let cpus: Int
    public let memoryMiB: Int
    public let publishedMTU: UInt32
    public let extraKernelArgs: String?
    public let expectedParentPID: Int32?

    public init(
        vmmBinary: URL, kernel: URL, initrd: URL, disk: URL, ociTools: URL, workspace: String?,
        dockerSocket: URL, ociSocket: URL, buildkitSocket: URL, workerID: UUID, instanceID: UUID,
        cpus: Int, memoryMiB: Int, publishedMTU: UInt32 = 9000, extraKernelArgs: String? = nil,
        expectedParentPID: Int32? = nil
    ) {
        self.vmmBinary = vmmBinary
        self.kernel = kernel
        self.initrd = initrd
        self.disk = disk
        self.ociTools = ociTools
        self.workspace = workspace
        self.dockerSocket = dockerSocket
        self.ociSocket = ociSocket
        self.buildkitSocket = buildkitSocket
        self.workerID = workerID
        self.instanceID = instanceID
        self.cpus = cpus
        self.memoryMiB = memoryMiB
        self.publishedMTU = publishedMTU
        self.extraKernelArgs = extraKernelArgs
        self.expectedParentPID = expectedParentPID
    }

    public var kernelCmdline: String { kernelCmdline(options: HVFKernelArguments(extra: extraKernelArgs)) }

    private func kernelCmdline(options: HVFKernelArguments) -> String {
        var parts = [
            "quiet",
            "console=ttyAMA0",
            "rcupdate.rcu_expedited=1",
            "psi=1",
            "cgroup.memory=nokmem,nosocket",
            "slab_min_order=2",
            "swiotlb=noforce",
            "workqueue.power_efficient=1",
            "micropod.ci_sched=\(options.scheduler)",
            "micropod.ci_wakeup=\(options.wakeup)",
            "micropod.ci_sysctls=perf",
            "micropod.ci_cc=\(options.congestion)",
            "mp.worker=\(workerID.uuidString)",
            "mp.instance=\(instanceID.uuidString)",
            "mp.mtu=\(publishedMTU)",
        ]
        if let workspace, !workspace.isEmpty {
            parts.append("mp.workspace=\(workspace)")
        }
        if let extra = options.extra?.trimmingCharacters(in: .whitespacesAndNewlines), !extra.isEmpty {
            parts.append(extra)
        }
        parts.append("panic=-1")
        return parts.joined(separator: " ")
    }

    public var arguments: [String] { arguments(kernelCmdline: kernelCmdline) }

    func validatedArguments() throws -> [String] {
        arguments(kernelCmdline: kernelCmdline(options: try HVFKernelArguments.parse(extraKernelArgs)))
    }

    private func arguments(kernelCmdline: String) -> [String] {
        var args = [
            "--kernel", kernel.path,
            "--initrd", initrd.path,
            "--disk", disk.path,
            "--cpus", String(cpus),
            "--memory-mib", String(memoryMiB),
            "--share", "oci-tools:\(ociTools.path):ro",
        ]
        if let workspace, !workspace.isEmpty {
            args += ["--share", "workspace:\(workspace)"]
        }
        args += [
            "--vsock-expose", "\(dockerSocket.path):2375",
            "--vsock-expose", "\(ociSocket.path):2376",
            "--vsock-expose", "\(buildkitSocket.path):2377",
            "--published-net",
            "--published-mtu", String(publishedMTU),
            "--cmdline", kernelCmdline,
        ]
        if let expectedParentPID {
            args += ["--parent-pid", String(expectedParentPID)]
        }
        return args
    }
}

extension CIWorker {
    func selectedVMM() throws -> CIWorkerVMM {
        let vmm = try CIWorkerVMM.parse(resourceEnvironment["MICROPOD_CI_VMM"])
        if vmm == .hvf && !isNativeRunner {
            throw MicropodError.message("MICROPOD_CI_VMM=hvf requires MICROPOD_CI_ENGINE=containerd")
        }
        if vmm == .hvf {
            _ = try HVFKernelArguments.parse(resourceEnvironment[HVFKernelArguments.environmentKey])
        }
        return vmm
    }

    func resolveHVFPaths() throws -> (vmmBinary: URL, initrd: URL) {
        let fm = FileManager.default
        let binPath: String
        if let explicit = resourceEnvironment["MICROPOD_CI_HVF_BIN"], !explicit.isEmpty {
            binPath = explicit
        } else if let exeDir = Bundle.main.executableURL?.resolvingSymlinksInPath().deletingLastPathComponent() {
            let sibling = exeDir.appendingPathComponent("micropod-vmm").path
            guard fm.isExecutableFile(atPath: sibling) else {
                throw MicropodError.message(
                    "Set MICROPOD_CI_HVF_BIN to the signed micropod-vmm binary when using MICROPOD_CI_VMM=hvf")
            }
            binPath = sibling
        } else {
            throw MicropodError.message("Missing MICROPOD_CI_HVF_BIN for MICROPOD_CI_VMM=hvf")
        }
        guard fm.isExecutableFile(atPath: binPath) else {
            throw MicropodError.message("MICROPOD_CI_HVF_BIN is not executable: \(binPath)")
        }

        let initrdPath: String
        if let explicit = resourceEnvironment["MICROPOD_CI_HVF_INITRD"], !explicit.isEmpty {
            initrdPath = explicit
        } else {
            let sibling = URL(fileURLWithPath: binPath).deletingLastPathComponent()
                .appendingPathComponent("mp-hvf-init.cpio").path
            guard fm.fileExists(atPath: sibling) else {
                throw MicropodError.message(
                    "Set MICROPOD_CI_HVF_INITRD to mp-hvf-init.cpio when using MICROPOD_CI_VMM=hvf")
            }
            initrdPath = sibling
        }
        guard fm.fileExists(atPath: initrdPath) else {
            throw MicropodError.message("MICROPOD_CI_HVF_INITRD not found: \(initrdPath)")
        }
        return (URL(fileURLWithPath: binPath), URL(fileURLWithPath: initrdPath))
    }

    func launchHVFProcess(
        config: Configuration, instanceID: UUID, cpus: Int, diskURL: URL, ociTools: URL
    ) throws -> Process {
        let (vmmBin, initrd) = try resolveHVFPaths()
        guard let kernelPath = config.kernel else {
            throw MicropodError.message("MICROPOD_CI_VMM=hvf requires MICROPOD_CI_KERNEL (Linux ARM64 Image)")
        }
        let spec = HVFWorkerLaunchSpec(
            vmmBinary: vmmBin,
            kernel: URL(fileURLWithPath: kernelPath),
            initrd: initrd,
            disk: diskURL,
            ociTools: ociTools,
            workspace: config.workspace,
            dockerSocket: dockerSocket,
            ociSocket: ociSocket,
            buildkitSocket: buildkitSocket,
            workerID: config.worker,
            instanceID: instanceID,
            cpus: cpus,
            memoryMiB: config.memoryMiB,
            publishedMTU: config.publishedMTU ?? 9000,
            extraKernelArgs: resourceEnvironment[HVFKernelArguments.environmentKey],
            expectedParentPID: getpid()
        )
        let proc = Process()
        proc.executableURL = spec.vmmBinary
        proc.arguments = try spec.validatedArguments()
        proc.standardOutput = FileHandle.standardOutput
        proc.standardError = FileHandle.standardError
        proc.standardInput = FileHandle.nullDevice
        try proc.run()
        return proc
    }
}
