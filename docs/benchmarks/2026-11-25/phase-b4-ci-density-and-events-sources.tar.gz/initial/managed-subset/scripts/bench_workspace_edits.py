#!/usr/bin/env python3
"""Measure when a running container sees a host edit on a shared workspace."""

import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import statistics
import subprocess
import sys
import tempfile
import time
from uuid import uuid4


CASES = ("size", "held", "replace", "unlink")
LABEL = "io.micropod.workspace-bench"
CONTAINER_ID = re.compile(r"[a-f0-9]{64}")


def marker_data(path):
    try:
        return path.read_text()
    except FileNotFoundError:
        return ""


def wait_marker(path, child):
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline:
        data = marker_data(path)
        if data:
            return data
        if child.poll() is not None:
            # The final marker can appear between the read and the exit check.
            data = marker_data(path)
            if data:
                return data
            raise RuntimeError(f"guest exited before {path.name}: {child.communicate(timeout=2)}")
        time.sleep(0.0005)
    raise TimeoutError(f"waiting for {path.name}")


def apply_edit(path, case):
    if case == "replace":
        tmp = path.with_suffix(".new")
        tmp.write_bytes(b"revision")
        tmp.replace(path)
    elif case == "unlink":
        path.unlink()
    else:
        with path.open("r+b", buffering=0) as f:
            if case == "size":
                f.seek(0, os.SEEK_END)
            f.write(b"revision")


def check_host_edit(path, case):
    if case == "unlink":
        if os.path.lexists(path):
            raise RuntimeError(f"host path {path.name} survived unlink")
    elif path.read_bytes() != (b"previousrevision" if case == "size" else b"revision"):
        raise RuntimeError(f"host path {path.name} contains unexpected bytes after edit")


def remove_probe(docker, name, settle):
    deadline = time.monotonic() + 20

    def call(*args, **options):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError(f"cleaning up {name}")
        try:
            return subprocess.run([*docker, *args], capture_output=True, text=True, timeout=remaining, **options)
        except subprocess.CalledProcessError as exc:
            raise RuntimeError(f"Docker {args[0]} failed during cleanup: {exc.stderr.strip()}") from exc

    def owned_id():
        rows = call("ps", "-a", "--no-trunc", "--filter", f"label={LABEL}={name}", "--format",
                    '{{.ID}}|{{.Names}}|{{.Label "' + LABEL + '"}}', check=True).stdout.splitlines()
        if not rows:
            return None
        parts = rows[0].split("|")
        if len(rows) != 1 or len(parts) != 3 or parts[1:] != [name, name] or not CONTAINER_ID.fullmatch(parts[0]):
            raise RuntimeError(f"Docker returned an unverified cleanup container for {name}")
        return parts[0]

    # A canceled Docker client can lose its create response before the container appears.
    quiet_until = time.monotonic() + settle
    while True:
        if id_ := owned_id():
            removed = call("rm", "-f", id_)
            if owned_id():
                raise RuntimeError(f"Docker retained {name} after force removal: {removed.stderr.strip()}")
        if time.monotonic() >= quiet_until:
            return
        time.sleep(0.1)


@contextmanager
def guest_probe(docker, name, directory, *args):
    cmd = [*docker, "run", "--rm", "--name", name, "--label", f"{LABEL}={name}", "--pull", "never",
           "--network", "none", "--mount", f"type=bind,src={directory},dst=/bench", "alpine:3.23",
           "/bench/probe", *args]
    child = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        yield child
    finally:
        failed = sys.exc_info()[0] is not None
        errors = []
        try:
            if child.poll() is None:
                child.kill()
                child.wait(timeout=5)
        except Exception as exc:
            errors.append(f"reaping Docker client: {exc}")
        finally:
            child.stdout.close()
            child.stderr.close()
        try:
            remove_probe(docker, name, settle=1 if failed else 0)
        except Exception as exc:
            errors.append(f"removing Docker container: {exc}")
        if errors:
            message = f"Cleanup failed for {name}. " + ". ".join(errors)
            if failed:
                print(message, file=sys.stderr)
            else:
                raise RuntimeError(message)


def run(args, directory):
    probe = directory / "probe"
    shutil.copy2(args.probe, probe)
    probe.chmod(0o755)
    tree = directory / "tree"
    tree.mkdir()
    digest = hashlib.sha256()
    paths = hashlib.sha256()
    count = 512
    size = 0
    for i in range(count):
        folder = tree / f"pkg{i // 16:03}"
        folder.mkdir(exist_ok=True)
        source = f"package p\nfunc F{i}() int {{ return {i} }}\n".encode()
        path = folder / f"src{i:04}.go"
        path.write_bytes(source)
        digest.update(source)
        paths.update(path.relative_to(tree).as_posix().encode() + b"\0")
        size += len(source)
    for i in range(args.rounds):
        for case in CASES:
            target = directory / f"{case}-{i}"
            target.write_bytes(b"previous")
            past = time.time_ns() - 5_000_000_000
            os.utime(target, ns=(past, past))
    name = "mp-ws-" + uuid4().hex
    docker = ["docker", "--host", args.host]
    samples = {case: [] for case in CASES}
    with guest_probe(docker, name, directory, "/bench", str(args.rounds)) as child:
        for i in range(args.rounds):
            for case in CASES:
                path = directory / f"{case}-{i}"
                wait_marker(path.with_suffix(".ready"), child)
                start = time.monotonic_ns()
                apply_edit(path, case)
                edited = time.monotonic_ns()
                result = wait_marker(path.with_suffix(".done"), child)
                acknowledged = time.monotonic_ns()
                check_host_edit(path, case)
                samples[case].append({"result": result, "host_ms": round((acknowledged - start) / 1_000_000, 3),
                                      "host_edit_ms": round((edited - start) / 1_000_000, 3),
                                      "after_edit_ack_ms": round((acknowledged - edited) / 1_000_000, 3)})
        out, err = child.communicate(timeout=10)
        if child.returncode:
            raise RuntimeError((out, err))
    median = {}
    for case, rows in samples.items():
        successful = [r["host_ms"] for r in rows if r["result"] == "observed"]
        median[case] = round(statistics.median(successful), 3) if successful else None
    with guest_probe(docker, name + "-scan", directory, "scan", "/bench/tree") as child:
        out, err = child.communicate(timeout=90)
        if child.returncode:
            raise RuntimeError((out, err))
        scans = json.loads(out)
        if [(r["pass"], r["scheduled_pause_ms"]) for r in scans] != [(1, 0), (2, 0), (3, 50)]:
            raise RuntimeError("workspace scan returned an unexpected pass sequence")
        if any(r["files"] != count or r["bytes"] != size or r["read_bytes"] != size or
               r["sha256"] != digest.hexdigest() or r["path_sha256"] != paths.hexdigest() for r in scans):
            raise RuntimeError("workspace scan returned different lexical paths, sizes or source bytes")
    return {"samples": samples, "median_observed_ms": median, "scans": scans, "timing_scope": {
                "host_ms": "Host edit through host observation of the guest completion marker, including polling and guest validation",
                "host_edit_ms": "Host edit through return of the host file operation",
                "after_edit_ack_ms": "Return of the host file operation through host observation of the guest completion marker",
                "stat_ms": "Guest lexical directory walk and file stat",
                "read_ms": "Guest open, read and hash of every file in walk order",
            },
            "complete": all(r["result"] == "observed" for rows in samples.values() for r in rows)}


def interrupted(signum, _frame):
    raise InterruptedError(f"received signal {signum}")


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, interrupted)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True, help="Docker Unix endpoint")
    parser.add_argument("--workspace", type=Path, required=True, help="worker's configured host workspace")
    parser.add_argument("--probe", type=Path, required=True, help="Linux arm64 build of scripts/workspacebench/main.go")
    parser.add_argument("--rounds", type=int, default=5)
    args = parser.parse_args()
    if not 1 <= args.rounds <= 100:
        parser.error("rounds must be between 1 and 100")
    with tempfile.TemporaryDirectory(prefix="edit-", dir=args.workspace.resolve()) as work:
        result = run(args, Path(work))
    print(json.dumps(result))
    raise SystemExit(0 if result["complete"] else 1)
