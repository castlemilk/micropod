#!/usr/bin/env python3
"""Check live Docker and Compose event streams, replay filters and disconnect through a selected engine."""

import argparse
from contextlib import ExitStack
import json
import os
from pathlib import Path
import signal
import subprocess
from tempfile import TemporaryDirectory
import threading
import time

from qualify_docker_restart import LABEL, Qualification, require


class Stream:
    def __init__(self, fixture, args):
        self.events = []
        self.error = None
        self.changed = threading.Condition()
        self.process = subprocess.Popen([*fixture.cli, *args], env=fixture.env, start_new_session=True, stdin=subprocess.DEVNULL,
                                        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        self.reader = threading.Thread(target=self.read, daemon=True)
        self.reader.start()

    def read(self):
        try:
            for line in self.process.stdout:
                event = json.loads(line)
                with self.changed:
                    self.events.append(event)
                    self.changed.notify_all()
        except ValueError as err:
            self.error = str(err)
        finally:
            with self.changed:
                self.changed.notify_all()

    def await_event(self, predicate):
        with self.changed:
            if not self.changed.wait_for(lambda: any(map(predicate, self.events)) or self.error, timeout=8):
                raise RuntimeError(f"Timed out waiting for a live event. Received {self.events!r}")
            require(not self.error, f"Invalid event stream. {self.error}")

    def close(self):
        # Docker may exec a Compose plugin that still holds the streaming socket.
        try:
            os.killpg(self.process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            self.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(self.process.pid, signal.SIGKILL)
            self.process.wait(timeout=5)
        self.reader.join(timeout=3)
        self.process.stdout.close()
        self.process.stderr.close()
        require(not self.reader.is_alive(), "Docker event reader did not terminate")


def listeners(fixture):
    return int(fixture.docker("info", "--format", "{{.NEventsListener}}", timeout=5).stdout)


def await_listeners(fixture, predicate, streams=()):
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        for stream in streams:
            if stream.process.poll() is not None:
                raise RuntimeError(f"Event subscription exited. {stream.process.stderr.read().strip()}")
        value = listeners(fixture)
        if predicate(value):
            return value
        time.sleep(0.075)
    raise RuntimeError(f"Event listener count did not reach the expected value. Last observed {value}")


def stamp(ns):
    sec, nanos = divmod(ns, 1_000_000_000)
    return f"{sec}.{nanos:09d}"


def checked_engine_rows(rows, cid, project):
    for row in rows:
        attrs = row["Actor"]["Attributes"]
        require(row["Type"] == "container" and row["Actor"]["ID"] == cid and row["scope"] == "local",
                "Received an event for a different object or scope")
        require(attrs[LABEL] == project and attrs["com.docker.compose.service"] == "job"
                and attrs["com.docker.compose.project"] == project, "Actor labels did not identify this service")
        require(row["time"] == row["timeNano"] // 1_000_000_000 and row["timeNano"] > 0, "Invalid event timestamp")
        if row["Action"] == "die":
            require(attrs["exitCode"] == "0", f"Graceful service exit reported {attrs['exitCode']}")
    require(all(a["timeNano"] <= b["timeNano"] for a, b in zip(rows, rows[1:])), "Events arrived out of order")
    return [row["Action"] for row in rows]


def lifecycle(actions):
    relevant = [action for action in actions if action in {"start", "die", "stop", "destroy"}]
    require(len(relevant) == 7 and relevant[0] == relevant[3] == "start" and relevant[-1] == "destroy"
            and set(relevant[1:3]) == set(relevant[4:6]) == {"die", "stop"}, f"Lifecycle actions {actions}")


def qualify(fixture):
    fixture.compose_file.write_text(json.dumps({"services": {"job": {
        "image": fixture.image, "network_mode": "none", "labels": {LABEL: fixture.key},
        "entrypoint": ["sh", "-ec"],
        "command": ["trap 'exit 0' TERM; sleep 90 & wait"],
    }}}))
    fixture.compose_touched = True
    fixture.compose("create", "--pull", "never")
    cid = fixture.inspect(fixture.compose("ps", "-a", "-q", "job").stdout.strip())["Id"]
    base_count = listeners(fixture)
    filters = ["--filter", "type=container", "--filter", f"container={cid[:12]}",
               "--filter", f"label={LABEL}={fixture.key}"]
    expires = str(int(time.time()) + 25)
    with ExitStack() as stack:
        engine = Stream(fixture, ["events", *filters, "--until", expires, "--format", "{{json .}}"])
        stack.callback(engine.close)
        compose = Stream(fixture, ["compose", "-p", fixture.key, "-f", str(fixture.compose_file),
                                   "events", "--json", "--until", expires, "job"])
        stack.callback(compose.close)
        active_count = await_listeners(fixture, lambda value: value >= base_count + 2, [engine, compose])
        for _ in range(2):
            fixture.compose("start", "job")
            fixture.compose("stop", "--timeout", "3", "job")
        fixture.compose("down", "--timeout", "3")
        engine.await_event(lambda event: event.get("Action") == "destroy")
        compose.await_event(lambda event: event.get("action") == "destroy")
    close_start = time.monotonic()
    require(time.time() < int(expires) - 3, "The clients did not disconnect before the server deadline")
    final_count = listeners(fixture)
    while final_count > base_count and time.time() < int(expires) + 3:
        time.sleep(0.125)
        final_count = listeners(fixture)
    released_s = time.monotonic() - close_start
    observed_release_time = time.time()
    require(final_count <= base_count, "Timed subscriptions were not released by the server")
    engine_actions = checked_engine_rows(engine.events, cid, fixture.key)
    lifecycle(engine_actions)
    require(engine_actions[0] == "create" and engine_actions.count("create") == 1,
            "The subscription with --until did not replay the existing create event")
    for row in compose.events:
        require(row["service"] == "job" and row["id"] == cid, "Compose reported another service or container")
    compose_actions = [row["action"] for row in compose.events]
    lifecycle(compose_actions)

    # Bound the replay strictly inside the first and last live events.
    lower = next(row["timeNano"] for row in engine.events if row["Action"] == "start") + 1
    upper = engine.events[-1]["timeNano"] - 1
    bounds = ["--since", stamp(lower), "--until", stamp(upper)]
    replay = fixture.docker("events", *filters, *bounds, "--filter", "event=start", "--filter", "event=die",
                            "--format", "{{json .}}", timeout=10)
    replay_rows = [json.loads(line) for line in replay.stdout.splitlines()]
    checked_engine_rows(replay_rows, cid, fixture.key)
    wanted = [row for row in engine.events if lower <= row["timeNano"] <= upper and row["Action"] in {"start", "die"}]
    require(replay_rows == wanted and len(wanted) == 3, "Bounded replay disagreed with the original live events")
    excluded = fixture.docker("events", "--since", stamp(lower), "--until", stamp(upper),
                              "--filter", f"container={cid}", "--filter", f"label={LABEL}=absent-{fixture.key}",
                              "--format", "{{json .}}", timeout=10)
    require(not excluded.stdout.strip(), "An event matched an unrelated label")
    return {"container": cid, "listener_counts": [base_count, active_count, final_count],
            "listener_release_seconds": round(released_s, 4), "released_before_deadline": observed_release_time < int(expires) - 1,
            "live_engine": engine.events, "live_compose": compose.events, "bounded_replay": replay_rows,
            "excluded_label_count": 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    endpoint = parser.add_mutually_exclusive_group(required=True)
    endpoint.add_argument("--host")
    endpoint.add_argument("--context")
    parser.add_argument("--image", default="alpine:3.23")
    args = parser.parse_args()
    with TemporaryDirectory(prefix="micropod-events-") as work:
        fixture = Qualification(Path(work), args, prefix="mp-events-")
        try:
            result = qualify(fixture)
        finally:
            cleanup = fixture.cleanup()
        print(json.dumps({**result, "cleanup": cleanup}, indent=2))


if __name__ == "__main__":
    main()
