//! Direct Apple Silicon Hypervisor.framework bindings for macOS 15–26+.
//! Includes hardware-assisted ARM GICv3 (`hv_gic_create`), 16 KiB Stage-2
//! IPA granules (`HV_IPA_GRANULE_16KB`), and `hv_vm_allocate`.

#![allow(non_camel_case_types, dead_code)]

use std::ffi::c_void;
use std::fmt;

pub type hv_return_t = i32;
pub type hv_vcpu_t = u64;
pub type hv_ipa_t = u64;
pub type hv_memory_flags_t = u64;
pub type hv_allocate_flags_t = u64;
pub type hv_vm_config_t = *mut c_void;
pub type hv_vcpu_config_t = *mut c_void;
pub type hv_gic_config_t = *mut c_void;

pub const HV_SUCCESS: hv_return_t = 0;

pub const HV_MEMORY_READ: hv_memory_flags_t = 1 << 0;
pub const HV_MEMORY_WRITE: hv_memory_flags_t = 1 << 1;
pub const HV_MEMORY_EXEC: hv_memory_flags_t = 1 << 2;
pub const HV_MEMORY_RWX: hv_memory_flags_t = HV_MEMORY_READ | HV_MEMORY_WRITE | HV_MEMORY_EXEC;

pub const HV_ALLOCATE_DEFAULT: hv_allocate_flags_t = 0;

#[repr(u32)]
#[derive(Debug, Copy, Clone, Eq, PartialEq)]
pub enum hv_ipa_granule_t {
    HV_IPA_GRANULE_4KB = 0,
    HV_IPA_GRANULE_16KB = 1,
}

#[repr(u32)]
#[derive(Debug, Copy, Clone, Eq, PartialEq)]
pub enum hv_exit_reason_t {
    HV_EXIT_REASON_CANCELED = 0,
    HV_EXIT_REASON_EXCEPTION = 1,
    HV_EXIT_REASON_VTIMER_ACTIVATED = 2,
    HV_EXIT_REASON_UNKNOWN = 3,
}

#[repr(C)]
#[derive(Debug, Copy, Clone)]
pub struct hv_vcpu_exit_exception_t {
    pub syndrome: u64,
    pub virtual_address: u64,
    pub physical_address: hv_ipa_t,
}

#[repr(C)]
#[derive(Debug, Copy, Clone)]
pub struct hv_vcpu_exit_t {
    pub reason: hv_exit_reason_t,
    pub exception: hv_vcpu_exit_exception_t,
}

#[repr(u32)]
#[derive(Debug, Copy, Clone, Eq, PartialEq)]
pub enum hv_reg_t {
    HV_REG_X0 = 0,
    HV_REG_X1 = 1,
    HV_REG_X2 = 2,
    HV_REG_X3 = 3,
    HV_REG_X4 = 4,
    HV_REG_X5 = 5,
    HV_REG_X6 = 6,
    HV_REG_X7 = 7,
    HV_REG_X8 = 8,
    HV_REG_X9 = 9,
    HV_REG_X10 = 10,
    HV_REG_X11 = 11,
    HV_REG_X12 = 12,
    HV_REG_X13 = 13,
    HV_REG_X14 = 14,
    HV_REG_X15 = 15,
    HV_REG_X16 = 16,
    HV_REG_X17 = 17,
    HV_REG_X18 = 18,
    HV_REG_X19 = 19,
    HV_REG_X20 = 20,
    HV_REG_X21 = 21,
    HV_REG_X22 = 22,
    HV_REG_X23 = 23,
    HV_REG_X24 = 24,
    HV_REG_X25 = 25,
    HV_REG_X26 = 26,
    HV_REG_X27 = 27,
    HV_REG_X28 = 28,
    HV_REG_X29 = 29,
    HV_REG_X30 = 30,
    HV_REG_PC = 31,
    HV_REG_FPCR = 32,
    HV_REG_FPSR = 33,
    HV_REG_CPSR = 34,
}

impl hv_reg_t {
    pub fn gpr(idx: u32) -> Option<Self> {
        match idx {
            0 => Some(Self::HV_REG_X0),
            1 => Some(Self::HV_REG_X1),
            2 => Some(Self::HV_REG_X2),
            3 => Some(Self::HV_REG_X3),
            4 => Some(Self::HV_REG_X4),
            5 => Some(Self::HV_REG_X5),
            6 => Some(Self::HV_REG_X6),
            7 => Some(Self::HV_REG_X7),
            8 => Some(Self::HV_REG_X8),
            9 => Some(Self::HV_REG_X9),
            10 => Some(Self::HV_REG_X10),
            11 => Some(Self::HV_REG_X11),
            12 => Some(Self::HV_REG_X12),
            13 => Some(Self::HV_REG_X13),
            14 => Some(Self::HV_REG_X14),
            15 => Some(Self::HV_REG_X15),
            16 => Some(Self::HV_REG_X16),
            17 => Some(Self::HV_REG_X17),
            18 => Some(Self::HV_REG_X18),
            19 => Some(Self::HV_REG_X19),
            20 => Some(Self::HV_REG_X20),
            21 => Some(Self::HV_REG_X21),
            22 => Some(Self::HV_REG_X22),
            23 => Some(Self::HV_REG_X23),
            24 => Some(Self::HV_REG_X24),
            25 => Some(Self::HV_REG_X25),
            26 => Some(Self::HV_REG_X26),
            27 => Some(Self::HV_REG_X27),
            28 => Some(Self::HV_REG_X28),
            29 => Some(Self::HV_REG_X29),
            30 => Some(Self::HV_REG_X30),
            _ => None,
        }
    }
}

#[repr(u16)]
#[derive(Debug, Copy, Clone, Eq, PartialEq)]
pub enum hv_sys_reg_t {
    HV_SYS_REG_MIDR_EL1 = 0xc000,
    HV_SYS_REG_MPIDR_EL1 = 0xc005,
    HV_SYS_REG_ID_AA64PFR0_EL1 = 0xc020,
    HV_SYS_REG_ID_AA64PFR1_EL1 = 0xc021,
    HV_SYS_REG_ID_AA64DFR0_EL1 = 0xc028,
    HV_SYS_REG_ID_AA64DFR1_EL1 = 0xc029,
    HV_SYS_REG_ID_AA64ISAR0_EL1 = 0xc030,
    HV_SYS_REG_ID_AA64ISAR1_EL1 = 0xc031,
    HV_SYS_REG_ID_AA64MMFR0_EL1 = 0xc038,
    HV_SYS_REG_ID_AA64MMFR1_EL1 = 0xc039,
    HV_SYS_REG_ID_AA64MMFR2_EL1 = 0xc03a,
    HV_SYS_REG_SCTLR_EL1 = 0xc080,
    HV_SYS_REG_ACTLR_EL1 = 0xc081,
    HV_SYS_REG_CPACR_EL1 = 0xc082,
    HV_SYS_REG_CNTKCTL_EL1 = 0xc708,
    HV_SYS_REG_CNTV_CTL_EL0 = 0xdf19,
    HV_SYS_REG_CNTV_CVAL_EL0 = 0xdf1a,
    HV_SYS_REG_CNTP_CTL_EL0 = 0xdf11,
    HV_SYS_REG_CNTP_CVAL_EL0 = 0xdf12,
    HV_SYS_REG_SP_EL1 = 0xe208,
}

#[repr(u16)]
#[derive(Debug, Copy, Clone, Eq, PartialEq)]
pub enum hv_gic_intid_t {
    HV_GIC_INT_PERFORMANCE_MONITOR = 23,
    HV_GIC_INT_MAINTENANCE = 25,
    HV_GIC_INT_EL2_PHYSICAL_TIMER = 26,
    HV_GIC_INT_EL1_VIRTUAL_TIMER = 27,
    HV_GIC_INT_EL1_PHYSICAL_TIMER = 30,
}

#[link(name = "Hypervisor", kind = "framework")]
unsafe extern "C" {
    pub fn os_release(object: *mut c_void);

    // VM configuration & lifecycle
    pub fn hv_vm_config_create() -> hv_vm_config_t;
    pub fn hv_vm_config_get_max_ipa_size(ipa_bit_length: *mut u32) -> hv_return_t;
    pub fn hv_vm_config_get_default_ipa_size(ipa_bit_length: *mut u32) -> hv_return_t;
    pub fn hv_vm_config_set_ipa_size(config: hv_vm_config_t, ipa_bit_length: u32) -> hv_return_t;
    pub fn hv_vm_config_get_default_ipa_granule(granule: *mut hv_ipa_granule_t) -> hv_return_t;
    pub fn hv_vm_config_set_ipa_granule(config: hv_vm_config_t, granule: hv_ipa_granule_t) -> hv_return_t;
    pub fn hv_vm_get_max_vcpu_count(max_vcpu_count: *mut u32) -> hv_return_t;
    pub fn hv_vm_create(config: hv_vm_config_t) -> hv_return_t;
    pub fn hv_vm_destroy() -> hv_return_t;
    pub fn hv_vm_map(addr: *mut c_void, ipa: hv_ipa_t, size: usize, flags: hv_memory_flags_t) -> hv_return_t;
    pub fn hv_vm_unmap(ipa: hv_ipa_t, size: usize) -> hv_return_t;
    pub fn hv_vm_protect(ipa: hv_ipa_t, size: usize, flags: hv_memory_flags_t) -> hv_return_t;
    pub fn hv_vm_allocate(uvap: *mut *mut c_void, size: usize, flags: hv_allocate_flags_t) -> hv_return_t;
    pub fn hv_vm_deallocate(uva: *mut c_void, size: usize) -> hv_return_t;

    // Hardware ARM GICv3
    pub fn hv_gic_config_create() -> hv_gic_config_t;
    pub fn hv_gic_config_set_distributor_base(config: hv_gic_config_t, addr: hv_ipa_t) -> hv_return_t;
    pub fn hv_gic_config_set_redistributor_base(config: hv_gic_config_t, addr: hv_ipa_t) -> hv_return_t;
    pub fn hv_gic_create(config: hv_gic_config_t) -> hv_return_t;
    pub fn hv_gic_set_spi(intid: u32, level: bool) -> hv_return_t;
    pub fn hv_gic_get_distributor_size(size: *mut usize) -> hv_return_t;
    pub fn hv_gic_get_distributor_base_alignment(align: *mut usize) -> hv_return_t;
    pub fn hv_gic_get_redistributor_region_size(size: *mut usize) -> hv_return_t;
    pub fn hv_gic_get_redistributor_size(size: *mut usize) -> hv_return_t;
    pub fn hv_gic_get_redistributor_base_alignment(align: *mut usize) -> hv_return_t;
    pub fn hv_gic_get_redistributor_base(vcpu: hv_vcpu_t, addr: *mut hv_ipa_t) -> hv_return_t;
    pub fn hv_gic_get_spi_interrupt_range(base: *mut u32, count: *mut u32) -> hv_return_t;
    pub fn hv_gic_get_intid(interrupt: hv_gic_intid_t, intid: *mut u32) -> hv_return_t;

    // vCPU
    pub fn hv_vcpu_config_create() -> hv_vcpu_config_t;
    pub fn hv_vcpu_create(vcpu: *mut hv_vcpu_t, exit: *mut *const hv_vcpu_exit_t, config: hv_vcpu_config_t) -> hv_return_t;
    pub fn hv_vcpu_destroy(vcpu: hv_vcpu_t) -> hv_return_t;
    pub fn hv_vcpu_run(vcpu: hv_vcpu_t) -> hv_return_t;
    pub fn hv_vcpus_exit(vcpus: *const hv_vcpu_t, count: u32) -> hv_return_t;
    pub fn hv_vcpu_get_reg(vcpu: hv_vcpu_t, reg: hv_reg_t, value: *mut u64) -> hv_return_t;
    pub fn hv_vcpu_set_reg(vcpu: hv_vcpu_t, reg: hv_reg_t, value: u64) -> hv_return_t;
    pub fn hv_vcpu_get_sys_reg(vcpu: hv_vcpu_t, reg: hv_sys_reg_t, value: *mut u64) -> hv_return_t;
    pub fn hv_vcpu_set_sys_reg(vcpu: hv_vcpu_t, reg: hv_sys_reg_t, value: u64) -> hv_return_t;
    pub fn hv_vcpu_set_vtimer_mask(vcpu: hv_vcpu_t, masked: bool) -> hv_return_t;
    pub fn hv_vcpu_get_exec_time(vcpu: hv_vcpu_t, time: *mut u64) -> hv_return_t;
}

#[derive(Debug, Clone)]
pub struct HvError {
    pub op: &'static str,
    pub code: hv_return_t,
}

impl fmt::Display for HvError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "HVF {} failed: {:#010x}", self.op, self.code as u32)
    }
}

impl std::error::Error for HvError {}

impl From<HvError> for String {
    fn from(e: HvError) -> Self {
        e.to_string()
    }
}

pub fn check(rc: hv_return_t, op: &'static str) -> Result<(), HvError> {
    if rc == HV_SUCCESS {
        Ok(())
    } else {
        Err(HvError { op, code: rc })
    }
}
