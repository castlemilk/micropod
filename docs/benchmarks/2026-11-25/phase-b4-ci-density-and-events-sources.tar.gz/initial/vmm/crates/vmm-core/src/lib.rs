//! Core Apple Silicon Hypervisor.framework VMM runtime:
//! - 16 KiB Stage-2 IPA granule (`HV_IPA_GRANULE_16KB`)
//! - Hardware ARM GICv3 (`hv_gic_create`) + SMP PSCI 1.0
//! - PL011 UART console with boot milestone tracking
//! - Virtio-MMIO v2 bus: RNG, Blk, Balloon (MADV_FREE), Virtio-FS (FUSE),
//!   Virtio-Vsock (Unix socket mux + port broker), and dual smoltcp Virtio-Net.

use std::collections::{HashMap, VecDeque};
use std::ffi::CString;
use std::io::{self, Write};
use std::path::PathBuf;
use std::ptr;
use std::sync::atomic::{AtomicBool, AtomicU32, AtomicU64, Ordering};
use std::sync::{Arc, Barrier, Condvar, Mutex};
use std::thread;
use std::time::{Duration, Instant};

use hvf_sys::*;
use vmm_fdt::{CacheTopology, VirtioMmioDesc, VmFdtConfig, build_arm64_fdt};
use vmm_net::{NetConfig, NetMetrics, VirtioNetBridge};
use vmm_virtio::virtiofs::{FsMetrics, VirtioFs};
use vmm_virtio::vsock::{HostServiceHandler, VirtioVsock, VsockExposeSpec};
use vmm_virtio::{
    BalloonMetrics, BlkMetrics, GuestMemory, VirtioBalloon, VirtioBlk, VirtioMmioDevice, VirtioRng,
};

mod boot_clock;
mod disk;

pub const RAM_BASE: u64 = 0x4000_0000;
pub const UART_BASE: u64 = 0x0900_0000;
pub const UART_SIZE: u64 = 0x1000;
pub const UART_INTID: u32 = 33; // SPI 1
pub const VIRTIO_MMIO_BASE: u64 = 0x0a00_0000;
pub const VIRTIO_MMIO_STRIDE: u64 = 0x200;
pub const VIRTIO_SPI_BASE_INTID: u32 = 48; // SPI 16+
pub const VSOCK_PORT_BROKER: u32 = 2378;

const PSCI_VERSION: u32 = 0x8400_0000;
const PSCI_CPU_OFF: u32 = 0x8400_0002;
const PSCI_CPU_ON_32: u32 = 0x8400_0003;
const PSCI_CPU_ON_64: u32 = 0xc400_0003;
const PSCI_AFFINITY_INFO_32: u32 = 0x8400_0004;
const PSCI_AFFINITY_INFO_64: u32 = 0xc400_0004;
const PSCI_SYSTEM_OFF: u32 = 0x8400_0008;
const PSCI_SYSTEM_RESET: u32 = 0x8400_0009;
const PSCI_FEATURES: u32 = 0x8400_000a;
const SMCCC_VERSION: u32 = 0x8000_0000;
const SMCCC_ARCH_FEATURES: u32 = 0x8000_0001;
const PSCI_RET_NOT_SUPPORTED: u64 = (-1i64) as u64;

static SIGNAL_SHUTDOWN: AtomicBool = AtomicBool::new(false);

extern "C" fn handle_term_signal(_sig: libc::c_int) {
    SIGNAL_SHUTDOWN.store(true, Ordering::SeqCst);
}

unsafe extern "C" {
    fn sysctlbyname(
        name: *const std::ffi::c_char,
        oldp: *mut std::ffi::c_void,
        oldlenp: *mut usize,
        newp: *mut std::ffi::c_void,
        newlen: usize,
    ) -> i32;
    fn proc_pid_rusage(pid: i32, flavor: i32, buffer: *mut std::ffi::c_void) -> i32;
    fn getpid() -> i32;
}

fn sysctl_u64(name: &str) -> Option<u64> {
    let cname = CString::new(name).ok()?;
    let mut val: u64 = 0;
    let mut len = std::mem::size_of::<u64>();
    let rc = unsafe {
        sysctlbyname(
            cname.as_ptr(),
            (&mut val as *mut u64).cast(),
            &mut len,
            ptr::null_mut(),
            0,
        )
    };
    if rc == 0 { Some(val) } else { None }
}

pub fn host_cache_topology() -> (CacheTopology, u32) {
    let topo = CacheTopology {
        l1i_size: sysctl_u64("hw.perflevel0.l1icachesize").unwrap_or(196608) as u32,
        l1d_size: sysctl_u64("hw.perflevel0.l1dcachesize").unwrap_or(131072) as u32,
        l2_size: sysctl_u64("hw.perflevel0.l2cachesize").unwrap_or(16 * 1024 * 1024) as u32,
        line_size: sysctl_u64("hw.cachelinesize").unwrap_or(128) as u32,
    };
    let freq = sysctl_u64("hw.tbfrequency").unwrap_or(24_000_000) as u32;
    (topo, freq)
}

#[repr(C)]
struct RusageInfoV4 {
    ri_uuid: [u8; 16],
    ri_user_time: u64,
    ri_system_time: u64,
    ri_pkg_idle_wkups: u64,
    ri_interrupt_wkups: u64,
    ri_pageins: u64,
    ri_wired_size: u64,
    ri_resident_size: u64,
    ri_phys_footprint: u64,
    ri_proc_start_abstime: u64,
    ri_proc_exit_abstime: u64,
    ri_child_user_time: u64,
    ri_child_system_time: u64,
    ri_child_pkg_idle_wkups: u64,
    ri_child_interrupt_wkups: u64,
    ri_child_pageins: u64,
    ri_child_elapsed_abstime: u64,
    ri_diskio_bytesread: u64,
    ri_diskio_byteswritten: u64,
    ri_cpu_time_qos_default: u64,
    ri_cpu_time_qos_maintenance: u64,
    ri_cpu_time_qos_background: u64,
    ri_cpu_time_qos_utility: u64,
    ri_cpu_time_qos_legacy: u64,
    ri_cpu_time_qos_user_initiated: u64,
    ri_cpu_time_qos_user_interactive: u64,
    ri_billed_system_time: u64,
    ri_serviced_system_time: u64,
    ri_logical_writes: u64,
    ri_lifetime_max_phys_footprint: u64,
    ri_instructions: u64,
    ri_cycles: u64,
    ri_billed_energy: u64,
    ri_serviced_energy: u64,
    ri_interval_max_phys_footprint: u64,
    ri_runnable_time: u64,
}

pub fn host_phys_footprint_bytes() -> (u64, u64) {
    let mut ri = unsafe { std::mem::zeroed::<RusageInfoV4>() };
    let rc = unsafe { proc_pid_rusage(getpid(), 4, (&mut ri as *mut RusageInfoV4).cast()) };
    if rc == 0 {
        (ri.ri_phys_footprint, ri.ri_lifetime_max_phys_footprint)
    } else {
        (0, 0)
    }
}

struct Pl011 {
    rx: VecDeque<u8>,
    imsc: u32,
    ris: u32,
    cr: u32,
    lcr_h: u32,
    ibrd: u32,
    fbrd: u32,
    echo_stdout: bool,
    captured: Vec<u8>,
    t0: Instant,
    first_tx_ms: Option<f64>,
    init_ms: Option<f64>,
}

impl Pl011 {
    fn new(t0: Instant, echo_stdout: bool) -> Self {
        Self {
            rx: VecDeque::new(),
            imsc: 0,
            ris: 0x20,
            cr: 0x0301,
            lcr_h: 0,
            ibrd: 0,
            fbrd: 0,
            echo_stdout,
            captured: Vec::with_capacity(64 * 1024),
            t0,
            first_tx_ms: None,
            init_ms: None,
        }
    }

    fn update_irq(&self) {
        let level = (self.ris & self.imsc) != 0;
        let _ = unsafe { hv_gic_set_spi(UART_INTID, level) };
    }

    fn read(&mut self, offset: u64) -> u64 {
        match offset {
            0x000 => {
                let b = self.rx.pop_front().unwrap_or(0);
                if self.rx.is_empty() {
                    self.ris &= !0x10;
                    self.update_irq();
                }
                b as u64
            }
            0x018 => {
                let mut fr = 1u64 << 7;
                if self.rx.is_empty() {
                    fr |= 1 << 4;
                }
                fr
            }
            0x024 => self.ibrd as u64,
            0x028 => self.fbrd as u64,
            0x02c => self.lcr_h as u64,
            0x030 => self.cr as u64,
            0x038 => self.imsc as u64,
            0x03c => self.ris as u64,
            0x040 => (self.ris & self.imsc) as u64,
            0xfe0 => 0x11,
            0xfe4 => 0x10,
            0xfe8 => 0x14,
            0xfec => 0x00,
            0xff0 => 0x0d,
            0xff4 => 0xf0,
            0xff8 => 0x05,
            0xffc => 0xb1,
            _ => 0,
        }
    }

    fn write(&mut self, offset: u64, val: u64) {
        let v = val as u32;
        match offset {
            0x000 => {
                let b = (v & 0xff) as u8;
                if self.first_tx_ms.is_none() {
                    self.first_tx_ms = Some(self.t0.elapsed().as_secs_f64() * 1000.0);
                }
                if self.echo_stdout {
                    let _ = std::io::stdout().write_all(&[b]);
                    if b == b'\n' {
                        let _ = std::io::stdout().flush();
                    }
                }
                if self.captured.len() < 256 * 1024 {
                    self.captured.push(b);
                }
                if self.init_ms.is_none()
                    && self.captured.ends_with(b"MICROPOD_VMM_INIT_READY")
                {
                    self.init_ms = Some(self.t0.elapsed().as_secs_f64() * 1000.0);
                }
                self.ris |= 0x20;
                self.update_irq();
            }
            0x024 => self.ibrd = v,
            0x028 => self.fbrd = v,
            0x02c => self.lcr_h = v,
            0x030 => self.cr = v,
            0x038 => {
                self.imsc = v;
                self.update_irq();
            }
            0x044 => {
                self.ris &= !v;
                self.update_irq();
            }
            _ => {}
        }
    }
}

struct SecondaryStart {
    entry: u64,
    context_id: u64,
    started: bool,
}

struct SharedState {
    uart: Mutex<Pl011>,
    virtio: Vec<Mutex<VirtioMmioDevice>>,
    shutdown: AtomicBool,
    exit_reason: Mutex<String>,
    vcpu_handles: Mutex<Vec<hv_vcpu_t>>,
    vcpus_online: AtomicU32,
    mmio_exits: AtomicU64,
    wfi_exits: AtomicU64,
    secondary_starts: Vec<(Mutex<SecondaryStart>, Condvar)>,
}

impl SharedState {
    fn request_shutdown(&self, reason: &str) {
        {
            let mut exit_reason = self.exit_reason.lock().unwrap();
            if !self.shutdown.swap(true, Ordering::SeqCst) {
                *exit_reason = reason.to_string();
            }
        }
        for (mu, cv) in &self.secondary_starts {
            let _g = mu.lock().unwrap();
            cv.notify_all();
        }
        let handles = self.vcpu_handles.lock().unwrap();
        if !handles.is_empty() {
            let _ = unsafe { hv_vcpus_exit(handles.as_ptr(), handles.len() as u32) };
        }
    }
}

#[derive(Debug, Clone)]
pub struct ShareSpec {
    pub tag: String,
    pub host_path: PathBuf,
    pub read_only: bool,
}

pub struct VmConfig {
    pub kernel_path: PathBuf,
    pub initrd_path: Option<PathBuf>,
    pub disk_path: Option<PathBuf>,
    pub disk_read_only: bool,
    pub num_vcpus: u32,
    pub memory_mib: usize,
    pub cmdline: String,
    pub enable_balloon: bool,
    pub enable_net: bool,
    pub enable_published_net: bool,
    pub published_mtu: u16,
    pub enable_vsock: bool,
    pub vsock_exposes: Vec<VsockExposeSpec>,
    pub shares: Vec<ShareSpec>,
    pub echo_console: bool,
    pub timeout_secs: u64,
}

#[derive(Debug, Clone)]
pub struct VmRunReport {
    pub exit_reason: String,
    pub ipa_granule: &'static str,
    pub num_vcpus: u32,
    pub vcpus_started: u32,
    pub memory_mib: usize,
    pub boot_to_first_uart_ms: Option<f64>,
    pub boot_to_init_ms: Option<f64>,
    pub total_wall_ms: f64,
    pub mmio_exits: u64,
    pub wfi_exits: u64,
    pub blk_read_ops: u64,
    pub blk_write_ops: u64,
    pub blk_read_bytes: u64,
    pub blk_write_bytes: u64,
    pub balloon_kicks: u64,
    pub balloon_ranges: u64,
    pub balloon_reclaimed_bytes: u64,
    pub net_tx_packets: u64,
    pub net_tx_bytes: u64,
    pub net_rx_packets: u64,
    pub net_rx_bytes: u64,
    pub published_binds: u64,
    pub published_conns: u64,
    pub fs_requests: u64,
    pub fs_bytes_read: u64,
    pub host_phys_footprint_mib: f64,
    pub host_peak_footprint_mib: f64,
    pub console_output: String,
}

fn align_up(v: u64, align: u64) -> u64 {
    (v + align - 1) & !(align - 1)
}

pub fn run_vm(cfg: VmConfig) -> Result<VmRunReport, String> {
    run_vm_with_parent(cfg, None)
}

fn verify_expected_parent(expected_parent_pid: Option<libc::pid_t>) -> Result<(), String> {
    let Some(expected) = expected_parent_pid else {
        return Ok(());
    };
    if expected <= 1 {
        return Err("expected parent PID must be greater than 1".into());
    }
    // The kernel updates the parent when it reparents an orphaned process.
    let actual = unsafe { libc::getppid() };
    if actual != expected {
        return Err(format!("expected parent PID {expected}, found {actual}"));
    }
    Ok(())
}

/// Run a VM whose lifetime may be tied to its direct supervisor process.
pub fn run_vm_with_parent(
    cfg: VmConfig,
    expected_parent_pid: Option<libc::pid_t>,
) -> Result<VmRunReport, String> {
    verify_expected_parent(expected_parent_pid)?;
    SIGNAL_SHUTDOWN.store(false, Ordering::SeqCst);
    unsafe {
        libc::signal(libc::SIGTERM, handle_term_signal as *const () as libc::sighandler_t);
        libc::signal(libc::SIGINT, handle_term_signal as *const () as libc::sighandler_t);
        libc::signal(libc::SIGPIPE, libc::SIG_IGN);
    }

    let t0 = Instant::now();
    let kernel_bytes =
        std::fs::read(&cfg.kernel_path).map_err(|e| format!("read kernel: {e}"))?;
    if kernel_bytes.len() < 64 {
        return Err("kernel Image too small".into());
    }
    let magic = u32::from_le_bytes(kernel_bytes[56..60].try_into().unwrap());
    if magic != 0x644d_5241 {
        return Err(format!("invalid ARM64 Image magic {magic:#x}"));
    }
    let text_offset = u64::from_le_bytes(kernel_bytes[8..16].try_into().unwrap());
    let image_size = u64::from_le_bytes(kernel_bytes[16..24].try_into().unwrap())
        .max(kernel_bytes.len() as u64);

    let initrd_bytes = match &cfg.initrd_path {
        Some(p) => Some(std::fs::read(p).map_err(|e| format!("read initrd: {e}"))?),
        None => None,
    };
    verify_expected_parent(expected_parent_pid)?;
    // Keep the locked file alive through VM teardown. The block device's
    // duplicate also retains the lock until its I/O worker releases the file.
    let disk = cfg
        .disk_path
        .as_deref()
        .map(|path| {
            disk::open(path, cfg.disk_read_only).map_err(|e| match e.kind() {
                io::ErrorKind::WouldBlock if !cfg.disk_read_only => {
                    format!("disk {} is locked by another writer", path.display())
                }
                _ => format!("open disk {}: {e}", path.display()),
            })
        })
        .transpose()?;

    // 1. Create VM with 16 KiB Stage-2 IPA granule (macOS 26+)
    let vm_cfg = unsafe { hv_vm_config_create() };
    if vm_cfg.is_null() {
        return Err("hv_vm_config_create returned null".into());
    }
    let mut ipa_granule = "default";
    let g_rc = unsafe { hv_vm_config_set_ipa_granule(vm_cfg, hv_ipa_granule_t::HV_IPA_GRANULE_16KB) };
    if g_rc == HV_SUCCESS {
        ipa_granule = "16KiB";
    }
    let create_res = check(unsafe { hv_vm_create(vm_cfg) }, "hv_vm_create");
    unsafe { os_release(vm_cfg) };
    create_res.map_err(|e| e.to_string())?;

    let mut ram_ptr: *mut std::ffi::c_void = ptr::null_mut();
    let ram_size = cfg.memory_mib * 1024 * 1024;
    let run_res = (|| -> Result<VmRunReport, String> {
        // 2. Configure and create Apple Hardware GICv3 BEFORE creating vCPUs
        let mut gicd_size: usize = 0;
        let mut gicd_align: usize = 0;
        let mut gicr_region_size: usize = 0;
        let mut gicr_align: usize = 0;
        check(unsafe { hv_gic_get_distributor_size(&mut gicd_size) }, "gic dist size")
            .map_err(|e| e.to_string())?;
        check(
            unsafe { hv_gic_get_distributor_base_alignment(&mut gicd_align) },
            "gic dist align",
        )
        .map_err(|e| e.to_string())?;
        check(
            unsafe { hv_gic_get_redistributor_region_size(&mut gicr_region_size) },
            "gic redist size",
        )
        .map_err(|e| e.to_string())?;
        check(
            unsafe { hv_gic_get_redistributor_base_alignment(&mut gicr_align) },
            "gic redist align",
        )
        .map_err(|e| e.to_string())?;

        let gicd_base = align_up(0x1000_0000, gicd_align.max(0x10000) as u64);
        let gicr_base = align_up(gicd_base + gicd_size as u64, gicr_align.max(0x20000) as u64);
        if gicr_base + (gicr_region_size as u64) > RAM_BASE {
            return Err(format!(
                "GIC redistributor region ({:#x} + {:#x}) overlaps RAM ({:#x})",
                gicr_base, gicr_region_size, RAM_BASE
            ));
        }

        let gic_cfg = unsafe { hv_gic_config_create() };
        if gic_cfg.is_null() {
            return Err("hv_gic_config_create returned null".into());
        }
        let gic_res = (|| {
            check(
                unsafe { hv_gic_config_set_distributor_base(gic_cfg, gicd_base) },
                "gic set dist base",
            )?;
            check(
                unsafe { hv_gic_config_set_redistributor_base(gic_cfg, gicr_base) },
                "gic set redist base",
            )?;
            check(unsafe { hv_gic_create(gic_cfg) }, "hv_gic_create")
        })();
        unsafe { os_release(gic_cfg) };
        gic_res.map_err(|e| e.to_string())?;

        let mut vtimer_intid: u32 = 27;
        let mut ptimer_intid: u32 = 30;
        let _ = unsafe { hv_gic_get_intid(hv_gic_intid_t::HV_GIC_INT_EL1_VIRTUAL_TIMER, &mut vtimer_intid) };
        let _ = unsafe { hv_gic_get_intid(hv_gic_intid_t::HV_GIC_INT_EL1_PHYSICAL_TIMER, &mut ptimer_intid) };

        // 3. Allocate & map guest RAM via hv_vm_allocate (supports MADV_FREE reclaim)
        check(
            unsafe { hv_vm_allocate(&mut ram_ptr, ram_size, HV_ALLOCATE_DEFAULT) },
            "hv_vm_allocate",
        )
        .map_err(|e| e.to_string())?;
        check(
            unsafe { hv_vm_map(ram_ptr, RAM_BASE, ram_size, HV_MEMORY_RWX) },
            "hv_vm_map",
        )
        .map_err(|e| e.to_string())?;

        let mem = Arc::new(unsafe { GuestMemory::new(ram_ptr.cast(), RAM_BASE, ram_size) });

        // 4. Load kernel Image, optional initrd
        let kernel_ipa = RAM_BASE + text_offset;
        {
            let dst = mem
                .write_slice(kernel_ipa, kernel_bytes.len())
                .ok_or("kernel exceeds guest RAM")?;
            dst.copy_from_slice(&kernel_bytes);
        }
        let mut next_ipa = align_up(kernel_ipa + image_size + (4 << 20), 16 * 1024);

        let initrd_range = if let Some(ref rd) = initrd_bytes {
            let start = next_ipa;
            let end = start + rd.len() as u64;
            let dst = mem
                .write_slice(start, rd.len())
                .ok_or("initrd exceeds guest RAM")?;
            dst.copy_from_slice(rd);
            next_ipa = align_up(end + (1 << 20), 2 << 20);
            Some((start, end))
        } else {
            next_ipa = align_up(next_ipa, 2 << 20);
            None
        };

        // 5. Attach Virtio-MMIO v2 devices
        let blk_metrics = Arc::new(BlkMetrics::default());
        let balloon_metrics = Arc::new(BalloonMetrics::default());
        let net_metrics = Arc::new(NetMetrics::default());
        let fs_metrics = Arc::new(FsMetrics::default());

        let mut virtio_devs: Vec<Mutex<VirtioMmioDevice>> = Vec::new();
        let mut virtio_descs: Vec<VirtioMmioDesc> = Vec::new();
        let mut push_dev = |backend: Box<dyn vmm_virtio::VirtioBackend>| {
            let slot = virtio_devs.len() as u64;
            let base = VIRTIO_MMIO_BASE + slot * VIRTIO_MMIO_STRIDE;
            let intid = VIRTIO_SPI_BASE_INTID + slot as u32;
            virtio_devs.push(Mutex::new(VirtioMmioDevice::new(intid, mem.clone(), backend)));
            virtio_descs.push(VirtioMmioDesc {
                base,
                size: VIRTIO_MMIO_STRIDE,
                spi: intid - 32,
            });
        };

        push_dev(Box::new(VirtioRng));
        if let Some(disk) = &disk {
            let file = disk
                .try_clone()
                .map_err(|e| format!("duplicate disk descriptor: {e}"))?;
            let blk = VirtioBlk::new(file, cfg.disk_read_only, blk_metrics.clone())
                .map_err(|e| format!("init virtio-blk: {e}"))?;
            push_dev(Box::new(blk));
        }
        if cfg.enable_balloon {
            push_dev(Box::new(VirtioBalloon::new(balloon_metrics.clone())));
        }

        let mut vsock_services: HashMap<u32, HostServiceHandler> = HashMap::new();
        // Linux probes virtio-mmio DT nodes in order:
        // eth0 = primary egress (10.42.0.2/24), eth1 = dedicated published-port link (10.43.0.2/24)
        if cfg.enable_net {
            let net0 = vmm_net::VirtioNetEgress::new(NetConfig::primary_egress(), net_metrics.clone())
                .map_err(|e| format!("init eth0 virtio-net egress: {e}"))?;
            push_dev(Box::new(net0));
        }
        if cfg.enable_published_net {
            let net1 = VirtioNetBridge::new(
                NetConfig::published_link(cfg.published_mtu),
                net_metrics.clone(),
            )
            .map_err(|e| format!("init eth1 virtio-net: {e}"))?;
            if let Some(broker) = net1.port_broker() {
                vsock_services.insert(VSOCK_PORT_BROKER, broker.vsock_handler());
            }
            push_dev(Box::new(net1));
        }
        for share in &cfg.shares {
            let vfs = VirtioFs::new(&share.tag, share.host_path.clone(), share.read_only, fs_metrics.clone())
                .map_err(|e| format!("init virtiofs {}: {e}", share.tag))?;
            push_dev(Box::new(vfs));
        }
        if cfg.enable_vsock || !cfg.vsock_exposes.is_empty() || !vsock_services.is_empty() {
            let vsock = VirtioVsock::new(cfg.vsock_exposes.clone(), vsock_services);
            push_dev(Box::new(vsock));
        }

        let (cache_topo, timer_freq_hz) = host_cache_topology();
        let dtb = build_arm64_fdt(&VmFdtConfig {
            num_vcpus: cfg.num_vcpus,
            ram_base: RAM_BASE,
            ram_size: ram_size as u64,
            gicd_base,
            gicd_size: gicd_size as u64,
            gicr_base,
            gicr_size: gicr_region_size as u64,
            uart_base: UART_BASE,
            uart_size: UART_SIZE,
            uart_spi: UART_INTID - 32,
            vtimer_ppi: vtimer_intid - 16,
            ptimer_ppi: ptimer_intid - 16,
            timer_freq_hz,
            cmdline: boot_clock::cmdline(&cfg.cmdline, std::time::SystemTime::now())?,
            initrd: initrd_range,
            cache: cache_topo,
            virtio_mmio: virtio_descs,
        });
        let fdt_ipa = next_ipa;
        {
            let dst = mem
                .write_slice(fdt_ipa, dtb.len())
                .ok_or("FDT exceeds guest RAM")?;
            dst.copy_from_slice(&dtb);
        }

        // 6. Launch all vCPU threads behind a startup barrier so GICv3 topology is final
        let mut secondary_starts = Vec::with_capacity(cfg.num_vcpus as usize);
        for _ in 0..cfg.num_vcpus {
            secondary_starts.push((
                Mutex::new(SecondaryStart {
                    entry: 0,
                    context_id: 0,
                    started: false,
                }),
                Condvar::new(),
            ));
        }
        let shared = Arc::new(SharedState {
            uart: Mutex::new(Pl011::new(t0, cfg.echo_console)),
            virtio: virtio_devs,
            shutdown: AtomicBool::new(false),
            exit_reason: Mutex::new("unknown".into()),
            vcpu_handles: Mutex::new(Vec::with_capacity(cfg.num_vcpus as usize)),
            vcpus_online: AtomicU32::new(1),
            mmio_exits: AtomicU64::new(0),
            wfi_exits: AtomicU64::new(0),
            secondary_starts,
        });

        let barrier = Arc::new(Barrier::new(cfg.num_vcpus as usize));
        let mut threads = Vec::with_capacity(cfg.num_vcpus as usize);

        // Watch for signals, deadlines, and loss of the managed supervisor.
        let wd_shared = shared.clone();
        let timeout_secs = cfg.timeout_secs;
        let _watchdog = thread::spawn(move || {
            let deadline = if timeout_secs > 0 {
                Some(Instant::now() + Duration::from_secs(timeout_secs))
            } else {
                None
            };
            loop {
                if wd_shared.shutdown.load(Ordering::Relaxed) {
                    return;
                }
                if SIGNAL_SHUTDOWN.load(Ordering::Relaxed) {
                    wd_shared.request_shutdown("signal");
                    return;
                }
                if verify_expected_parent(expected_parent_pid).is_err() {
                    wd_shared.request_shutdown("parent-exited");
                    return;
                }
                if let Some(d) = deadline {
                    if Instant::now() >= d {
                        wd_shared.request_shutdown("timeout");
                        return;
                    }
                }
                thread::sleep(Duration::from_millis(25));
            }
        });

        for cpu_id in 0..cfg.num_vcpus {
            let shared_c = shared.clone();
            let barrier_c = barrier.clone();
            let num_vcpus = cfg.num_vcpus;
            threads.push(thread::spawn(move || -> Result<(), String> {
                run_vcpu_thread(cpu_id, num_vcpus, kernel_ipa, fdt_ipa, shared_c, barrier_c)
            }));
        }

        for h in threads {
            h.join().map_err(|_| "vCPU thread panicked".to_string())??;
        }

        let total_wall_ms = t0.elapsed().as_secs_f64() * 1000.0;
        let (phys_b, peak_b) = host_phys_footprint_bytes();
        let uart = shared.uart.lock().unwrap();
        Ok(VmRunReport {
            exit_reason: shared.exit_reason.lock().unwrap().clone(),
            ipa_granule,
            num_vcpus: cfg.num_vcpus,
            vcpus_started: shared.vcpus_online.load(Ordering::Relaxed),
            memory_mib: cfg.memory_mib,
            boot_to_first_uart_ms: uart.first_tx_ms,
            boot_to_init_ms: uart.init_ms,
            total_wall_ms,
            mmio_exits: shared.mmio_exits.load(Ordering::Relaxed),
            wfi_exits: shared.wfi_exits.load(Ordering::Relaxed),
            blk_read_ops: blk_metrics.read_ops.load(Ordering::Relaxed),
            blk_write_ops: blk_metrics.write_ops.load(Ordering::Relaxed),
            blk_read_bytes: blk_metrics.read_bytes.load(Ordering::Relaxed),
            blk_write_bytes: blk_metrics.write_bytes.load(Ordering::Relaxed),
            balloon_kicks: balloon_metrics.report_kicks.load(Ordering::Relaxed),
            balloon_ranges: balloon_metrics.reported_ranges.load(Ordering::Relaxed),
            balloon_reclaimed_bytes: balloon_metrics.reclaimed_bytes.load(Ordering::Relaxed),
            net_tx_packets: net_metrics.tx_packets.load(Ordering::Relaxed),
            net_tx_bytes: net_metrics.tx_bytes.load(Ordering::Relaxed),
            net_rx_packets: net_metrics.rx_packets.load(Ordering::Relaxed),
            net_rx_bytes: net_metrics.rx_bytes.load(Ordering::Relaxed),
            published_binds: net_metrics.published_binds.load(Ordering::Relaxed),
            published_conns: net_metrics.published_conns.load(Ordering::Relaxed),
            fs_requests: fs_metrics.requests.load(Ordering::Relaxed),
            fs_bytes_read: fs_metrics.bytes_read.load(Ordering::Relaxed),
            host_phys_footprint_mib: (phys_b as f64) / (1024.0 * 1024.0),
            host_peak_footprint_mib: (peak_b as f64) / (1024.0 * 1024.0),
            console_output: String::from_utf8_lossy(&uart.captured).into_owned(),
        })
    })();

    let _ = unsafe { hv_vm_destroy() };
    if !ram_ptr.is_null() {
        let _ = unsafe { hv_vm_deallocate(ram_ptr, ram_size) };
    }
    run_res
}

fn run_vcpu_thread(
    cpu_id: u32,
    num_vcpus: u32,
    kernel_ipa: u64,
    fdt_ipa: u64,
    shared: Arc<SharedState>,
    barrier: Arc<Barrier>,
) -> Result<(), String> {
    // Pin vCPU threads to Apple Silicon P-cores via macOS User-Interactive QoS
    unsafe {
        libc::pthread_set_qos_class_self_np(libc::qos_class_t::QOS_CLASS_USER_INTERACTIVE, 0);
    }
    let mut vcpu: hv_vcpu_t = 0;
    let mut exit_ptr: *const hv_vcpu_exit_t = ptr::null();
    let vcfg = unsafe { hv_vcpu_config_create() };
    let rc = unsafe { hv_vcpu_create(&mut vcpu, &mut exit_ptr, vcfg) };
    if !vcfg.is_null() {
        unsafe { os_release(vcfg) };
    }
    check(rc, "hv_vcpu_create").map_err(|e| e.to_string())?;

    let mpidr = 0x8000_0000u64 | (cpu_id as u64);
    check(
        unsafe { hv_vcpu_set_sys_reg(vcpu, hv_sys_reg_t::HV_SYS_REG_MPIDR_EL1, mpidr) },
        "set MPIDR_EL1",
    )
    .map_err(|e| e.to_string())?;

    shared.vcpu_handles.lock().unwrap().push(vcpu);
    barrier.wait();

    let res = (|| -> Result<(), String> {
        let (entry_pc, x0) = if cpu_id == 0 {
            (kernel_ipa, fdt_ipa)
        } else {
            let (mu, cv) = &shared.secondary_starts[cpu_id as usize];
            let mut st = mu.lock().unwrap();
            while !st.started && !shared.shutdown.load(Ordering::SeqCst) {
                st = cv.wait(st).unwrap();
            }
            if shared.shutdown.load(Ordering::SeqCst) {
                return Ok(());
            }
            (st.entry, st.context_id)
        };

        unsafe {
            check(hv_vcpu_set_reg(vcpu, hv_reg_t::HV_REG_CPSR, 0x3c5), "set CPSR")?;
            check(hv_vcpu_set_reg(vcpu, hv_reg_t::HV_REG_PC, entry_pc), "set PC")?;
            check(hv_vcpu_set_reg(vcpu, hv_reg_t::HV_REG_X0, x0), "set X0")?;
            check(hv_vcpu_set_reg(vcpu, hv_reg_t::HV_REG_X1, 0), "set X1")?;
            check(hv_vcpu_set_reg(vcpu, hv_reg_t::HV_REG_X2, 0), "set X2")?;
            check(hv_vcpu_set_reg(vcpu, hv_reg_t::HV_REG_X3, 0), "set X3")?;
        }

        loop {
            if shared.shutdown.load(Ordering::Relaxed) {
                break;
            }
            check(unsafe { hv_vcpu_run(vcpu) }, "hv_vcpu_run").map_err(|e| e.to_string())?;
            let exit = unsafe { *exit_ptr };
            match exit.reason {
                hv_exit_reason_t::HV_EXIT_REASON_CANCELED => {
                    if shared.shutdown.load(Ordering::Relaxed) {
                        break;
                    }
                }
                hv_exit_reason_t::HV_EXIT_REASON_VTIMER_ACTIVATED => {
                    let _ = unsafe { hv_vcpu_set_vtimer_mask(vcpu, false) };
                }
                hv_exit_reason_t::HV_EXIT_REASON_EXCEPTION => {
                    let esr = exit.exception.syndrome;
                    let ec = (esr >> 26) & 0x3f;
                    match ec {
                        0x01 => {
                            shared.wfi_exits.fetch_add(1, Ordering::Relaxed);
                            advance_pc(vcpu)?;
                        }
                        0x16 | 0x17 => {
                            handle_psci(vcpu, ec, num_vcpus, &shared)?;
                            if shared.shutdown.load(Ordering::Relaxed) {
                                break;
                            }
                        }
                        0x24 => {
                            shared.mmio_exits.fetch_add(1, Ordering::Relaxed);
                            handle_mmio(vcpu, esr, exit.exception.physical_address, &shared)?;
                        }
                        0x18 => {
                            let is_read = (esr & 1) != 0;
                            let rt = ((esr >> 5) & 0x1f) as u32;
                            if is_read {
                                if let Some(reg) = hv_reg_t::gpr(rt) {
                                    let _ = unsafe { hv_vcpu_set_reg(vcpu, reg, 0) };
                                }
                            }
                            advance_pc(vcpu)?;
                        }
                        _ => {
                            let mut pc = 0u64;
                            let _ = unsafe { hv_vcpu_get_reg(vcpu, hv_reg_t::HV_REG_PC, &mut pc) };
                            shared.request_shutdown(&format!(
                                "unhandled_ec_{ec:#x}_esr_{esr:#x}_pc_{pc:#x}"
                            ));
                            break;
                        }
                    }
                }
                hv_exit_reason_t::HV_EXIT_REASON_UNKNOWN => {
                    shared.request_shutdown("unknown_exit");
                    break;
                }
            }
        }
        Ok(())
    })();

    let _ = unsafe { hv_vcpu_destroy(vcpu) };
    res
}

#[inline]
fn advance_pc(vcpu: hv_vcpu_t) -> Result<(), String> {
    let mut pc = 0u64;
    check(unsafe { hv_vcpu_get_reg(vcpu, hv_reg_t::HV_REG_PC, &mut pc) }, "get PC")
        .map_err(|e| e.to_string())?;
    check(unsafe { hv_vcpu_set_reg(vcpu, hv_reg_t::HV_REG_PC, pc + 4) }, "set PC")
        .map_err(|e| e.to_string())
}

fn handle_psci(
    vcpu: hv_vcpu_t,
    ec: u64,
    num_vcpus: u32,
    shared: &SharedState,
) -> Result<(), String> {
    let mut x0 = 0u64;
    let mut x1 = 0u64;
    let mut x2 = 0u64;
    let mut x3 = 0u64;
    unsafe {
        let _ = hv_vcpu_get_reg(vcpu, hv_reg_t::HV_REG_X0, &mut x0);
        let _ = hv_vcpu_get_reg(vcpu, hv_reg_t::HV_REG_X1, &mut x1);
        let _ = hv_vcpu_get_reg(vcpu, hv_reg_t::HV_REG_X2, &mut x2);
        let _ = hv_vcpu_get_reg(vcpu, hv_reg_t::HV_REG_X3, &mut x3);
    }
    let fn_id = x0 as u32;
    let ret: u64 = match fn_id {
        PSCI_VERSION => 0x0001_0000,
        SMCCC_VERSION => 0x0001_0001,
        SMCCC_ARCH_FEATURES => match x1 as u32 {
            SMCCC_VERSION => 0,
            _ => PSCI_RET_NOT_SUPPORTED,
        },
        PSCI_FEATURES => match x1 as u32 {
            PSCI_VERSION | PSCI_CPU_OFF | PSCI_CPU_ON_32 | PSCI_CPU_ON_64
            | PSCI_AFFINITY_INFO_32 | PSCI_AFFINITY_INFO_64 | PSCI_SYSTEM_OFF
            | PSCI_SYSTEM_RESET | PSCI_FEATURES => 0,
            _ => PSCI_RET_NOT_SUPPORTED,
        },
        PSCI_CPU_ON_32 | PSCI_CPU_ON_64 => {
            let target = (x1 & 0xff) as u32;
            if target > 0 && target < num_vcpus {
                let (mu, cv) = &shared.secondary_starts[target as usize];
                let mut st = mu.lock().unwrap();
                if st.started {
                    (-4i64) as u64
                } else {
                    st.entry = x2;
                    st.context_id = x3;
                    st.started = true;
                    shared.vcpus_online.fetch_add(1, Ordering::Relaxed);
                    cv.notify_all();
                    0
                }
            } else {
                (-2i64) as u64
            }
        }
        PSCI_AFFINITY_INFO_32 | PSCI_AFFINITY_INFO_64 => {
            let target = (x1 & 0xff) as u32;
            if target == 0 {
                0
            } else if target < num_vcpus {
                let st = shared.secondary_starts[target as usize].0.lock().unwrap();
                if st.started { 0 } else { 1 }
            } else {
                (-2i64) as u64
            }
        }
        PSCI_SYSTEM_OFF => {
            shared.request_shutdown("poweroff");
            0
        }
        PSCI_SYSTEM_RESET => {
            shared.request_shutdown("reboot");
            0
        }
        PSCI_CPU_OFF => {
            shared.request_shutdown("cpu_off");
            0
        }
        _ => PSCI_RET_NOT_SUPPORTED,
    };
    let _ = unsafe { hv_vcpu_set_reg(vcpu, hv_reg_t::HV_REG_X0, ret) };
    if ec == 0x17 {
        advance_pc(vcpu)?;
    }
    Ok(())
}

fn handle_mmio(
    vcpu: hv_vcpu_t,
    esr: u64,
    ipa: u64,
    shared: &SharedState,
) -> Result<(), String> {
    let isv = ((esr >> 24) & 1) != 0;
    if !isv {
        return advance_pc(vcpu);
    }
    let sas = ((esr >> 22) & 3) as usize;
    let size = 1usize << sas;
    let sse = ((esr >> 21) & 1) != 0;
    let srt = ((esr >> 16) & 0x1f) as u32;
    let sf = ((esr >> 15) & 1) != 0;
    let is_write = ((esr >> 6) & 1) != 0;

    if is_write {
        let mut val = 0u64;
        if let Some(reg) = hv_reg_t::gpr(srt) {
            let _ = unsafe { hv_vcpu_get_reg(vcpu, reg, &mut val) };
        }
        if ipa >= UART_BASE && ipa < UART_BASE + UART_SIZE {
            shared.uart.lock().unwrap().write(ipa - UART_BASE, val);
        } else if ipa >= VIRTIO_MMIO_BASE {
            let rel = ipa - VIRTIO_MMIO_BASE;
            let slot = (rel / VIRTIO_MMIO_STRIDE) as usize;
            let off = rel % VIRTIO_MMIO_STRIDE;
            if let Some(dev) = shared.virtio.get(slot) {
                dev.lock().unwrap().mmio_write(off, size, val);
            }
        }
    } else {
        let mut val = if ipa >= UART_BASE && ipa < UART_BASE + UART_SIZE {
            shared.uart.lock().unwrap().read(ipa - UART_BASE)
        } else if ipa >= VIRTIO_MMIO_BASE {
            let rel = ipa - VIRTIO_MMIO_BASE;
            let slot = (rel / VIRTIO_MMIO_STRIDE) as usize;
            let off = rel % VIRTIO_MMIO_STRIDE;
            shared
                .virtio
                .get(slot)
                .map_or(0, |d| d.lock().unwrap().mmio_read(off, size))
        } else {
            0
        };
        if sse {
            val = match size {
                1 => (val as i8) as i64 as u64,
                2 => (val as i16) as i64 as u64,
                4 => (val as i32) as i64 as u64,
                _ => val,
            };
            if !sf {
                val &= 0xffff_ffff;
            }
        }
        if let Some(reg) = hv_reg_t::gpr(srt) {
            let _ = unsafe { hv_vcpu_set_reg(vcpu, reg, val) };
        }
    }
    advance_pc(vcpu)
}
