import Crypto
import Darwin
import Foundation
import MicropodCore

/// Selects which macOS virtualization backend backs a native Micropod CI worker.
public enum CIWorkerVMM: String, Codable, Sendable {
    case vz
    case hvf

    public static func parse(_ raw: String?) throws -> CIWorkerVMM {
        guard let raw, !raw.isEmpty else { return .vz }
        guard let value = CIWorkerVMM(rawValue: raw.lowercased()) else {
            throw MicropodError.message("MICROPOD_CI_VMM must be 'vz' or 'hvf'")
        }
        return value
    }
}

struct HVFKernelArguments {
    static let environmentKey = "MICROPOD_SANDBOX_KERNEL_ARGS"
    private static let bootClockKey = "mp.boot_realtime_ns"
    private static let workspaceKey = "mp.workspace"
    private static let encodedWorkspaceKey = "mp.workspace_b64"
    private static let workspaceLabelPrefix = "io.micropod.workspace-sha256="
    private static let guestKeys: Set<String> = [
        "mp.worker", "mp.instance", workspaceKey, encodedWorkspaceKey, "mp.mtu", "micropod.ci_sysctls",
    ]
    private static let reserved = guestKeys.union(["--", "console", "panic", bootClockKey])
    private static let quotes = CharacterSet(charactersIn: "\"")

    private enum Selector: String {
        case scheduler = "micropod.ci_sched"
        case wakeup = "micropod.ci_wakeup"
        case congestion = "micropod.ci_cc"

        var supported: [String] {
            switch self {
            case .scheduler: ["hrtick", "hrtick-1ms", "hrtick-500us", "hrtick-250us", "hrtick-125us"]
            case .wakeup: ["next-buddy", "next-buddy,sync-colocate", "sync-colocate", "next-buddy,sync-colocate,no-ttwu-queue"]
            case .congestion: ["cubic", "bbr"]
            }
        }
    }

    var scheduler = "hrtick-250us"
    var wakeup = "next-buddy,sync-colocate"
    var congestion = "cubic"
    var extra: String?

    static func parse(_ raw: String?) throws -> Self {
        guard let raw else { return Self() }
        var seen = Set<Selector>()
        var result = Self()
        var extra = ""
        var retainedStart = raw.startIndex
        for argument in try arguments(in: raw) {
            let (name, field) = parameter(argument)
            let key = name.trimmingCharacters(in: quotes)
            if reserved.contains(key) {
                throw MicropodError.message("Kernel argument \(key) is reserved by the HVF worker")
            }
            guard let selector = Selector(rawValue: key) else { continue }
            guard seen.insert(selector).inserted else {
                throw MicropodError.message("Specify \(key) at most once in \(environmentKey)")
            }
            guard let field, name == key, selector.supported.contains(String(field)) else {
                let choices = selector.supported.map { "'\($0)'" }.joined(separator: ", ")
                throw MicropodError.message("\(key) must be one of \(choices)")
            }
            let value = String(field)
            switch selector {
            case .scheduler: result.scheduler = value
            case .wakeup: result.wakeup = value
            case .congestion: result.congestion = value
            }
            extra += raw[retainedStart..<argument.startIndex]
            retainedStart = argument.endIndex
        }
        extra += raw[retainedStart...]
        // The VMM's clock guard, guest init and runner still scan whitespace-delimited fields.
        // A Linux-quoted value must not introduce a second managed field into those readers.
        for token in extra.split(whereSeparator: \.isWhitespace) {
            let (name, value) = parameter(token)
            let key = String(name)
            if key.trimmingCharacters(in: quotes) == bootClockKey
                || value != nil && (guestKeys.contains(key) || Selector(rawValue: key) != nil)
            {
                throw MicropodError.message(
                    "Managed kernel argument \(key) must be a separate argument in \(environmentKey)")
            }
        }
        result.extra = extra
        return result
    }

    private static func parameter(_ argument: Substring) -> (Substring, Substring?) {
        guard let equals = argument.utf8.firstIndex(of: 0x3d) else { return (argument, nil) }
        return (argument[..<equals], argument[argument.utf8.index(after: equals)...])
    }

    private static func arguments(in raw: String) throws -> [Substring] {
        let bytes = raw.utf8
        var result: [Substring] = []
        var start: String.Index?
        var quoted = false
        // Linux groups double-quoted text without applying shell escapes.
        for index in bytes.indices {
            let byte = bytes[index]
            guard byte != 0 else { throw MicropodError.message("\(environmentKey) cannot contain a NUL character") }
            if byte == 0x22 { quoted.toggle() }
            if !quoted, byte == 0x20 || (0x09...0x0d).contains(byte) {
                if let begin = start { result.append(raw[begin..<index]) }
                start = nil
            } else if start == nil {
                start = index
            }
        }
        guard !quoted else { throw MicropodError.message("Unclosed double quote in \(environmentKey)") }
        if let start { result.append(raw[start...]) }
        return result
    }

    static func workspaceArgument(_ path: String) throws -> String {
        let bytes = path.utf8
        let components = bytes.split(separator: 0x2f, omittingEmptySubsequences: false).dropFirst()
        guard bytes.first == 0x2f, !bytes.contains(0), !components.isEmpty,
            !components.contains(where: { $0.isEmpty || $0.elementsEqual([0x2e]) || $0.elementsEqual([0x2e, 0x2e]) })
        else {
            throw MicropodError.message("The HVF workspace must be a canonical absolute path below the root")
        }
        guard !bytes.contains(0x3a) else {
            throw MicropodError.message("The HVF workspace path cannot contain a colon in the VMM share specification")
        }
        if needsWorkspaceEncoding(path) {
            // The suffix lets guest-init reject an argument truncated to a shorter base64 string.
            return "\(encodedWorkspaceKey)=\(Data(bytes).base64EncodedString())."
        }
        return "\(workspaceKey)=\(path)"
    }

    private static func needsWorkspaceEncoding(_ path: String) -> Bool {
        path.unicodeScalars.contains { $0.properties.isWhitespace || $0 == "\"" || $0 == "'" }
    }

    static func workspaceDigest(_ path: String?) -> String? {
        guard let path, needsWorkspaceEncoding(path) else { return nil }
        return SHA256.hash(data: Data(path.utf8)).map { String(format: "%02x", $0) }.joined()
    }

    static func attestWorkspace(_ path: String?, labels: [String]) throws -> String? {
        guard let digest = workspaceDigest(path) else { return nil }
        let evidence = labels.filter { $0.hasPrefix(workspaceLabelPrefix) }
        guard evidence == [workspaceLabelPrefix + digest] else {
            throw MicropodError.message(
                "The HVF worker did not attest its workspace. Use a matching initrd and runner tools.")
        }
        return digest
    }
}

/// Deterministic command-line launch specification for the Rust Hypervisor.framework VMM (`micropod-vmm`).
public struct HVFWorkerLaunchSpec: Sendable, Equatable {
    public let vmmBinary: URL
    public let kernel: URL
    public let initrd: URL
    public let disk: URL
    public let ociTools: URL
    public let workspace: String?
    public let dockerSocket: URL
    public let ociSocket: URL
    public let buildkitSocket: URL
    public let workerID: UUID
    public let instanceID: UUID
    public let cpus: Int
    public let memoryMiB: Int
    public let publishedMTU: UInt32
    public let extraKernelArgs: String?
    public let expectedParentPID: Int32?

    public init(
        vmmBinary: URL, kernel: URL, initrd: URL, disk: URL, ociTools: URL, workspace: String?,
        dockerSocket: URL, ociSocket: URL, buildkitSocket: URL, workerID: UUID, instanceID: UUID,
        cpus: Int, memoryMiB: Int, publishedMTU: UInt32 = 9000, extraKernelArgs: String? = nil,
        expectedParentPID: Int32? = nil
    ) {
        self.vmmBinary = vmmBinary
        self.kernel = kernel
        self.initrd = initrd
        self.disk = disk
        self.ociTools = ociTools
        self.workspace = workspace
        self.dockerSocket = dockerSocket
        self.ociSocket = ociSocket
        self.buildkitSocket = buildkitSocket
        self.workerID = workerID
        self.instanceID = instanceID
        self.cpus = cpus
        self.memoryMiB = memoryMiB
        self.publishedMTU = publishedMTU
        self.extraKernelArgs = extraKernelArgs
        self.expectedParentPID = expectedParentPID
    }

    /// The command line sent to the VMM, or an empty string when the specification is invalid.
    public var kernelCmdline: String { (try? validatedKernelCmdline()) ?? "" }

    private func validatedKernelCmdline() throws -> String {
        let options = try HVFKernelArguments.parse(extraKernelArgs)
        var parts = [
            "quiet",
            "console=ttyAMA0",
            "rcupdate.rcu_expedited=1",
            "psi=1",
            "cgroup.memory=nokmem,nosocket",
            "slab_min_order=2",
            "swiotlb=noforce",
            "workqueue.power_efficient=1",
            "micropod.ci_sched=\(options.scheduler)",
            "micropod.ci_wakeup=\(options.wakeup)",
            "micropod.ci_sysctls=perf",
            "micropod.ci_cc=\(options.congestion)",
            "mp.worker=\(workerID.uuidString)",
            "mp.instance=\(instanceID.uuidString)",
            "mp.mtu=\(publishedMTU)",
        ]
        if let workspace, !workspace.isEmpty {
            parts.append(try HVFKernelArguments.workspaceArgument(workspace))
        }
        if let extra = options.extra?.trimmingCharacters(in: .whitespacesAndNewlines), !extra.isEmpty {
            parts.append(extra)
        }
        parts.append("panic=-1")
        return parts.joined(separator: " ")
    }

    /// The VMM arguments, or an empty array when the specification is invalid.
    public var arguments: [String] { (try? validatedArguments()) ?? [] }

    /// Build the VMM arguments or report which kernel option is invalid.
    public func validatedArguments() throws -> [String] {
        arguments(kernelCmdline: try validatedKernelCmdline())
    }

    private func arguments(kernelCmdline: String) -> [String] {
        var args = [
            "--kernel", kernel.path,
            "--initrd", initrd.path,
            "--disk", disk.path,
            "--cpus", String(cpus),
            "--memory-mib", String(memoryMiB),
            "--share", "oci-tools:\(ociTools.path):ro",
        ]
        if let workspace, !workspace.isEmpty {
            args += ["--share", "workspace:\(workspace)"]
        }
        args += [
            "--vsock-expose", "\(dockerSocket.path):2375",
            "--vsock-expose", "\(ociSocket.path):2376",
            "--vsock-expose", "\(buildkitSocket.path):2377",
            "--published-net",
            "--published-mtu", String(publishedMTU),
            "--cmdline", kernelCmdline,
        ]
        if let expectedParentPID {
            args += ["--parent-pid", String(expectedParentPID)]
        }
        return args
    }
}

extension CIWorker {
    func selectedVMM() throws -> CIWorkerVMM {
        let vmm = try CIWorkerVMM.parse(resourceEnvironment["MICROPOD_CI_VMM"])
        if vmm == .hvf && !isNativeRunner {
            throw MicropodError.message("MICROPOD_CI_VMM=hvf requires MICROPOD_CI_ENGINE=containerd")
        }
        if vmm == .hvf {
            _ = try HVFKernelArguments.parse(resourceEnvironment[HVFKernelArguments.environmentKey])
        }
        return vmm
    }

    func resolveHVFPaths() throws -> (vmmBinary: URL, initrd: URL) {
        let fm = FileManager.default
        let binPath: String
        if let explicit = resourceEnvironment["MICROPOD_CI_HVF_BIN"], !explicit.isEmpty {
            binPath = explicit
        } else if let exeDir = Bundle.main.executableURL?.resolvingSymlinksInPath().deletingLastPathComponent() {
            let sibling = exeDir.appendingPathComponent("micropod-vmm").path
            guard fm.isExecutableFile(atPath: sibling) else {
                throw MicropodError.message(
                    "Set MICROPOD_CI_HVF_BIN to the signed micropod-vmm binary when using MICROPOD_CI_VMM=hvf")
            }
            binPath = sibling
        } else {
            throw MicropodError.message("Missing MICROPOD_CI_HVF_BIN for MICROPOD_CI_VMM=hvf")
        }
        guard fm.isExecutableFile(atPath: binPath) else {
            throw MicropodError.message("MICROPOD_CI_HVF_BIN is not executable: \(binPath)")
        }

        let initrdPath: String
        if let explicit = resourceEnvironment["MICROPOD_CI_HVF_INITRD"], !explicit.isEmpty {
            initrdPath = explicit
        } else {
            let sibling = URL(fileURLWithPath: binPath).deletingLastPathComponent()
                .appendingPathComponent("mp-hvf-init.cpio").path
            guard fm.fileExists(atPath: sibling) else {
                throw MicropodError.message(
                    "Set MICROPOD_CI_HVF_INITRD to mp-hvf-init.cpio when using MICROPOD_CI_VMM=hvf")
            }
            initrdPath = sibling
        }
        guard fm.fileExists(atPath: initrdPath) else {
            throw MicropodError.message("MICROPOD_CI_HVF_INITRD not found: \(initrdPath)")
        }
        return (URL(fileURLWithPath: binPath), URL(fileURLWithPath: initrdPath))
    }

    func launchHVFProcess(
        config: Configuration, instanceID: UUID, cpus: Int, diskURL: URL, ociTools: URL
    ) throws -> Process {
        let (vmmBin, initrd) = try resolveHVFPaths()
        guard let kernelPath = config.kernel else {
            throw MicropodError.message("MICROPOD_CI_VMM=hvf requires MICROPOD_CI_KERNEL (Linux ARM64 Image)")
        }
        let spec = HVFWorkerLaunchSpec(
            vmmBinary: vmmBin,
            kernel: URL(fileURLWithPath: kernelPath),
            initrd: initrd,
            disk: diskURL,
            ociTools: ociTools,
            workspace: config.workspace,
            dockerSocket: dockerSocket,
            ociSocket: ociSocket,
            buildkitSocket: buildkitSocket,
            workerID: config.worker,
            instanceID: instanceID,
            cpus: cpus,
            memoryMiB: config.memoryMiB,
            publishedMTU: config.publishedMTU ?? 9000,
            extraKernelArgs: resourceEnvironment[HVFKernelArguments.environmentKey],
            expectedParentPID: getpid()
        )
        let proc = Process()
        proc.executableURL = spec.vmmBinary
        proc.arguments = try spec.validatedArguments()
        proc.standardOutput = FileHandle.standardOutput
        proc.standardError = FileHandle.standardError
        proc.standardInput = FileHandle.nullDevice
        try proc.run()
        return proc
    }
}
