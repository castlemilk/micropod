import Darwin
import Foundation
import MicropodCore
import XCTest

@testable import MicropodApp

final class AgentSupervisorTests: XCTestCase {
    private var runDirectory: URL!

    override func setUp() async throws {
        runDirectory = FileManager.default.temporaryDirectory
            .appendingPathComponent("agent-supervisor-tests-\(UUID().uuidString)")
        try FileManager.default.createDirectory(at: runDirectory, withIntermediateDirectories: true)
    }

    override func tearDown() async throws {
        try? FileManager.default.removeItem(at: runDirectory)
    }

    // MARK: - Unix socket probe

    func testUnixSocketProbeDetectsBoundAndUnboundPaths() throws {
        // sun_path is ~104 bytes — keep the test path short.
        let socketPath = "/tmp/mpsup-\(UUID().uuidString.prefix(8)).sock"
        defer { try? FileManager.default.removeItem(atPath: socketPath) }
        XCTAssertFalse(AgentSupervisor.unixSocketAccepts(socketPath))

        let fd = try bindUnixListener(at: socketPath)
        defer { close(fd) }
        XCTAssertTrue(AgentSupervisor.unixSocketAccepts(socketPath))
    }

    // MARK: - Spawn / adopt / terminate

    func testHealthyEndpointIsAdoptedWithoutSpawn() async throws {
        let spec = AgentSpec(
            id: "fake", displayName: "Fake", binaryName: "definitely-not-a-real-binary",
            probe: .custom { true },
            enabledDefaultsKey: "test.fake.enabled", endpoint: "nowhere")
        let statuses = StatusSink()
        let supervisor = AgentSupervisor(
            specs: [spec], runDirectory: runDirectory,
            isEnabled: { _ in true },
            onStatus: { statuses.record($0) })

        await tickUntilOwnerVerified(supervisor)

        let status = await supervisor.statuses().first
        XCTAssertEqual(status?.state, .adopted)
        XCTAssertNil(status?.pid)
    }

    func testUnhealthySpecSpawnsAndTerminatesOwnedChild() async throws {
        // A real process we control: /bin/sleep with a probe that only goes
        // healthy once we flip the flag — proves spawn → running → terminate.
        let healthy = FlagBox()
        let spec = AgentSpec(
            id: "sleeper", displayName: "Sleeper", binaryName: "sleep",
            arguments: ["300"],
            probe: .custom { healthy.value },
            enabledDefaultsKey: "test.sleeper.enabled", endpoint: "n/a",
            binaryPathOverride: "/bin/sleep", reapsForeignCopies: false)
        let supervisor = AgentSupervisor(
            specs: [spec], runDirectory: runDirectory,
            isEnabled: { _ in true },
            onStatus: { _ in })

        // One failed probe is only a suspicion — spawn happens on the
        // second consecutive miss.
        await supervisor.tick()
        var status = await supervisor.statuses().first
        XCTAssertNil(status?.pid)

        await supervisor.tick()
        status = await supervisor.statuses().first
        XCTAssertEqual(status?.state, .starting)
        let pid = status?.pid
        XCTAssertNotNil(pid)

        // Probe goes healthy → owned child marked running.
        healthy.set(true)
        await supervisor.tick()
        status = await supervisor.statuses().first
        XCTAssertEqual(status?.state, .running)
        XCTAssertEqual(status?.pid, pid)

        // PID file exists while the child is ours.
        let pidFile = runDirectory.appendingPathComponent("sleeper.pid")
        XCTAssertTrue(FileManager.default.fileExists(atPath: pidFile.path))

        // Quit-time teardown kills the owned child and removes the pid file.
        supervisor.terminateOwnedSync()
        XCTAssertFalse(processAlive(pid!))
        XCTAssertFalse(FileManager.default.fileExists(atPath: pidFile.path))
    }

    func testDisabledAgentIsNotSpawned() async throws {
        let spec = AgentSpec(
            id: "off", displayName: "Off", binaryName: "sleep",
            arguments: ["300"],
            probe: .custom { false },
            enabledDefaultsKey: "test.off.enabled", endpoint: "n/a",
            binaryPathOverride: "/bin/sleep", reapsForeignCopies: false)
        let supervisor = AgentSupervisor(
            specs: [spec], runDirectory: runDirectory,
            isEnabled: { _ in false },
            onStatus: { _ in })

        await tickUntilOwnerVerified(supervisor)

        let status = await supervisor.statuses().first
        XCTAssertEqual(status?.state, .stopped)
        XCTAssertNil(status?.pid)
    }

    // MARK: - Orphan reaping safety

    func testStalePidFileDoesNotKillUnrelatedProcess() async throws {
        // A live process whose path does NOT match the spec binary — the
        // pid could have been recycled; the supervisor must leave it alone.
        let sleeper = Process()
        sleeper.executableURL = URL(fileURLWithPath: "/bin/sleep")
        sleeper.arguments = ["60"]
        try sleeper.run()
        defer {
            if sleeper.isRunning { sleeper.terminate() }
        }
        XCTAssertTrue(processAlive(sleeper.processIdentifier))

        let record: [String: Any] = [
            "pid": Int(sleeper.processIdentifier),
            "binary": "nonexistent-test-shim",
        ]
        let pidFile = runDirectory.appendingPathComponent("docker-shim.pid")
        try JSONSerialization.data(withJSONObject: record).write(to: pidFile)

        // The override keeps the supervisor from resolving the real shim in
        // .build/ and spawning it mid-test — the agent lands in `.missing`.
        let spec = AgentSpec(
            id: "docker-shim", displayName: "Shim", binaryName: "nonexistent-test-shim",
            probe: .custom { false },
            enabledDefaultsKey: "test.shim.enabled", endpoint: "sock",
            binaryPathOverride: "/nonexistent/nonexistent-test-shim",
            reapsForeignCopies: false)
        let supervisor = AgentSupervisor(
            specs: [spec], runDirectory: runDirectory,
            isEnabled: { _ in true },
            onStatus: { _ in })

        // Reaping needs two confirmed misses.
        await supervisor.tick()
        await supervisor.tick()

        XCTAssertTrue(
            processAlive(sleeper.processIdentifier),
            "orphan reaper must never kill a pid that isn't our binary")
        XCTAssertFalse(FileManager.default.fileExists(atPath: pidFile.path))
    }

    /// "Restart All" must not respawn a disabled agent — restart() runs a
    /// tick, and a tick on a disabled spec stops it rather than spawning.
    func testRestartAllSkipsDisabledAgents() async throws {
        let enabled = AgentSpec(
            id: "on", displayName: "On", binaryName: "definitely-not-a-real-binary",
            probe: .custom { true },
            enabledDefaultsKey: "test.on.enabled", endpoint: "nowhere")
        let disabled = AgentSpec(
            id: "off", displayName: "Off", binaryName: "sleep",
            arguments: ["300"],
            probe: .custom { false },
            enabledDefaultsKey: "test.off.enabled", endpoint: "n/a",
            binaryPathOverride: "/bin/sleep", reapsForeignCopies: false)
        let supervisor = AgentSupervisor(
            specs: [enabled, disabled], runDirectory: runDirectory,
            isEnabled: { $0.id == "on" },
            onStatus: { _ in })

        await supervisor.tick()
        await supervisor.restartAll()

        let statuses = await supervisor.statuses()
        XCTAssertEqual(statuses.first { $0.id == "on" }?.state, .adopted)
        let off = statuses.first { $0.id == "off" }
        XCTAssertEqual(off?.state, .stopped)
        XCTAssertNil(off?.pid)
        XCTAssertFalse(
            FileManager.default.fileExists(
                atPath: runDirectory.appendingPathComponent("off.pid").path))
    }

    // MARK: - Endpoint identity

    /// A healthy endpoint served by a different binary than the one the
    /// supervisor would spawn must not be adopted — and a foreign-named
    /// process must never be killed to make room.
    func testForeignEndpointOwnerIsNotAdopted() async throws {
        let socketPath = "/tmp/mpsup-\(UUID().uuidString.prefix(8)).sock"
        let nc = try spawnNCListener(at: socketPath)
        defer {
            if nc.isRunning { nc.terminate() }
            try? FileManager.default.removeItem(atPath: socketPath)
        }
        try await waitForSocket(socketPath)

        // The spec reaps foreign copies of its binary: name it after a
        // private copy, never a system binary, or the tick SIGTERMs every
        // `sleep` on the host (CI steps' `sleep 5` included).
        let sleeper = try privateSleepBinary()
        defer { try? FileManager.default.removeItem(atPath: sleeper.path) }
        let spec = AgentSpec(
            id: "fake", displayName: "Fake", binaryName: sleeper.name,
            probe: .unixSocket(path: socketPath),
            enabledDefaultsKey: "test.fake-foreign.enabled", endpoint: socketPath,
            binaryPathOverride: sleeper.path)
        let supervisor = AgentSupervisor(
            specs: [spec], runDirectory: runDirectory,
            isEnabled: { _ in true },
            onStatus: { _ in })

        await tickUntilOwnerVerified(supervisor)

        let status = await supervisor.statuses().first
        XCTAssertEqual(status?.state, .retryPending)
        XCTAssertTrue(status?.lastError?.contains("foreign") ?? false)
        XCTAssertTrue(
            processAlive(nc.processIdentifier),
            "a foreign-named process must be left alone")
    }

    /// An endpoint served by exactly the binary the supervisor would
    /// spawn is adopted as before.
    func testExpectedBinaryEndpointIsAdopted() async throws {
        let socketPath = "/tmp/mpsup-\(UUID().uuidString.prefix(8)).sock"
        let nc = try spawnNCListener(at: socketPath)
        defer {
            if nc.isRunning { nc.terminate() }
            try? FileManager.default.removeItem(atPath: socketPath)
        }
        try await waitForSocket(socketPath)

        let spec = AgentSpec(
            id: "fake", displayName: "Fake", binaryName: "nc",
            probe: .unixSocket(path: socketPath),
            enabledDefaultsKey: "test.fake-own.enabled", endpoint: socketPath,
            binaryPathOverride: "/usr/bin/nc")
        let supervisor = AgentSupervisor(
            specs: [spec], runDirectory: runDirectory,
            isEnabled: { _ in true },
            onStatus: { _ in })

        await tickUntilOwnerVerified(supervisor)

        let status = await supervisor.statuses().first
        XCTAssertEqual(status?.state, .adopted)
    }

    /// A process whose binary file was replaced *after* it exec'd (the
    /// Sparkle bundle-swap orphan shape) is stale even though its path
    /// matches — it must be rejected and reaped so a fresh copy binds.
    func testStaleBinaryCopyIsReapedNotAdopted() async throws {
        // Copy nc and stamp the copy with a future mtime: the running
        // process necessarily predates "its" binary.
        let name = "nc-stale-\(UUID().uuidString.prefix(8))"
        // proc_pidpath is canonical — resolve symlinks so the override
        // path matches what the process reports (e.g. /var → /private/var).
        let staleBinary = URL(fileURLWithPath: NSTemporaryDirectory() + name)
            .resolvingSymlinksInPath().path
        try FileManager.default.copyItem(atPath: "/usr/bin/nc", toPath: staleBinary)
        try FileManager.default.setAttributes(
            [.modificationDate: Date().addingTimeInterval(3600)],
            ofItemAtPath: staleBinary)
        defer { try? FileManager.default.removeItem(atPath: staleBinary) }

        let socketPath = "/tmp/mpsup-\(UUID().uuidString.prefix(8)).sock"
        let stale = Process()
        stale.executableURL = URL(fileURLWithPath: staleBinary)
        stale.arguments = ["-lU", "-k", socketPath]
        try stale.run()
        defer {
            if stale.isRunning { stale.terminate() }
            try? FileManager.default.removeItem(atPath: socketPath)
        }
        try await waitForSocket(socketPath)

        let spec = AgentSpec(
            id: "fake", displayName: "Fake", binaryName: name,
            probe: .unixSocket(path: socketPath),
            enabledDefaultsKey: "test.fake-stale.enabled", endpoint: socketPath,
            binaryPathOverride: staleBinary)
        let supervisor = AgentSupervisor(
            specs: [spec], runDirectory: runDirectory,
            isEnabled: { _ in true },
            onStatus: { _ in })

        await tickUntilOwnerVerified(supervisor)

        let status = await supervisor.statuses().first
        XCTAssertEqual(status?.state, .retryPending)
        XCTAssertFalse(
            processAlive(stale.processIdentifier),
            "a stale same-name copy must be reaped so a fresh binary can bind")
    }

    /// A same-name process serving a *different* endpoint — the installed
    /// app's agent while a dev build or smoke test runs — must never be
    /// killed, even when our own endpoint is down and we're about to respawn.
    func testSameNameProcessOnAnotherEndpointIsNeverReaped() async throws {
        let bins = try sameNameListeners()
        defer { bins.cleanup() }
        let otherSocket = "/tmp/mpsup-\(UUID().uuidString.prefix(8)).sock"
        let other = Process()
        other.executableURL = URL(fileURLWithPath: bins.theirs)
        other.arguments = ["-lU", "-k", otherSocket]
        try other.run()
        defer {
            if other.isRunning { other.terminate() }
            try? FileManager.default.removeItem(atPath: otherSocket)
        }
        try await waitForSocket(otherSocket)

        // Our endpoint has nothing on it: two failed probes → respawn path,
        // which used to SIGTERM every process with the binary's name.
        let ourSocket = "/tmp/mpsup-\(UUID().uuidString.prefix(8)).sock"
        let spec = AgentSpec(
            id: "fake", displayName: "Fake", binaryName: bins.name,
            probe: .unixSocket(path: ourSocket),
            enabledDefaultsKey: "test.fake-isolated.enabled", endpoint: ourSocket,
            binaryPathOverride: bins.ours)
        let supervisor = AgentSupervisor(
            specs: [spec], runDirectory: runDirectory, isEnabled: { _ in true }, onStatus: { _ in })
        await supervisor.tick()
        await supervisor.tick()
        await supervisor.stop()
        try? FileManager.default.removeItem(atPath: ourSocket)

        XCTAssertTrue(
            processAlive(other.processIdentifier),
            "a same-name process on another endpoint belongs to someone else")
    }

    /// A healthy endpoint served by a same-name binary at a different path
    /// (the launchd-managed MicropodAPI on 45454) is a conflict to surface,
    /// not a process to kill.
    func testHealthySameNameBinaryAtAnotherPathIsNotReaped() async throws {
        let bins = try sameNameListeners()
        defer { bins.cleanup() }
        let socketPath = "/tmp/mpsup-\(UUID().uuidString.prefix(8)).sock"
        let theirs = Process()
        theirs.executableURL = URL(fileURLWithPath: bins.theirs)
        theirs.arguments = ["-lU", "-k", socketPath]
        try theirs.run()
        defer {
            if theirs.isRunning { theirs.terminate() }
            try? FileManager.default.removeItem(atPath: socketPath)
        }
        try await waitForSocket(socketPath)

        let spec = AgentSpec(
            id: "fake", displayName: "Fake", binaryName: bins.name,
            probe: .unixSocket(path: socketPath),
            enabledDefaultsKey: "test.fake-otherpath.enabled", endpoint: socketPath,
            binaryPathOverride: bins.ours)
        let supervisor = AgentSupervisor(
            specs: [spec], runDirectory: runDirectory, isEnabled: { _ in true }, onStatus: { _ in })
        await tickUntilOwnerVerified(supervisor)

        let status = await supervisor.statuses().first
        XCTAssertEqual(status?.state, .retryPending)
        XCTAssertTrue(status?.lastError?.contains("foreign") ?? false)
        XCTAssertTrue(processAlive(theirs.processIdentifier), "another build's healthy agent must be left alone")
    }

    /// A wedged-but-listening API port owned by a different binary gets
    /// the same treatment — this is the stale-MicropodAPI-on-45454 case.
    func testForeignHTTPListenerIsNotAdopted() async throws {
        // Find a free port, then hand it to a dumb HTTP responder.
        let port = try ephemeralTCPPort()
        let http = Process()
        http.executableURL = URL(fileURLWithPath: "/usr/bin/python3")
        http.arguments = ["-m", "http.server", "\(port)", "--bind", "127.0.0.1"]
        try http.run()
        defer { if http.isRunning { http.terminate() } }
        try await waitForHTTP(port: port)

        // The spec reaps foreign copies of its binary: name it after a
        // private copy, never a system binary, or the tick SIGTERMs every
        // `sleep` on the host (CI steps' `sleep 5` included).
        let sleeper = try privateSleepBinary()
        defer { try? FileManager.default.removeItem(atPath: sleeper.path) }
        let spec = AgentSpec(
            id: "fake", displayName: "Fake", binaryName: sleeper.name,
            probe: .http(port: port, path: "/"),
            enabledDefaultsKey: "test.fake-http.enabled", endpoint: "127.0.0.1:\(port)",
            binaryPathOverride: sleeper.path)
        let supervisor = AgentSupervisor(
            specs: [spec], runDirectory: runDirectory,
            isEnabled: { _ in true },
            onStatus: { _ in })

        await tickUntilOwnerVerified(supervisor)

        let status = await supervisor.statuses().first
        XCTAssertEqual(status?.state, .retryPending)
        XCTAssertTrue(
            processAlive(http.processIdentifier),
            "a foreign-named process must be left alone")
    }

    // MARK: - Helpers

    /// A uniquely named copy of /bin/sleep, so a spec that reaps foreign
    /// copies of its binary can only ever match processes of this test.
    /// Two copies of nc with the same basename in different directories —
    /// "same binary name, different build" (installed app vs dev build, or
    /// the launchd MicropodAPI vs the app's own).
    private func sameNameListeners() throws -> (name: String, ours: String, theirs: String, cleanup: () -> Void) {
        let name = "nc-agent-\(UUID().uuidString.prefix(8))"
        let base = URL(fileURLWithPath: NSTemporaryDirectory()).resolvingSymlinksInPath()
        let oursDir = base.appendingPathComponent("ours-\(UUID().uuidString.prefix(6))")
        let theirsDir = base.appendingPathComponent("theirs-\(UUID().uuidString.prefix(6))")
        for dir in [oursDir, theirsDir] {
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            try FileManager.default.copyItem(atPath: "/usr/bin/nc", toPath: dir.appendingPathComponent(name).path)
        }
        return (
            name, oursDir.appendingPathComponent(name).path, theirsDir.appendingPathComponent(name).path,
            {
                try? FileManager.default.removeItem(at: oursDir)
                try? FileManager.default.removeItem(at: theirsDir)
            }
        )
    }

    /// Ticks until the supervisor reached an ownership verdict. On a heavily
    /// loaded host lsof can exceed its bound; the supervisor then refuses to
    /// decide that tick (fail closed) and says so — the verdict comes later.
    private func tickUntilOwnerVerified(_ supervisor: AgentSupervisor, attempts: Int = 4) async {
        for _ in 0..<attempts {
            await supervisor.tick()
            let status = await supervisor.statuses().first
            if status?.lastError?.contains("could not verify") != true { return }
        }
    }

    private func privateSleepBinary() throws -> (name: String, path: String) {
        let name = "sleep-test-\(UUID().uuidString.prefix(8))"
        let path = URL(fileURLWithPath: NSTemporaryDirectory() + name)
            .resolvingSymlinksInPath().path
        try FileManager.default.copyItem(atPath: "/bin/sleep", toPath: path)
        return (name, path)
    }

    private func processAlive(_ pid: Int32) -> Bool {
        kill(pid, 0) == 0 || errno == EPERM
    }

    private func spawnNCListener(at socketPath: String) throws -> Process {
        let nc = Process()
        nc.executableURL = URL(fileURLWithPath: "/usr/bin/nc")
        nc.arguments = ["-lU", "-k", socketPath]
        try nc.run()
        return nc
    }

    private func waitForSocket(_ path: String) async throws {
        for _ in 0..<50 {
            if AgentSupervisor.unixSocketAccepts(path) { return }
            try await Task.sleep(for: .milliseconds(100))
        }
        XCTFail("listener never bound \(path)")
    }

    /// Reserve-then-release an ephemeral TCP port for a test responder.
    private func ephemeralTCPPort() throws -> UInt16 {
        let fd = socket(AF_INET, SOCK_STREAM, 0)
        guard fd >= 0 else { throw POSIXError(.EIO) }
        defer { close(fd) }
        var addr = sockaddr_in()
        addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port = 0
        addr.sin_addr = in_addr(s_addr: INADDR_LOOPBACK.bigEndian)
        guard
            withUnsafePointer(
                to: &addr,
                {
                    $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                        Darwin.bind(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
                    }
                }) == 0
        else { throw POSIXError(.EIO) }
        var bound = sockaddr_in()
        var len = socklen_t(MemoryLayout<sockaddr_in>.size)
        guard
            withUnsafeMutablePointer(
                to: &bound,
                {
                    $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                        getsockname(fd, $0, &len)
                    }
                }) == 0
        else { throw POSIXError(.EIO) }
        return UInt16(bigEndian: bound.sin_port)
    }

    private func waitForHTTP(port: UInt16) async throws {
        let url = URL(string: "http://127.0.0.1:\(port)/")!
        for _ in 0..<50 {
            if let (_, response) = try? await URLSession.shared.data(from: url),
                (response as? HTTPURLResponse).map({ (200..<300).contains($0.statusCode) })
                    == true
            {
                return
            }
            try await Task.sleep(for: .milliseconds(100))
        }
        XCTFail("HTTP responder never came up on \(port)")
    }

    private func bindUnixListener(at path: String) throws -> Int32 {
        let fd = socket(AF_UNIX, SOCK_STREAM, 0)
        guard fd >= 0 else { throw NSError(domain: "socket", code: Int(errno)) }
        var addr = sockaddr_un()
        addr.sun_family = sa_family_t(AF_UNIX)
        let pathBytes = Array(path.utf8CString)
        guard pathBytes.count <= MemoryLayout.size(ofValue: addr.sun_path) else {
            throw NSError(domain: "path-too-long", code: 0)
        }
        withUnsafeMutableBytes(of: &addr.sun_path) { dest in
            pathBytes.withUnsafeBufferPointer { src in
                memcpy(dest.baseAddress, src.baseAddress!, pathBytes.count)
            }
        }
        let bound = withUnsafePointer(to: &addr) { ptr in
            ptr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sa in
                Darwin.bind(fd, sa, socklen_t(MemoryLayout<sockaddr_un>.size))
            }
        }
        guard bound == 0 else { throw NSError(domain: "bind", code: Int(errno)) }
        guard listen(fd, 1) == 0 else { throw NSError(domain: "listen", code: Int(errno)) }
        return fd
    }
}

/// Mutable flag readable from the @Sendable probe closure.
private final class FlagBox: @unchecked Sendable {
    private let lock = NSLock()
    private var flag = false
    var value: Bool {
        lock.lock()
        defer { lock.unlock() }
        return flag
    }
    func set(_ newValue: Bool) {
        lock.lock()
        flag = newValue
        lock.unlock()
    }
}

/// Collects the latest published status list.
private final class StatusSink: @unchecked Sendable {
    private let lock = NSLock()
    private var latest: [AgentStatus] = []
    func record(_ statuses: [AgentStatus]) {
        lock.lock()
        latest = statuses
        lock.unlock()
    }
}
