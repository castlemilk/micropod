//! Virtio-FS (Device ID 26) FUSE 7.31+ host directory share device.
//! Mounts macOS host directories directly inside Linux via `mount -t virtiofs <tag> <dst>`.

use std::collections::HashMap;
use std::ffi::CString;
use std::fs::{self, File, FileTimes, OpenOptions};
use std::io::ErrorKind;
use std::os::fd::AsRawFd;
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::{FileExt, MetadataExt, OpenOptionsExt, PermissionsExt};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use crate::{GuestMemory, VirtQueue, VirtioBackend, collect_readable, scatter_writable};

// FUSE opcodes (Linux include/uapi/linux/fuse.h)
const FUSE_LOOKUP: u32 = 1;
const FUSE_FORGET: u32 = 2;
const FUSE_GETATTR: u32 = 3;
const FUSE_SETATTR: u32 = 4;
const FUSE_READLINK: u32 = 5;
const FUSE_SYMLINK: u32 = 6;
const FUSE_MKDIR: u32 = 9;
const FUSE_UNLINK: u32 = 10;
const FUSE_RMDIR: u32 = 11;
const FUSE_RENAME: u32 = 12;
const FUSE_LINK: u32 = 13;
const FUSE_OPEN: u32 = 14;
const FUSE_READ: u32 = 15;
const FUSE_WRITE: u32 = 16;
const FUSE_STATFS: u32 = 17;
const FUSE_RELEASE: u32 = 18;
const FUSE_FSYNC: u32 = 20;
const FUSE_GETXATTR: u32 = 22;
const FUSE_LISTXATTR: u32 = 23;
const FUSE_FLUSH: u32 = 25;
const FUSE_INIT: u32 = 26;
const FUSE_OPENDIR: u32 = 27;
const FUSE_READDIR: u32 = 28;
const FUSE_RELEASEDIR: u32 = 29;
const FUSE_FSYNCDIR: u32 = 30;
const FUSE_ACCESS: u32 = 34;
const FUSE_CREATE: u32 = 35;
const FUSE_DESTROY: u32 = 38;
const FUSE_BATCH_FORGET: u32 = 42;
const FUSE_READDIRPLUS: u32 = 44;
const FUSE_RENAME2: u32 = 45;
const FUSE_LSEEK: u32 = 46;
const FUSE_STATX: u32 = 52;

const FUSE_ASYNC_READ: u32 = 1 << 0;
const FUSE_BIG_WRITES: u32 = 1 << 5;
const FUSE_AUTO_INVAL_DATA: u32 = 1 << 12;
const FUSE_DO_READDIRPLUS: u32 = 1 << 13;
const FUSE_NO_OPEN_SUPPORT: u32 = 1 << 17;
const FUSE_PARALLEL_DIROPS: u32 = 1 << 18;
const FUSE_MAX_PAGES: u32 = 1 << 22;
const FUSE_CACHE_SYMLINKS: u32 = 1 << 23;
const FUSE_EXPLICIT_INVAL_DATA: u32 = 1 << 25;

// FUSE open_flags (Linux include/uapi/linux/fuse.h)
const FOPEN_KEEP_CACHE: u32 = 1 << 1;
const FOPEN_CACHE_DIR: u32 = 1 << 3;
const FOPEN_NOFLUSH: u32 = 1 << 5;

const FATTR_MODE: u32 = 1 << 0;
const FATTR_SIZE: u32 = 1 << 3;
const FATTR_ATIME: u32 = 1 << 4;
const FATTR_MTIME: u32 = 1 << 5;
const FATTR_FH: u32 = 1 << 6;
const FATTR_ATIME_NOW: u32 = 1 << 7;
const FATTR_MTIME_NOW: u32 = 1 << 8;

const FUSE_ROOT_ID: u64 = 1;

// Linux errno values (arm64 generic)
const LINUX_EPERM: i32 = 1;
const LINUX_ENOENT: i32 = 2;
const LINUX_EIO: i32 = 5;
const LINUX_EBADF: i32 = 9;
const LINUX_EACCES: i32 = 13;
const LINUX_EEXIST: i32 = 17;
const LINUX_ENOTDIR: i32 = 20;
const LINUX_EISDIR: i32 = 21;
const LINUX_EINVAL: i32 = 22;
const LINUX_EROFS: i32 = 30;
const LINUX_ENAMETOOLONG: i32 = 36;
const LINUX_ENOSYS: i32 = 38;
const LINUX_ENOTEMPTY: i32 = 39;
const LINUX_ENODATA: i32 = 61;
const LINUX_EOPNOTSUPP: i32 = 95;
const LINUX_ESTALE: i32 = 116;
const FUSE_GETATTR_FH: u32 = 1;
#[cfg(target_vendor = "apple")]
const METADATA_OPEN_FLAGS: i32 = libc::O_EVTONLY;
#[cfg(not(target_vendor = "apple"))]
const METADATA_OPEN_FLAGS: i32 = 0;

// Writable shares may be changed by a host editor while a guest file is open.
fn cache_validity(read_only: bool) -> (u64, u32) {
    if read_only { (3600, 0) } else { (0, 8_000_000) }
}

struct OpenFile {
    nodeid: u64,
    file: Arc<File>,
}

fn io_err_to_linux(e: &std::io::Error) -> i32 {
    if let Some(raw) = e.raw_os_error() {
        return match raw {
            libc::EPERM => LINUX_EPERM,
            libc::ENOENT => LINUX_ENOENT,
            libc::EACCES => LINUX_EACCES,
            libc::EEXIST => LINUX_EEXIST,
            libc::ENOTDIR => LINUX_ENOTDIR,
            libc::EISDIR => LINUX_EISDIR,
            libc::EINVAL => LINUX_EINVAL,
            libc::EROFS => LINUX_EROFS,
            libc::ENAMETOOLONG => LINUX_ENAMETOOLONG,
            libc::ENOTEMPTY => LINUX_ENOTEMPTY,
            libc::ENOSYS => LINUX_ENOSYS,
            libc::ENODATA => LINUX_ENODATA,
            libc::EOPNOTSUPP => LINUX_EOPNOTSUPP,
            _ => LINUX_EIO,
        };
    }
    match e.kind() {
        ErrorKind::NotFound => LINUX_ENOENT,
        ErrorKind::PermissionDenied => LINUX_EACCES,
        ErrorKind::AlreadyExists => LINUX_EEXIST,
        ErrorKind::InvalidInput => LINUX_EINVAL,
        _ => LINUX_EIO,
    }
}

#[derive(Default)]
pub struct FsMetrics {
    pub requests: AtomicU64,
    pub bytes_read: AtomicU64,
    pub bytes_written: AtomicU64,
}

#[derive(Clone)]
struct DirEntryRec {
    name: Vec<u8>,
    path: PathBuf,
    ino: u64,
    dtype: u32,
}

pub struct VirtioFs {
    tag: [u8; 36],
    root: PathBuf,
    read_only: bool,
    next_nodeid: u64,
    next_fh: u64,
    node_to_path: HashMap<u64, PathBuf>,
    path_to_node: HashMap<PathBuf, u64>,
    host_inodes: HashMap<u64, (u64, u64)>,
    open_files: HashMap<u64, OpenFile>,
    open_dirs: HashMap<u64, Arc<Vec<DirEntryRec>>>,
    // Read-only hot caches (eliminates repeat host lstat/open syscalls on oci-tools!)
    ro_lookup_cache: HashMap<(u64, Vec<u8>), Result<u64, i32>>,
    ro_attr_cache: HashMap<u64, fs::Metadata>,
    ro_file_cache: HashMap<u64, Arc<File>>,
    read_buf: Vec<u8>,
    metrics: Arc<FsMetrics>,
}

impl VirtioFs {
    pub fn new(tag: &str, root: PathBuf, read_only: bool, metrics: Arc<FsMetrics>) -> std::io::Result<Self> {
        let canon = fs::canonicalize(&root)?;
        let mut tag_bytes = [0u8; 36];
        let src = tag.as_bytes();
        let n = src.len().min(36);
        tag_bytes[..n].copy_from_slice(&src[..n]);

        let mut node_to_path = HashMap::new();
        let mut path_to_node = HashMap::new();
        node_to_path.insert(FUSE_ROOT_ID, canon.clone());
        path_to_node.insert(canon.clone(), FUSE_ROOT_ID);

        Ok(Self {
            tag: tag_bytes,
            root: canon,
            read_only,
            next_nodeid: 2,
            next_fh: 1,
            node_to_path,
            path_to_node,
            host_inodes: HashMap::new(),
            open_files: HashMap::new(),
            open_dirs: HashMap::new(),
            ro_lookup_cache: HashMap::new(),
            ro_attr_cache: HashMap::new(),
            ro_file_cache: HashMap::new(),
            read_buf: vec![0u8; 256 * 1024],
            metrics,
        })
    }

    fn intern_path(&mut self, path: PathBuf) -> u64 {
        if let Some(&id) = self.path_to_node.get(&path) {
            return id;
        }
        let id = self.next_nodeid;
        self.next_nodeid += 1;
        self.node_to_path.insert(id, path.clone());
        self.path_to_node.insert(path, id);
        id
    }

    fn retire_path(&mut self, path: &Path) {
        if let Some(id) = self.path_to_node.remove(path) {
            self.node_to_path.remove(&id);
            self.host_inodes.remove(&id);
        }
    }

    // An editor can atomically replace a pathname. Linux keys its page cache by
    // FUSE node ID, so the replacement must receive a distinct ID while open
    // handles to the old inode continue to address their original contents.
    fn observe_path(&mut self, path: PathBuf, md: &fs::Metadata) -> u64 {
        if self.read_only {
            return self.intern_path(path);
        }
        let identity = (md.dev(), md.ino());
        if self.path_to_node.get(&path).is_some_and(|id| !self.matches_inode(*id, md)) {
            self.retire_path(&path);
        }
        let id = self.intern_path(path);
        self.host_inodes.entry(id).or_insert(identity);
        id
    }

    fn matches_inode(&self, nodeid: u64, md: &fs::Metadata) -> bool {
        self.host_inodes.get(&nodeid).is_none_or(|known| *known == (md.dev(), md.ino()))
    }

    fn node_metadata(&self, nodeid: u64, body: &[u8]) -> Result<fs::Metadata, i32> {
        if !self.read_only && body.len() >= 16 && u32::from_le_bytes(body[..4].try_into().unwrap()) & FUSE_GETATTR_FH != 0 {
            let fh = u64::from_le_bytes(body[8..16].try_into().unwrap());
            let open = self.open_files.get(&fh).filter(|open| open.nodeid == nodeid).ok_or(LINUX_EBADF)?;
            return open.file.metadata().map_err(|e| io_err_to_linux(&e));
        }
        let by_path = self.node_to_path.get(&nodeid).ok_or(LINUX_ESTALE).and_then(|p| {
            let md = fs::symlink_metadata(p).map_err(|e| io_err_to_linux(&e))?;
            if self.matches_inode(nodeid, &md) { Ok(md) } else { Err(LINUX_ESTALE) }
        });
        if matches!(by_path, Err(LINUX_ENOENT | LINUX_ESTALE)) {
            if let Some(open) = self.open_files.values().find(|open| open.nodeid == nodeid) {
                return open.file.metadata().map_err(|e| io_err_to_linux(&e));
            }
        }
        by_path
    }

    fn set_attributes(&self, nodeid: u64, body: &[u8], valid: u32) -> Result<fs::Metadata, i32> {
        let file = if valid & FATTR_FH != 0 {
            let fh = u64::from_le_bytes(body[8..16].try_into().unwrap());
            self.open_files.get(&fh).filter(|f| f.nodeid == nodeid)
                .ok_or(LINUX_EBADF)?.file.clone()
        } else {
            let path = self.node_to_path.get(&nodeid).ok_or(LINUX_ESTALE)?;
            let mut opts = OpenOptions::new();
            if valid & FATTR_SIZE != 0 {
                opts.write(true);
            } else {
                opts.read(true);
            }
            // O_EVTONLY allows metadata operations on a mode-000 inode.
            let flags = if valid & FATTR_SIZE != 0 { 0 } else { METADATA_OPEN_FLAGS };
            opts.custom_flags(flags | libc::O_NOFOLLOW | libc::O_NONBLOCK);
            let f = opts.open(path).map_err(|e| io_err_to_linux(&e))?;
            let md = f.metadata().map_err(|e| io_err_to_linux(&e))?;
            if !self.matches_inode(nodeid, &md) {
                return Err(LINUX_ESTALE);
            }
            Arc::new(f)
        };
        if valid & FATTR_SIZE != 0 {
            let size = u64::from_le_bytes(body[16..24].try_into().unwrap());
            file.set_len(size).map_err(|e| io_err_to_linux(&e))?;
        }
        if valid & FATTR_MODE != 0 {
            let mode = u32::from_le_bytes(body[68..72].try_into().unwrap());
            file.set_permissions(fs::Permissions::from_mode(mode & 0o7777)).map_err(|e| io_err_to_linux(&e))?;
        }
        if valid & (FATTR_ATIME | FATTR_MTIME | FATTR_ATIME_NOW | FATTR_MTIME_NOW) != 0 {
            let timestamp = |offset: usize, subsec_offset: usize, now_flag: u32| -> Result<SystemTime, i32> {
                if valid & now_flag != 0 { return Ok(SystemTime::now()); }
                let secs = i64::from_le_bytes(body[offset..offset+8].try_into().unwrap());
                let nanos = u32::from_le_bytes(body[subsec_offset..subsec_offset+4].try_into().unwrap());
                if nanos >= 1_000_000_000 { return Err(LINUX_EINVAL); }
                let whole = Duration::from_secs(secs.unsigned_abs());
                let base = if secs < 0 { UNIX_EPOCH.checked_sub(whole) } else { UNIX_EPOCH.checked_add(whole) };
                base.and_then(|t| t.checked_add(Duration::from_nanos(u64::from(nanos)))).ok_or(LINUX_EINVAL)
            };
            let mut times = FileTimes::new();
            if valid & (FATTR_ATIME | FATTR_ATIME_NOW) != 0 {
                times = times.set_accessed(timestamp(32, 56, FATTR_ATIME_NOW)?);
            }
            if valid & (FATTR_MTIME | FATTR_MTIME_NOW) != 0 {
                times = times.set_modified(timestamp(40, 60, FATTR_MTIME_NOW)?);
            }
            file.set_times(times).map_err(|e| io_err_to_linux(&e))?;
        }
        file.metadata().map_err(|e| io_err_to_linux(&e))
    }

    fn child_path(&self, parent_id: u64, name: &[u8]) -> Result<PathBuf, i32> {
        let parent = self.node_to_path.get(&parent_id).ok_or(LINUX_ENOENT)?;
        if name.is_empty() || name.contains(&b'/') || name.contains(&0) {
            return Err(LINUX_EINVAL);
        }
        if name == b"." {
            return Ok(parent.clone());
        }
        if name == b".." {
            if parent == &self.root {
                return Ok(self.root.clone());
            }
            return Ok(parent.parent().unwrap_or(&self.root).to_path_buf());
        }
        let os = std::ffi::OsStr::from_bytes(name);
        Ok(parent.join(os))
    }

    fn encode_attr(nodeid: u64, md: &fs::Metadata, out: &mut Vec<u8>) {
        // fuse_attr (88 bytes)
        out.extend_from_slice(&nodeid.to_le_bytes()); // ino
        out.extend_from_slice(&md.size().to_le_bytes()); // size
        out.extend_from_slice(&md.blocks().to_le_bytes()); // blocks
        out.extend_from_slice(&(md.atime() as u64).to_le_bytes()); // atime
        out.extend_from_slice(&(md.mtime() as u64).to_le_bytes()); // mtime
        out.extend_from_slice(&(md.ctime() as u64).to_le_bytes()); // ctime
        out.extend_from_slice(&(md.atime_nsec() as u32).to_le_bytes());
        out.extend_from_slice(&(md.mtime_nsec() as u32).to_le_bytes());
        out.extend_from_slice(&(md.ctime_nsec() as u32).to_le_bytes());
        out.extend_from_slice(&md.mode().to_le_bytes()); // mode (POSIX matches Linux!)
        out.extend_from_slice(&(md.nlink() as u32).to_le_bytes());
        // Map host owner UID/GID to root (0) inside guest CI worker so containerd/apk/crun work cleanly
        out.extend_from_slice(&0u32.to_le_bytes()); // uid
        out.extend_from_slice(&0u32.to_le_bytes()); // gid
        out.extend_from_slice(&(md.rdev() as u32).to_le_bytes());
        out.extend_from_slice(&4096u32.to_le_bytes()); // blksize
        out.extend_from_slice(&0u32.to_le_bytes()); // flags
    }

    fn encode_entry_out(nodeid: u64, md: &fs::Metadata, read_only: bool, out: &mut Vec<u8>) {
        // fuse_entry_out (128 bytes); read-only tools shares get 3600s dentry/attr caching
        let (valid_secs, valid_nsecs) = cache_validity(read_only);
        out.extend_from_slice(&nodeid.to_le_bytes());
        out.extend_from_slice(&1u64.to_le_bytes()); // generation
        out.extend_from_slice(&valid_secs.to_le_bytes()); // entry_valid
        out.extend_from_slice(&valid_secs.to_le_bytes()); // attr_valid
        out.extend_from_slice(&valid_nsecs.to_le_bytes()); // entry_valid_nsec
        out.extend_from_slice(&valid_nsecs.to_le_bytes()); // attr_valid_nsec
        Self::encode_attr(nodeid, md, out);
    }

    fn reply_err(unique: u64, errno: i32) -> Vec<u8> {
        let mut out = Vec::with_capacity(16);
        out.extend_from_slice(&16u32.to_le_bytes());
        out.extend_from_slice(&(-errno).to_le_bytes());
        out.extend_from_slice(&unique.to_le_bytes());
        out
    }

    fn reply_ok(unique: u64, body: &[u8]) -> Vec<u8> {
        let len = (16 + body.len()) as u32;
        let mut out = Vec::with_capacity(len as usize);
        out.extend_from_slice(&len.to_le_bytes());
        out.extend_from_slice(&0i32.to_le_bytes());
        out.extend_from_slice(&unique.to_le_bytes());
        out.extend_from_slice(body);
        out
    }

    fn parse_cstr(b: &[u8]) -> (&[u8], &[u8]) {
        match b.iter().position(|&c| c == 0) {
            Some(i) => (&b[..i], &b[i + 1..]),
            None => (b, &[]),
        }
    }

    fn linux_open_flags_to_options(flags: u32, read_only: bool) -> Result<OpenOptions, i32> {
        let acc = flags & 0x3;
        let write = acc == 1 || acc == 2;
        let trunc = (flags & 0o1000) != 0; // Linux O_TRUNC = 01000
        let append = (flags & 0o2000) != 0; // Linux O_APPEND = 02000
        let create = (flags & 0o100) != 0; // Linux O_CREAT = 0100
        let excl = (flags & 0o200) != 0; // Linux O_EXCL = 0200
        if read_only && (write || trunc || create) {
            return Err(LINUX_EROFS);
        }
        let mut opts = OpenOptions::new();
        opts.read(acc == 0 || acc == 2);
        opts.write(write);
        if trunc {
            opts.truncate(true);
        }
        if append {
            opts.append(true);
        }
        if create && excl {
            opts.create_new(true);
        } else if create {
            opts.create(true);
        }
        Ok(opts)
    }

    fn handle_fuse(&mut self, req: &[u8]) -> Option<Vec<u8>> {
        if req.len() < 40 {
            return None;
        }
        self.metrics.requests.fetch_add(1, Ordering::Relaxed);
        let opcode = u32::from_le_bytes(req[4..8].try_into().unwrap());
        let unique = u64::from_le_bytes(req[8..16].try_into().unwrap());
        let nodeid = u64::from_le_bytes(req[16..24].try_into().unwrap());
        let body = &req[40..];

        match opcode {
            FUSE_INIT => {
                let mut out = Vec::with_capacity(64);
                out.extend_from_slice(&7u32.to_le_bytes()); // major
                out.extend_from_slice(&31u32.to_le_bytes()); // minor
                out.extend_from_slice(&(128 * 1024u32).to_le_bytes()); // max_readahead
                let mut flags = FUSE_ASYNC_READ
                    | FUSE_BIG_WRITES
                    | FUSE_DO_READDIRPLUS
                    | FUSE_PARALLEL_DIROPS
                    | FUSE_MAX_PAGES
                    | FUSE_CACHE_SYMLINKS;
                if self.read_only {
                    // Read-only shares (e.g. oci-tools) are immutable: skip FUSE_OPEN/FLUSH/RELEASE
                    // completely (Linux sets fc->no_open=1 and FOPEN_KEEP_CACHE automatically) and
                    // keep guest page cache warm across container execs!
                    flags |= FUSE_NO_OPEN_SUPPORT | FUSE_EXPLICIT_INVAL_DATA;
                } else if body.get(12..16).is_some_and(|flags| {
                    u32::from_le_bytes(flags.try_into().unwrap()) & FUSE_AUTO_INVAL_DATA != 0
                }) {
                    flags |= FUSE_AUTO_INVAL_DATA;
                }
                out.extend_from_slice(&flags.to_le_bytes());
                out.extend_from_slice(&64u16.to_le_bytes()); // max_background
                out.extend_from_slice(&48u16.to_le_bytes()); // congestion_threshold
                out.extend_from_slice(&(128 * 1024u32).to_le_bytes()); // max_write
                out.extend_from_slice(&1u32.to_le_bytes()); // time_gran
                out.extend_from_slice(&32u16.to_le_bytes()); // max_pages
                out.extend_from_slice(&0u16.to_le_bytes()); // map_alignment
                out.extend_from_slice(&[0u8; 32]); // flags2 + unused[7]
                Some(Self::reply_ok(unique, &out))
            }
            FUSE_DESTROY => Some(Self::reply_ok(unique, &[])),
            FUSE_FORGET | FUSE_BATCH_FORGET => None, // No reply for FORGET
            FUSE_LOOKUP => {
                let (name, _) = Self::parse_cstr(body);
                if self.read_only {
                    let key = (nodeid, name.to_vec());
                    if let Some(cached) = self.ro_lookup_cache.get(&key) {
                        return match cached {
                            Ok(id) => {
                                if let Some(md) = self.ro_attr_cache.get(id) {
                                    let mut out = Vec::with_capacity(128);
                                    Self::encode_entry_out(*id, md, true, &mut out);
                                    return Some(Self::reply_ok(unique, &out));
                                }
                                Some(Self::reply_err(unique, LINUX_ENOENT))
                            }
                            Err(e) => Some(Self::reply_err(unique, *e)),
                        };
                    }
                }
                let path = match self.child_path(nodeid, name) {
                    Ok(p) => p,
                    Err(e) => return Some(Self::reply_err(unique, e)),
                };
                match fs::symlink_metadata(&path) {
                    Ok(md) => {
                        let id = self.observe_path(path, &md);
                        let mut out = Vec::with_capacity(128);
                        Self::encode_entry_out(id, &md, self.read_only, &mut out);
                        if self.read_only {
                            self.ro_lookup_cache.insert((nodeid, name.to_vec()), Ok(id));
                            self.ro_attr_cache.insert(id, md);
                        }
                        Some(Self::reply_ok(unique, &out))
                    }
                    Err(e) => {
                        let le = io_err_to_linux(&e);
                        if self.read_only && self.ro_lookup_cache.len() < 4096 {
                            self.ro_lookup_cache.insert((nodeid, name.to_vec()), Err(le));
                        }
                        Some(Self::reply_err(unique, le))
                    }
                }
            }
            FUSE_GETATTR => {
                if self.read_only {
                    if let Some(md) = self.ro_attr_cache.get(&nodeid) {
                        let mut out = Vec::with_capacity(104);
                        out.extend_from_slice(&3600u64.to_le_bytes()); // attr_valid
                        out.extend_from_slice(&0u32.to_le_bytes());
                        out.extend_from_slice(&0u32.to_le_bytes());
                        Self::encode_attr(nodeid, md, &mut out);
                        return Some(Self::reply_ok(unique, &out));
                    }
                }
                match self.node_metadata(nodeid, body) {
                    Ok(md) => {
                        let mut out = Vec::with_capacity(104);
                        let (valid_secs, valid_nsecs) = cache_validity(self.read_only);
                        out.extend_from_slice(&valid_secs.to_le_bytes());
                        out.extend_from_slice(&valid_nsecs.to_le_bytes());
                        out.extend_from_slice(&0u32.to_le_bytes());
                        Self::encode_attr(nodeid, &md, &mut out);
                        if self.read_only {
                            self.ro_attr_cache.insert(nodeid, md);
                        }
                        Some(Self::reply_ok(unique, &out))
                    }
                    Err(errno) => Some(Self::reply_err(unique, errno)),
                }
            }
            FUSE_SETATTR => {
                if self.read_only {
                    return Some(Self::reply_err(unique, LINUX_EROFS));
                }
                if body.len() < 88 {
                    return Some(Self::reply_err(unique, LINUX_EINVAL));
                }
                let valid = u32::from_le_bytes(body[0..4].try_into().unwrap());
                let meta = self.set_attributes(nodeid, body, valid);
                Some(match meta {
                    Ok(md) => {
                        let mut out = Vec::with_capacity(104);
                        let (secs, nsecs) = cache_validity(false);
                        out.extend_from_slice(&secs.to_le_bytes());
                        out.extend_from_slice(&nsecs.to_le_bytes());
                        out.extend_from_slice(&0u32.to_le_bytes());
                        Self::encode_attr(nodeid, &md, &mut out);
                        Self::reply_ok(unique, &out)
                    }
                    Err(errno) => Self::reply_err(unique, errno),
                })
            }
            FUSE_READLINK => {
                let Some(path) = self.node_to_path.get(&nodeid).cloned() else {
                    return Some(Self::reply_err(unique, LINUX_ENOENT));
                };
                match fs::read_link(&path) {
                    Ok(target) => Some(Self::reply_ok(unique, target.as_os_str().as_bytes())),
                    Err(e) => Some(Self::reply_err(unique, io_err_to_linux(&e))),
                }
            }
            FUSE_OPEN => {
                if body.len() < 8 {
                    return Some(Self::reply_err(unique, LINUX_EINVAL));
                }
                let flags = u32::from_le_bytes(body[0..4].try_into().unwrap());
                if self.read_only {
                    if let Err(e) = Self::linux_open_flags_to_options(flags, true) {
                        return Some(Self::reply_err(unique, e));
                    }
                    // Tell Linux FUSE to activate fc->no_open=1 + FOPEN_KEEP_CACHE so subsequent
                    // opens/execs/closes on read-only binaries incur ZERO FUSE VM exits!
                    return Some(Self::reply_err(unique, LINUX_ENOSYS));
                }
                let Some(path) = self.node_to_path.get(&nodeid).cloned() else {
                    return Some(Self::reply_err(unique, LINUX_ESTALE));
                };
                let mut opts = match Self::linux_open_flags_to_options(flags, false) {
                    Ok(o) => o,
                    Err(e) => return Some(Self::reply_err(unique, e)),
                };
                // Validate the opened inode before applying a truncating open.
                // FUSE_CREATE is responsible for creating missing pathnames.
                opts.custom_flags(libc::O_NOFOLLOW).create(false).create_new(false).truncate(false);
                match opts.open(&path) {
                    Ok(file) => {
                        match file.metadata() {
                            Ok(md) if self.matches_inode(nodeid, &md) => {}
                            Ok(_) => return Some(Self::reply_err(unique, LINUX_ESTALE)),
                            Err(e) => return Some(Self::reply_err(unique, io_err_to_linux(&e))),
                        }
                        if flags & 0o1000 != 0 {
                            if let Err(e) = file.set_len(0) {
                                return Some(Self::reply_err(unique, io_err_to_linux(&e)));
                            }
                        }
                        let fh = self.next_fh;
                        self.next_fh += 1;
                        self.open_files.insert(fh, OpenFile { nodeid, file: Arc::new(file) });
                        let mut out = [0u8; 16];
                        out[0..8].copy_from_slice(&fh.to_le_bytes());
                        // Each mutable open invalidates cached pages. Skipping
                        // FLUSH remains safe for handles that cannot write.
                        if flags & (3 | 0o1000 | 0o2000) == 0 {
                            out[8..12].copy_from_slice(&FOPEN_NOFLUSH.to_le_bytes());
                        }
                        Some(Self::reply_ok(unique, &out))
                    }
                    Err(e) => {
                        // A stale positive dentry must be revalidated, even
                        // when the new binding prevents open (such as a symlink).
                        let stale = self.host_inodes.contains_key(&nodeid)
                            && match fs::symlink_metadata(&path) {
                                Ok(md) => !self.matches_inode(nodeid, &md),
                                Err(stat_error) => matches!(
                                    stat_error.raw_os_error(),
                                    Some(libc::ENOENT | libc::ENOTDIR | libc::ELOOP)
                                ),
                            };
                        let errno = if stale { LINUX_ESTALE } else { io_err_to_linux(&e) };
                        Some(Self::reply_err(unique, errno))
                    }
                }
            }
            FUSE_CREATE => {
                if self.read_only {
                    return Some(Self::reply_err(unique, LINUX_EROFS));
                }
                if body.len() < 16 {
                    return Some(Self::reply_err(unique, LINUX_EINVAL));
                }
                let flags = u32::from_le_bytes(body[0..4].try_into().unwrap());
                let mode = u32::from_le_bytes(body[4..8].try_into().unwrap());
                let (name, _) = Self::parse_cstr(&body[16..]);
                let path = match self.child_path(nodeid, name) {
                    Ok(p) => p,
                    Err(e) => return Some(Self::reply_err(unique, e)),
                };
                let mut opts = match Self::linux_open_flags_to_options(flags | 0o100, false) {
                    Ok(o) => o,
                    Err(e) => return Some(Self::reply_err(unique, e)),
                };
                opts.mode(mode & 0o7777);
                match opts.open(&path) {
                    Ok(file) => {
                        let md = match file.metadata() {
                            Ok(m) => m,
                            Err(e) => return Some(Self::reply_err(unique, io_err_to_linux(&e))),
                        };
                        let id = self.observe_path(path, &md);
                        let fh = self.next_fh;
                        self.next_fh += 1;
                        self.open_files.insert(fh, OpenFile { nodeid: id, file: Arc::new(file) });
                        let mut out = Vec::with_capacity(144);
                        Self::encode_entry_out(id, &md, self.read_only, &mut out);
                        out.extend_from_slice(&fh.to_le_bytes());
                        out.extend_from_slice(&0u32.to_le_bytes());
                        out.extend_from_slice(&0i32.to_le_bytes());
                        Some(Self::reply_ok(unique, &out))
                    }
                    Err(e) => Some(Self::reply_err(unique, io_err_to_linux(&e))),
                }
            }
            FUSE_READ => {
                if body.len() < 24 {
                    return Some(Self::reply_err(unique, LINUX_EINVAL));
                }
                let fh = u64::from_le_bytes(body[0..8].try_into().unwrap());
                let offset = u64::from_le_bytes(body[8..16].try_into().unwrap());
                let size = (u32::from_le_bytes(body[16..20].try_into().unwrap()) as usize)
                    .min(1024 * 1024);
                let file = if fh != 0 {
                    match self.open_files.get(&fh) {
                        Some(f) => f.file.clone(),
                        None => return Some(Self::reply_err(unique, LINUX_EBADF)),
                    }
                } else if self.read_only {
                    // FUSE_NO_OPEN_SUPPORT: fh == 0, resolve directly from nodeid cache!
                    if let Some(cached) = self.ro_file_cache.get(&nodeid) {
                        cached.clone()
                    } else {
                        let Some(path) = self.node_to_path.get(&nodeid).cloned() else {
                            return Some(Self::reply_err(unique, LINUX_ENOENT));
                        };
                        match File::open(&path) {
                            Ok(f) => {
                                let arc_f = Arc::new(f);
                                if self.ro_file_cache.len() < 256 {
                                    self.ro_file_cache.insert(nodeid, arc_f.clone());
                                }
                                arc_f
                            }
                            Err(e) => return Some(Self::reply_err(unique, io_err_to_linux(&e))),
                        }
                    }
                } else {
                    return Some(Self::reply_err(unique, LINUX_EBADF));
                };
                if self.read_buf.len() < size {
                    self.read_buf.resize(size, 0);
                }
                match file.read_at(&mut self.read_buf[..size], offset) {
                    Ok(n) => {
                        self.metrics.bytes_read.fetch_add(n as u64, Ordering::Relaxed);
                        Some(Self::reply_ok(unique, &self.read_buf[..n]))
                    }
                    Err(e) => Some(Self::reply_err(unique, io_err_to_linux(&e))),
                }
            }
            FUSE_WRITE => {
                if self.read_only {
                    return Some(Self::reply_err(unique, LINUX_EROFS));
                }
                if body.len() < 40 {
                    return Some(Self::reply_err(unique, LINUX_EINVAL));
                }
                let fh = u64::from_le_bytes(body[0..8].try_into().unwrap());
                let offset = u64::from_le_bytes(body[8..16].try_into().unwrap());
                let size = u32::from_le_bytes(body[16..20].try_into().unwrap()) as usize;
                let data = &body[40..body.len().min(40 + size)];
                let Some(file) = self.open_files.get(&fh) else {
                    return Some(Self::reply_err(unique, LINUX_EBADF));
                };
                match file.file.write_at(data, offset) {
                    Ok(n) => {
                        self.metrics.bytes_written.fetch_add(n as u64, Ordering::Relaxed);
                        let mut out = [0u8; 8];
                        out[0..4].copy_from_slice(&(n as u32).to_le_bytes());
                        Some(Self::reply_ok(unique, &out))
                    }
                    Err(e) => Some(Self::reply_err(unique, io_err_to_linux(&e))),
                }
            }
            FUSE_FLUSH | FUSE_FSYNC | FUSE_FSYNCDIR => {
                if opcode == FUSE_FSYNC && body.len() >= 8 {
                    let fh = u64::from_le_bytes(body[0..8].try_into().unwrap());
                    if let Some(f) = self.open_files.get(&fh) {
                        let _ = unsafe { libc::fsync(f.file.as_raw_fd()) };
                    }
                }
                Some(Self::reply_ok(unique, &[]))
            }
            FUSE_RELEASE => {
                if body.len() >= 8 {
                    let fh = u64::from_le_bytes(body[0..8].try_into().unwrap());
                    self.open_files.remove(&fh);
                }
                Some(Self::reply_ok(unique, &[]))
            }
            FUSE_OPENDIR => {
                let Some(path) = self.node_to_path.get(&nodeid).cloned() else {
                    return Some(Self::reply_err(unique, LINUX_ENOENT));
                };
                let rd = match fs::read_dir(&path) {
                    Ok(r) => r,
                    Err(e) => return Some(Self::reply_err(unique, io_err_to_linux(&e))),
                };
                let mut entries = Vec::new();
                for ent in rd.flatten() {
                    let p = ent.path();
                    let name = ent.file_name().as_os_str().as_bytes().to_vec();
                    let dtype = ent
                        .file_type()
                        .map(|ft| {
                            if ft.is_dir() {
                                4u32 // DT_DIR
                            } else if ft.is_symlink() {
                                10u32 // DT_LNK
                            } else {
                                8u32 // DT_REG
                            }
                        })
                        .unwrap_or(0);
                    let ino = self.intern_path(p.clone());
                    entries.push(DirEntryRec { name, path: p, ino, dtype });
                }
                let fh = self.next_fh;
                self.next_fh += 1;
                self.open_dirs.insert(fh, Arc::new(entries));
                let mut out = [0u8; 16];
                out[0..8].copy_from_slice(&fh.to_le_bytes());
                let open_flags = if self.read_only {
                    FOPEN_KEEP_CACHE | FOPEN_CACHE_DIR | FOPEN_NOFLUSH
                } else {
                    0
                };
                out[8..12].copy_from_slice(&open_flags.to_le_bytes());
                Some(Self::reply_ok(unique, &out))
            }
            FUSE_READDIR | FUSE_READDIRPLUS => {
                if body.len() < 20 {
                    return Some(Self::reply_err(unique, LINUX_EINVAL));
                }
                let fh = u64::from_le_bytes(body[0..8].try_into().unwrap());
                let offset = u64::from_le_bytes(body[8..16].try_into().unwrap()) as usize;
                let max_size = u32::from_le_bytes(body[16..20].try_into().unwrap()) as usize;
                let Some(entries) = self.open_dirs.get(&fh).cloned() else {
                    return Some(Self::reply_err(unique, LINUX_EBADF));
                };
                let mut out = Vec::with_capacity(max_size.min(65536));
                let plus = opcode == FUSE_READDIRPLUS;
                for (i, e) in entries.iter().enumerate().skip(offset) {
                    let name_len = e.name.len();
                    let raw_ent = (if plus { 128 } else { 0 }) + 24 + name_len;
                    let padded = (raw_ent + 7) & !7;
                    if out.len() + padded > max_size {
                        break;
                    }
                    let (ino, dtype) = if plus {
                        let Ok(md) = fs::symlink_metadata(&e.path) else {
                            continue;
                        };
                        let id = if self.read_only { e.ino } else { self.observe_path(e.path.clone(), &md) };
                        Self::encode_entry_out(id, &md, self.read_only, &mut out);
                        // IFTODT on Darwin and Linux extracts the high mode bits.
                        (id, (md.mode() >> 12) & 0xf)
                    } else {
                        (e.ino, e.dtype)
                    };
                    out.extend_from_slice(&ino.to_le_bytes());
                    out.extend_from_slice(&((i + 1) as u64).to_le_bytes());
                    out.extend_from_slice(&(name_len as u32).to_le_bytes());
                    out.extend_from_slice(&dtype.to_le_bytes());
                    out.extend_from_slice(&e.name);
                    while out.len() % 8 != 0 {
                        out.push(0);
                    }
                }
                Some(Self::reply_ok(unique, &out))
            }
            FUSE_RELEASEDIR => {
                if body.len() >= 8 {
                    let fh = u64::from_le_bytes(body[0..8].try_into().unwrap());
                    self.open_dirs.remove(&fh);
                }
                Some(Self::reply_ok(unique, &[]))
            }
            FUSE_MKDIR => {
                if self.read_only {
                    return Some(Self::reply_err(unique, LINUX_EROFS));
                }
                if body.len() < 8 {
                    return Some(Self::reply_err(unique, LINUX_EINVAL));
                }
                let mode = u32::from_le_bytes(body[0..4].try_into().unwrap());
                let (name, _) = Self::parse_cstr(&body[8..]);
                let path = match self.child_path(nodeid, name) {
                    Ok(p) => p,
                    Err(e) => return Some(Self::reply_err(unique, e)),
                };
                if let Err(e) = fs::create_dir(&path) {
                    return Some(Self::reply_err(unique, io_err_to_linux(&e)));
                }
                let _ = fs::set_permissions(&path, fs::Permissions::from_mode(mode & 0o7777));
                match fs::symlink_metadata(&path) {
                    Ok(md) => {
                        let id = self.observe_path(path, &md);
                        let mut out = Vec::with_capacity(128);
                        Self::encode_entry_out(id, &md, self.read_only, &mut out);
                        Some(Self::reply_ok(unique, &out))
                    }
                    Err(e) => Some(Self::reply_err(unique, io_err_to_linux(&e))),
                }
            }
            FUSE_UNLINK => {
                if self.read_only {
                    return Some(Self::reply_err(unique, LINUX_EROFS));
                }
                let (name, _) = Self::parse_cstr(body);
                let path = match self.child_path(nodeid, name) {
                    Ok(p) => p,
                    Err(e) => return Some(Self::reply_err(unique, e)),
                };
                match fs::remove_file(&path) {
                    Ok(()) => Some(Self::reply_ok(unique, &[])),
                    Err(e) => Some(Self::reply_err(unique, io_err_to_linux(&e))),
                }
            }
            FUSE_RMDIR => {
                if self.read_only {
                    return Some(Self::reply_err(unique, LINUX_EROFS));
                }
                let (name, _) = Self::parse_cstr(body);
                let path = match self.child_path(nodeid, name) {
                    Ok(p) => p,
                    Err(e) => return Some(Self::reply_err(unique, e)),
                };
                match fs::remove_dir(&path) {
                    Ok(()) => Some(Self::reply_ok(unique, &[])),
                    Err(e) => Some(Self::reply_err(unique, io_err_to_linux(&e))),
                }
            }
            FUSE_RENAME | FUSE_RENAME2 => {
                if self.read_only {
                    return Some(Self::reply_err(unique, LINUX_EROFS));
                }
                let hdr_len = if opcode == FUSE_RENAME2 { 16 } else { 8 };
                if body.len() < hdr_len {
                    return Some(Self::reply_err(unique, LINUX_EINVAL));
                }
                let newdir = u64::from_le_bytes(body[0..8].try_into().unwrap());
                let (oldname, rest) = Self::parse_cstr(&body[hdr_len..]);
                let (newname, _) = Self::parse_cstr(rest);
                let old_p = match self.child_path(nodeid, oldname) {
                    Ok(p) => p,
                    Err(e) => return Some(Self::reply_err(unique, e)),
                };
                let new_p = match self.child_path(newdir, newname) {
                    Ok(p) => p,
                    Err(e) => return Some(Self::reply_err(unique, e)),
                };
                match fs::rename(&old_p, &new_p) {
                    Ok(()) => {
                        if old_p != new_p {
                            // Identical hard links make rename a no-op.
                            let unchanged = fs::symlink_metadata(&old_p)
                                .and_then(|old| {
                                    fs::symlink_metadata(&new_p).map(|new| {
                                        (old.dev(), old.ino()) == (new.dev(), new.ino())
                                    })
                                })
                                .unwrap_or(false);
                            if !unchanged {
                                // Open descriptors for the displaced inode remain in open_files.
                                self.retire_path(&new_p);
                                if let Some(id) = self.path_to_node.remove(&old_p) {
                                    self.node_to_path.insert(id, new_p.clone());
                                    self.path_to_node.insert(new_p, id);
                                }
                            }
                        }
                        Some(Self::reply_ok(unique, &[]))
                    }
                    Err(e) => Some(Self::reply_err(unique, io_err_to_linux(&e))),
                }
            }
            FUSE_SYMLINK => {
                if self.read_only {
                    return Some(Self::reply_err(unique, LINUX_EROFS));
                }
                let (name, rest) = Self::parse_cstr(body);
                let (target, _) = Self::parse_cstr(rest);
                let link_p = match self.child_path(nodeid, name) {
                    Ok(p) => p,
                    Err(e) => return Some(Self::reply_err(unique, e)),
                };
                let target_os = std::ffi::OsStr::from_bytes(target);
                if let Err(e) = std::os::unix::fs::symlink(target_os, &link_p) {
                    return Some(Self::reply_err(unique, io_err_to_linux(&e)));
                }
                match fs::symlink_metadata(&link_p) {
                    Ok(md) => {
                        let id = self.observe_path(link_p, &md);
                        let mut out = Vec::with_capacity(128);
                        Self::encode_entry_out(id, &md, self.read_only, &mut out);
                        Some(Self::reply_ok(unique, &out))
                    }
                    Err(e) => Some(Self::reply_err(unique, io_err_to_linux(&e))),
                }
            }
            FUSE_LINK => {
                if self.read_only {
                    return Some(Self::reply_err(unique, LINUX_EROFS));
                }
                if body.len() < 8 {
                    return Some(Self::reply_err(unique, LINUX_EINVAL));
                }
                let old_id = u64::from_le_bytes(body[0..8].try_into().unwrap());
                let (name, _) = Self::parse_cstr(&body[8..]);
                let Some(old_p) = self.node_to_path.get(&old_id).cloned() else {
                    return Some(Self::reply_err(unique, LINUX_ENOENT));
                };
                let new_p = match self.child_path(nodeid, name) {
                    Ok(p) => p,
                    Err(e) => return Some(Self::reply_err(unique, e)),
                };
                if let Err(e) = fs::hard_link(&old_p, &new_p) {
                    return Some(Self::reply_err(unique, io_err_to_linux(&e)));
                }
                match fs::symlink_metadata(&new_p) {
                    Ok(md) => {
                        let id = self.observe_path(new_p, &md);
                        let mut out = Vec::with_capacity(128);
                        Self::encode_entry_out(id, &md, self.read_only, &mut out);
                        Some(Self::reply_ok(unique, &out))
                    }
                    Err(e) => Some(Self::reply_err(unique, io_err_to_linux(&e))),
                }
            }
            FUSE_STATFS => {
                let mut st: libc::statfs = unsafe { std::mem::zeroed() };
                let cpath = CString::new(self.root.as_os_str().as_bytes()).unwrap_or_default();
                let rc = unsafe { libc::statfs(cpath.as_ptr(), &mut st) };
                if rc != 0 {
                    return Some(Self::reply_err(unique, LINUX_EIO));
                }
                let mut out = Vec::with_capacity(80);
                out.extend_from_slice(&(st.f_blocks).to_le_bytes());
                out.extend_from_slice(&(st.f_bfree).to_le_bytes());
                out.extend_from_slice(&(st.f_bavail).to_le_bytes());
                out.extend_from_slice(&(st.f_files).to_le_bytes());
                out.extend_from_slice(&(st.f_ffree).to_le_bytes());
                out.extend_from_slice(&(st.f_bsize).to_le_bytes());
                out.extend_from_slice(&255u32.to_le_bytes()); // namelen
                out.extend_from_slice(&(st.f_bsize).to_le_bytes()); // frsize
                out.extend_from_slice(&[0u8; 28]); // padding + spare[6]
                Some(Self::reply_ok(unique, &out))
            }
            FUSE_ACCESS => Some(Self::reply_ok(unique, &[])),
            FUSE_GETXATTR | FUSE_LISTXATTR => Some(Self::reply_err(unique, LINUX_ENODATA)),
            FUSE_LSEEK | FUSE_STATX => Some(Self::reply_err(unique, LINUX_ENOSYS)),
            _ => Some(Self::reply_err(unique, LINUX_ENOSYS)),
        }
    }
}

impl VirtioBackend for VirtioFs {
    fn device_id(&self) -> u32 {
        26
    }
    fn features(&self) -> u64 {
        0
    }
    fn num_queues(&self) -> usize {
        2 // 0 = hiprio, 1 = request queue 0
    }
    fn queue_max_size(&self, _q: usize) -> u16 {
        256
    }
    fn read_config(&self, offset: u64, data: &mut [u8]) {
        let mut cfg = [0u8; 40];
        cfg[0..36].copy_from_slice(&self.tag);
        cfg[36..40].copy_from_slice(&1u32.to_le_bytes()); // num_request_queues = 1
        let start = offset as usize;
        for (i, b) in data.iter_mut().enumerate() {
            *b = cfg.get(start + i).copied().unwrap_or(0);
        }
    }
    fn handle_queue(&mut self, q_idx: usize, queues: &mut [VirtQueue], mem: &GuestMemory) -> bool {
        let q = &mut queues[q_idx];
        let mut used_any = false;
        while let Some((head, bufs)) = q.pop(mem) {
            let req = collect_readable(&bufs, mem);
            let written = if let Some(resp) = self.handle_fuse(&req) {
                scatter_writable(&bufs, mem, &resp)
            } else {
                0
            };
            q.push_used(mem, head, written);
            used_any = true;
        }
        used_any
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn request(fsys: &mut VirtioFs, opcode: u32, nodeid: u64, body: &[u8]) -> Vec<u8> {
        let mut req = vec![0; 40];
        let size = (req.len() + body.len()) as u32;
        req[0..4].copy_from_slice(&size.to_le_bytes());
        req[4..8].copy_from_slice(&opcode.to_le_bytes());
        req[8..16].copy_from_slice(&1u64.to_le_bytes());
        req[16..24].copy_from_slice(&nodeid.to_le_bytes());
        req.extend_from_slice(body);
        fsys.handle_fuse(&req).unwrap()
    }

    fn errno(reply: &[u8]) -> i32 {
        -i32::from_le_bytes(reply[4..8].try_into().unwrap())
    }

    fn lookup(fsys: &mut VirtioFs, name: &[u8]) -> u64 {
        let reply = request(fsys, FUSE_LOOKUP, FUSE_ROOT_ID, name);
        assert_eq!(errno(&reply), 0);
        u64::from_le_bytes(reply[16..24].try_into().unwrap())
    }

    fn open(fsys: &mut VirtioFs, nodeid: u64, flags: u32) -> Vec<u8> {
        let mut body = [0; 8];
        body[..4].copy_from_slice(&flags.to_le_bytes());
        request(fsys, FUSE_OPEN, nodeid, &body)
    }

    #[test]
    fn mutable_opens_only_skip_flush_for_read_only_handles() {
        let dir = std::env::temp_dir().join(format!("mp-vfs-open-{}", std::process::id()));
        fs::create_dir(&dir).unwrap();
        let path = dir.join("source");
        fs::write(&path, b"unchanged").unwrap();
        let mut fsys = VirtioFs::new("workspace", dir.clone(), false, Arc::new(FsMetrics::default())).unwrap();
        let id = lookup(&mut fsys, b"source\0");
        for (flags, expected) in [(0, FOPEN_NOFLUSH), (0, FOPEN_NOFLUSH), (2, 0)] {
            let reply = open(&mut fsys, id, flags);
            assert_eq!(errno(&reply), 0);
            assert_eq!(u32::from_le_bytes(reply[24..28].try_into().unwrap()), expected);
        }
        fs::remove_file(path).unwrap();
        fs::remove_dir(dir).unwrap();
    }

    #[test]
    fn mutable_share_keeps_open_inode_across_host_replacement() {
        let dir = std::env::temp_dir().join(format!("mp-vfs-replace-{}", std::process::id()));
        fs::create_dir(&dir).unwrap();
        let path = dir.join("source");
        fs::write(&path, b"original").unwrap();
        let mut fsys = VirtioFs::new("workspace", dir.clone(), false, Arc::new(FsMetrics::default())).unwrap();
        let first = lookup(&mut fsys, b"source\0");
        let opened = open(&mut fsys, first, 2);
        assert_eq!(errno(&opened), 0);
        let old_fh = u64::from_le_bytes(opened[16..24].try_into().unwrap());
        let old_file = fsys.open_files[&old_fh].file.clone();
        let new_path = dir.join("replacement");
        fs::write(&new_path, b"revision").unwrap();
        fs::rename(&new_path, &path).unwrap();
        assert_eq!(errno(&open(&mut fsys, first, 0o1002)), LINUX_ESTALE);
        assert_eq!(fs::read(&path).unwrap(), b"revision");
        let second = lookup(&mut fsys, b"source\0");
        assert_ne!(first, second);
        assert_eq!(errno(&open(&mut fsys, first, 0o1002)), LINUX_ESTALE);
        assert_eq!(fsys.node_metadata(first, &[]).unwrap().ino(), old_file.metadata().unwrap().ino());
        let mut getattr = [0; 16];
        getattr[..4].copy_from_slice(&FUSE_GETATTR_FH.to_le_bytes());
        getattr[8..16].copy_from_slice(&old_fh.to_le_bytes());
        let old_attr = request(&mut fsys, FUSE_GETATTR, first, &getattr);
        assert_eq!(errno(&old_attr), 0);
        assert_eq!(u64::from_le_bytes(old_attr[40..48].try_into().unwrap()), 8);
        assert_eq!(errno(&request(&mut fsys, FUSE_GETATTR, second, &getattr)), LINUX_EBADF);
        let mut body = [0; 88];
        body[8..16].copy_from_slice(&old_fh.to_le_bytes());
        body[16..24].copy_from_slice(&1u64.to_le_bytes());
        fsys.set_attributes(first, &body, FATTR_FH | FATTR_SIZE).unwrap();
        assert_eq!(old_file.metadata().unwrap().size(), 1);
        assert_eq!(fs::read(&path).unwrap(), b"revision");
        assert_eq!(fsys.set_attributes(second, &body, FATTR_FH | FATTR_SIZE).unwrap_err(), LINUX_EBADF);
        body[40..48].copy_from_slice(&1_600_000_000i64.to_le_bytes());
        body[68..72].copy_from_slice(&0o640u32.to_le_bytes());
        let md = fsys.set_attributes(second, &body, FATTR_MTIME | FATTR_MODE).unwrap();
        assert_eq!((md.mtime(), md.mode() & 0o777), (1_600_000_000, 0o640));
        assert_eq!(errno(&open(&mut fsys, second, 0o1002)), 0);
        assert_eq!(fs::metadata(&path).unwrap().size(), 0);
        fs::remove_file(path).unwrap();
        fs::remove_dir(dir).unwrap();
    }

    #[test]
    fn rename_overwrite_retires_the_destination_and_readdirplus_reports_the_current_type() {
        let dir = std::env::temp_dir().join(format!("mp-vfs-rename-{}", std::process::id()));
        fs::create_dir(&dir).unwrap();
        let path = dir.join("destination");
        fs::write(&path, b"displaced").unwrap();
        fs::write(dir.join("backup"), b"replacement").unwrap();
        let mut fsys = VirtioFs::new("workspace", dir.clone(), false, Arc::new(FsMetrics::default())).unwrap();
        let old = lookup(&mut fsys, b"destination\0");
        let new = lookup(&mut fsys, b"backup\0");
        let old_open = open(&mut fsys, old, 0);
        assert_eq!(errno(&old_open), 0);

        let mut rename = FUSE_ROOT_ID.to_le_bytes().to_vec();
        rename.extend_from_slice(b"backup\0destination\0");
        assert_eq!(errno(&request(&mut fsys, FUSE_RENAME, FUSE_ROOT_ID, &rename)), 0);
        assert!(!fsys.node_to_path.contains_key(&old));
        assert!(!fsys.host_inodes.contains_key(&old));
        assert_eq!(lookup(&mut fsys, b"destination\0"), new);
        let mut read = [0; 24];
        read[..8].copy_from_slice(&old_open[16..24]);
        read[16..20].copy_from_slice(&64u32.to_le_bytes());
        let old_data = request(&mut fsys, FUSE_READ, old, &read);
        assert_eq!(errno(&old_data), 0);
        assert_eq!(&old_data[16..], b"displaced");

        let opendir = request(&mut fsys, FUSE_OPENDIR, FUSE_ROOT_ID, &[0; 8]);
        assert_eq!(errno(&opendir), 0);
        std::os::unix::fs::symlink("new-target", dir.join("link")).unwrap();
        fs::rename(dir.join("link"), &path).unwrap();
        assert_eq!(errno(&open(&mut fsys, new, 0)), LINUX_ESTALE);

        read[..8].copy_from_slice(&opendir[16..24]);
        read[16..20].copy_from_slice(&4096u32.to_le_bytes());
        let directory = request(&mut fsys, FUSE_READDIRPLUS, FUSE_ROOT_ID, &read);
        assert_eq!(errno(&directory), 0);
        let current = u64::from_le_bytes(directory[16..24].try_into().unwrap());
        assert_ne!(current, new);
        assert_eq!(lookup(&mut fsys, b"destination\0"), current);
        assert_eq!(u32::from_le_bytes(directory[164..168].try_into().unwrap()), libc::DT_LNK as u32);
        assert_eq!(&directory[168..179], b"destination");
        fs::remove_file(path).unwrap();
        fs::remove_dir(dir).unwrap();
    }

    #[test]
    fn virtiofs_init_lookup_and_read() {
        let dir = std::env::temp_dir().join(format!("mp-vfs-test-{}", std::process::id()));
        let _ = fs::remove_dir_all(&dir);
        fs::create_dir_all(&dir).unwrap();
        fs::write(dir.join("hello.txt"), b"hello-virtiofs").unwrap();

        let mut vfs = VirtioFs::new("test-tag", dir.clone(), true, Arc::new(FsMetrics::default())).unwrap();
        // FUSE_INIT
        let mut init_req = vec![0u8; 56];
        init_req[0..4].copy_from_slice(&56u32.to_le_bytes());
        init_req[4..8].copy_from_slice(&FUSE_INIT.to_le_bytes());
        init_req[8..16].copy_from_slice(&1u64.to_le_bytes());
        let resp = vfs.handle_fuse(&init_req).unwrap();
        assert_eq!(i32::from_le_bytes(resp[4..8].try_into().unwrap()), 0);
        assert_eq!(u32::from_le_bytes(resp[16..20].try_into().unwrap()), 7);

        // FUSE_LOOKUP "hello.txt"
        let mut lookup = vec![0u8; 40];
        lookup[4..8].copy_from_slice(&FUSE_LOOKUP.to_le_bytes());
        lookup[8..16].copy_from_slice(&2u64.to_le_bytes());
        lookup[16..24].copy_from_slice(&FUSE_ROOT_ID.to_le_bytes());
        lookup.extend_from_slice(b"hello.txt\0");
        let l = lookup.len() as u32;
        lookup[0..4].copy_from_slice(&l.to_le_bytes());
        let lresp = vfs.handle_fuse(&lookup).unwrap();
        assert_eq!(i32::from_le_bytes(lresp[4..8].try_into().unwrap()), 0);
        let child_id = u64::from_le_bytes(lresp[16..24].try_into().unwrap());
        assert!(child_id >= 2);

        // FUSE_OPEN on read-only share returns ENOSYS (activating Linux fc->no_open + FOPEN_KEEP_CACHE)
        let mut open_req = vec![0u8; 48];
        open_req[0..4].copy_from_slice(&48u32.to_le_bytes());
        open_req[4..8].copy_from_slice(&FUSE_OPEN.to_le_bytes());
        open_req[8..16].copy_from_slice(&3u64.to_le_bytes());
        open_req[16..24].copy_from_slice(&child_id.to_le_bytes());
        let oresp = vfs.handle_fuse(&open_req).unwrap();
        assert_eq!(i32::from_le_bytes(oresp[4..8].try_into().unwrap()), -LINUX_ENOSYS);

        // FUSE_READ with fh == 0 resolves directly via nodeid cache
        let mut read_req = vec![0u8; 64];
        read_req[0..4].copy_from_slice(&64u32.to_le_bytes());
        read_req[4..8].copy_from_slice(&FUSE_READ.to_le_bytes());
        read_req[8..16].copy_from_slice(&4u64.to_le_bytes());
        read_req[16..24].copy_from_slice(&child_id.to_le_bytes());
        read_req[56..60].copy_from_slice(&64u32.to_le_bytes()); // size = 64
        let rresp = vfs.handle_fuse(&read_req).unwrap();
        assert_eq!(i32::from_le_bytes(rresp[4..8].try_into().unwrap()), 0);
        assert_eq!(&rresp[16..], b"hello-virtiofs");

        // Path traversal rejected
        assert_eq!(vfs.child_path(FUSE_ROOT_ID, b"../etc").unwrap_err(), LINUX_EINVAL);

        let _ = fs::remove_dir_all(&dir);
    }
}
