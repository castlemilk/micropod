//! Virtio-Vsock (Device ID 19) with bidirectional Host<->Guest Unix socket
//! multiplexing and in-process guest->host service hooks (e.g., Micropod's
//! 4-byte published-port broker on host port 2378).

use std::collections::{HashMap, VecDeque};
use std::io::{Read, Write};
use std::os::fd::AsRawFd;
use std::os::unix::net::{UnixListener, UnixStream};
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, AtomicU32, Ordering};
use std::sync::{Arc, Condvar, Mutex};
use std::thread;
use std::time::Duration;

use crate::{GuestMemory, IrqLine, VirtQueue, VirtioBackend, collect_readable, scatter_writable};

pub const HOST_CID: u64 = 2;
pub const GUEST_CID: u64 = 3;

const VIRTIO_VSOCK_TYPE_STREAM: u16 = 1;
const VIRTIO_VSOCK_OP_REQUEST: u16 = 1;
const VIRTIO_VSOCK_OP_RESPONSE: u16 = 2;
const VIRTIO_VSOCK_OP_RST: u16 = 3;
const VIRTIO_VSOCK_OP_SHUTDOWN: u16 = 4;
const VIRTIO_VSOCK_OP_RW: u16 = 5;
const VIRTIO_VSOCK_OP_CREDIT_UPDATE: u16 = 6;
const VIRTIO_VSOCK_OP_CREDIT_REQUEST: u16 = 7;

const SHUTDOWN_RCV: u32 = 1;
const SHUTDOWN_SEND: u32 = 2;

const VSOCK_HDR_LEN: usize = 44;
const BUF_ALLOC: u32 = 256 * 1024;
const MAX_PKT_PAYLOAD: usize = 4096; // Matches Linux VIRTIO_VSOCK_DEFAULT_RX_BUF_SIZE

#[derive(Debug, Clone, Copy)]
pub struct VsockHdr {
    pub src_cid: u64,
    pub dst_cid: u64,
    pub src_port: u32,
    pub dst_port: u32,
    pub len: u32,
    pub sock_type: u16,
    pub op: u16,
    pub flags: u32,
    pub buf_alloc: u32,
    pub fwd_cnt: u32,
}

impl VsockHdr {
    pub fn decode(b: &[u8]) -> Option<Self> {
        if b.len() < VSOCK_HDR_LEN {
            return None;
        }
        Some(Self {
            src_cid: u64::from_le_bytes(b[0..8].try_into().ok()?),
            dst_cid: u64::from_le_bytes(b[8..16].try_into().ok()?),
            src_port: u32::from_le_bytes(b[16..20].try_into().ok()?),
            dst_port: u32::from_le_bytes(b[20..24].try_into().ok()?),
            len: u32::from_le_bytes(b[24..28].try_into().ok()?),
            sock_type: u16::from_le_bytes(b[28..30].try_into().ok()?),
            op: u16::from_le_bytes(b[30..32].try_into().ok()?),
            flags: u32::from_le_bytes(b[32..36].try_into().ok()?),
            buf_alloc: u32::from_le_bytes(b[36..40].try_into().ok()?),
            fwd_cnt: u32::from_le_bytes(b[40..44].try_into().ok()?),
        })
    }

    pub fn encode(&self) -> [u8; VSOCK_HDR_LEN] {
        let mut b = [0u8; VSOCK_HDR_LEN];
        b[0..8].copy_from_slice(&self.src_cid.to_le_bytes());
        b[8..16].copy_from_slice(&self.dst_cid.to_le_bytes());
        b[16..20].copy_from_slice(&self.src_port.to_le_bytes());
        b[20..24].copy_from_slice(&self.dst_port.to_le_bytes());
        b[24..28].copy_from_slice(&self.len.to_le_bytes());
        b[28..30].copy_from_slice(&self.sock_type.to_le_bytes());
        b[30..32].copy_from_slice(&self.op.to_le_bytes());
        b[32..36].copy_from_slice(&self.flags.to_le_bytes());
        b[36..40].copy_from_slice(&self.buf_alloc.to_le_bytes());
        b[40..44].copy_from_slice(&self.fwd_cnt.to_le_bytes());
        b
    }
}

#[derive(Clone)]
pub struct VsockExposeSpec {
    pub host_unix_path: PathBuf,
    pub guest_port: u32,
}

/// Callback invoked when the guest opens a vsock stream to a registered host port.
/// Receives a host-side `UnixStream` paired directly with the guest vsock stream.
pub type HostServiceHandler = Arc<dyn Fn(UnixStream) + Send + Sync>;

struct RxPacket {
    hdr: VsockHdr,
    payload: Vec<u8>,
}

struct StreamState {
    host_port: u32,
    guest_port: u32,
    connected: bool,
    closed: bool,
    guest_send_eof: bool,
    host_send_eof: bool,
    rst_sent: bool,
    tx_cnt: u32,        // bytes host has sent to guest
    fwd_cnt: u32,       // bytes host has forwarded from guest to host UnixStream
    peer_buf_alloc: u32,
    peer_fwd_cnt: u32,
    to_host_buf: VecDeque<u8>,
}

impl StreamState {
    fn peer_credit(&self) -> u32 {
        self.peer_buf_alloc
            .saturating_sub(self.tx_cnt.wrapping_sub(self.peer_fwd_cnt))
    }
}

struct MuxInner {
    rx_queue: Option<VirtQueue>,
    rx_pending: VecDeque<RxPacket>,
    streams: HashMap<(u32, u32), Arc<(Mutex<StreamState>, Condvar)>>,
    host_services: HashMap<u32, HostServiceHandler>,
    mem: Option<Arc<GuestMemory>>,
    irq: Option<IrqLine>,
    shutdown: AtomicBool,
}

impl MuxInner {
    fn enqueue_rx(&mut self, pkt: RxPacket) {
        self.rx_pending.push_back(pkt);
        self.flush_rx();
    }

    fn flush_rx(&mut self) {
        let (Some(mem), Some(irq), Some(rxq)) =
            (self.mem.as_ref(), self.irq.as_ref(), self.rx_queue.as_mut())
        else {
            return;
        };
        let mut pushed = false;
        while self.rx_pending.front().is_some() {
            let Some((head, bufs)) = rxq.pop(mem) else {
                break;
            };
            let mut pkt = self.rx_pending.pop_front().unwrap();
            let writable_total: usize = bufs
                .iter()
                .filter(|b| b.is_write)
                .map(|b| b.len as usize)
                .sum();
            let max_payload = writable_total.saturating_sub(VSOCK_HDR_LEN);
            if pkt.hdr.op == VIRTIO_VSOCK_OP_RW && pkt.payload.len() > max_payload && max_payload > 0 {
                let tail = pkt.payload.split_off(max_payload);
                let mut rem_hdr = pkt.hdr;
                rem_hdr.len = tail.len() as u32;
                pkt.hdr.len = max_payload as u32;
                self.rx_pending.push_front(RxPacket { hdr: rem_hdr, payload: tail });
            }
            let hdr_bytes = pkt.hdr.encode();
            let mut full = Vec::with_capacity(VSOCK_HDR_LEN + pkt.payload.len());
            full.extend_from_slice(&hdr_bytes);
            full.extend_from_slice(&pkt.payload);
            let written = scatter_writable(&bufs, mem, &full);
            rxq.push_used(mem, head, written);
            pushed = true;
        }
        if pushed {
            irq.raise_used_buffer();
        }
    }
}

pub struct VirtioVsock {
    inner: Arc<Mutex<MuxInner>>,
    next_host_port: Arc<AtomicU32>,
    expose_specs: Vec<VsockExposeSpec>,
    listeners_started: bool,
}

impl VirtioVsock {
    pub fn new(
        expose_specs: Vec<VsockExposeSpec>,
        host_services: HashMap<u32, HostServiceHandler>,
    ) -> Self {
        Self {
            inner: Arc::new(Mutex::new(MuxInner {
                rx_queue: None,
                rx_pending: VecDeque::with_capacity(256),
                streams: HashMap::new(),
                host_services,
                mem: None,
                irq: None,
                shutdown: AtomicBool::new(false),
            })),
            next_host_port: Arc::new(AtomicU32::new(40_000)),
            expose_specs,
            listeners_started: false,
        }
    }

    fn start_host_listeners(&mut self) {
        if self.listeners_started {
            return;
        }
        self.listeners_started = true;
        for spec in &self.expose_specs {
            let _ = std::fs::remove_file(&spec.host_unix_path);
            if let Some(parent) = spec.host_unix_path.parent() {
                let _ = std::fs::create_dir_all(parent);
            }
            let Ok(listener) = UnixListener::bind(&spec.host_unix_path) else {
                eprintln!(
                    "[micropod-vmm] vsock: failed to bind {}",
                    spec.host_unix_path.display()
                );
                continue;
            };
            // Owner-only 0600 permissions matching Micropod security invariant
            let _ = std::fs::set_permissions(
                &spec.host_unix_path,
                std::os::unix::fs::PermissionsExt::from_mode(0o600),
            );
            let inner = self.inner.clone();
            let next_port = self.next_host_port.clone();
            let guest_port = spec.guest_port;
            let _ = listener.set_nonblocking(true);
            let lfd = listener.as_raw_fd();
            thread::spawn(move || {
                loop {
                    if inner.lock().unwrap().shutdown.load(Ordering::Relaxed) {
                        break;
                    }
                    let mut pfd = libc::pollfd {
                        fd: lfd,
                        events: libc::POLLIN,
                        revents: 0,
                    };
                    let prc = unsafe { libc::poll(&mut pfd, 1, 100) };
                    if prc <= 0 {
                        continue;
                    }
                    loop {
                        match listener.accept() {
                            Ok((unix_stream, _)) => {
                                let host_port = next_port.fetch_add(1, Ordering::Relaxed);
                                let inner_c = inner.clone();
                                thread::spawn(move || {
                                    bridge_host_initiated(inner_c, unix_stream, host_port, guest_port);
                                });
                            }
                            Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => break,
                            Err(_) => return,
                        }
                    }
                }
            });
        }
    }

    fn handle_tx_packet(&self, raw: &[u8]) {
        let Some(hdr) = VsockHdr::decode(raw) else {
            return;
        };
        let payload = &raw[VSOCK_HDR_LEN..raw.len().min(VSOCK_HDR_LEN + hdr.len as usize)];
        let key = (hdr.dst_port, hdr.src_port); // (host_port, guest_port)

        match hdr.op {
            VIRTIO_VSOCK_OP_REQUEST => {
                // Guest -> Host service connection (e.g. ports.sock on host port 2378)
                let handler = {
                    let g = self.inner.lock().unwrap();
                    g.host_services.get(&hdr.dst_port).cloned()
                };
                if let Some(handler) = handler {
                    if let Ok((a, b)) = UnixStream::pair() {
                        let Ok(writer) = a.try_clone() else {
                            return;
                        };
                        let st = Arc::new((
                            Mutex::new(StreamState {
                                host_port: hdr.dst_port,
                                guest_port: hdr.src_port,
                                connected: true,
                                closed: false,
                                guest_send_eof: false,
                                host_send_eof: false,
                                rst_sent: false,
                                tx_cnt: 0,
                                fwd_cnt: 0,
                                peer_buf_alloc: hdr.buf_alloc,
                                peer_fwd_cnt: hdr.fwd_cnt,
                                to_host_buf: VecDeque::new(),
                            }),
                            Condvar::new(),
                        ));
                        {
                            let mut g = self.inner.lock().unwrap();
                            g.streams.insert(key, st.clone());
                            g.enqueue_rx(RxPacket {
                                hdr: VsockHdr {
                                    src_cid: HOST_CID,
                                    dst_cid: GUEST_CID,
                                    src_port: hdr.dst_port,
                                    dst_port: hdr.src_port,
                                    len: 0,
                                    sock_type: VIRTIO_VSOCK_TYPE_STREAM,
                                    op: VIRTIO_VSOCK_OP_RESPONSE,
                                    flags: 0,
                                    buf_alloc: BUF_ALLOC,
                                    fwd_cnt: 0,
                                },
                                payload: Vec::new(),
                            });
                        }
                        let inner_w = self.inner.clone();
                        let st_w = st.clone();
                        thread::spawn(move || {
                            pump_guest_to_host(inner_w, st_w, writer);
                        });
                        let inner_r = self.inner.clone();
                        let st_r = st.clone();
                        thread::spawn(move || {
                            pump_host_to_guest(inner_r, st_r, a);
                        });
                        thread::spawn(move || {
                            handler(b);
                        });
                        return;
                    }
                }
                // No host service listening -> RST
                self.inner.lock().unwrap().enqueue_rx(RxPacket {
                    hdr: VsockHdr {
                        src_cid: HOST_CID,
                        dst_cid: GUEST_CID,
                        src_port: hdr.dst_port,
                        dst_port: hdr.src_port,
                        len: 0,
                        sock_type: VIRTIO_VSOCK_TYPE_STREAM,
                        op: VIRTIO_VSOCK_OP_RST,
                        flags: 0,
                        buf_alloc: BUF_ALLOC,
                        fwd_cnt: 0,
                    },
                    payload: Vec::new(),
                });
            }
            VIRTIO_VSOCK_OP_RESPONSE => {
                let st_opt = self.inner.lock().unwrap().streams.get(&key).cloned();
                if let Some(st) = st_opt {
                    let mut s = st.0.lock().unwrap();
                    s.connected = true;
                    s.peer_buf_alloc = hdr.buf_alloc;
                    s.peer_fwd_cnt = hdr.fwd_cnt;
                    st.1.notify_all();
                }
            }
            VIRTIO_VSOCK_OP_RW => {
                let st_opt = self.inner.lock().unwrap().streams.get(&key).cloned();
                if let Some(st) = st_opt {
                    let mut s = st.0.lock().unwrap();
                    s.peer_buf_alloc = hdr.buf_alloc;
                    s.peer_fwd_cnt = hdr.fwd_cnt;
                    s.to_host_buf.extend(payload);
                    st.1.notify_all();
                }
            }
            VIRTIO_VSOCK_OP_CREDIT_UPDATE => {
                let st_opt = self.inner.lock().unwrap().streams.get(&key).cloned();
                if let Some(st) = st_opt {
                    let mut s = st.0.lock().unwrap();
                    s.peer_buf_alloc = hdr.buf_alloc;
                    s.peer_fwd_cnt = hdr.fwd_cnt;
                    st.1.notify_all();
                }
            }
            VIRTIO_VSOCK_OP_CREDIT_REQUEST => {
                let st_opt = self.inner.lock().unwrap().streams.get(&key).cloned();
                if let Some(st) = st_opt {
                    let fwd = st.0.lock().unwrap().fwd_cnt;
                    self.inner.lock().unwrap().enqueue_rx(RxPacket {
                        hdr: VsockHdr {
                            src_cid: HOST_CID,
                            dst_cid: GUEST_CID,
                            src_port: hdr.dst_port,
                            dst_port: hdr.src_port,
                            len: 0,
                            sock_type: VIRTIO_VSOCK_TYPE_STREAM,
                            op: VIRTIO_VSOCK_OP_CREDIT_UPDATE,
                            flags: 0,
                            buf_alloc: BUF_ALLOC,
                            fwd_cnt: fwd,
                        },
                        payload: Vec::new(),
                    });
                }
            }
            VIRTIO_VSOCK_OP_SHUTDOWN => {
                let st_opt = self.inner.lock().unwrap().streams.get(&key).cloned();
                if let Some(st) = st_opt {
                    let send_rst = {
                        let mut s = st.0.lock().unwrap();
                        if (hdr.flags & SHUTDOWN_SEND) != 0 {
                            s.guest_send_eof = true;
                        }
                        if (hdr.flags & SHUTDOWN_RCV) != 0 {
                            s.closed = true;
                        }
                        st.1.notify_all();
                        let both = s.guest_send_eof && (s.host_send_eof || s.closed) && s.to_host_buf.is_empty();
                        if both && !s.rst_sent {
                            s.rst_sent = true;
                            Some((s.host_port, s.guest_port, s.fwd_cnt))
                        } else {
                            None
                        }
                    };
                    if let Some((hp, gp, fwd)) = send_rst {
                        let mut g = self.inner.lock().unwrap();
                        g.streams.remove(&(hp, gp));
                        g.enqueue_rx(RxPacket {
                            hdr: VsockHdr {
                                src_cid: HOST_CID,
                                dst_cid: GUEST_CID,
                                src_port: hp,
                                dst_port: gp,
                                len: 0,
                                sock_type: VIRTIO_VSOCK_TYPE_STREAM,
                                op: VIRTIO_VSOCK_OP_RST,
                                flags: 0,
                                buf_alloc: BUF_ALLOC,
                                fwd_cnt: fwd,
                            },
                            payload: Vec::new(),
                        });
                    }
                }
            }
            VIRTIO_VSOCK_OP_RST => {
                let st_opt = self.inner.lock().unwrap().streams.remove(&key);
                if let Some(st) = st_opt {
                    let mut s = st.0.lock().unwrap();
                    s.closed = true;
                    st.1.notify_all();
                }
            }
            _ => {}
        }
    }
}

fn bridge_host_initiated(
    inner: Arc<Mutex<MuxInner>>,
    unix_stream: UnixStream,
    host_port: u32,
    guest_port: u32,
) {
    let _ = unix_stream.set_nonblocking(false);
    let writer = match unix_stream.try_clone() {
        Ok(w) => w,
        Err(_) => return,
    };
    let st = Arc::new((
        Mutex::new(StreamState {
            host_port,
            guest_port,
            connected: false,
            closed: false,
            guest_send_eof: false,
            host_send_eof: false,
            rst_sent: false,
            tx_cnt: 0,
            fwd_cnt: 0,
            peer_buf_alloc: 0,
            peer_fwd_cnt: 0,
            to_host_buf: VecDeque::new(),
        }),
        Condvar::new(),
    ));
    let key = (host_port, guest_port);
    {
        let mut g = inner.lock().unwrap();
        g.streams.insert(key, st.clone());
        g.enqueue_rx(RxPacket {
            hdr: VsockHdr {
                src_cid: HOST_CID,
                dst_cid: GUEST_CID,
                src_port: host_port,
                dst_port: guest_port,
                len: 0,
                sock_type: VIRTIO_VSOCK_TYPE_STREAM,
                op: VIRTIO_VSOCK_OP_REQUEST,
                flags: 0,
                buf_alloc: BUF_ALLOC,
                fwd_cnt: 0,
            },
            payload: Vec::new(),
        });
    }
    // Wait for guest OP_RESPONSE (up to 5s)
    {
        let mut s = st.0.lock().unwrap();
        let deadline = std::time::Instant::now() + Duration::from_secs(5);
        while !s.connected && !s.closed {
            let rem = deadline.saturating_duration_since(std::time::Instant::now());
            if rem.is_zero() {
                s.closed = true;
                break;
            }
            let (ns, _) = st.1.wait_timeout(s, rem).unwrap();
            s = ns;
        }
        if !s.connected || s.closed {
            drop(s);
            inner.lock().unwrap().streams.remove(&key);
            return;
        }
    }
    let inner_w = inner.clone();
    let st_w = st.clone();
    thread::spawn(move || {
        pump_guest_to_host(inner_w, st_w, writer);
    });
    pump_host_to_guest(inner, st, unix_stream);
}

fn pump_guest_to_host(
    inner: Arc<Mutex<MuxInner>>,
    st: Arc<(Mutex<StreamState>, Condvar)>,
    mut writer: UnixStream,
) {
    loop {
        let (chunk, eof, hp, gp) = {
            let mut s = st.0.lock().unwrap();
            while s.to_host_buf.is_empty() && !s.guest_send_eof && !s.closed {
                s = st.1.wait(s).unwrap();
            }
            if !s.to_host_buf.is_empty() {
                let take = s.to_host_buf.len().min(64 * 1024);
                let data: Vec<u8> = s.to_host_buf.drain(..take).collect();
                (data, false, s.host_port, s.guest_port)
            } else {
                (Vec::new(), true, s.host_port, s.guest_port)
            }
        };
        if !chunk.is_empty() {
            if writer.write_all(&chunk).is_err() {
                let mut s = st.0.lock().unwrap();
                s.closed = true;
                st.1.notify_all();
                break;
            }
            let new_fwd = {
                let mut s = st.0.lock().unwrap();
                s.fwd_cnt = s.fwd_cnt.wrapping_add(chunk.len() as u32);
                s.fwd_cnt
            };
            inner.lock().unwrap().enqueue_rx(RxPacket {
                hdr: VsockHdr {
                    src_cid: HOST_CID,
                    dst_cid: GUEST_CID,
                    src_port: hp,
                    dst_port: gp,
                    len: 0,
                    sock_type: VIRTIO_VSOCK_TYPE_STREAM,
                    op: VIRTIO_VSOCK_OP_CREDIT_UPDATE,
                    flags: 0,
                    buf_alloc: BUF_ALLOC,
                    fwd_cnt: new_fwd,
                },
                payload: Vec::new(),
            });
            continue;
        }
        if eof {
            let _ = writer.shutdown(std::net::Shutdown::Write);
            let send_rst = {
                let mut s = st.0.lock().unwrap();
                if (s.host_send_eof || s.closed) && !s.rst_sent {
                    s.rst_sent = true;
                    Some((s.host_port, s.guest_port, s.fwd_cnt))
                } else {
                    None
                }
            };
            if let Some((hp, gp, fwd)) = send_rst {
                let mut g = inner.lock().unwrap();
                g.streams.remove(&(hp, gp));
                g.enqueue_rx(RxPacket {
                    hdr: VsockHdr {
                        src_cid: HOST_CID,
                        dst_cid: GUEST_CID,
                        src_port: hp,
                        dst_port: gp,
                        len: 0,
                        sock_type: VIRTIO_VSOCK_TYPE_STREAM,
                        op: VIRTIO_VSOCK_OP_RST,
                        flags: 0,
                        buf_alloc: BUF_ALLOC,
                        fwd_cnt: fwd,
                    },
                    payload: Vec::new(),
                });
            }
            break;
        }
    }
}

fn pump_host_to_guest(
    inner: Arc<Mutex<MuxInner>>,
    st: Arc<(Mutex<StreamState>, Condvar)>,
    mut reader: UnixStream,
) {
    let mut buf = vec![0u8; MAX_PKT_PAYLOAD];
    loop {
        match reader.read(&mut buf) {
            Ok(0) => {
                // EOF from host client -> send SHUTDOWN(SEND) (or RST if guest already EOF)
                let (hp, gp, fwd, send_rst) = {
                    let mut s = st.0.lock().unwrap();
                    s.host_send_eof = true;
                    let both = s.guest_send_eof && s.to_host_buf.is_empty() && !s.rst_sent;
                    if both {
                        s.rst_sent = true;
                    }
                    (s.host_port, s.guest_port, s.fwd_cnt, both)
                };
                let mut g = inner.lock().unwrap();
                if send_rst {
                    g.streams.remove(&(hp, gp));
                }
                g.enqueue_rx(RxPacket {
                    hdr: VsockHdr {
                        src_cid: HOST_CID,
                        dst_cid: GUEST_CID,
                        src_port: hp,
                        dst_port: gp,
                        len: 0,
                        sock_type: VIRTIO_VSOCK_TYPE_STREAM,
                        op: if send_rst { VIRTIO_VSOCK_OP_RST } else { VIRTIO_VSOCK_OP_SHUTDOWN },
                        flags: if send_rst { 0 } else { SHUTDOWN_SEND },
                        buf_alloc: BUF_ALLOC,
                        fwd_cnt: fwd,
                    },
                    payload: Vec::new(),
                });
                break;
            }
            Ok(n) => {
                let mut offset = 0;
                while offset < n {
                    let (hp, gp, fwd, chunk_len) = {
                        let mut s = st.0.lock().unwrap();
                        let mut requested_credit = false;
                        while s.peer_credit() == 0 && !s.closed {
                            if !requested_credit {
                                let (hp, gp, fwd) = (s.host_port, s.guest_port, s.fwd_cnt);
                                drop(s);
                                inner.lock().unwrap().enqueue_rx(RxPacket {
                                    hdr: VsockHdr {
                                        src_cid: HOST_CID,
                                        dst_cid: GUEST_CID,
                                        src_port: hp,
                                        dst_port: gp,
                                        len: 0,
                                        sock_type: VIRTIO_VSOCK_TYPE_STREAM,
                                        op: VIRTIO_VSOCK_OP_CREDIT_REQUEST,
                                        flags: 0,
                                        buf_alloc: BUF_ALLOC,
                                        fwd_cnt: fwd,
                                    },
                                    payload: Vec::new(),
                                });
                                requested_credit = true;
                                s = st.0.lock().unwrap();
                                continue;
                            }
                            let (ns, _) =
                                st.1.wait_timeout(s, Duration::from_millis(10)).unwrap();
                            s = ns;
                            requested_credit = false;
                        }
                        if s.closed {
                            return;
                        }
                        let take = (n - offset)
                            .min(s.peer_credit() as usize)
                            .min(MAX_PKT_PAYLOAD);
                        s.tx_cnt = s.tx_cnt.wrapping_add(take as u32);
                        (s.host_port, s.guest_port, s.fwd_cnt, take)
                    };
                    let slice = buf[offset..offset + chunk_len].to_vec();
                    offset += chunk_len;
                    inner.lock().unwrap().enqueue_rx(RxPacket {
                        hdr: VsockHdr {
                            src_cid: HOST_CID,
                            dst_cid: GUEST_CID,
                            src_port: hp,
                            dst_port: gp,
                            len: chunk_len as u32,
                            sock_type: VIRTIO_VSOCK_TYPE_STREAM,
                            op: VIRTIO_VSOCK_OP_RW,
                            flags: 0,
                            buf_alloc: BUF_ALLOC,
                            fwd_cnt: fwd,
                        },
                        payload: slice,
                    });
                }
            }
            Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
            Err(_) => {
                let (hp, gp, fwd) = {
                    let mut s = st.0.lock().unwrap();
                    s.closed = true;
                    (s.host_port, s.guest_port, s.fwd_cnt)
                };
                let mut g = inner.lock().unwrap();
                g.streams.remove(&(hp, gp));
                g.enqueue_rx(RxPacket {
                    hdr: VsockHdr {
                        src_cid: HOST_CID,
                        dst_cid: GUEST_CID,
                        src_port: hp,
                        dst_port: gp,
                        len: 0,
                        sock_type: VIRTIO_VSOCK_TYPE_STREAM,
                        op: VIRTIO_VSOCK_OP_RST,
                        flags: 0,
                        buf_alloc: BUF_ALLOC,
                        fwd_cnt: fwd,
                    },
                    payload: Vec::new(),
                });
                break;
            }
        }
    }
}

impl VirtioBackend for VirtioVsock {
    fn device_id(&self) -> u32 {
        19
    }
    fn features(&self) -> u64 {
        0
    }
    fn num_queues(&self) -> usize {
        3 // 0 = RX, 1 = TX, 2 = Event
    }
    fn queue_max_size(&self, _q: usize) -> u16 {
        256
    }
    fn read_config(&self, offset: u64, data: &mut [u8]) {
        let cfg = GUEST_CID.to_le_bytes();
        let start = offset as usize;
        for (i, b) in data.iter_mut().enumerate() {
            *b = cfg.get(start + i).copied().unwrap_or(0);
        }
    }
    fn attach(&mut self, mem: Arc<GuestMemory>, irq: IrqLine) {
        let mut g = self.inner.lock().unwrap();
        g.mem = Some(mem);
        g.irq = Some(irq);
    }
    fn queue_ready(&mut self, q_idx: usize, q: &VirtQueue) {
        if q_idx == 0 {
            let mut g = self.inner.lock().unwrap();
            g.rx_queue = Some(q.clone());
            g.flush_rx();
            drop(g);
            self.start_host_listeners();
        }
    }
    fn reset(&mut self) {
        let mut g = self.inner.lock().unwrap();
        g.rx_queue = None;
        g.rx_pending.clear();
        g.streams.clear();
    }
    fn handle_queue(&mut self, q_idx: usize, queues: &mut [VirtQueue], mem: &GuestMemory) -> bool {
        match q_idx {
            0 => {
                // Guest refilled RX descriptors -> sync rx_queue state and flush pending packets
                let mut g = self.inner.lock().unwrap();
                if let Some(ref mut rxq) = g.rx_queue {
                    rxq.ready = queues[0].ready;
                    rxq.size = queues[0].size;
                    rxq.desc_addr = queues[0].desc_addr;
                    rxq.avail_addr = queues[0].avail_addr;
                    rxq.used_addr = queues[0].used_addr;
                } else {
                    g.rx_queue = Some(queues[0].clone());
                }
                g.flush_rx();
                false // flush_rx raises IRQ directly via IrqLine
            }
            1 => {
                // Guest sent TX packets
                let mut packets = Vec::new();
                while let Some((head, bufs)) = queues[1].pop(mem) {
                    let raw = collect_readable(&bufs, mem);
                    packets.push(raw);
                    queues[1].push_used(mem, head, 0);
                }
                let had_tx = !packets.is_empty();
                for raw in packets {
                    self.handle_tx_packet(&raw);
                }
                had_tx
            }
            _ => false,
        }
    }
}

impl Drop for VirtioVsock {
    fn drop(&mut self) {
        self.inner.lock().unwrap().shutdown.store(true, Ordering::SeqCst);
        for spec in &self.expose_specs {
            let _ = std::fs::remove_file(&spec.host_unix_path);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn vsock_hdr_roundtrip() {
        let hdr = VsockHdr {
            src_cid: HOST_CID,
            dst_cid: GUEST_CID,
            src_port: 40001,
            dst_port: 2375,
            len: 512,
            sock_type: VIRTIO_VSOCK_TYPE_STREAM,
            op: VIRTIO_VSOCK_OP_RW,
            flags: 0,
            buf_alloc: BUF_ALLOC,
            fwd_cnt: 1024,
        };
        let enc = hdr.encode();
        let dec = VsockHdr::decode(&enc).unwrap();
        assert_eq!(dec.src_cid, HOST_CID);
        assert_eq!(dec.dst_cid, GUEST_CID);
        assert_eq!(dec.src_port, 40001);
        assert_eq!(dec.dst_port, 2375);
        assert_eq!(dec.len, 512);
        assert_eq!(dec.op, VIRTIO_VSOCK_OP_RW);
        assert_eq!(dec.fwd_cnt, 1024);
    }
}
