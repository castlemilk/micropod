//! Host <-> guest control channel over Virtio-Vsock (`VSOCK_PORT_CTRL = 2379`).
//!
//! Provides two production lifecycle primitives with zero idle CPU overhead:
//! 1. **Live wall-clock sync (`CLOCK <unix_ns>\n`)**: pushed immediately when `mp-hvf-init`
//!    connects (including right after `--restore-from` snapshot forks!) and whenever the
//!    host wall clock jumps relative to monotonic time (macOS lid sleep/wake or NTP steps).
//! 2. **Graceful guest shutdown (`POWEROFF\n`)**: pushed on host `SIGTERM`/`SIGINT` so
//!    `mp-hvf-init` stops the worker, calls `sync(2)`, remounts ext4 cleanly, and triggers
//!    `PSCI_SYSTEM_OFF` before any hard `hv_vcpus_exit` fallback.

use std::io::{Read, Write};
use std::os::unix::net::UnixStream;
use std::sync::{Arc, Mutex};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use vmm_virtio::vsock::HostServiceHandler;

pub const VSOCK_PORT_CTRL: u32 = 2379;
const MIN_UNIX_SECS: u64 = 1_577_836_800; // 2020-01-01 UTC

struct CtrlInner {
    next_gen: u64,
    active: Option<(u64, UnixStream)>,
    poweroff_requested: bool,
}

pub struct GuestControl {
    inner: Arc<Mutex<CtrlInner>>,
}

/// Convert `SystemTime` to a validated Unix nanosecond timestamp (`>= 2020-01-01 UTC`).
pub fn current_unix_ns(now: SystemTime) -> Option<i64> {
    let elapsed = now.duration_since(UNIX_EPOCH).ok()?;
    if elapsed.as_secs() < MIN_UNIX_SECS {
        return None;
    }
    i64::try_from(elapsed.as_nanos()).ok()
}

/// Returns true if wall-clock elapsed time diverged from monotonic elapsed time by more
/// than `threshold_ns` (for example after macOS lid sleep/wake or a large NTP step).
pub fn clock_jump_exceeds_threshold(
    prev_sys_ns: i64,
    now_sys_ns: i64,
    mono_elapsed_ns: i64,
    threshold_ns: i64,
) -> bool {
    let sys_delta = now_sys_ns.saturating_sub(prev_sys_ns);
    let drift = sys_delta.saturating_sub(mono_elapsed_ns).unsigned_abs();
    drift > threshold_ns.max(0) as u64
}

fn format_clock_cmd(now: SystemTime) -> Option<String> {
    let ns = current_unix_ns(now)?;
    Some(format!("CLOCK {ns}\n"))
}

fn write_cmd(stream: &mut UnixStream, cmd: &str) -> bool {
    stream.write_all(cmd.as_bytes()).is_ok()
}

impl GuestControl {
    pub fn new() -> Self {
        Self {
            inner: Arc::new(Mutex::new(CtrlInner {
                next_gen: 1,
                active: None,
                poweroff_requested: false,
            })),
        }
    }

    pub fn is_connected(&self) -> bool {
        self.inner.lock().unwrap().active.is_some()
    }

    /// Push a `CLOCK <unix_ns>` update to the connected guest init, if any.
    pub fn send_clock_sync(&self, now: SystemTime) -> bool {
        let Some(cmd) = format_clock_cmd(now) else {
            return false;
        };
        let mut g = self.inner.lock().unwrap();
        let Some((_, ref mut stream)) = g.active else {
            return false;
        };
        if write_cmd(stream, &cmd) {
            true
        } else {
            g.active = None;
            false
        }
    }

    /// Request a graceful guest poweroff. Returns `true` if `POWEROFF` was delivered
    /// to an active guest control connection (so the caller should wait for `PSCI_SYSTEM_OFF`).
    pub fn request_poweroff(&self) -> bool {
        let mut g = self.inner.lock().unwrap();
        g.poweroff_requested = true;
        let Some((_, ref mut stream)) = g.active else {
            return false;
        };
        if write_cmd(stream, "POWEROFF\n") {
            true
        } else {
            g.active = None;
            false
        }
    }

    /// Build the `VirtioVsock` host service handler for `VSOCK_PORT_CTRL`.
    pub fn vsock_handler(&self) -> HostServiceHandler {
        let inner = self.inner.clone();
        Arc::new(move |mut stream: UnixStream| {
            let _ = stream.set_write_timeout(Some(Duration::from_millis(500)));
            let _ = stream.set_read_timeout(None);

            // Sync guest wall clock immediately on connect (cold boot or snapshot restore).
            if let Some(cmd) = format_clock_cmd(SystemTime::now()) {
                if !write_cmd(&mut stream, &cmd) {
                    return;
                }
            }

            let Ok(mut writer) = stream.try_clone() else {
                return;
            };
            let _ = writer.set_write_timeout(Some(Duration::from_millis(500)));

            let my_gen = {
                let mut g = inner.lock().unwrap();
                let conn_gen = g.next_gen;
                g.next_gen = g.next_gen.wrapping_add(1).max(1);
                if g.poweroff_requested {
                    let _ = write_cmd(&mut writer, "POWEROFF\n");
                }
                g.active = Some((conn_gen, writer));
                conn_gen
            };

            // Park at 0% CPU until the guest closes or resets the control stream.
            let mut buf = [0u8; 256];
            loop {
                match stream.read(&mut buf) {
                    Ok(0) => break,
                    Ok(_) => {}
                    Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
                    Err(_) => break,
                }
            }

            let mut g = inner.lock().unwrap();
            if g.active
                .as_ref()
                .is_some_and(|(conn_gen, _)| *conn_gen == my_gen)
            {
                g.active = None;
            }
        })
    }
}

impl Default for GuestControl {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::{BufRead, BufReader};
    use std::thread;

    #[test]
    fn guest_control_sends_initial_clock_resync_and_poweroff() {
        let ctrl = GuestControl::new();
        assert!(!ctrl.is_connected());
        assert!(!ctrl.request_poweroff());

        // Reset via a fresh GuestControl to test connected flow
        let ctrl = GuestControl::new();
        let handler = ctrl.vsock_handler();
        let (host_end, guest_end) = UnixStream::pair().unwrap();
        let _ = guest_end.set_read_timeout(Some(Duration::from_secs(2)));
        let t = thread::spawn(move || handler(host_end));

        let mut reader = BufReader::new(guest_end);
        let mut line = String::new();
        reader.read_line(&mut line).unwrap();
        assert!(line.starts_with("CLOCK "), "expected initial CLOCK, got {line:?}");
        let ns: i64 = line.trim().strip_prefix("CLOCK ").unwrap().parse().unwrap();
        assert!(ns >= (MIN_UNIX_SECS as i64) * 1_000_000_000);

        // Wait briefly for handler to register active stream
        for _ in 0..50 {
            if ctrl.is_connected() {
                break;
            }
            thread::sleep(Duration::from_millis(2));
        }
        assert!(ctrl.is_connected());

        let t_sync = UNIX_EPOCH + Duration::new(1_800_000_000, 987_654_321);
        assert!(ctrl.send_clock_sync(t_sync));
        line.clear();
        reader.read_line(&mut line).unwrap();
        assert_eq!(line, "CLOCK 1800000000987654321\n");

        assert!(ctrl.request_poweroff());
        line.clear();
        reader.read_line(&mut line).unwrap();
        assert_eq!(line, "POWEROFF\n");

        drop(reader);
        t.join().unwrap();
        assert!(!ctrl.is_connected());
    }

    #[test]
    fn guest_control_delivers_pending_poweroff_on_connect() {
        let ctrl = GuestControl::new();
        assert!(!ctrl.request_poweroff());

        let handler = ctrl.vsock_handler();
        let (host_end, guest_end) = UnixStream::pair().unwrap();
        let _ = guest_end.set_read_timeout(Some(Duration::from_secs(2)));
        let t = thread::spawn(move || handler(host_end));

        let mut reader = BufReader::new(guest_end);
        let mut line1 = String::new();
        let mut line2 = String::new();
        reader.read_line(&mut line1).unwrap();
        reader.read_line(&mut line2).unwrap();
        assert!(line1.starts_with("CLOCK "));
        assert_eq!(line2, "POWEROFF\n");

        drop(reader);
        t.join().unwrap();
    }

    #[test]
    fn clock_jump_detector_catches_sleep_wake_and_ntp_steps() {
        let base = 1_770_000_000_000_000_000i64;
        let threshold = 500_000_000i64; // 500 ms
        // Normal 1s tick with 2ms jitter -> no sync needed
        assert!(!clock_jump_exceeds_threshold(
            base,
            base + 1_002_000_000,
            1_000_000_000,
            threshold
        ));
        // Mac lid sleep for 2 hours (wall jumps +7200s, monotonic advances 1s) -> sync!
        assert!(clock_jump_exceeds_threshold(
            base,
            base + 7_201_000_000_000,
            1_000_000_000,
            threshold
        ));
        // NTP backward step of 5 seconds -> sync!
        assert!(clock_jump_exceeds_threshold(
            base,
            base - 4_000_000_000,
            1_000_000_000,
            threshold
        ));
    }
}
