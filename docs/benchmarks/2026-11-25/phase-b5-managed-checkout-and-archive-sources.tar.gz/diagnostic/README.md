# Mutable workspace FUSE attribution

This is a private diagnostic build of the frozen `candidate-v2` VMM. The patch changes only the optional `workspace-fuse-diag` Cargo feature and its mutable `workspace` dispatch instrumentation. The feature is absent from a regular release. A diagnostic release arms a single worker only when its environment contains `MICROPOD_VMM_FUSE_DIAG_TOKEN` with 16 lowercase hexadecimal digits.

## Capture an isolated worker

Set `D` to this directory. Choose a fresh token for each worker start and use the signed diagnostic binary as `MICROPOD_CI_HVF_BIN`. Use the established private worker, kernel, initrd and ARM64 Alpine 3.23 image. Run no other guest workspace jobs while the probe is active. For async readahead, unset `MICROPOD_VMM_FUSE_SYNC_READ`. For sync readahead, set it to `1` before starting the worker.

```bash
D=/private/tmp/mp-wci-AWfKIVpK/home/artifacts/diagnostic
TOKEN=$(python3 -c 'import secrets; print(secrets.token_hex(8))')
export MICROPOD_VMM_FUSE_DIAG_TOKEN="$TOKEN"
export MICROPOD_CI_HVF_BIN="$D/micropod-vmm-fuse-diag"
unset MICROPOD_VMM_FUSE_SYNC_READ
```

Pass these variables to the foreground worker and save its complete `serve.log`. After the guest and Docker endpoint are ready, run the following with `U` set to the worker's `unix://` Docker endpoint, `WORK` to the worker's configured host workspace, and `SERVE_LOG` to the full worker log.

```bash
python3 -B "$D/tools/probe.py" run \
  --host "$U" --workspace "$WORK" \
  --probe "$D/workspace-fuse-probe-linux-arm64" --token "$TOKEN" \
  > "$D/receipts/async-guest.json"

cp "$SERVE_LOG" "$D/receipts/async-serve.log"

python3 -B "$D/tools/probe.py" receipt \
  --guest "$D/receipts/async-guest.json" --host-log "$D/receipts/async-serve.log" \
  --vmm "$MICROPOD_CI_HVF_BIN" --read-mode async --token "$TOKEN" \
  > "$D/receipts/async-opcodes.json"
```

The capture creates and removes a uniquely labeled Docker container and a temporary fixture under `WORK`. It verifies all three walks and read/hash passes against the original 512-file fixture, its 20,772 bytes and both SHA-256 digests. Unique negative lookups outside the fixture delimit each operation phase. The guest timer excludes the lookups, which take one round trip each. The VMM reports counts, response counts, handler time and used-ring publication time per opcode. It omits paths, inode IDs and file handles. Guest phase elapsed time includes transport, interrupts, scheduling and guest/user code.

The three paired close samples run after the scans with baseline/delay order reversed in pair two. Each treatment pauses the first and only expected RELEASE by a requested 8 ms. The receipt records the actual host pause and requires one replying RELEASE in each arm and zero stray RELEASEs between arms before classifying a pair. The timed interval is just Go `File.Close`. A later drain gives queued releases time to reach the device. This can establish whether the caller waits for a reply. It does not measure whether an asynchronous RELEASE delays a subsequent operation in an otherwise busy queue.

The binary preserves the frozen candidate's shutdown behavior. The separate worker-teardown patch can be applied to a private copy if that fix is needed for the run. An instrumented read interval includes the instrumentation's collection cost, so use ordinary release measurements for performance comparisons.

## Rebuild and validate

```bash
cd "$D/source"
cargo +1.99.1 test --locked --offline --workspace --features vmm-virtio/workspace-fuse-diag
cargo +1.99.1 build --release --locked --offline --workspace --features vmm-virtio/workspace-fuse-diag
codesign --force --sign - --entitlements entitlements.plist \
  --identifier org.micropod.workspace-fuse-diagnostic target/release/micropod-vmm
codesign --verify --strict target/release/micropod-vmm
```

The guest program uses the same Go 1.27.0 as the original frozen workspace probe. The normal shared Go cache suffices.

```bash
cd "$D/tools"
GOOS=linux GOARCH=arm64 CGO_ENABLED=0 go build -trimpath -ldflags='-s -w' \
  -o ../workspace-fuse-probe-linux-arm64 main.go
go build -trimpath -o ../workspace-fuse-probe-darwin-arm64 main.go
python3 -B -m unittest -v test_probe.py
```
