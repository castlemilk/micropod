//! Private instrumentation for the mutable-workspace scan. Neither names nor
//! inode IDs are emitted. Phase markers are ordinary unsuccessful FUSE lookups.

use std::fmt::Write;
use std::io;
use std::thread;
use std::time::{Duration, Instant};

use super::{FUSE_LOOKUP, FUSE_RELEASE};
use crate::{DescBuf, GuestMemory};

const TOKEN_ENV: &str = "MICROPOD_VMM_FUSE_DIAG_TOKEN";
const LOG_PREFIX: &str = "[micropod-vmm] workspace-fuse-diag ";
const DELAY_MS: u64 = 8;
const PHASES: [&str; 12] = [
    "walk-1",
    "read-1",
    "walk-2",
    "read-2",
    "walk-3",
    "read-3",
    "close-base-1",
    "close-delay-1",
    "close-delay-2",
    "close-base-2",
    "close-base-3",
    "close-delay-3",
];
const OPCODES: usize = 64; // unknown values are counted in bucket zero

#[derive(Clone, Copy, Default)]
struct Totals {
    count: u64,
    reply_count: u64,
    handler_ns: u64,
    handler_max_ns: u64,
    used_ns: u64,
    used_max_ns: u64,
}

struct Phase {
    start: Instant,
    totals: [Totals; OPCODES],
    injected_ns: u64,
}

#[derive(Debug, PartialEq)]
pub(super) enum Marker {
    Start(usize),
    End(usize),
    Bad,
}

pub(super) enum Request {
    Marker(Marker),
    Request { opcode: u32, start: Instant },
    GapRelease,
}

pub(super) struct Handled {
    request: Request,
    handler_ns: u64,
    written: u32,
}

impl Request {
    pub(super) fn handled(self, written: u32) -> Handled {
        let handler_ns = match self {
            Request::Request { start, .. } => nanos_since(start),
            _ => 0,
        };
        Handled {
            request: self,
            handler_ns,
            written,
        }
    }
}

pub(super) struct WorkspaceFuseDiagnostic {
    token: String,
    marker_prefix: String,
    next: usize,
    phase: Option<Phase>,
    gap_releases: u64,
    failed: bool,
}

fn nanos_since(start: Instant) -> u64 {
    start.elapsed().as_nanos() as u64
}

fn valid_token(token: &str) -> bool {
    token.len() == 16
        && token
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
}

fn prefix<const N: usize>(desc: &[DescBuf], mem: &GuestMemory) -> Option<([u8; N], usize)> {
    let mut bytes = [0; N];
    let mut copied = 0;
    for d in desc.iter().filter(|d| !d.is_write) {
        let take = (d.len as usize).min(N - copied);
        let data = mem.read_slice(d.addr, take)?;
        bytes[copied..copied + take].copy_from_slice(data);
        copied += take;
        if copied == N {
            break;
        }
    }
    Some((bytes, copied))
}

impl WorkspaceFuseDiagnostic {
    fn new(token: String) -> Self {
        Self {
            marker_prefix: format!(".mpd-{token}-"),
            token,
            next: 0,
            phase: None,
            gap_releases: 0,
            failed: false,
        }
    }

    pub(super) fn configured(tag: &str, read_only: bool) -> io::Result<Option<Self>> {
        if tag != "workspace" || read_only {
            return Ok(None);
        }
        let Some(value) = std::env::var_os(TOKEN_ENV) else {
            return Ok(None);
        };
        let token = value.into_string().unwrap_or_default();
        if !valid_token(&token) {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                format!("{TOKEN_ENV} needs 16 lowercase hex digits"),
            ));
        }
        eprintln!(
            "{LOG_PREFIX}{{\"token\":\"{token}\",\"event\":\"ready\",\"release_delay_ms\":{DELAY_MS}}}"
        );
        Ok(Some(Self::new(token)))
    }

    fn marker(&self, input: &[u8]) -> Option<Marker> {
        let body = input.get(40..)?;
        let nul = body.iter().position(|b| *b == 0)?;
        let name = body[..nul].strip_prefix(self.marker_prefix.as_bytes())?;
        if let Some((phase, edge)) = name.split_last_chunk::<2>() {
            if let Some(i) = PHASES.iter().position(|p| p.as_bytes() == phase) {
                return Some(match edge {
                    b"-s" => Marker::Start(i),
                    b"-e" => Marker::End(i),
                    _ => Marker::Bad,
                });
            }
        }
        Some(Marker::Bad)
    }

    pub(super) fn before_chain(&mut self, desc: &[DescBuf], mem: &GuestMemory) -> Option<Request> {
        if self.failed || self.next == PHASES.len() {
            return None;
        }
        let (header, copied) = prefix::<8>(desc, mem)?;
        if copied != header.len() {
            return None;
        }
        let opcode = u32::from_le_bytes(header[4..8].try_into().unwrap());
        if opcode == FUSE_LOOKUP {
            let (input, len) = prefix::<80>(desc, mem)?;
            if let Some(marker) = self.marker(&input[..len]) {
                return Some(Request::Marker(marker));
            }
        }
        if let Some(phase) = &mut self.phase {
            if opcode == FUSE_RELEASE
                && phase.injected_ns == 0
                && PHASES[self.next].starts_with("close-delay-")
            {
                let start = Instant::now();
                thread::sleep(Duration::from_millis(DELAY_MS));
                phase.injected_ns = nanos_since(start);
            }
            return Some(Request::Request {
                opcode,
                start: Instant::now(),
            });
        }
        (opcode == FUSE_RELEASE && self.next > 0).then_some(Request::GapRelease)
    }

    pub(super) fn published(&mut self, handled: Handled) {
        match handled.request {
            Request::Marker(marker) => self.transition(marker, handled.written),
            Request::GapRelease => self.gap_releases += 1,
            Request::Request { opcode, start } => {
                let used_ns = nanos_since(start);
                let bucket = if (opcode as usize) < OPCODES {
                    opcode as usize
                } else {
                    0
                };
                let totals = &mut self.phase.as_mut().unwrap().totals[bucket];
                totals.count += 1;
                totals.reply_count += u64::from(handled.written >= 16);
                totals.handler_ns += handled.handler_ns;
                totals.handler_max_ns = totals.handler_max_ns.max(handled.handler_ns);
                totals.used_ns += used_ns;
                totals.used_max_ns = totals.used_max_ns.max(used_ns);
            }
        }
    }

    fn transition(&mut self, marker: Marker, written: u32) {
        let token = &self.token;
        if written == 16 {
            match marker {
                Marker::Start(i) if i == self.next && self.phase.is_none() => {
                    self.phase = Some(Phase {
                        start: Instant::now(),
                        totals: [Totals::default(); OPCODES],
                        injected_ns: 0,
                    });
                    return;
                }
                Marker::End(i) if i == self.next && self.phase.is_some() => {
                    let phase = self.phase.take().unwrap();
                    let span_ns = nanos_since(phase.start);
                    let gap_releases = std::mem::take(&mut self.gap_releases);
                    let mut line = format!(
                        "{LOG_PREFIX}{{\"token\":\"{token}\",\"event\":\"phase\",\"phase\":\"{}\",\"span_ns\":{span_ns},\"gap_releases_before\":{gap_releases},\"injected_ns\":{},\"ops\":[",
                        PHASES[i], phase.injected_ns
                    );
                    let mut separator = "";
                    for (op, t) in phase.totals.iter().enumerate().filter(|(_, t)| t.count > 0) {
                        write!(
                            &mut line,
                            "{separator}[{op},{},{},{},{},{},{}]",
                            t.count,
                            t.reply_count,
                            t.handler_ns,
                            t.handler_max_ns,
                            t.used_ns,
                            t.used_max_ns
                        )
                        .unwrap();
                        separator = ",";
                    }
                    line.push_str("]}");
                    eprintln!("{line}");
                    self.next += 1;
                    if self.next == PHASES.len() {
                        eprintln!("{LOG_PREFIX}{{\"token\":\"{token}\",\"event\":\"complete\"}}");
                    }
                    return;
                }
                _ => {}
            }
        }
        self.failed = true;
        eprintln!(
            "{LOG_PREFIX}{{\"token\":\"{token}\",\"event\":\"protocol-error\",\"expected_phase_index\":{},\"marker_reply_bytes\":{written}}}",
            self.next
        );
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fragmented_lookup_marker_is_scoped_and_ends_before_the_prefix_limit() {
        let trace = WorkspaceFuseDiagnostic::new("0123456789abcdef".to_owned());
        let mut packet = [0u8; 96];
        packet[4..8].copy_from_slice(&FUSE_LOOKUP.to_le_bytes());
        let name = b".mpd-0123456789abcdef-close-delay-2-e\0";
        packet[40..40 + name.len()].copy_from_slice(name);
        let mem = unsafe { GuestMemory::new(packet.as_mut_ptr(), 0x100, packet.len()) };
        let desc = [
            DescBuf {
                addr: 0x100,
                len: 5,
                is_write: false,
            },
            DescBuf {
                addr: 0x150,
                len: 16,
                is_write: true,
            },
            DescBuf {
                addr: 0x105,
                len: 73,
                is_write: false,
            },
        ];
        let (bytes, len) = prefix::<80>(&desc, &mem).unwrap();
        assert_eq!(trace.marker(&bytes[..len]), Some(Marker::End(8)));
        assert!(
            WorkspaceFuseDiagnostic::new("ffffffffffffffff".to_owned())
                .marker(&bytes[..len])
                .is_none()
        );
        assert!(trace.marker(&bytes[..len - 1]).is_none());
    }

    #[test]
    fn marker_sequence_counts_replies_and_rejects_overlap() {
        let mut trace = WorkspaceFuseDiagnostic::new("0123456789abcdef".to_owned());
        trace.transition(Marker::Start(0), 16);
        trace.published(
            Request::Request {
                opcode: FUSE_RELEASE,
                start: Instant::now(),
            }
            .handled(16),
        );
        let t = trace.phase.as_ref().unwrap().totals[FUSE_RELEASE as usize];
        assert_eq!((t.count, t.reply_count), (1, 1));
        trace.transition(Marker::End(0), 16);
        assert_eq!(trace.next, 1);
        trace.transition(Marker::Start(1), 16);
        trace.transition(Marker::Start(1), 16);
        assert!(trace.failed);
    }
}
