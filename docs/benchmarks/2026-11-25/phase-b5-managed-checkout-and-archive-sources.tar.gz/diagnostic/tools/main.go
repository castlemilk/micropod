// Guest workspace scan copied from scripts/workspacebench/main.go with phase
// markers outside the walk and read timers and a separate close-only probe.
package main

import (
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"regexp"
	"time"
)

func phaseMarker(parent, token, phase, edge string) error {
	_, err := os.Stat(filepath.Join(parent, ".mpd-"+token+"-"+phase+"-"+edge))
	if !errors.Is(err, os.ErrNotExist) {
		return fmt.Errorf("marker %s/%s should be absent: %v", phase, edge, err)
	}
	return nil
}

type scanPass struct {
	Pass       int     `json:"pass"`
	PauseMS    int64   `json:"scheduled_pause_ms"`
	Files      int     `json:"files"`
	Bytes      int64   `json:"bytes"`
	ReadBytes  int64   `json:"read_bytes"`
	WalkMS     float64 `json:"stat_ms"`
	ReadMS     float64 `json:"read_ms"`
	WalkNS     int64   `json:"walk_ns"`
	ReadNS     int64   `json:"read_ns"`
	Digest     string  `json:"sha256"`
	PathDigest string  `json:"path_sha256"`
}

func scan(dir, parent, token string) ([]scanPass, error) {
	results := make([]scanPass, 0, 3)
	for i, delay := range []time.Duration{0, 0, 50 * time.Millisecond} {
		time.Sleep(delay)
		result := scanPass{Pass: i + 1, PauseMS: delay.Milliseconds()}
		walkPhase := fmt.Sprintf("walk-%d", i+1)
		readPhase := fmt.Sprintf("read-%d", i+1)
		var files []string
		if err := phaseMarker(parent, token, walkPhase, "s"); err != nil {
			return nil, err
		}
		start := time.Now()
		err := filepath.WalkDir(dir, func(path string, entry fs.DirEntry, err error) error {
			if err != nil || entry.IsDir() {
				return err
			}
			info, err := entry.Info()
			if err != nil {
				return err
			}
			if !info.Mode().IsRegular() {
				return fmt.Errorf("workspace entry is not regular")
			}
			files = append(files, path)
			result.Bytes += info.Size()
			return nil
		})
		elapsed := time.Since(start)
		if err != nil {
			return nil, err
		}
		result.WalkMS = float64(elapsed.Microseconds()) / 1000
		result.WalkNS = elapsed.Nanoseconds()
		if err := phaseMarker(parent, token, walkPhase, "e"); err != nil {
			return nil, err
		}
		result.Files = len(files)
		if err := phaseMarker(parent, token, readPhase, "s"); err != nil {
			return nil, err
		}
		start = time.Now()
		digest := sha256.New()
		for _, path := range files {
			data, err := os.ReadFile(path)
			if err != nil {
				return nil, err
			}
			result.ReadBytes += int64(len(data))
			digest.Write(data)
		}
		elapsed = time.Since(start)
		result.ReadMS = float64(elapsed.Microseconds()) / 1000
		result.ReadNS = elapsed.Nanoseconds()
		if err := phaseMarker(parent, token, readPhase, "e"); err != nil {
			return nil, err
		}
		result.Digest = fmt.Sprintf("%x", digest.Sum(nil))
		paths := sha256.New()
		for _, path := range files {
			rel, err := filepath.Rel(dir, path)
			if err != nil {
				return nil, err
			}
			paths.Write([]byte(filepath.ToSlash(rel)))
			paths.Write([]byte{0})
		}
		result.PathDigest = fmt.Sprintf("%x", paths.Sum(nil))
		results = append(results, result)
	}
	return results, nil
}

type closeSample struct {
	Pair    int    `json:"pair"`
	Phase   string `json:"phase"`
	CloseNS int64  `json:"guest_close_ns"`
}

func measureClose(dir, parent, token, phase string, i int) (int64, error) {
	f, err := os.Open(filepath.Join(dir, "pkg000", fmt.Sprintf("src%04d.go", i)))
	if err != nil {
		return 0, err
	}
	data, err := io.ReadAll(f)
	if err != nil || string(data) != fmt.Sprintf("package p\nfunc F%d() int { return %d }\n", i, i) {
		f.Close()
		return 0, fmt.Errorf("close sample %d opened different source or could not read it", i)
	}
	if err := phaseMarker(parent, token, phase, "s"); err != nil {
		f.Close()
		return 0, err
	}
	start := time.Now()
	err = f.Close()
	elapsed := time.Since(start).Nanoseconds()
	if err != nil {
		return 0, err
	}
	// Give a release dispatched after close returned time to enter the queue.
	// This drain belongs to the host scope only, outside guest CloseNS.
	time.Sleep(20 * time.Millisecond)
	return elapsed, phaseMarker(parent, token, phase, "e")
}

func run(dir, token string) error {
	parent := filepath.Dir(dir)
	results, err := scan(dir, parent, token)
	if err != nil {
		return err
	}
	time.Sleep(50 * time.Millisecond)
	closes := make([]closeSample, 0, 6)
	for i, order := range [][2]string{{"base", "delay"}, {"delay", "base"}, {"base", "delay"}} {
		for _, arm := range order {
			phase := fmt.Sprintf("close-%s-%d", arm, i+1)
			elapsed, err := measureClose(dir, parent, token, phase, len(closes))
			if err != nil {
				return err
			}
			closes = append(closes, closeSample{i + 1, phase, elapsed})
		}
	}
	return json.NewEncoder(os.Stdout).Encode(struct {
		Token  string        `json:"token"`
		Scans  []scanPass    `json:"scans"`
		Closes []closeSample `json:"closes"`
	}{token, results, closes})
}

func main() {
	if len(os.Args) != 3 || !regexp.MustCompile(`^[0-9a-f]{16}$`).MatchString(os.Args[2]) {
		fmt.Fprintln(os.Stderr, "usage: probe TREE TOKEN, with 16 lowercase hex digits")
		os.Exit(2)
	}
	if err := run(filepath.Clean(os.Args[1]), os.Args[2]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
