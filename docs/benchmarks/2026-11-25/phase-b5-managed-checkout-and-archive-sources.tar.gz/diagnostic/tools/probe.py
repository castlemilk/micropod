#!/usr/bin/env python3
"""Drive and reconcile a private mutable-workspace FUSE opcode probe."""

import argparse
import hashlib
import json
import re
import signal
import tempfile
from pathlib import Path
from uuid import uuid4

from bench_workspace_edits import guest_probe, interrupted


PREFIX = "[micropod-vmm] workspace-fuse-diag "
TOKEN = re.compile(r"[0-9a-f]{16}")
SCANS = [(1, 0), (2, 0), (3, 50)]
WALK_READ = tuple(f"{kind}-{i}" for i, _ in SCANS for kind in ("walk", "read"))
CLOSES = ("close-base-1", "close-delay-1", "close-delay-2",
          "close-base-2", "close-base-3", "close-delay-3")
OPCODE_NAMES = {
    0: "OTHER", 1: "LOOKUP", 2: "FORGET", 3: "GETATTR", 4: "SETATTR", 5: "READLINK",
    6: "SYMLINK", 8: "MKNOD", 9: "MKDIR", 10: "UNLINK", 11: "RMDIR", 12: "RENAME",
    13: "LINK", 14: "OPEN", 15: "READ", 16: "WRITE", 17: "STATFS", 18: "RELEASE",
    20: "FSYNC", 21: "SETXATTR", 22: "GETXATTR", 23: "LISTXATTR", 24: "REMOVEXATTR",
    25: "FLUSH", 26: "INIT", 27: "OPENDIR", 28: "READDIR", 29: "RELEASEDIR",
    30: "FSYNCDIR", 31: "GETLK", 32: "SETLK", 33: "SETLKW", 34: "ACCESS",
    35: "CREATE", 36: "INTERRUPT", 37: "BMAP", 38: "DESTROY", 39: "IOCTL",
    40: "POLL", 41: "NOTIFY_REPLY", 42: "BATCH_FORGET", 43: "FALLOCATE",
    44: "READDIRPLUS", 45: "RENAME2", 46: "LSEEK", 47: "COPY_FILE_RANGE",
    48: "SETUPMAPPING", 49: "REMOVEMAPPING", 50: "SYNCFS", 51: "TMPFILE", 52: "STATX",
}
CONTENT = "760cda3100af7b8d352897b31f3cce28cff7ac936856b69c2464fd1d0090f99c"
PATHS = "e64b63c69253b0a44b1ec5b497335b3236faf52fc25743c761718b3f110ca878"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()


def fixture(tree):
    for i in range(512):
        path = tree / f"pkg{i // 16:03}" / f"src{i:04}.go"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(f"package p\nfunc F{i}() int {{ return {i} }}\n".encode())


def verify_guest(guest, token):
    require(guest["token"] == token, "guest token differs from the worker token")
    scans = guest["scans"]
    require([(row["pass"], row["scheduled_pause_ms"]) for row in scans] == SCANS,
            "unexpected guest scan order or pause")
    for row in scans:
        require((row["files"], row["bytes"], row["read_bytes"], row["sha256"], row["path_sha256"])
                == (512, 20772, 20772, CONTENT, PATHS), "guest scan differs from the frozen fixture")
        require(all(type(row[key]) is int and row[key] > 0 for key in ("walk_ns", "read_ns")),
                "guest scan omitted an elapsed interval")
    closes = guest["closes"]
    require(tuple(row["phase"] for row in closes) == CLOSES, "unexpected guest close order")
    require(all(row["pair"] == int(row["phase"][-1]) and type(row["guest_close_ns"]) is int
                and row["guest_close_ns"] > 0 for row in closes), "guest close omitted an elapsed interval")


def read_host_log(log, token):
    events = []
    for line in log.splitlines():
        if line.startswith(PREFIX):
            event = json.loads(line[len(PREFIX):])
            if event.get("token") == token:
                events.append(event)
    require([event["event"] for event in events] == ["ready"] + ["phase"] * 12 + ["complete"],
            "VMM diagnostics missing phase boundaries or recorded a protocol error")
    require(tuple(event["phase"] for event in events[1:-1]) == WALK_READ + CLOSES,
            "VMM phase order differs from the guest phase order")
    delay_ms = events[0]["release_delay_ms"]
    require(delay_ms == 8, "unexpected VMM release injection")
    phases = {}
    for event in events[1:-1]:
        phase = event["phase"]
        summary = {key: event[key] for key in ("span_ns", "gap_releases_before", "injected_ns")}
        require(all(type(value) is int and value >= 0 for value in summary.values())
                and summary["span_ns"] > 0, f"invalid VMM duration or gap count in {phase}")
        require(phase.startswith("close-delay-") or summary["injected_ns"] == 0,
                f"VMM unexpectedly injected a delay during {phase}")
        ops = {}
        last = -1
        for row in event["ops"]:
            require(len(row) == 7 and all(type(value) is int and value >= 0 for value in row),
                    f"invalid opcode row in {phase}")
            op, count, replies, handler, handler_max, used, used_max = row
            require(last < op < 64 and 0 < count and 0 <= replies <= count
                    and 0 <= handler_max <= handler <= used <= summary["span_ns"]
                    and handler_max <= used_max <= used, f"inconsistent VMM opcode totals in {phase}")
            ops[OPCODE_NAMES.get(op, f"OP_{op}")] = {
                "opcode": op, "count": count, "reply_count": replies,
                "host_handler_ns": handler, "host_handler_max_ns": handler_max,
                "host_to_used_ns": used, "host_to_used_max_ns": used_max,
            }
            last = op
        summary["ops"] = ops
        phases[phase] = summary
    return phases, delay_ms


def release_attribution(phases, closes, delay_ms):
    guest_ns = {row["phase"]: row["guest_close_ns"] for row in closes}
    pairs = []
    for i in range(1, 4):
        base, delayed = f"close-base-{i}", f"close-delay-{i}"
        before, after = phases[base], phases[delayed]
        release_ops = [phase["ops"].get("RELEASE", {}) for phase in (before, after)]
        injection_ns = after["injected_ns"]
        delta_ns = guest_ns[delayed] - guest_ns[base]
        valid = (all(op.get("count") == op.get("reply_count") == 1 for op in release_ops)
                 and all(phase["gap_releases_before"] == 0 for phase in (before, after))
                 and injection_ns >= delay_ms * 1_000_000)
        classification = "inconclusive"
        if valid and delta_ns * 4 >= injection_ns * 3:
            classification = "caller-waits-for-release"
        elif valid and guest_ns[delayed] * 4 < injection_ns:
            classification = "caller-returns-before-release"
        pairs.append({
            "pair": i, "base_guest_ns": guest_ns[base], "delayed_guest_ns": guest_ns[delayed],
            "injected_host_ns": injection_ns, "guest_delta_ns": delta_ns,
            "matched_single_release": valid, "classification": classification,
        })
    verdicts = set(row["classification"] for row in pairs)
    return {
        "classification": verdicts.pop() if len(verdicts) == 1 else "inconclusive",
        "pairs": pairs,
    }


def build_receipt(guest, log, token):
    verify_guest(guest, token)
    phases, delay_ms = read_host_log(log, token)
    for row in guest["scans"]:
        for kind in ("walk", "read"):
            phases[f"{kind}-{row['pass']}"]["guest_elapsed_ns"] = row[f"{kind}_ns"]
    for row in guest["closes"]:
        phases[row["phase"]]["guest_elapsed_ns"] = row["guest_close_ns"]
    return {
        "schema": 1, "token": token, "scope": "single mutable virtiofs workspace share",
        "synchronous_readahead_observed": "workspace FUSE_INIT uses synchronous readahead" in log,
        "timing": {
            "guest_elapsed_ns": "monotonic guest interval, excluding phase markers and close drain",
            "span_ns": "host monotonic interval between the two marker replies reaching the used ring",
            "host_handler_ns": "sum of guest descriptor handlers, excluding injected pause and used-ring publish",
            "host_to_used_ns": "sum from handler entry to used-ring publication, excluding injected pause",
            "gap_releases_before": "additional RELEASE requests between phases, outside opcode totals",
        },
        "scan_passes": guest["scans"], "phases": phases,
        "release_attribution": release_attribution(phases, guest["closes"], delay_ms),
    }


def run_guest(args):
    require(args.host.startswith("unix://"), "the probe requires a dedicated managed Unix socket")
    binary = args.probe.read_bytes()
    with tempfile.TemporaryDirectory(prefix="fuse-ops-", dir=args.workspace.resolve(strict=True)) as temp:
        work = Path(temp)
        fixture(work / "tree")
        program = work / "probe"
        program.write_bytes(binary)
        program.chmod(0o755)
        name = "mp-ws-op-" + uuid4().hex
        with guest_probe(["docker", "--host", args.host], name, work, "/bench/tree", args.token) as child:
            output, error = child.communicate(timeout=90)
            if child.returncode:
                raise RuntimeError(f"guest probe exited {child.returncode}: {error.decode(errors='replace').strip()}")
            receipt = json.loads(output)
            verify_guest(receipt, args.token)
    receipt["guest_binary_sha256"] = hashlib.sha256(binary).hexdigest()
    return receipt


def main():
    signal.signal(signal.SIGTERM, interrupted)
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    run = commands.add_parser("run")
    run.add_argument("--host", required=True)
    run.add_argument("--workspace", type=Path, required=True)
    run.add_argument("--probe", type=Path, required=True)
    receipt = commands.add_parser("receipt")
    receipt.add_argument("--guest", type=Path, required=True)
    receipt.add_argument("--host-log", type=Path, required=True)
    receipt.add_argument("--vmm", type=Path, required=True)
    receipt.add_argument("--read-mode", choices=("sync", "async"), required=True)
    for command in (run, receipt):
        command.add_argument("--token", required=True)
    args = parser.parse_args()
    if TOKEN.fullmatch(args.token) is None:
        parser.error("--token needs 16 lowercase hex digits")
    if args.command == "run":
        result = run_guest(args)
    else:
        guest = json.loads(args.guest.read_bytes())
        result = build_receipt(guest, args.host_log.read_text(errors="replace"), args.token)
        require(result["synchronous_readahead_observed"] == (args.read_mode == "sync"),
                "worker did not negotiate the requested readahead mode")
        result["guest_binary_sha256"] = guest["guest_binary_sha256"]
        result["vmm_binary_sha256"] = sha256(args.vmm)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
