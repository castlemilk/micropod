import json
import subprocess
import tempfile
import unittest
from pathlib import Path

import probe


TOKEN = "0123456789abcdef"


def host_log(release_ns=8_500_000, count=1):
    events = [{"event": "ready", "release_delay_ms": 8}]
    for phase in probe.WALK_READ + probe.CLOSES:
        op = (18, count, count, 10, 10, 11, 11) if phase.startswith("close-") else (15, 512, 512, 100, 1, 200, 2)
        events.append({
            "event": "phase", "phase": phase, "span_ns": 40_000_000,
            "gap_releases_before": 0, "ops": [op],
            "injected_ns": release_ns if phase.startswith("close-delay-") else 0,
        })
    events.append({"event": "complete"})
    startup = "[micropod-vmm] workspace FUSE_INIT uses synchronous readahead\n"
    return startup + "\n".join(probe.PREFIX + json.dumps({"token": TOKEN, **event}) for event in events)


class ReceiptTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with tempfile.TemporaryDirectory() as temp:
            tree = Path(temp) / "tree"
            probe.fixture(tree)
            native = Path(__file__).resolve().parents[1] / "workspace-fuse-probe-darwin-arm64"
            cls.guest = json.loads(subprocess.check_output([native, tree, TOKEN]))

    def classify(self, delayed_ns, count=1):
        guest = {**self.guest, "closes": [
            {**row, "guest_close_ns": delayed_ns if "delay" in row["phase"] else 50_000}
            for row in self.guest["closes"]
        ]}
        return probe.build_receipt(guest, host_log(count=count), TOKEN)

    def test_three_actual_scans_match_fixture_and_separate_host_attributions(self):
        receipt = self.classify(8_600_000)
        self.assertTrue(receipt["synchronous_readahead_observed"])
        self.assertEqual(receipt["phases"]["read-1"]["ops"]["READ"]["count"], 512)
        self.assertEqual(receipt["release_attribution"]["classification"], "caller-waits-for-release")
        self.assertEqual(receipt["release_attribution"]["pairs"][0]["guest_delta_ns"], 8_550_000)

    def test_asynchronous_or_contaminated_close_does_not_claim_waiting(self):
        self.assertEqual(self.classify(70_000)["release_attribution"]["classification"],
                         "caller-returns-before-release")
        self.assertEqual(self.classify(8_600_000, count=2)["release_attribution"]["classification"],
                         "inconclusive")

    def test_missing_or_out_of_order_boundary_and_corrupt_path_hash_fail(self):
        lines = host_log().splitlines()
        for changed in (lines[:-1], [*lines[:2], lines[3], lines[2], *lines[4:]]):
            with self.assertRaisesRegex(ValueError, "phase"):
                probe.build_receipt(self.guest, "\n".join(changed), TOKEN)
        scans = [{**p, "path_sha256": "incorrect"} for p in self.guest["scans"]]
        with self.assertRaisesRegex(ValueError, "fixture"):
            probe.build_receipt({**self.guest, "scans": scans}, host_log(), TOKEN)


if __name__ == "__main__":
    unittest.main()
