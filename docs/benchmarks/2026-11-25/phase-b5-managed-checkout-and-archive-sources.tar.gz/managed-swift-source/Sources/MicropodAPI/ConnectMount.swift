import Foundation
import MicropodCore
import MicropodRuntime
import SwiftProtobuf

/// Connect-protocol mount: `POST /api/micropod.v1.<Service>/<Method>`.
///
/// The daemon API is grouped into per-domain services (ContainerService,
/// ImageService, VolumeService, NetworkService, ComposeService,
/// SystemService) — the service segment is matched by the caller; method
/// names are unique across services so dispatch keys on the method alone.
/// The pre-split `micropod.v1.MicropodService` prefix is accepted as an
/// alias for backward compatibility with v0.8 SDK clients.
///
/// Makes the documented Connect surface real on the shipped server — unary
/// calls take a proto-JSON body and return proto-JSON; server-streaming
/// RPCs speak Connect envelope framing (`application/connect+json`).
/// Requests decode straight into the same `Micropod_V1_*` messages the core
/// services already vend, so the wire contract stays true to proto/micropod/v1.
extension APIHandlers {

    /// Route `/api/micropod.v1.<Service>/*`. Returns nil for methods that
    /// don't exist so the caller can fall through to 404.
    func connectRPC(method: String, body: Data, headers: [String: String]) async -> HTTPResponse? {
        // The liveness RPCs are where a CLI-started API notices the runtime
        // came up: they re-resolve the backend (rate-limited) before
        // answering, so `runtime_backend` flips to native on the first
        // Ping/GetSystem after the swap.
        let services =
            method == "Ping" || method == "GetSystem"
            ? await runtime.refreshIfNeeded() : await runtime.current
        do {
            switch method {
            case "GetSystem":
                if versionEnvironment.role == .connect, versionEnvironment.usesDedicatedRuntime() {
                    return unary(try await dedicatedSystem())
                }
                var snapshot = Micropod_V1_SystemSnapshot()
                var status = try await system.status()
                status.runtimeBackend = services.kind.rawValue
                snapshot.status = status
                // A stopped runtime is a status, not an error — and it has no
                // `df` to report (asking would fail the whole call).
                if status.status != "stopped" {
                    snapshot.diskUsage = try await system.diskUsage()
                }
                let health = services.health
                let manifest = await versionManifest(
                    apple: AppleObservation(
                        reported: status.apiServerVersion, commit: health?.apiServerCommit ?? "",
                        state: status.status == "running" ? .running : .stopped,
                        appRoot: (health?.appRoot ?? (status.appRoot.isEmpty ? nil : status.appRoot)).map {
                            URL(fileURLWithPath: $0)
                        },
                        installRoot: health?.installRoot ?? (status.installRoot.isEmpty ? nil : status.installRoot)),
                    digests: true)
                manifest.apply(to: &snapshot)
                return unary(snapshot)

            case "Ping":
                if versionEnvironment.role == .connect, versionEnvironment.usesDedicatedRuntime() {
                    return unary(try await dedicatedPing(services))
                }
                return unary(await ping(services))

            case "GetUpdateState":
                return unary(await currentUpdateState())

            case "ListRuntimes":
                return unary(try await runtimes(services))

            case "SetDefaultRuntime":
                let req = try decode(Micropod_V1_SetDefaultRuntimeRequest.self, body)
                try required(req.name, "name")
                return unary(try await setDefaultRuntime(req.name, services))

            case "UpdateRuntime":
                let req = try decode(Micropod_V1_UpdateRuntimeRequest.self, body)
                try required(req.name, "name")
                return unary(
                    try await updateRuntime(
                        req.name, req.hasEnabled ? req.enabled : nil, req.hasEndpoint ? req.endpoint : nil,
                        services))

            case "ListContainers":
                var resp = Micropod_V1_ListContainersResponse()
                resp.containers = try await listedContainersWithExitCodes(in: services)
                return unary(resp)

            case "GetContainer":
                let req = try decode(Micropod_V1_ContainerRef.self, body)
                try check(req)
                return unary(try await lookupContainer(req.id, in: services))

            case "WaitContainer":
                let req = try decode(Micropod_V1_WaitContainerRequest.self, body)
                try check(req)
                // Unknown ids fail fast — never a silent `exited: true`, and
                // never a wait against a container that does not exist.
                if await pendingNativeState(req.id, in: services) == nil {
                    _ = try await lookupContainer(req.id, in: services)
                }
                let seconds = req.timeoutSeconds == 0 ? 30 : min(req.timeoutSeconds, 300)
                return unary(try await waitContainer(id: req.id, timeout: .seconds(Int(seconds)), in: services))

            case "RunContainer":
                let req = try decode(Micropod_V1_RunContainerRequest.self, body)
                try check(req)
                let id = try await services.containers.run(try runRequest(from: req))
                return unary(Micropod_V1_ContainerRef.with { $0.id = id })

            case "CreateContainer":
                let req = try decode(Micropod_V1_RunContainerRequest.self, body)
                try check(req)
                let id = try await services.containers.create(try runRequest(from: req))
                return unary(Micropod_V1_ContainerRef.with { $0.id = id })

            case "StartContainer":
                let req = try decode(Micropod_V1_ContainerRef.self, body)
                try check(req)
                try await services.containers.start(req.id)
                return unary(Micropod_V1_Empty())

            case "StopContainer":
                let req = try decode(Micropod_V1_ContainerRef.self, body)
                try check(req)
                try await services.containers.stop(req.id)
                return unary(Micropod_V1_Empty())

            case "RestartContainer":
                let req = try decode(Micropod_V1_ContainerRef.self, body)
                try check(req)
                try await services.containers.restart(req.id)
                return unary(Micropod_V1_Empty())

            case "KillContainer":
                let req = try decode(Micropod_V1_ContainerRef.self, body)
                try check(req)
                try await services.containers.kill(req.id)
                return unary(Micropod_V1_Empty())

            case "DeleteContainer":
                let req = try decode(Micropod_V1_DeleteContainerRequest.self, body)
                try check(req)
                try await services.containers.delete(req.id, force: req.force)
                MetricsStore.shared?.remove(.container, req.id)
                return unary(Micropod_V1_Empty())

            case "StreamContainerLogs":
                let req = try decodeStreamRequest(Micropod_V1_StreamLogsRequest.self, body)
                try check(req)
                let events = services.logs.stream(
                    id: req.id,
                    tail: req.tail > 0 ? Int(req.tail) : nil,
                    boot: req.boot)
                // `skip_lines`: a client re-opening after a transport error
                // already holds the first N lines — drop them server-side.
                // Each line stays its own LogChunk envelope (clients count
                // envelopes as lines); a flood packs many envelopes into one
                // awaited socket write instead of one write per line.
                return streamEnvelope(dropping(req.skipLines, from: events), coalesce: true) { line in
                    Micropod_V1_LogChunk.with { $0.text = line.text }
                }

            case "ListImages":
                var resp = Micropod_V1_ListImagesResponse()
                resp.images = try await images.list()
                return unary(resp)

            case "PullImage":
                let req = try decodeStreamRequest(Micropod_V1_PullImageRequest.self, body)
                try check(req)
                // No platform pulls linux/<host arch>, not every platform in
                // the index (see ImageService.pull).
                let budget = try ImagePullBudget.api(headers: headers)
                let events = images.pullForAPI(
                    req.reference,
                    platform: req.hasPlatform ? req.platform : nil, budget: budget)
                return streamEnvelope(events) { event in
                    Micropod_V1_ProgressLine.with {
                        $0.line = event.line
                        if let stage = event.stage { $0.stage = Int32(stage) }
                        if let total = event.totalStages { $0.totalStages = Int32(total) }
                    }
                }

            case "DeleteImage":
                let req = try decode(Micropod_V1_DeleteImageRequest.self, body)
                try check(req)
                try await images.delete(req.reference, force: req.force)
                return unary(Micropod_V1_Empty())

            case "ListVolumes":
                var resp = Micropod_V1_ListVolumesResponse()
                resp.volumes = try await services.volumes.list()
                return unary(resp)

            case "CreateVolume":
                let req = try decode(Micropod_V1_CreateVolumeRequest.self, body)
                try check(req)
                try await services.volumes.create(
                    name: req.name,
                    size: req.hasSize ? req.size : nil,
                    labels: req.labels,
                    options: req.options)
                return unary(Micropod_V1_Empty())

            case "DeleteVolume":
                let req = try decode(Micropod_V1_DeleteVolumeRequest.self, body)
                try check(req)
                try await services.volumes.delete(req.name)
                return unary(Micropod_V1_Empty())

            case "CloneVolume":
                let req = try decode(Micropod_V1_CloneVolumeRequest.self, body)
                try check(req)
                return unary(
                    try await services.volumes.clone(
                        source: req.source,
                        name: req.name,
                        size: req.hasSize ? req.size : nil,
                        labels: req.labels))

            case "CommitVolumeClone":
                let req = try decode(Micropod_V1_CommitVolumeCloneRequest.self, body)
                try check(req)
                let allocated = try await services.volumes.commitClone(containerID: req.containerID, volume: req.volume)
                return unary(Micropod_V1_CommitVolumeCloneResponse.with { $0.allocatedBytes = allocated })

            case "ListNetworks":
                var resp = Micropod_V1_ListNetworksResponse()
                resp.networks = try await networks.list()
                return unary(resp)

            case "CreateNetwork":
                let req = try decode(Micropod_V1_CreateNetworkRequest.self, body)
                try check(req)
                try await networks.create(
                    name: req.name,
                    internal: req.`internal`,
                    subnet: req.hasSubnet ? req.subnet : nil,
                    subnetV6: req.hasSubnetV6 ? req.subnetV6 : nil,
                    driver: req.hasDriver ? req.driver : nil,
                    options: req.options,
                    labels: req.labels)
                return unary(Micropod_V1_Empty())

            case "DeleteNetwork":
                let req = try decode(Micropod_V1_DeleteNetworkRequest.self, body)
                try check(req)
                try await networks.delete(req.name)
                return unary(Micropod_V1_Empty())

            case "GetStats":
                let req = try decode(Micropod_V1_GetStatsRequest.self, body)
                var resp = Micropod_V1_GetStatsResponse()
                // Empty ids = every running container (the pre-`ids` shape).
                resp.snapshot = try await services.stats.snapshot(ids: req.ids)
                return unary(resp)

            case "Exec":
                let req = try decode(Micropod_V1_ExecRequest.self, body)
                try check(req)
                // `arguments` is a verbatim argv; `command` is the older
                // split-on-spaces field and only consulted when it is empty.
                let argv =
                    req.arguments.isEmpty
                    ? req.command.split(separator: " ").map(String.init)
                    : req.arguments
                let result = try await services.containers.execDetailed(
                    ContainerExecRequest(
                        containerID: req.id,
                        arguments: argv,
                        workdir: req.hasWorkdir ? req.workdir : nil,
                        env: req.env))
                return unary(
                    Micropod_V1_ExecResponse.with {
                        $0.output = result.output
                        $0.exitCode = result.exitCode
                        $0.error = result.error
                    })

            case "GetUsage":
                return unary(usageReportProto(try await usage(services).report()))

            case "GetVolumePolicy":
                return unary(volumePolicyProto(VolumePolicyStore.load()))

            case "SetVolumePolicy":
                let req = try decode(Micropod_V1_VolumePolicy.self, body)
                let policy = volumePolicy(from: req)
                try VolumePolicyStore.save(policy)
                return unary(volumePolicyProto(policy))

            case "CheckForUpdates":
                return unary(updateStatus(from: try await appControl.checkForUpdates()))

            case "GetUpdateStatus":
                return unary(updateStatus(from: try await appControl.updateStatus()))

            case "ApplyUpdate":
                return unary(updateStatus(from: try await appControl.applyUpdate()))

            case "ComposeUp":
                let req = try decodeStreamRequest(Micropod_V1_ComposeUpRequest.self, body)
                try check(req)
                let spec = try await compose.parse(url: URL(fileURLWithPath: req.path))
                let plan = try compose.plan(spec: spec, enabledProfiles: Set(req.profiles))
                let name = spec.name
                let events = AsyncThrowingStream<Micropod_V1_ComposeUpEvent, Error> { cont in
                    Task {
                        do {
                            for try await line in compose.up(plan: plan) {
                                cont.yield(.with { $0.line = line })
                            }
                            cont.yield(
                                .with {
                                    $0.name = name
                                    $0.done = true
                                })
                            cont.finish()
                        } catch {
                            cont.finish(throwing: error)
                        }
                    }
                }
                return streamEnvelope(events) { $0 }

            case "ComposeDown":
                let req = try decode(Micropod_V1_ComposeDownRequest.self, body)
                try check(req)
                try await compose.down(composeName: req.name)
                return unary(Micropod_V1_Empty())

            case "GetK8sStatus":
                let config = k8s.loadConfig() ?? .defaults
                let s = try await k8s.status(name: config.clusterName)
                return unary(k8sStatus(from: s))

            case "GetK8sConfig":
                return unary(k8sConfigProto(from: k8s.loadConfig() ?? .defaults))

            case "SetK8sConfig":
                let req = try decode(Micropod_V1_K8sConfig.self, body)
                try k8s.saveConfig(k8sConfig(from: req))
                return unary(req)

            case "K8sUp":
                guard k8s.isEnabled else {
                    return connectError(.unavailable, K8sError.disabled.description)
                }
                let req = try decodeStreamRequest(Micropod_V1_K8sUpRequest.self, body)
                var config = k8s.loadConfig() ?? .defaults
                if req.hasImage { config.image = req.image }
                if req.hasMemory { config.memory = req.memory }
                if req.hasCpus { config.cpus = req.cpus }
                if req.hasMetalLb { config.metalLB = req.metalLb }
                if req.hasIngress { config.ingress = req.ingress }
                if req.hasLbPool { config.lbPool = req.lbPool }
                if req.hasClusterName { config.clusterName = req.clusterName }
                let events = k8s.upEvents(config)
                return streamEnvelope(events) { event in
                    Micropod_V1_K8sUpEvent.with {
                        $0.line = event.line
                        if let status = event.status {
                            $0.done = true
                            $0.status = self.k8sStatus(from: status)
                        }
                    }
                }

            case "K8sDown":
                guard k8s.isEnabled else {
                    return connectError(.unavailable, K8sError.disabled.description)
                }
                try await k8s.down(k8s.loadConfig() ?? .defaults)
                return unary(Micropod_V1_Empty())

            case "GetKubeconfig":
                let path = k8s.kubeconfigURL.path
                guard let contents = try? String(contentsOfFile: path, encoding: .utf8) else {
                    return connectError(.notFound, "no kubeconfig — run K8sUp first")
                }
                return unary(
                    Micropod_V1_GetKubeconfigResponse.with {
                        $0.path = path
                        $0.contents = contents
                    })

            case "LoadK8sImage":
                guard k8s.isEnabled else {
                    return connectError(.unavailable, K8sError.disabled.description)
                }
                let req = try decodeStreamRequest(Micropod_V1_LoadK8sImageRequest.self, body)
                guard !req.ref.isEmpty || !req.archive.isEmpty else {
                    return connectError(.invalidArgument, "LoadK8sImage needs a ref or archive bytes")
                }
                let events = k8s.loadImageEvents(
                    ref: req.ref.isEmpty ? nil : req.ref,
                    archiveData: req.archive.isEmpty ? nil : req.archive,
                    name: req.hasClusterName ? req.clusterName : nil)
                return streamEnvelope(events) { event in
                    Micropod_V1_K8sLoadEvent.with {
                        $0.line = event.line
                        if let image = event.image {
                            $0.done = true
                            $0.ref = image.ref
                            $0.bytes = image.bytes
                        }
                    }
                }

            case "ListK8sImages":
                let req =
                    body.isEmpty
                    ? Micropod_V1_ListK8sImagesRequest()
                    : (try? decode(Micropod_V1_ListK8sImagesRequest.self, body))
                        ?? Micropod_V1_ListK8sImagesRequest()
                let refs = try await k8s.listImages(
                    name: req.hasClusterName ? req.clusterName : nil)
                return unary(Micropod_V1_ListK8sImagesResponse.with { $0.refs = refs })

            case "ListMachines":
                var resp = Micropod_V1_ListMachinesResponse()
                resp.machines = try await machines.list().map(machineProto)
                return unary(resp)

            case "GetMachineStats":
                let req =
                    body.isEmpty
                    ? Micropod_V1_GetMachineStatsRequest()
                    : try decode(Micropod_V1_GetMachineStatsRequest.self, body)
                return unary(try await machineStats.snapshot(id: req.id))

            case "StreamMachineLogs":
                let req = try decodeStreamRequest(Micropod_V1_StreamMachineLogsRequest.self, body)
                try check(req)
                let tail = req.tail > 0 ? Int(req.tail) : nil
                if req.follow {
                    return streamEnvelope(machines.streamLogs(req.id, tail: tail, boot: req.boot)) { line in
                        Micropod_V1_LogChunk.with { $0.text = line.text }
                    }
                }
                let lines = try await machines.logs(req.id, tail: tail, boot: req.boot)
                let events = AsyncThrowingStream<LogLine, Error> { continuation in
                    for line in lines { continuation.yield(line) }
                    continuation.finish()
                }
                return streamEnvelope(events) { line in
                    Micropod_V1_LogChunk.with { $0.text = line.text }
                }

            // MARK: SandboxService

            case "StartSandbox":
                let req = try decode(Micropod_V1_StartSandboxRequest.self, body)
                let id = try await services.containers.run(try sandboxRunRequest(from: req))
                return unary(Micropod_V1_ContainerRef.with { $0.id = id })

            case "StartProcess":
                let req = try decode(Micropod_V1_StartProcessRequest.self, body)
                try required(req.id, "id")
                guard !req.command.isEmpty else {
                    throw ConnectDecodeError(code: .invalidArgument, message: "command is required")
                }
                let (processID, pid) = try await sandboxEngine.startProcess(
                    req.id, command: req.command, cwd: req.cwd, env: req.env, stdin: req.stdin)
                return unary(
                    Micropod_V1_ProcessRef.with {
                        $0.id = req.id
                        $0.processID = processID
                        $0.pid = pid
                    })

            case "StreamProcess":
                let req = try decodeStreamRequest(Micropod_V1_ProcessRef.self, body)
                try required(req.id, "id")
                try required(req.processID, "process_id")
                let events = try sandboxEngine.streamProcess(req.id, processID: req.processID)
                return streamEnvelope(events, coalesce: true, map: Self.processEvent)

            case "WriteProcessStdin":
                let req = try decode(Micropod_V1_WriteProcessStdinRequest.self, body)
                try required(req.id, "id")
                try required(req.processID, "process_id")
                try sandboxEngine.writeStdin(req.id, processID: req.processID, data: req.data, close: req.close)
                return unary(Micropod_V1_Empty())

            case "SignalProcess":
                let req = try decode(Micropod_V1_SignalProcessRequest.self, body)
                try required(req.id, "id")
                try required(req.processID, "process_id")
                try await sandboxEngine.signalProcess(req.id, processID: req.processID, signal: req.signal)
                return unary(Micropod_V1_Empty())

            case "ReadFile":
                let req = try decode(Micropod_V1_PathRequest.self, body)
                try requiredPath(req.id, req.path)
                let data = try await sandboxEngine.readFile(req.id, path: req.path)
                return unary(Micropod_V1_FileContent.with { $0.data = data })

            case "WriteFile":
                let req = try decode(Micropod_V1_WriteFileRequest.self, body)
                try requiredPath(req.id, req.path)
                try await sandboxEngine.writeFile(
                    req.id, path: req.path, data: req.data, append: req.append,
                    mode: req.hasMode ? req.mode : nil, createParents: req.createParents)
                return unary(Micropod_V1_Empty())

            case "ListDir":
                let req = try decode(Micropod_V1_PathRequest.self, body)
                try requiredPath(req.id, req.path)
                let entries = try await sandboxEngine.listDir(req.id, path: req.path)
                return unary(Micropod_V1_ListDirResponse.with { $0.entries = entries.map(Self.dirEntry) })

            case "StatPath":
                let req = try decode(Micropod_V1_PathRequest.self, body)
                try requiredPath(req.id, req.path)
                var stat = Self.fileStat(try await sandboxEngine.stat(req.id, path: req.path))
                stat.path = req.path
                return unary(stat)

            case "MakeDir":
                let req = try decode(Micropod_V1_MakeDirRequest.self, body)
                try requiredPath(req.id, req.path)
                try await sandboxEngine.makeDir(
                    req.id, path: req.path, recursive: req.hasRecursive ? req.recursive : true)
                return unary(Micropod_V1_Empty())

            case "RemovePath":
                let req = try decode(Micropod_V1_RemovePathRequest.self, body)
                try requiredPath(req.id, req.path)
                try await sandboxEngine.remove(req.id, path: req.path, recursive: req.recursive)
                return unary(Micropod_V1_Empty())

            case "RenamePath":
                let req = try decode(Micropod_V1_RenamePathRequest.self, body)
                try requiredPath(req.id, req.from)
                try required(req.to, "to")
                try await sandboxEngine.rename(req.id, from: req.from, to: req.to)
                return unary(Micropod_V1_Empty())

            case "CopyPath":
                let req = try decode(Micropod_V1_CopyPathRequest.self, body)
                try requiredPath(req.id, req.from)
                try required(req.to, "to")
                try await sandboxEngine.copy(req.id, from: req.from, to: req.to, recursive: req.recursive)
                return unary(Micropod_V1_Empty())

            case "ChmodPath":
                let req = try decode(Micropod_V1_ChmodPathRequest.self, body)
                try requiredPath(req.id, req.path)
                guard req.mode <= 0o7777 else {
                    throw ConnectDecodeError(code: .invalidArgument, message: "mode must be at most 0o7777")
                }
                try await sandboxEngine.chmod(req.id, path: req.path, mode: req.mode)
                return unary(Micropod_V1_Empty())

            case "WatchPath":
                let req = try decodeStreamRequest(Micropod_V1_WatchPathRequest.self, body)
                try requiredPath(req.id, req.path)
                let changes = try await sandboxEngine.watch(
                    req.id, path: req.path, recursive: req.hasRecursive ? req.recursive : true)
                return streamEnvelope(changes) { change in
                    Micropod_V1_WatchEvent.with {
                        $0.event = change.event
                        $0.path = change.path
                    }
                }

            case "CheckpointSandbox":
                let req = try decode(Micropod_V1_CheckpointSandboxRequest.self, body)
                try required(req.id, "id")
                try checkpointName(req.name)
                try await sandboxEngine.checkpoint(req.id, name: req.name)
                return unary(Micropod_V1_Empty())

            case "ListCheckpoints":
                return unary(Self.checkpoints())

            case "GetMetricsHistory":
                let req = try decode(Micropod_V1_GetMetricsHistoryRequest.self, body)
                guard let kind = MetricsStore.Kind(rawValue: req.kind.isEmpty ? "system" : req.kind) else {
                    throw ConnectDecodeError(
                        code: .invalidArgument, message: "kind must be system, container or machine")
                }
                if kind != .system { try required(req.id, "id") }
                guard let metricsStore = MetricsStore.shared else {
                    throw ConnectDecodeError(code: .unavailable, message: "the metrics store can't be opened")
                }
                let range = TimeInterval(req.rangeSeconds == 0 ? 3600 : min(req.rangeSeconds, 30 * 86400))
                let history = metricsStore.history(kind, kind == .system ? "all" : req.id, range: range)
                let formatter = ISO8601DateFormatter()
                return unary(
                    Micropod_V1_MetricsHistory.with { out in
                        out.resolutionSeconds = UInt32(history.resolution)
                        out.points = history.points.map { point in
                            .with {
                                $0.timestamp = formatter.string(from: point.timestamp)
                                $0.cpuPercent = point.average.cpuPercent
                                $0.cpuPercentMax = point.peak.cpuPercent
                                $0.memoryUsedBytes = point.average.memoryUsedBytes
                                $0.memoryUsedBytesMax = point.peak.memoryUsedBytes
                                $0.memoryLimitBytes = point.average.memoryLimitBytes
                                $0.networkRxBytesPerSecond = point.average.networkRxRate
                                $0.networkTxBytesPerSecond = point.average.networkTxRate
                                $0.blockReadBytesPerSecond = point.average.blockReadRate
                                $0.blockWriteBytesPerSecond = point.average.blockWriteRate
                            }
                        }
                    })

            case "UpdateSandboxSecret":
                let req = try decode(Micropod_V1_UpdateSandboxSecretRequest.self, body)
                try required(req.id, "id")
                try required(req.name, "name")
                try required(req.value, "value")
                try await sandboxEngine.updateSecret(
                    req.id, name: req.name, value: req.value,
                    expiresAt: try expiry(req.expiresAt, field: "expires_at"))
                return unary(Micropod_V1_Empty())

            case "DeleteCheckpoint":
                let req = try decode(Micropod_V1_CheckpointRef.self, body)
                try checkpointName(req.name)
                guard SandboxVM.listCheckpoints().contains(where: { $0.name == req.name }) else {
                    throw ConnectDecodeError(code: .notFound, message: "no checkpoint '\(req.name)'")
                }
                try SandboxVM.deleteCheckpoint(req.name)
                return unary(Micropod_V1_Empty())

            default:
                return nil
            }
        } catch is ImagePullBudget.InvalidHeaders {
            return connectError(.invalidArgument, "Invalid image pull budget headers")
        } catch let error as ConnectDecodeError {
            return connectError(error.code, error.message)
        } catch let error as AppControlError {
            switch error {
            case .callFailed:
                // e.g. ApplyUpdate before a download is staged.
                return connectError(.failedPrecondition, error.localizedDescription)
            default:
                return connectError(.unavailable, error.localizedDescription)
            }
        } catch {
            // Structured MicropodError cases, XPC transport failures and
            // upstream "code: detail" strings all classify through the shared
            // table (MicropodCore.ConnectCodeMapping) — tested in isolation.
            scheduleRecovery(after: error)
            return connectError(code(for: error), error.localizedDescription)
        }
    }

    /// Millisecond liveness for detection and health ticks — never `df`, and
    /// never an error: an unreachable runtime is `status: "stopped"`.
    ///
    /// Native backend: XPC `ping` with a 2 s ceiling (the apiserver answers in
    /// milliseconds when up). CLI backend: `container system status`, which
    /// `SystemService` already reports as a status when the daemon is down.
    private func ping(_ services: RuntimeServices) async -> Micropod_V1_PingResponse {
        var response = Micropod_V1_PingResponse()
        if versionEnvironment.runtimeAdmission().isClosed {
            response.status = "maintenance"
            response.runtimeBackend = services.kind.rawValue
            let manifest = await versionManifest(
                apple: AppleObservation(
                    reported: services.health?.apiServerVersion ?? "", commit: services.health?.apiServerCommit ?? "",
                    state: .unknown, appRoot: services.health?.appRoot.map { URL(fileURLWithPath: $0) },
                    detail: "Runtime maintenance has closed workload admission"),
                digests: false)
            manifest.apply(to: &response)
            return response
        }

        response.runtimeBackend = services.kind.rawValue
        response.features = APIFeatures.supported
        // Only the native backend can read an init image's labels, which
        // the init image guard needs (the CLI backend drops an override).
        if services.kind == .native {
            response.features.append(InitImageSelection.feature)
        }
        if ProcessInfo.processInfo.environment["MICROPOD_ISOLATED_RUNTIME"] == "1" {
            response.features.append(RuntimeCoordinationEnrollment.dataCapability)
        }
        response.defaultRuntime = EngineRegistry.shared.defaultName
        // Only the native backend sends the apiserver requests it counts;
        // the CLI backend's `container` children are invisible to it.
        if services.kind == .native {
            response.containerOperations = Self.containerOperations(ContainerOperationQueue.shared.snapshot())
        }
        var apple = AppleObservation(reported: "", state: .stopped)
        if let api = services.api {
            let health = try? await api.ping(timeout: .seconds(2))
            if let health {
                response.status = "running"
                response.apiServerVersion = health.apiServerVersion
            } else {
                response.status = "stopped"
                response.apiServerVersion = services.health?.apiServerVersion ?? ""
            }
            let known = health ?? services.health
            apple = AppleObservation(
                reported: response.apiServerVersion, commit: known?.apiServerCommit ?? "",
                state: health == nil ? .stopped : .running, appRoot: known?.appRoot.map { URL(fileURLWithPath: $0) },
                installRoot: known?.installRoot)
            // Cached after the first call — no CLI spawn on the hot path.
            response.cliVersion = (try? await system.cliVersion()) ?? ""
        } else {
            do {
                let status = try await system.status()
                response.status = status.status
                response.apiServerVersion = status.apiServerVersion
                response.cliVersion = status.cliVersion
                apple = AppleObservation(
                    reported: status.apiServerVersion, state: status.status == "running" ? .running : .stopped,
                    appRoot: status.appRoot.isEmpty ? nil : URL(fileURLWithPath: status.appRoot),
                    installRoot: status.installRoot.isEmpty ? nil : status.installRoot)
            } catch {
                // A stopped runtime never gets here (it is a status); whatever
                // did — timeout, missing CLI — means the runtime is not answering.
                response.status = "stopped"
                response.cliVersion = (try? await system.cliVersion()) ?? ""
                apple.detail = "The runtime did not answer: \(error.localizedDescription)"
            }
        }
        await versionManifest(apple: apple, digests: false).apply(to: &response)
        return response
    }

    static func containerOperations(_ snapshot: ContainerOperationQueue.Snapshot)
        -> Micropod_V1_ContainerOperationQueue
    {
        var queue = Micropod_V1_ContainerOperationQueue()
        queue.depth = UInt32(clamping: snapshot.depth)
        queue.inFlight = UInt32(clamping: snapshot.inFlight)
        queue.abandoned = UInt32(clamping: snapshot.abandoned)
        queue.waiting = UInt32(clamping: snapshot.waiting)
        let age = snapshot.oldestAge.components
        queue.oldestAgeMs = UInt64(clamping: max(0, age.seconds * 1000 + age.attoseconds / 1_000_000_000_000_000))
        return queue
    }

    /// Ping in front of a dedicated runtime: its API reports the runtime and
    /// its own components; this account adds the app, its updater and the
    /// services it retains. While maintenance holds the runtime's admission
    /// gate, the answer is `maintenance`, as on a desktop runtime.
    private func dedicatedPing(_ services: RuntimeServices) async throws -> Micropod_V1_PingResponse {
        let upstream: Micropod_V1_PingResponse
        do {
            upstream = try await dedicatedSystemCall("Ping", as: Micropod_V1_PingResponse.self, timeout: .seconds(5))
        } catch {
            guard versionEnvironment.runtimeAdmission().isClosed else {
                throw ConnectDecodeError(
                    code: .unavailable,
                    message: "Managed runtime API unavailable; check runtime setup and maintenance: "
                        + error.localizedDescription)
            }
            var response = Micropod_V1_PingResponse()
            response.status = "maintenance"
            response.runtimeBackend = services.kind.rawValue
            await versionManifest(
                apple: AppleObservation(
                    reported: "", state: .unknown, detail: "Runtime maintenance has closed workload admission"),
                digests: false
            )
            .merging(dedicated: [], protocolVersion: MicropodProtocol.apiVersion, peerProtocol: nil, appleReported: "")
            .apply(to: &response)
            return response
        }
        var response = upstream
        await versionManifest(
            apple: AppleObservation(reported: upstream.apiServerVersion, state: .running), digests: false
        )
        .merging(
            dedicated: upstream.components, protocolVersion: upstream.protocolVersion,
            peerProtocol: upstream.hasPeerProtocol ? upstream.peerProtocol : nil,
            appleReported: upstream.apiServerVersion
        )
        .apply(to: &response)
        return response
    }

    /// GetSystem in front of a dedicated runtime (see dedicatedPing).
    private func dedicatedSystem() async throws -> Micropod_V1_SystemSnapshot {
        let upstream: Micropod_V1_SystemSnapshot
        do {
            upstream = try await dedicatedSystemCall(
                "GetSystem", as: Micropod_V1_SystemSnapshot.self, timeout: .seconds(60))
        } catch {
            throw ConnectDecodeError(
                code: .unavailable,
                message: "Managed runtime API unavailable; check runtime setup and maintenance: "
                    + error.localizedDescription)
        }
        var snapshot = upstream
        await versionManifest(
            apple: AppleObservation(reported: upstream.status.apiServerVersion, state: .running), digests: true
        )
        .merging(
            dedicated: upstream.components, protocolVersion: upstream.protocolVersion,
            peerProtocol: upstream.hasPeerProtocol ? upstream.peerProtocol : nil,
            appleReported: upstream.status.apiServerVersion
        )
        .apply(to: &snapshot)
        return snapshot
    }

    private func code(for error: Error) -> ConnectWireCode {
        ConnectWireCode(rawValue: ConnectCodeMapping.code(for: error)) ?? .internal
    }

    // MARK: - Container lookup / exit codes

    /// One container by id, or `not_found`. Goes through `list()` rather than
    /// `inspect` so absence is a plain "not in the list" instead of a
    /// backend-specific error text to classify; anything the list call
    /// throws (runtime down → `unavailable`) propagates untouched.
    private func lookupContainer(
        _ id: String, in services: RuntimeServices
    ) async throws -> Micropod_V1_Container {
        guard let container = try await listedContainersWithExitCodes(in: services).first(where: { $0.id == id }) else {
            throw ConnectDecodeError(code: .notFound, message: "container \(id) not found")
        }
        return container
    }

    private func listedContainersWithExitCodes(in services: RuntimeServices) async throws -> [Micropod_V1_Container] {
        for _ in 0..<3 {
            let revision = await ContainerLifecycleClaims.shared.revision()
            let list = try await services.containers.list()
            let enriched = await withExitCodes(list, from: services.exitCodes)
            if services.kind != .native { return enriched }
            if await ContainerLifecycleClaims.shared.revision() == revision { return enriched }
        }
        throw MicropodError.message("unavailable: container lifecycle changed during observation; retry")
    }

    /// The container as the runtime lists it, nil when it is not listed.
    /// Throws whatever the list call throws (runtime down → `unavailable`).
    private func listedContainer(
        _ id: String, in services: RuntimeServices
    ) async throws -> Micropod_V1_Container? {
        try await services.containers.list().first(where: { $0.id == id })
    }

    /// Folds registry exit codes into `Container.exit_code`. Only the native
    /// backend records them; on CLI (`exitCodes == nil`) the field stays
    /// empty rather than fabricating a value.
    func withExitCodes(
        _ list: [Micropod_V1_Container], from exitCodes: ExitCodeRegistry?
    ) async -> [Micropod_V1_Container] {
        guard let exitCodes else { return list }
        var out = list
        for index in out.indices {
            let id = out[index].id
            let snapshot = await exitCodes.snapshot(for: id)
            if await NativeContainerService.acceptsExitCode(id),
                await exitCodes.snapshot(for: id) == snapshot, let code = snapshot.entry?.exitCode
            {
                out[index].exitCode = String(code)
            }
        }
        return out
    }

    /// The state a native create/start this process still owns implies,
    /// nil when none is owned (or on another backend).
    private func pendingNativeState(_ id: String, in services: RuntimeServices) async -> String? {
        guard services.kind == .native else { return nil }
        switch await ContainerLifecycleClaims.shared.kind(of: id) {
        case .starting: return "starting"
        case .creating: return "created"
        default: return nil
        }
    }

    /// Waits for the container to be terminal or `timeout` to elapse — see
    /// ``ContainerExitWait``: a container the registry tracks wakes the
    /// request the moment its exit is recorded; any other is polled at 150 ms.
    /// A runtime that stops answering mid-wait throws (`unavailable`)
    /// instead of reporting a false exit.
    private func waitContainer(
        id: String, timeout: Duration, in services: RuntimeServices
    ) async throws -> Micropod_V1_WaitContainerResponse {
        let exitCodes = services.exitCodes
        var park: (@Sendable (String, Duration) async -> Bool)?
        if let router = services.containers as? RuntimeRouter {
            park = { id, timeout in await router.awaitStateChange(id, timeout: timeout) }
        }
        let outcome = try await ContainerExitWait.wait(
            id: id, timeout: timeout, exitCodes: exitCodes, park: park,
            observationRevision: {
                services.kind == .native ? await ContainerLifecycleClaims.shared.revision() : 0
            },
            acceptExitCode: { id in
                if services.kind != .native { return true }
                return await NativeContainerService.acceptsExitCode(id)
            },
            state: { id, exitKnown in
                let state = await services.containers.state(of: id)
                guard state == "unknown", !exitKnown else { return state }
                if let pending = await pendingNativeState(id, in: services) { return pending }
                // `state(of:)` answers `unknown` both for a container that is
                // gone and for a runtime that is not answering. The list tells
                // them apart: it throws when the runtime is down, and a
                // container it no longer lists has really vanished.
                return try await listedContainer(id, in: services)?.state ?? "unknown"
            })
        var known = outcome.known
        var exitCode = outcome.exitCode
        // The sandbox engine records its sessions' exit codes itself.
        if outcome.exited, !known, let code = await sandboxEngine.exitCode(id) {
            known = true
            exitCode = code
        }
        return .with {
            $0.exited = outcome.exited
            $0.known = known
            if let exitCode { $0.exitCode = exitCode }
            $0.state = outcome.state
        }
    }

    // MARK: - Wire helpers

    /// Mirrors the `buf.validate` constraints declared on the protos — the Go
    /// apiserver enforces them via its protovalidate interceptor, but this
    /// in-process mount bypasses that chain, so required/non-empty fields are
    /// checked here before dispatch.
    private func requiredPath(_ id: String, _ path: String) throws {
        try required(id, "id")
        try required(path, "path")
    }

    private func checkpointName(_ name: String) throws {
        guard name.range(of: #"^[A-Za-z0-9][A-Za-z0-9._-]*$"#, options: .regularExpression) != nil else {
            throw ConnectDecodeError(code: .invalidArgument, message: "invalid checkpoint name '\(name)'")
        }
    }

    private func required(_ value: String, _ field: String) throws {
        if value.isEmpty {
            throw ConnectDecodeError(
                code: .invalidArgument, message: "\(field): value is required")
        }
    }

    private func check(_ req: Micropod_V1_ContainerRef) throws {
        try required(req.id, "id")
    }

    private func check(_ req: Micropod_V1_RunContainerRequest) throws {
        try required(req.image, "image")
        if req.hasName { try safeComponent(req.name, "name") }
        for volume in VolumeAttachments.namedVolumes(in: req.volumes) { try safeVolumeName(volume, "volumes") }
        if req.capAdd.count > 64 || req.capDrop.count > 64 {
            throw ConnectDecodeError(
                code: .invalidArgument, message: "cap_add/cap_drop: at most 64 entries each")
        }
        if req.hasCpus && req.cpus <= 0 {
            throw ConnectDecodeError(
                code: .invalidArgument, message: "cpus: must be greater than 0")
        }
        if req.hasPlatform {
            let parts = req.platform.split(separator: "/", omittingEmptySubsequences: false)
            if parts.count < 2 || parts.count > 3 || parts.contains(where: \.isEmpty) {
                throw ConnectDecodeError(
                    code: .invalidArgument, message: "platform: must be os/arch[/variant]")
            }
        }
        for port in req.ports {
            if port.containerPort == 0 || port.containerPort > 65535 {
                throw ConnectDecodeError(
                    code: .invalidArgument,
                    message: "ports.containerPort: must be in 1...65535")
            }
            if port.hostPort > 65535 {
                throw ConnectDecodeError(
                    code: .invalidArgument,
                    message: "ports.hostPort: must be in 0...65535")
            }
        }
    }

    private func check(_ req: Micropod_V1_DeleteContainerRequest) throws {
        try required(req.id, "id")
    }

    private func check(_ req: Micropod_V1_WaitContainerRequest) throws {
        try required(req.id, "id")
        if req.timeoutSeconds < 0 {
            throw ConnectDecodeError(
                code: .invalidArgument, message: "timeoutSeconds: must be 0 or greater")
        }
    }

    private func check(_ req: Micropod_V1_StreamLogsRequest) throws {
        try required(req.id, "id")
        if req.tail < 0 {
            throw ConnectDecodeError(
                code: .invalidArgument, message: "tail: must be 0 or greater")
        }
        if req.skipLines < 0 {
            throw ConnectDecodeError(
                code: .invalidArgument, message: "skipLines: must be 0 or greater")
        }
    }

    private func check(_ req: Micropod_V1_StreamMachineLogsRequest) throws {
        try required(req.id, "id")
        if req.tail < 0 {
            throw ConnectDecodeError(
                code: .invalidArgument, message: "tail: must be 0 or greater")
        }
    }

    private func machineProto(_ machine: MachineEntry) -> Micropod_V1_Machine {
        Micropod_V1_Machine.with {
            $0.id = machine.name
            $0.state = machine.state ?? ""
            $0.ipAddress = machine.ip ?? ""
            $0.cpus = Int32(machine.cpus ?? 0)
            $0.memoryBytes = machine.memoryBytes ?? 0
            $0.diskBytes = machine.diskBytes ?? 0
            $0.createdAt = machine.created ?? ""
            $0.default = machine.defaultMachine ?? false
        }
    }

    private func check(_ req: Micropod_V1_PullImageRequest) throws {
        try required(req.reference, "reference")
    }

    private func check(_ req: Micropod_V1_DeleteImageRequest) throws {
        try required(req.reference, "reference")
    }

    private func check(_ req: Micropod_V1_CreateVolumeRequest) throws {
        try required(req.name, "name")
    }

    private func check(_ req: Micropod_V1_DeleteVolumeRequest) throws {
        try required(req.name, "name")
    }

    private func check(_ req: Micropod_V1_CloneVolumeRequest) throws {
        try required(req.source, "source")
        try required(req.name, "name")
        try safeVolumeName(req.source, "source")
        try safeVolumeName(req.name, "name")
        // Cloning a volume onto itself would create a duplicate listing (or
        // trip the runtime's own already-exists) and clonefile the image
        // over itself — never meaningful.
        guard req.source != req.name else {
            throw ConnectDecodeError(code: .invalidArgument, message: "name: must differ from source")
        }
    }

    private func check(_ req: Micropod_V1_CommitVolumeCloneRequest) throws {
        try required(req.containerID, "containerId")
        try required(req.volume, "volume")
        try safeComponent(req.containerID, "containerId")
        try safeVolumeName(req.volume, "volume")
    }

    /// Container ids and volume names are clone-path components
    /// (`<cloneRoot>/<id>/<volume>.img`) that reach the clone-dir lifecycle
    /// before the runtime validates them, so the runtime's grammars are
    /// enforced here, before dispatch (`VolumeClone.requireSafeComponent`
    /// and `requireSafeVolumeName` guard the paths themselves): the
    /// container-id grammar for ids, and for volume names the volume
    /// grammar, which has no 63-character cap and is bounded only by the
    /// filename limit.
    private func safeComponent(_ value: String, _ field: String) throws {
        guard VolumeClone.isSafeComponent(value) else {
            throw ConnectDecodeError(
                code: .invalidArgument, message: "\(field): '\(value)' must match \(VolumeClone.componentGrammar)")
        }
    }

    private func safeVolumeName(_ value: String, _ field: String) throws {
        guard VolumeClone.isSafeVolumeName(value) else {
            throw ConnectDecodeError(
                code: .invalidArgument, message: "\(field): '\(value)' must match \(VolumeClone.volumeNameGrammar)")
        }
    }

    private func check(_ req: Micropod_V1_CreateNetworkRequest) throws {
        try required(req.name, "name")
    }

    private func check(_ req: Micropod_V1_DeleteNetworkRequest) throws {
        try required(req.name, "name")
    }

    /// `command` lost its `required` constraint when `arguments` arrived:
    /// exactly one of them has to carry the argv.
    private func check(_ req: Micropod_V1_ExecRequest) throws {
        try required(req.id, "id")
        if req.command.isEmpty && req.arguments.isEmpty {
            throw ConnectDecodeError(
                code: .invalidArgument, message: "command: value is required when arguments is empty")
        }
    }

    private func check(_ req: Micropod_V1_ComposeUpRequest) throws {
        try required(req.path, "path")
    }

    private func check(_ req: Micropod_V1_ComposeDownRequest) throws {
        try required(req.name, "name")
    }

    private func decode<M: Message>(_ type: M.Type, _ body: Data) throws -> M {
        do {
            return try M(jsonUTF8Data: body.isEmpty ? Data("{}".utf8) : body)
        } catch {
            throw ConnectDecodeError(
                code: .invalidArgument,
                message: "invalid request body: \(error.localizedDescription)")
        }
    }

    /// Server-streaming requests arrive envelope-framed; the first (and
    /// only) frame carries the proto-JSON request.
    private func decodeStreamRequest<M: Message>(_ type: M.Type, _ body: Data) throws -> M {
        var payload = body
        if body.count >= 5 {
            let length =
                Int(body[body.startIndex + 1]) << 24 | Int(body[body.startIndex + 2]) << 16
                | Int(body[body.startIndex + 3]) << 8 | Int(body[body.startIndex + 4])
            if body.count >= 5 + length {
                payload = Data(body[(body.startIndex + 5)..<(body.startIndex + 5 + length)])
            }
        }
        return try decode(type, payload)
    }

    private func unary<M: Message>(_ message: M) -> HTTPResponse {
        let body = (try? message.jsonUTF8Data()) ?? Data("{}".utf8)
        return .data(200, "application/json", body)
    }

    /// Drops the first `count` events and forwards the rest (and the
    /// terminal error, if any) unchanged. `count <= 0` is the identity.
    private func dropping<E: Sendable>(
        _ count: Int64, from events: AsyncThrowingStream<E, Error>
    ) -> AsyncThrowingStream<E, Error> {
        guard count > 0 else { return events }
        return AsyncThrowingStream { continuation in
            let task = Task {
                var remaining = count
                do {
                    for try await event in events {
                        if remaining > 0 {
                            remaining -= 1
                            continue
                        }
                        continuation.yield(event)
                    }
                    continuation.finish()
                } catch {
                    continuation.finish(throwing: error)
                }
            }
            continuation.onTermination = { _ in task.cancel() }
        }
    }

    /// Wraps a throwing event stream into Connect envelopes: each message as
    /// a data frame, then an EndStream trailer. Errors surface in the
    /// trailer's `error` object per the Connect spec. With `coalesce`, whole
    /// envelopes are batched into writes of up to 64 KiB or 10 ms
    /// (`StreamFrameCoalescer`); the bytes on the wire are unchanged.
    private func streamEnvelope<E: Sendable, M: Message>(
        _ events: AsyncThrowingStream<E, Error>,
        coalesce: Bool = false,
        map: @escaping @Sendable (E) -> M
    ) -> HTTPResponse {
        let stream = AsyncStream<Data> { continuation in
            let task = Task {
                do {
                    for try await event in events {
                        let payload = (try? map(event).jsonUTF8Data()) ?? Data("{}".utf8)
                        continuation.yield(ConnectEnvelope.frame(payload, flags: 0))
                    }
                    continuation.yield(ConnectEnvelope.frame(Data("{}".utf8), flags: 0x02))
                } catch {
                    // Same table as unary errors: an unknown id is
                    // `not_found`, a dropped XPC channel is `unavailable`
                    // (and prompts a backend re-resolution).
                    scheduleRecovery(after: error)
                    let code = ConnectCodeMapping.code(for: error)
                    let wire =
                        #"{"error":{"code":"\#(code)","message":"\#(Self.escapeJSON(error.localizedDescription))"}}"#
                    continuation.yield(ConnectEnvelope.frame(Data(wire.utf8), flags: 0x02))
                }
                continuation.finish()
            }
            continuation.onTermination = { _ in task.cancel() }
        }
        return .stream(
            200, "application/connect+json", coalesce ? StreamFrameCoalescer.coalesce(stream) : stream)
    }

    private func connectError(_ code: ConnectWireCode, _ message: String) -> HTTPResponse {
        let body = #"{"code":"\#(code.rawValue)","message":"\#(Self.escapeJSON(message))"}"#
        return .data(code.httpStatus, "application/json", Data(body.utf8))
    }

    /// JSON string-literal escaping for the hand-built error bodies —
    /// `connectError` and the stream trailer. A refused client value, a CLI
    /// stderr line or a `requireDistinct` message reaches the body verbatim,
    /// so every control character U+0000–U+001F is escaped too (`\t`, `\n`,
    /// `\r`, `\b`, `\f` short forms, the rest as `\u00XX`): with one left
    /// bare the body is not JSON, and connect-go reads an unparseable 400 as
    /// `internal` — the client would see `internal` for precisely the inputs
    /// the guard refuses.
    private static func escapeJSON(_ text: String) -> String {
        var escaped = ""
        escaped.reserveCapacity(text.utf8.count)
        for scalar in text.unicodeScalars {
            switch scalar {
            case "\\": escaped += "\\\\"
            case "\"": escaped += "\\\""
            case "\n": escaped += "\\n"
            case "\r": escaped += "\\r"
            case "\t": escaped += "\\t"
            case "\u{08}": escaped += "\\b"
            case "\u{0C}": escaped += "\\f"
            case "\u{00}"..."\u{1F}": escaped += String(format: "\\u%04x", scalar.value)
            default: escaped.unicodeScalars.append(scalar)
            }
        }
        return escaped
    }

    // MARK: - Proto → service conversion

    private func runRequest(from proto: Micropod_V1_RunContainerRequest) throws -> ContainerRunRequest {
        var request = ContainerRunRequest(
            image: proto.image,
            name: proto.hasName ? proto.name : nil,
            // Connect unary calls can't carry an attached stdio session —
            // always run detached, matching the Go apiserver's behavior.
            detach: true,
            cpus: proto.hasCpus ? proto.cpus : nil,
            memory: proto.hasMemory ? proto.memory : nil,
            env: proto.env,
            publishedPorts: proto.ports.map {
                PortSpec(
                    hostPort: Int($0.hostPort),
                    containerPort: Int($0.containerPort),
                    transportProtocol: $0.protocol.isEmpty ? "tcp" : $0.protocol,
                    hostIP: $0.hostIp.isEmpty ? nil : $0.hostIp)
            },
            volumes: proto.volumes,
            labels: proto.labels.map { LabelSpec(key: $0.key, value: $0.value) },
            useInit: proto.init_p,
            user: proto.hasUser ? proto.user : nil,
            platform: proto.hasPlatform ? proto.platform : nil,
            workdir: proto.hasWorkdir ? proto.workdir : nil,
            entrypoint: proto.hasEntrypoint ? proto.entrypoint : nil,
            arguments: proto.arguments,
            noPull: proto.noPull,
            runtime: proto.hasRuntime ? proto.runtime : nil,
            sandbox: proto.hasSandbox ? try sandboxOptions(from: proto.sandbox, network: nil) : nil,
            initImage: proto.hasInitImage ? proto.initImage : nil)
        do {
            try request.applySecurityOptions(from: proto)
        } catch let error as LinuxCapabilities.InvalidName {
            throw ConnectDecodeError(code: .invalidArgument, message: "cap_add/cap_drop: \(error.description)")
        } catch let error as LinuxCapabilities.Conflict {
            throw ConnectDecodeError(code: .invalidArgument, message: error.description)
        }
        return request
    }

    private func k8sStatus(from s: K8sStatus) -> Micropod_V1_K8sStatus {
        Micropod_V1_K8sStatus.with {
            $0.enabled = k8s.isEnabled
            $0.exists = s.exists
            $0.running = s.running
            $0.address = s.address ?? ""
            $0.nodeReady = s.nodeReady
            $0.kubeconfigPath = s.kubeconfigPath
        }
    }

    private func k8sConfigProto(from c: K8sConfig) -> Micropod_V1_K8sConfig {
        Micropod_V1_K8sConfig.with {
            $0.enabled = c.enabled
            $0.image = c.image
            $0.memory = c.memory
            $0.cpus = c.cpus
            $0.metalLb = c.metalLB
            $0.ingress = c.ingress
            if let pool = c.lbPool { $0.lbPool = pool }
            $0.clusterName = c.clusterName
        }
    }

    private func k8sConfig(from p: Micropod_V1_K8sConfig) -> K8sConfig {
        var c = K8sConfig.defaults
        c.enabled = p.enabled
        if !p.image.isEmpty { c.image = p.image }
        if !p.memory.isEmpty { c.memory = p.memory }
        if p.cpus > 0 { c.cpus = p.cpus }
        c.metalLB = p.metalLb
        c.ingress = p.ingress
        if p.hasLbPool { c.lbPool = p.lbPool }
        if !p.clusterName.isEmpty { c.clusterName = p.clusterName }
        return c
    }

    private func usageReportProto(_ report: UsageService.Report) -> Micropod_V1_UsageReport {
        Micropod_V1_UsageReport.with { proto in
            proto.images = report.images.map { entry in
                Micropod_V1_UsageReport.ImageUsage.with {
                    $0.image = entry.image
                    $0.usedByContainerIds = entry.usedByContainerIDs
                    $0.inUse = entry.inUse
                }
            }
            proto.volumes = report.volumes.map { entry in
                Micropod_V1_UsageReport.VolumeUsage.with {
                    $0.volume = entry.volume
                    $0.usedByContainerIds = entry.usedByContainerIDs
                    $0.inUse = entry.inUse
                }
            }
            proto.reclaimableImageBytes = report.reclaimableImageBytes
            proto.reclaimableVolumeBytes = report.reclaimableVolumeBytes
            proto.stoppedContainerCount = Int32(report.stoppedContainerCount)
        }
    }

    private func volumePolicyProto(_ policy: VolumePolicy) -> Micropod_V1_VolumePolicy {
        Micropod_V1_VolumePolicy.with { proto in
            switch policy.cloneMode {
            case .labels: proto.cloneMode = .labels
            case .goldens: proto.cloneMode = .goldens
            case .all: proto.cloneMode = .all
            }
            proto.goldenVolumes = policy.goldenVolumes
            proto.jobsOnly = policy.jobsOnly
            if let sync = policy.sync {
                switch sync {
                case .full: proto.sync = .full
                case .fsync: proto.sync = .fsync
                case .nosync: proto.sync = .nosync
                }
            }
            switch policy.cache {
            case .on: proto.cache = .on
            case .off: proto.cache = .off
            case .auto: proto.cache = .auto
            }
        }
    }

    /// Proto → service policy. Unspecified enums fall back to the standard
    /// defaults (labels / no sync override / cache on), so a sparse body
    /// still produces a valid stored policy.
    private func volumePolicy(from proto: Micropod_V1_VolumePolicy) -> VolumePolicy {
        let cloneMode: VolumePolicy.CloneMode =
            switch proto.cloneMode {
            case .goldens: .goldens
            case .all: .all
            default: .labels
            }
        let sync: VolumePolicy.SyncMode? =
            switch proto.sync {
            case .full: .full
            case .fsync: .fsync
            case .nosync: .nosync
            default: nil
            }
        let cache: VolumePolicy.CacheMode =
            switch proto.cache {
            case .off: .off
            case .auto: .auto
            default: .on
            }
        return VolumePolicy(
            cloneMode: cloneMode,
            goldenVolumes: proto.goldenVolumes,
            jobsOnly: proto.jobsOnly,
            sync: sync,
            cache: cache)
    }

    /// App-control statusReport dictionary → typed UpdateStatus. Unknown
    /// keys are ignored so the app can extend the report without a
    /// coordinated daemon bump.
    func updateStatus(from report: [String: Any]) -> Micropod_V1_UpdateStatus {
        Micropod_V1_UpdateStatus.with { proto in
            switch report["state"] as? String {
            case "unavailable": proto.state = .unavailable
            case "idle": proto.state = .idle
            case "checking": proto.state = .checking
            case "upToDate": proto.state = .upToDate
            case "updateAvailable": proto.state = .updateAvailable
            case "readyToInstall": proto.state = .readyToInstall
            case "installing": proto.state = .installing
            case "error": proto.state = .error
            default: proto.state = .unspecified
            }
            proto.feedConfigured = (report["feedConfigured"] as? Bool) ?? false
            proto.currentVersion = (report["currentVersion"] as? String) ?? ""
            if let v = report["availableVersion"] as? String { proto.availableVersion = v }
            proto.downloaded = (report["downloaded"] as? Bool) ?? false
            if let v = report["downloadedVersion"] as? String { proto.downloadedVersion = v }
            proto.readyToInstall = (report["readyToInstall"] as? Bool) ?? false
            // The blocker has its own field (and shapes update_state); `error`
            // is the updater's own failure only.
            if let v = report["error"] as? String { proto.error = v }
            if let v = report["checkedAt"] as? String { proto.checkedAt = v }
            proto.updateState = UpdateStateResolver.desktop(report: report)
            if let v = report["restartBlockedReason"] as? String { proto.restartBlockedReason = v }
            if let v = report["restartGuard"] as? String { proto.restartGuard = v }
            if let v = report["channel"] as? String { proto.channel = v }
            if let v = report["workloadProtocol"] as? Int, v >= 0 { proto.workloadProtocol = UInt32(v) }
            proto.payloadCompatible = (report["payloadCompatible"] as? Bool) ?? false
            if let v = report["currentSourceRevision"] as? String { proto.currentSourceRevision = v }
            if let v = report["desktopAdmission"] as? String { proto.desktopAdmission = v }
            if let v = report["updateScope"] as? String { proto.updateScope = v }
            if let v = report["recoveryError"] as? String { proto.recoveryError = v }
            if let transaction = report["transaction"] as? [String: Any] {
                proto.transaction = updateTransaction(from: transaction)
            }
        }
    }

    /// The durable receipt as the app encodes it (UpdateContinuityReceipt).
    private func updateTransaction(from receipt: [String: Any]) -> Micropod_V1_UpdateTransaction {
        Micropod_V1_UpdateTransaction.with { proto in
            if let v = receipt["operation"] as? String { proto.operationID = v }
            if let v = receipt["phase"] as? String { proto.phase = v }
            if let v = receipt["sourceVersion"] as? String { proto.sourceVersion = v }
            if let v = receipt["targetVersion"] as? String { proto.targetVersion = v }
            if let v = receipt["targetSourceRevision"] as? String { proto.targetSourceRevision = v }
            if let v = receipt["detail"] as? String { proto.detail = v }
            if let v = UpdateStateResolver.timestamp(receipt["updatedAt"]) { proto.updatedAt = v }
        }
    }
}

/// Connect envelope framing — [flags:1][length:4 big-endian][payload].
enum ConnectEnvelope {
    static func frame(_ payload: Data, flags: UInt8) -> Data {
        var frame = Data()
        frame.append(flags)
        var length = UInt32(payload.count).bigEndian
        frame.append(Data(bytes: &length, count: 4))
        frame.append(payload)
        return frame
    }
}

/// Connect error codes + their unary HTTP status mapping (per the spec).
enum ConnectWireCode: String {
    case canceled, unknown
    case invalidArgument = "invalid_argument"
    case deadlineExceeded = "deadline_exceeded"
    case notFound = "not_found"
    case alreadyExists = "already_exists"
    case permissionDenied = "permission_denied"
    case resourceExhausted = "resource_exhausted"
    case failedPrecondition = "failed_precondition"
    case aborted
    case outOfRange = "out_of_range"
    case unimplemented
    case `internal`
    case unavailable
    case dataLoss = "data_loss"
    case unauthenticated

    var httpStatus: Int {
        switch self {
        case .canceled: return 499
        case .invalidArgument, .outOfRange: return 400
        case .deadlineExceeded: return 504
        case .notFound, .unimplemented: return 404
        case .alreadyExists, .aborted: return 409
        case .permissionDenied: return 403
        case .resourceExhausted: return 429
        case .failedPrecondition: return 412
        case .unauthenticated: return 401
        case .unavailable: return 503
        case .unknown, .internal, .dataLoss: return 500
        }
    }
}

struct ConnectDecodeError: Error {
    let code: ConnectWireCode
    let message: String
}
