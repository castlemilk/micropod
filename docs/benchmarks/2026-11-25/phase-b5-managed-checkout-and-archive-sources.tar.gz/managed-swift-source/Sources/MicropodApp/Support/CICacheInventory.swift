import Foundation
import MicropodCore
import Observation

/// Read-only observations. File allocation is deliberately not aggregated:
/// APFS goldens and attempt clones may share extents.
struct CICacheVolume: Identifiable, Equatable, Sendable {
    let id: String
    let project: String
    let owner: String
    let ecosystem: String
    let source: String
    let key: String
    let scope: String
    let trust: String
    let lineage: String
    let createdAt: Date?
    let capacityBytes: UInt64?
    let allocatedBytes: UInt64?
    let activeContainers: [String]?
    let containerReferences: [String]?

    var activityLabel: String {
        guard let activeContainers else { return "Active use unknown" }
        return activeContainers.isEmpty
            ? "No active reference observed" : "Active in \(activeContainers.count) container(s)"
    }
}

struct CICacheSelection: Equatable, Sendable {
    var project: String = ""
    var owner: String = ""

    func includes(_ volume: CICacheVolume) -> Bool {
        (project.isEmpty || project == volume.project) && (owner.isEmpty || owner == volume.owner)
    }
}

struct CICacheRead: Sendable {
    let volumes: [Micropod_V1_Volume]
    let containers: [Micropod_V1_Container]?
    let truncated: Bool
}

protocol CICacheInventoryReading: Sendable {
    func read() async throws -> CICacheRead
}

struct RuntimeCICacheReader: CICacheInventoryReading {
    let volumes: any VolumeServing
    let containers: any ContainerServing
    static let limit = 512

    func read() async throws -> CICacheRead {
        async let volumeList = volumes.list()
        async let containerList = try? containers.list()
        let (listed, references) = try await (volumeList, containerList)
        return Self.bounded(volumes: listed, containers: references)
    }

    static func bounded(volumes: [Micropod_V1_Volume], containers: [Micropod_V1_Container]?) -> CICacheRead {
        let truncated = volumes.count > Self.limit || (containers?.count ?? 0) > Self.limit
        return CICacheRead(
            volumes: Array(volumes.prefix(Self.limit)),
            containers: truncated ? nil : containers,
            truncated: truncated)
    }
}

struct CICacheInventorySnapshot: Sendable {
    let measuredAt: Date
    let sourceID: String
    let volumes: [CICacheVolume]
    let referencesAvailable: Bool
    let truncated: Bool

    init(read: CICacheRead, sourceID: String, measuredAt: Date) {
        self.measuredAt = measuredAt
        self.sourceID = sourceID
        self.referencesAvailable = read.containers != nil
        self.truncated = read.truncated
        // Inspect only curated mount metadata; never guest data, logs or env.
        self.volumes = read.volumes.filter {
            $0.format.lowercased() == "ext4"
                && ($0.labels["cuttle.kind"] == "cache" || $0.id.hasPrefix("cf-cache-"))
        }.map { volume in
            let references = read.containers.map { containers in
                containers.filter { container in
                    container.mounts.contains { mount in
                        Self.references(mount.source, volume: volume, containerID: container.id)
                    }
                }
            }
            let active = references.map {
                $0.filter { ["running", "starting", "stopping", "paused"].contains($0.state.lowercased()) }
                    .map(\.id).sorted()
            }
            return CICacheVolume(
                id: volume.id, project: volume.labels["cuttle.project"] ?? "",
                owner: volume.labels["cuttle.owner"] ?? "",
                ecosystem: volume.labels["cuttle.ecosystem"] ?? volume.labels["cuttle.scope"] ?? "",
                source: volume.source,
                key: volume.labels["cuttle.key"] ?? "",
                scope: volume.labels["cuttle.scope"] ?? "",
                trust: volume.labels["cuttle.trust"] ?? "",
                lineage: volume.labels["cuttle.lineage"] ?? "",
                createdAt: CICacheTelemetry.date(volume.createdAt),
                capacityBytes: volume.sizeBytes > 0 ? volume.sizeBytes : nil,
                // Proto3 zero does not distinguish an omitted sample from zero
                // allocation. Stay conservative until the runtime supplies presence.
                allocatedBytes: volume.allocatedBytes > 0 ? volume.allocatedBytes : nil,
                activeContainers: active, containerReferences: references?.map(\.id).sorted())
        }.sorted {
            if $0.allocatedBytes != $1.allocatedBytes {
                return ($0.allocatedBytes ?? 0) > ($1.allocatedBytes ?? 0)
            }
            return $0.id < $1.id
        }
    }

    private static func references(_ source: String, volume: Micropod_V1_Volume, containerID: String) -> Bool {
        if source == volume.id || (!volume.source.isEmpty && source == volume.source) { return true }
        // A golden can be in use without an open handle on the golden itself.
        // Match the complete clone path suffix, not a substring of its name.
        return source.hasSuffix("/volume-clones/\(containerID)/\(volume.id).img")
    }

    func selected(_ selection: CICacheSelection) -> [CICacheVolume] {
        volumes.filter(selection.includes)
    }

    func isStale(at now: Date) -> Bool {
        now.timeIntervalSince(measuredAt) > 90 || measuredAt.timeIntervalSince(now) > 5
    }
}

struct CICacheCounter: Decodable, Sendable {
    let name: String
    let type: String
    let value: Double
    let capturedAt: String?
    let attributes: [String: String]?
}

struct CICacheTelemetry: Sendable {
    static let endpoint = URL(string: "http://127.0.0.1:5555/cache")!
    static let byteLimit = 1_048_576
    let receivedAt: Date
    let counters: [CICacheCounter]
    var attempts: [CICacheAttemptReport] = []
    var saves: [CICacheSaveReport] = []
    var invalidSaves = 0
    var saveFeedAvailable = false

    static func decode(_ data: Data, receivedAt: Date) throws -> Self {
        struct Envelope: Decodable {
            let ok: Bool
            let metrics: [CICacheCounter]
            let attempts: [CICacheAttemptReport]?
            let saves: [CICacheOptionalSave]?
        }
        guard data.count <= Self.byteLimit else { throw CICacheReadError.invalidCounters }
        let envelope = try JSONDecoder().decode(Envelope.self, from: data)
        guard envelope.ok, envelope.metrics.count <= 1024, (envelope.attempts?.count ?? 0) <= 20,
            (envelope.saves?.count ?? 0) <= 128,
            (envelope.attempts ?? []).allSatisfy({
                [$0.attemptId, $0.nodeId, $0.runnerId ?? "", $0.projectId ?? "", $0.runId ?? "", $0.observedAt ?? ""]
                    .allSatisfy { $0.count <= 512 }
            }),
            envelope.metrics.allSatisfy({ $0.value.isFinite && $0.value >= 0 })
        else { throw CICacheReadError.invalidCounters }
        return Self(
            receivedAt: receivedAt, counters: envelope.metrics, attempts: envelope.attempts ?? [],
            saves: (envelope.saves ?? []).compactMap(\.value),
            invalidSaves: (envelope.saves ?? []).filter { $0.value == nil }.count,
            saveFeedAvailable: envelope.saves != nil)
    }

    func jobReports(for selection: CICacheSelection) -> [CICacheAttemptReport] {
        guard selection.owner.isEmpty else { return [] }  // owner path is not a runner ID
        var seen = Set<String>()
        return attempts.reversed().filter {
            (selection.project.isEmpty || $0.projectId == selection.project) && seen.insert($0.id).inserted
        }
    }

    func proxyReports(for selection: CICacheSelection) -> [CICacheAttemptReport] {
        jobReports(for: selection).filter { $0.report.proxy != nil }
    }

    func saveReports(for selection: CICacheSelection) -> [CICacheSaveReport] {
        guard selection.owner.isEmpty else { return [] }
        var seen = Set<CICacheSaveReport.Key>()
        return saves.reversed().filter {
            (selection.project.isEmpty || $0.projectId == selection.project) && seen.insert($0.id).inserted
        }
    }

    /// Resolution events and proxy activity have distinct definitions.
    /// The endpoint does not assert rig/owner identity. Never join it to an
    /// owner selection. Project-less counters are hidden under a project filter.
    func observations(for selection: CICacheSelection) -> [CICacheCounterObservation] {
        guard selection.owner.isEmpty else { return [] }
        let definitions: [(String, String, String, String, CICacheCounterObservation.Unit)] =
            selection.project.isEmpty
            ? [
                ("Existing goldens", "cache_volume_total", "outcome", "hit", .count),
                ("New goldens", "cache_volume_total", "outcome", "created", .count),
                ("Existing store mounts", "cache_store_total", "outcome", "hit", .count),
                ("Seeded store mounts", "cache_store_total", "outcome", "seeded", .count),
                ("Cold store mounts", "cache_store_total", "outcome", "cold", .count),
                ("Proxy local requests", "depcache_requests_total", "tier", "local", .count),
                ("Proxy upstream requests", "depcache_requests_total", "tier", "upstream", .count),
                ("Proxy stale responses", "depcache_requests_total", "tier", "stale", .count),
                ("Proxy errors", "depcache_requests_total", "tier", "error", .count),
                ("Proxy bytes served", "depcache_bytes_total", "source", "local", .bytes),
                ("Proxy bytes fetched", "depcache_bytes_total", "source", "upstream", .bytes),
            ]
            : [
                ("Existing goldens", "cache_volume_total", "outcome", "hit", .count),
                ("New goldens", "cache_volume_total", "outcome", "created", .count),
            ]
        return definitions.compactMap { label, name, attribute, value, unit in
            let matching = counters.filter {
                $0.name == name && $0.type == "counter" && $0.attributes?[attribute] == value
                    && (selection.project.isEmpty || $0.attributes?["project"] == selection.project)
            }
            guard !matching.isEmpty else { return nil }  // absent is unavailable, not zero
            let total = matching.reduce(0) { $0 + $1.value }
            guard total.isFinite else { return nil }
            let dates = matching.compactMap { Self.date($0.capturedAt) }
            return CICacheCounterObservation(
                label: label, value: total, unit: unit, capturedAt: dates.count == matching.count ? dates.min() : nil)
        }
    }

    static func date(_ string: String?) -> Date? {
        guard let string else { return nil }
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter.date(from: string) ?? ISO8601DateFormatter().date(from: string)
    }
}

struct CICacheCounterObservation: Sendable {
    let label: String
    enum Unit: Sendable { case count, bytes }
    let value: Double
    let unit: Unit

    var formatted: String {
        if unit == .bytes, value == 0 { return "0 B" }
        if unit == .bytes, value < Double(Int64.max) {
            return ByteCountFormatter.string(fromByteCount: Int64(value), countStyle: .file)
        }
        return value.formatted(.number.precision(.fractionLength(0))) + (unit == .bytes ? " bytes" : "")
    }
    let capturedAt: Date?

    func freshness(at now: Date) -> String {
        guard let capturedAt else { return "Sample time unknown" }
        if capturedAt.timeIntervalSince(now) > 5 { return "Sample time invalid" }
        return now.timeIntervalSince(capturedAt) > 90 ? "Stale sample" : "Recent sample"
    }
}

enum CICacheByteFormat {
    static func string(_ value: UInt64?) -> String {
        guard let value else { return "Unknown" }
        if value == 0 { return "0 B" }
        guard value <= UInt64(Int64.max) else { return "\(value.formatted()) bytes" }
        return ByteCountFormatter.string(fromByteCount: Int64(value), countStyle: .file)
    }
}

enum CICacheReadError: Error { case invalidCounters, unavailable }

protocol CICacheTelemetryReading: Sendable {
    func read() async throws -> CICacheTelemetry
}

/// Fixed loopback, no redirects, credentials, cookies, cache or mutations.
private final class CacheCounterRedirectPolicy: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(
        _ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
        newRequest request: URLRequest, completionHandler: @escaping @Sendable (URLRequest?) -> Void
    ) { completionHandler(nil) }
}

struct LocalCICacheTelemetryReader: CICacheTelemetryReading {
    func read() async throws -> CICacheTelemetry {
        try await CICacheTelemetry.decode(
            Self.readData(
                from: CICacheTelemetry.endpoint,
                byteLimit: CICacheTelemetry.byteLimit), receivedAt: Date())
    }

    static func readData(from url: URL, byteLimit: Int) async throws -> Data {
        guard url.scheme == "http", url.host == "127.0.0.1", url.port == 5555,
            ["/cache", "/cache/history"].contains(url.path)
        else { throw CICacheReadError.unavailable }
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 3
        configuration.timeoutIntervalForResource = 3
        configuration.urlCache = nil
        configuration.urlCredentialStorage = nil
        configuration.httpCookieStorage = nil
        let session = URLSession(
            configuration: configuration, delegate: CacheCounterRedirectPolicy(), delegateQueue: nil)
        defer { session.invalidateAndCancel() }
        let (bytes, response) = try await session.bytes(from: url)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw CICacheReadError.unavailable }
        var data = Data()
        for try await byte in bytes {
            guard data.count < byteLimit else { throw CICacheReadError.invalidCounters }
            try Task.checkCancellation()
            data.append(byte)
        }
        return data
    }
}

@MainActor @Observable
final class CICacheStore {
    private(set) var inventory: CICacheInventorySnapshot?
    private(set) var telemetry: CICacheTelemetry?
    private(set) var history: CICacheHistorySnapshot?
    private(set) var inventoryError: String?
    private(set) var telemetryError: String?
    private(set) var isRefreshing = false
    @ObservationIgnored private var task: Task<Void, Never>?
    @ObservationIgnored private var epoch: UInt64 = 0
    @ObservationIgnored private var sourceID: String?
    @ObservationIgnored private var isPreview = false

    func refresh(
        reader: any CICacheInventoryReading, sourceID: String,
        telemetryReader: any CICacheTelemetryReading = LocalCICacheTelemetryReader(),
        historyReader: (any CICacheHistoryReading)? = nil
    ) async {
        guard !isPreview, !Task.isCancelled else { return }
        if self.sourceID != sourceID {
            cancelRefresh()
            self.sourceID = sourceID
            inventory = nil
            telemetry = nil
            history = nil
            inventoryError = nil
            telemetryError = nil
        }
        if let task {
            await task.value
            return
        }
        let epoch = self.epoch
        isRefreshing = true
        let task = Task { [weak self] in
            async let inventoryResult = Self.inventoryResult(reader)
            async let telemetryResult = Self.telemetryResult(telemetryReader)
            async let historyResult = historyReader?.read()
            let (inventoryRead, telemetryRead, historyRead) = await (inventoryResult, telemetryResult, historyResult)
            guard let self, !Task.isCancelled, self.epoch == epoch else { return }
            switch inventoryRead {
            case .success(let read):
                inventory = CICacheInventorySnapshot(read: read, sourceID: sourceID, measuredAt: Date())
                inventoryError = nil
            case .failure:
                inventoryError = "Named-volume inventory unavailable. Any retained rows are an earlier observation."
            }
            switch telemetryRead {
            case .success(let result):
                telemetry = result
                telemetryError = nil
            case .failure:
                telemetryError = "Local runner counters unavailable. Any retained counters are an earlier observation."
            }
            history = historyRead
            isRefreshing = false
            self.task = nil
        }
        self.task = task
        await task.value
    }

    nonisolated private static func inventoryResult(_ reader: any CICacheInventoryReading) async -> Result<
        CICacheRead, Error
    > {
        do { return .success(try await reader.read()) } catch { return .failure(error) }
    }

    nonisolated private static func telemetryResult(_ reader: any CICacheTelemetryReading) async -> Result<
        CICacheTelemetry, Error
    > {
        do { return .success(try await reader.read()) } catch { return .failure(error) }
    }

    func cancelRefresh() {
        epoch &+= 1
        task?.cancel()
        task = nil
        isRefreshing = false
    }

    func applyForPreview(
        _ inventory: CICacheInventorySnapshot?, telemetry: CICacheTelemetry? = nil, error: String? = nil,
        history: CICacheHistorySnapshot? = nil, telemetryError: String? = nil
    ) {
        cancelRefresh()
        isPreview = true
        self.inventory = inventory
        self.telemetry = telemetry
        self.history = history
        inventoryError = error
        self.telemetryError = telemetryError
    }
}
