import Containerization
import ContainerizationExtras
import Foundation
import MicropodCore
import Synchronization
import vmnet

/// Cleanup can remain uncertain before a configured VM exists. Its session
/// retains this resource until the same stop operation is confirmed.
protocol SandboxNetworkCleanup: Sendable {
    func stop() throws
}

/// One sandbox's vmnet network (macOS 26 `vmnet_network_create`, no
/// vm.networking entitlement): vmnet picks a free /24 under 192.168/16, so
/// parallel runs never contend for addresses, and sandboxes can't reach
/// each other. The guest gets `.2`, the host side (gateway) is `.1`.
///
/// Owned here rather than through Containerization's `VmnetNetwork`, which
/// never releases its `vmnet_network_ref` — the type imports as an opaque
/// pointer, so ARC can't — and every network then holds its subnet
/// reservation until the process exits. Harmless for a one-shot CLI run;
/// a long-lived API process ran out after ~20 networked sandboxes
/// (`VMNET_FAILURE`). Released on deinit: keep this alive until the VM has
/// stopped, or the guest dies mid-teardown.
final class SandboxNetwork: SandboxNetworkCleanup, @unchecked Sendable {
    let interface: VmnetNetwork.Interface
    let gateway: IPv4Address
    let publicationMTU: UInt32?
    let publicationGSOBytes: UInt32?
    private let reference: vmnet_network_ref
    private let anchor: Mutex<SandboxNetworkAnchor?>

    init(
        mode: vmnet.operating_modes_t, pinBridge: Bool = false, publicationMTU: UInt32? = nil,
        publicationGSOBytes: UInt32? = nil
    ) throws {
        self.publicationMTU = publicationMTU
        self.publicationGSOBytes = publicationGSOBytes
        var status: vmnet_return_t = .VMNET_FAILURE
        guard let config = vmnet_network_configuration_create(mode, &status) else {
            throw MicropodError.message("vmnet network configuration failed (status \(status.rawValue))")
        }
        defer { Self.release(config) }
        if let publicationMTU {
            guard mode == .VMNET_HOST_MODE else {
                throw MicropodError.message("A publication MTU requires a host-only network")
            }
            let result = vmnet_network_configuration_set_mtu(config, publicationMTU)
            guard result == .VMNET_SUCCESS else {
                throw MicropodError.message(
                    "vmnet rejected the \(publicationMTU)-byte publication MTU (status \(result.rawValue))")
            }
        }
        vmnet_network_configuration_disable_dhcp(config)
        guard let reference = vmnet_network_create(config, &status), status == .VMNET_SUCCESS else {
            throw MicropodError.message("vmnet network creation failed (status \(status.rawValue))")
        }
        self.reference = reference
        var subnet = in_addr()
        var mask = in_addr()
        vmnet_network_get_ipv4_subnet(reference, &subnet, &mask)
        let lower = UInt32(bigEndian: subnet.s_addr) & UInt32(bigEndian: mask.s_addr)
        let prefix = UInt8(UInt32(bigEndian: mask.s_addr).nonzeroBitCount)
        guard let v4Prefix = Prefix.ipv4(prefix) else {
            Self.release(reference)
            throw MicropodError.message("vmnet gave an unusable subnet mask /\(prefix)")
        }
        gateway = IPv4Address(lower + 1)

        // NAT66: the guest's v6 address and gateway mirror the v4 layout.
        var v6: (address: CIDRv6, gateway: IPv6Address)?
        var prefix6 = in6_addr()
        var length6: UInt8 = 0
        vmnet_network_get_ipv6_prefix(reference, &prefix6, &length6)
        if length6 > 0, let p6 = Prefix.ipv6(length6),
            let base = try? IPv6Address(withUnsafeBytes(of: prefix6) { Array($0) })
        {
            let network = base.value & p6.prefixMask128
            v6 = try? (address: CIDRv6(IPv6Address(network | 2), prefix: p6), gateway: IPv6Address(network | 1))
        }
        do {
            interface = VmnetNetwork.Interface(
                reference: reference,
                ipv4Address: try CIDRv4(IPv4Address(lower + 2), prefix: v4Prefix),
                ipv4Gateway: gateway,
                ipv6Address: v6?.address,
                ipv6Gateway: v6?.gateway,
                mtu: publicationMTU ?? 1500)
        } catch {
            Self.release(reference)
            throw error
        }
        do {
            anchor = Mutex(pinBridge ? try SandboxNetworkAnchor(network: reference) : nil)
        } catch {
            Self.release(reference)
            throw error
        }
    }

    static func workerNetwork(
        mode: vmnet.operating_modes_t, publicationMTU: UInt32? = nil,
        publicationGSOBytes: UInt32? = nil
    ) async throws
        -> SandboxNetwork
    {
        // Internet Sharing can reject the first attachment while retiring an old bridge.
        // Release each confirmed attempt before requesting the next reservation.
        for attempt in 1...3 {
            let network = try SandboxNetwork(
                mode: mode, pinBridge: true, publicationMTU: publicationMTU,
                publicationGSOBytes: publicationGSOBytes)
            do {
                try network.waitUntilReady()
                return network
            } catch {
                try network.stop()
                if attempt == 3 { throw error }
                try await Task.sleep(for: .milliseconds(250 * attempt))
            }
        }
        throw MicropodError.message("CI network did not become ready")
    }

    func waitUntilReady() throws { try anchor.withLock { try $0?.waitUntilReady() } }

    /// The VM NIC is detached before rotating the last attachment on this private network.
    /// Keep the reservation so the gateway, guest addresses and Docker resolver stay valid.
    func renewAnchor() throws {
        try anchor.withLock { anchor in
            try anchor?.stop()
            anchor = try SandboxNetworkAnchor(network: reference)
            try anchor?.waitUntilReady()
        }
    }

    func stop() throws { try anchor.withLock { try $0?.stop() } }

    deinit {
        do {
            try stop()
            Self.release(reference)
        } catch {
            // Keep the network reservation when stop is ambiguous. The API
            // must not turn that failure into a successful cleanup receipt.
            SecretSource.stderrLog("sandbox network cleanup remains unconfirmed")
        }
    }

    /// `CFRelease` for vmnet's CF-style objects (Swift hides `CFRelease`).
    private static func release(_ object: OpaquePointer) {
        Unmanaged<AnyObject>.fromOpaque(UnsafeRawPointer(object)).release()
    }
}
