import Foundation
import Network

/// The daemon's authoritative state: chunk store + active views + watcher.
/// One process, one state. The unix socket is just transport.
public actor SharedFSDaemon: SharedFSClient {
    public let cacheRoot: URL
    public let viewsRoot: URL
    public let store: ChunkStore
    /// Per-runner cap: 10GB global LRU (RUNNER_CACHE_MAX_BYTES, default 10<<30).
    public let cacheMaxBytes: UInt64
    /// Gauge `shared_cache_pinned_over_cap`: 1 when still over cap after eviction because all remaining are pinned.
    public private(set) var sharedCachePinnedOverCap: Int = 0
    /// Synchronous indexed size via store index (no `du`).
    public var sharedCacheSize: UInt64 { store.indexedSize }
    // MARK: - Metrics: shared_cache_* observables (mirrors cuttlefish runner)
    public private(set) var localHits: Int = 0
    public private(set) var remoteHits: Int = 0
    public private(set) var misses: Int = 0
    public private(set) var gcsPushErrors: Int = 0
    public private(set) var evictedChunksTotal: Int = 0
    private let gracePeriod: TimeInterval = 300  // 5m grace
    private var sweepTask: Task<Void, Never>?
    private var views: [ViewID: SharedView] = [:]
    // Live shared mounts: one view per src, bidirectional sync for live writes.
    private var sharedViews: [String: SharedView] = [:]
    private var sharedWatchers: [String: (srcWatcher: FSEventsWatcher, viewWatcher: FSEventsWatcher)] =
        [:]
    private var sharedRefCounts: [String: Int] = [:]
    // Per-container live sync via host hub
    private var viewsBySrc: [String: Set<ViewID>] = [:]
    private var viewWatchers: [ViewID: FSEventsWatcher] = [:]
    private var srcWatchers: [String: FSEventsWatcher] = [:]
    private var liveSync: [ViewID: SharedViewSync] = [:]
    /// A persistent, whole-cache retention preference. It also protects
    /// future chunks, unlike a UI-only list of currently visible hashes.
    private var cacheKeepEnabled: Bool
    private var cacheRetentionWarning: String? = nil
    private var cleanupReviews: [String: (createdAt: Date, hashes: [ChunkHash])] = [:]

    /// Shared mounts are also registered in `views` for inspect/refresh.
    /// Merge by identity so metrics and inventories count each view once.
    private var activeViews: [SharedView] {
        var unique = views
        for view in sharedViews.values { unique[view.id] = view }
        return Array(unique.values)
    }

    public init(cacheRoot: URL, cacheMaxBytes: UInt64? = nil) throws {
        self.cacheRoot = cacheRoot
        self.viewsRoot = cacheRoot.appendingPathComponent("views", isDirectory: true)
        self.store = try ChunkStore(root: cacheRoot.appendingPathComponent("chunks", isDirectory: true))
        try FileManager.default.createDirectory(at: viewsRoot, withIntermediateDirectories: true)
        let retentionURL = cacheRoot.appendingPathComponent("retention.json")
        if FileManager.default.fileExists(atPath: retentionURL.path) {
            do {
                cacheKeepEnabled = try JSONDecoder().decode(Bool.self, from: Data(contentsOf: retentionURL))
            } catch {
                // A damaged preference cannot be interpreted as consent
                // to evict kept data. Keep serving mounts and fail closed.
                cacheKeepEnabled = true
                cacheRetentionWarning =
                    "Retention preferences could not be read. Package data is kept until you choose a retention setting."
                fputs("[sharedfs] unreadable retention preference; preserving package cache\n", stderr)
            }
        } else {
            cacheKeepEnabled = false
        }
        if let cacheMaxBytes {
            self.cacheMaxBytes = cacheMaxBytes
        } else if let env = ProcessInfo.processInfo.environment["RUNNER_CACHE_MAX_BYTES"],
            let parsed = UInt64(env)
        {
            self.cacheMaxBytes = parsed
        } else {
            self.cacheMaxBytes = 10 << 30  // 10GB default
        }
        // Bootstrap without retaining the daemon while the sweep sleeps.
        Task.detached { [weak self] in
            await self?.startSweepLoop()
        }
    }

    deinit { sweepTask?.cancel() }

    private func startSweepLoop() {
        guard sweepTask == nil else { return }
        sweepTask = Task.detached { [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(for: .seconds(300)) } catch { return }
                guard !Task.isCancelled else { return }
                _ = await self?.enforceStorageCapIfNeeded()
                try? await self?.sweepOrphanedIfNeeded()
            }
        }
    }

    /// DiskManager hook: placeholder for sweepOrphanedVolumes integration.
    /// In micropod the equivalent is `gc()` on idle views; we expose for observability.
    public func sweepOrphanedIfNeeded() async throws {
        // For now, enforce cap also covers orphan sweep. Real DiskManager
        // would age-gate cf-cache-* volumes; here we just log.
        _ = await enforceStorageCapIfNeeded()
    }

    // MARK: - Storage cap (indexed size gate + LRU eviction)

    /// Enforced *before* next mount (synchronous indexed-size check via store metadata, no `du`)
    /// and via async 5m sweep. LRU-evict oldest chunks (by atime, refCount==0, 5m grace) until under cap;
    /// if still over and all remaining are pinned or <5m old, bypass grace and evict oldest refCount==0 anyway;
    /// emit `shared_cache_pinned_over_cap` gauge if still over.
    @discardableResult
    public func enforceStorageCapIfNeeded() async -> GCResult {
        let cap = cacheMaxBytes
        var removed = 0
        var reclaimed: UInt64 = 0
        // Fast path: already under cap
        if store.indexedSize <= cap {
            sharedCachePinnedOverCap = 0
            return GCResult(chunksRemoved: 0, bytesReclaimed: 0)
        }
        if cacheKeepEnabled {
            sharedCachePinnedOverCap = 1
            return GCResult(chunksRemoved: 0, bytesReclaimed: 0)
        }
        // After a restart, the daemon cannot prove that a retained view
        // directory is idle. Preserve its backing data rather than evict
        // against an incomplete mount registry; unreadable inventories
        // also fail closed.
        if (try? hasUntrackedViewDirectories()) != false {
            sharedCachePinnedOverCap = 1
            return GCResult(chunksRemoved: 0, bytesReclaimed: 0)
        }
        // Collect live pinned chunks from active views (view-backed pinning)
        var livePinned: Set<String> = []
        for view in activeViews {
            let hashes = chunksInUse(view: view.root)
            livePinned.formUnion(hashes)
        }

        let now = Date()
        let graceCutoff = now.addingTimeInterval(-gracePeriod)

        // Build mutable list of candidates from store index
        // Use store's internal tracking; we need atime/size/refCount per hash.
        // To avoid exposing internals, we enumerate all chunk files and query store metadata.
        var didEvict = true
        while store.indexedSize > cap, didEvict {
            didEvict = false
            let allHashes = store.allChunkHashes()
            if allHashes.isEmpty { break }
            struct Candidate {
                let hash: ChunkHash
                let atime: Date
                let size: UInt64
                let refCount: Int
                let isLivePinned: Bool
            }
            var candidates: [Candidate] = []
            for h in allHashes {
                let atime = store.atime(for: h) ?? Date.distantPast
                let size = store.chunkSize(h) ?? 0
                let rc = store.refCount(for: h)
                let live = livePinned.contains(h.value)
                candidates.append(Candidate(hash: h, atime: atime, size: size, refCount: rc, isLivePinned: live))
            }
            // Sort by atime oldest first for deterministic LRU
            candidates.sort { $0.atime < $1.atime }

            // Phase 1: grace-respecting candidates (refCount==0 && !livePinned && atime < graceCutoff)
            var chosen: Candidate?
            for c in candidates where c.refCount == 0 && !c.isLivePinned && c.atime < graceCutoff {
                chosen = c
                break
            }
            // Phase 2: bypass grace if still over cap — evict oldest refCount==0 anyway
            if chosen == nil {
                for c in candidates where c.refCount == 0 && !c.isLivePinned {
                    chosen = c
                    break
                }
            }
            if let victim = chosen {
                do {
                    try store.remove(victim.hash)
                    removed += 1
                    reclaimed += victim.size
                    didEvict = true
                    fputs(
                        "[sharedfs] evicted \(victim.hash.value.prefix(12)) size \(victim.size) atime \(victim.atime) (cap \(cap) size \(store.indexedSize))\n",
                        stderr)
                } catch {
                    fputs("[sharedfs] evict failed \(victim.hash.value): \(error)\n", stderr)
                    break
                }
            } else {
                // No evictable candidates — all remaining are pinned
                break
            }
        }
        if store.indexedSize > cap {
            sharedCachePinnedOverCap = 1
            fputs("[sharedfs] shared_cache_pinned_over_cap=1 size \(store.indexedSize) cap \(cap)\n", stderr)
        } else {
            sharedCachePinnedOverCap = 0
        }
        if removed > 0 {
            fputs(
                "[sharedfs] storage cap enforced: removed \(removed) chunks, reclaimed \(reclaimed) bytes, size now \(store.indexedSize) cap \(cap)\n",
                stderr)
            evictedChunksTotal += removed
        }
        return GCResult(chunksRemoved: removed, bytesReclaimed: reclaimed)
    }

    // MARK: - Metrics (shared_cache_*)

    /// Records a cache lookup outcome for `shared_cache_hit_total{hit="local|remote|miss"}`.
    @discardableResult
    public func recordCacheHit(hit: String, hash: ChunkHash) -> Int {
        switch hit {
        case "local":
            localHits += 1
            return localHits
        case "remote":
            remoteHits += 1
            return remoteHits
        case "miss":
            misses += 1
            return misses
        default:
            misses += 1
            return misses
        }
    }

    /// Records a GCS push error for `gcs_push_errors_total`.
    public func recordGCSPushError() {
        gcsPushErrors += 1
    }

    /// Returns the current shared-cache observable set, mirroring the Go
    /// RunnerMetric names: shared_cache_hit_total{hit="..."}, shared_cache_bytes,
    /// evicted_chunks_total, gcs_push_errors_total, shared_views_pinned.
    public func cacheMetrics() -> [String: Int] {
        // shared_views_pinned = active sharedViews count (pinned)
        let pinned = activeViews.count
        return [
            "shared_cache_hit_total_local": localHits,
            "shared_cache_hit_total_remote": remoteHits,
            "shared_cache_hit_total_miss": misses,
            "shared_cache_bytes": Int(sharedCacheSize),
            "evicted_chunks_total": evictedChunksTotal,
            "gcs_push_errors_total": gcsPushErrors,
            "shared_views_pinned": pinned,
            "shared_cache_pinned_over_cap": sharedCachePinnedOverCap,
        ]
    }

    // MARK: - SharedFSClient

    public func mount(src: URL, readonly: Bool) async throws -> MountInfo {
        // Enforce storage cap before next mount (synchronous indexed-size check, no du)
        _ = await enforceStorageCapIfNeeded()
        let normalized = src.resolvingSymlinksInPath().standardizedFileURL
        let id = ViewID.generate()
        let viewRoot = viewsRoot.appendingPathComponent(id.value, isDirectory: true)
        try SharedView.build(source: normalized, root: viewRoot)
        let view = SharedView(id: id, source: normalized, root: viewRoot)
        liveSync[id] = try SharedViewSync(source: normalized, view: viewRoot)
        views[id] = view
        viewsBySrc[normalized.path, default: []].insert(id)
        ensureWatchers(for: normalized, view: view)
        fputs("[sharedfs] mount \(normalized.path) -> \(viewRoot.path) (\(view.size()) bytes)\n", stderr)
        return MountInfo(
            id: id, src: normalized.path, viewPath: viewRoot.path,
            sizeBytes: view.size(), readonly: readonly, createdAt: view.createdAt)
    }

    public func mountShared(src: URL, readonly: Bool) async throws -> MountInfo {
        let view = try await acquireSharedView(src)
        return MountInfo(
            id: view.id, src: view.source.path, viewPath: view.root.path,
            sizeBytes: view.size(), readonly: readonly, createdAt: view.createdAt)
    }

    public func bindShared(src: URL, readonly: Bool) async throws -> SharedBind {
        let view = try await acquireSharedView(src)
        return SharedBind(id: view.id, viewPath: view.root.path)
    }

    private func acquireSharedView(_ src: URL) async throws -> SharedView {
        // Enforce storage cap before next mount (synchronous, no du)
        _ = await enforceStorageCapIfNeeded()
        let normalized = src.resolvingSymlinksInPath().standardizedFileURL
        let key = normalized.path
        if let existing = sharedViews[key] {
            sharedRefCounts[key, default: 1] += 1
            fputs("[sharedfs] mountShared reuse \(key) -> \(existing.root.path)\n", stderr)
            return existing
        }
        // Deterministic ID for shared view (so restarts can re-derive).
        let hash = (try? ChunkHash.compute(Data(key.utf8)))?.value.prefix(12) ?? Substring(UUID().uuidString.prefix(12))
        let id = ViewID(String(hash))
        let viewRoot = viewsRoot.appendingPathComponent("shared-\(id.value)", isDirectory: true)
        // Clean stale view dir if any.
        if FileManager.default.fileExists(atPath: viewRoot.path) {
            try? FileManager.default.removeItem(at: viewRoot)
        }
        try SharedView.build(source: normalized, root: viewRoot)
        let view = SharedView(id: id, source: normalized, root: viewRoot)
        liveSync[id] = try SharedViewSync(source: normalized, view: viewRoot)
        sharedViews[key] = view
        sharedRefCounts[key] = 1
        // Also register in views for list/inspect visibility.
        views[id] = view
        startSharedWatchers(src: normalized, view: view)
        fputs("[sharedfs] mountShared \(key) -> \(viewRoot.path)\n", stderr)
        return view
    }

    /// Rebuild the view from the live source. Called explicitly by clients
    /// (and auto-invoked on mount if any FSEvents have fired since the last
    /// build — see `mount`).
    public func refresh(id: ViewID) async throws -> MountInfo {
        guard let view = views[id] else {
            throw SharedFSError.daemonUnavailable
        }
        try SharedView.build(source: view.source, root: view.root)
        liveSync[id] = try SharedViewSync(source: view.source, view: view.root)
        return MountInfo(
            id: id, src: view.source.path, viewPath: view.root.path,
            sizeBytes: view.size(), readonly: false, createdAt: view.createdAt)
    }

    public func unmount(id: ViewID) async throws {
        // Shared view path: ref-counted, only destroyed when last user leaves.
        if let sharedKey = sharedViews.first(where: { $0.value.id == id })?.key {
            let remaining = (sharedRefCounts[sharedKey] ?? 1) - 1
            if remaining <= 0 {
                sharedWatchers[sharedKey]?.srcWatcher.stop()
                sharedWatchers[sharedKey]?.viewWatcher.stop()
                sharedWatchers.removeValue(forKey: sharedKey)
                if let sharedView = sharedViews[sharedKey] { try? sharedView.destroy() }
                sharedViews.removeValue(forKey: sharedKey)
                sharedRefCounts.removeValue(forKey: sharedKey)
                views.removeValue(forKey: id)
                liveSync.removeValue(forKey: id)
            } else {
                sharedRefCounts[sharedKey] = remaining
                // Keep the view alive for other containers; just forget the
                // per-container mapping (viewsBySrc not used for shared).
            }
            return
        }
        guard let view = views[id] else { return }
        viewWatchers[view.id]?.stop()
        viewWatchers.removeValue(forKey: view.id)
        if let srcKey = viewsBySrc.first(where: { $0.value.contains(view.id) })?.key {
            viewsBySrc[srcKey]?.remove(view.id)
            if viewsBySrc[srcKey]?.isEmpty == true {
                srcWatchers[srcKey]?.stop()
                srcWatchers.removeValue(forKey: srcKey)
                viewsBySrc.removeValue(forKey: srcKey)
            }
        }
        try view.destroy()
        views.removeValue(forKey: id)
        liveSync.removeValue(forKey: id)
    }

    public func inspect(id: ViewID) async throws -> MountInfo {
        guard let view = views[id] else {
            throw SharedFSError.daemonUnavailable
        }
        return MountInfo(
            id: id, src: view.source.path, viewPath: view.root.path,
            sizeBytes: view.size(), readonly: false, createdAt: view.createdAt)
    }

    public func sync(id: ViewID) async throws -> SyncResult {
        guard let view = views[id] else {
            throw SharedFSError.daemonUnavailable
        }
        let changed = try SharedView.syncToSource(view: view.root, source: view.source)
        liveSync[id] = try SharedViewSync(source: view.source, view: view.root)
        let bytes = changed.reduce(0) { acc, url in
            (try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize).map { acc + UInt64($0 ?? 0) } ?? acc
        }
        return SyncResult(id: id, synced: changed.map { $0.path }, bytesWritten: bytes)
    }

    public func list() async throws -> [MountInfo] {
        activeViews.map { view in
            MountInfo(
                id: view.id, src: view.source.path, viewPath: view.root.path,
                sizeBytes: view.size(), readonly: false, createdAt: view.createdAt)
        }
    }

    public func gc() async throws -> GCResult {
        // Live views can change while the host hashes their contents. A
        // manual purge therefore runs only when every ordinary/shared
        // mount is idle, and also honours explicit retention/ref counts.
        // Automatic cap eviction retains its bounded LRU policy.
        guard try cleanupBlockedReason() == nil else {
            return GCResult(chunksRemoved: 0, bytesReclaimed: 0)
        }
        // Use store index for size tracking; enumerate via store to keep index authoritative.
        let allHashes = store.allChunkHashes()
        // Also include any stray files not in index (e.g., pre-existing) by scanning filesystem.
        let fsNames = (try? FileManager.default.contentsOfDirectory(atPath: store.root.path)) ?? []
        var allNames = Set(allHashes.map { $0.value })
        allNames.formUnion(fsNames.filter { $0.count == 64 && $0.allSatisfy(\.isHexDigit) })
        var removed = 0
        var bytesReclaimed: UInt64 = 0
        for name in allNames {
            let hash = ChunkHash(unchecked: name)
            guard store.refCount(for: hash) == 0 else { continue }
            let url = store.root.appendingPathComponent(name)
            let size =
                store.chunkSize(hash)
                ?? {
                    let attrs = try? FileManager.default.attributesOfItem(atPath: url.path)
                    if let s = attrs?[.size] as? UInt64 { return s }
                    if let s = attrs?[.size] as? Int { return UInt64(s) }
                    return UInt64(0)
                }()
            // Use store.remove to keep indexedSize consistent; check existence without bumping atime.
            guard store.exists(hash) || FileManager.default.fileExists(atPath: url.path) else { continue }
            try store.remove(hash)
            removed += 1
            bytesReclaimed += size
        }
        if removed > 0 {
            evictedChunksTotal += removed
        }
        return GCResult(chunksRemoved: removed, bytesReclaimed: bytesReclaimed)
    }

    /// Snapshot reads the daemon's size index. Mount identities are cheap;
    /// sizeBytes is intentionally omitted rather than walking every view.
    public func cacheSnapshot() async throws -> SharedCacheSnapshot {
        let mounts = activeViews.map { view in
            MountInfo(
                id: view.id, src: view.source.path, viewPath: view.root.path,
                sizeBytes: 0, readonly: false, createdAt: view.createdAt)
        }.sorted { $0.src < $1.src }
        return SharedCacheSnapshot(
            cacheRoot: cacheRoot.path, measuredAt: Date(), storedBytes: store.indexedSize,
            capBytes: cacheMaxBytes, chunkCount: store.allChunkHashes().count,
            activeMounts: mounts, keepEnabled: cacheKeepEnabled,
            overCap: store.indexedSize > cacheMaxBytes, retentionWarning: cacheRetentionWarning)
    }

    public func setCacheKeepEnabled(_ enabled: Bool) async throws {
        let data = try JSONEncoder().encode(enabled)
        try data.write(to: cacheRoot.appendingPathComponent("retention.json"), options: .atomic)
        cacheKeepEnabled = enabled
        cacheRetentionWarning = nil
        cleanupReviews.removeAll()
    }

    public func reviewCacheCleanup() async throws -> SharedCacheCleanupReview {
        let now = Date()
        cleanupReviews = cleanupReviews.filter { now.timeIntervalSince($0.value.createdAt) < 300 }
        let all = store.allChunkHashes()
        let reason = try cleanupBlockedReason()
        let candidates = reason == nil ? all.filter { store.refCount(for: $0) == 0 } : []
        let id = UUID().uuidString
        // At most one current review; a newer review invalidates older UI.
        cleanupReviews.removeAll()
        if reason == nil { cleanupReviews[id] = (now, candidates) }
        return SharedCacheCleanupReview(
            id: id, createdAt: now, chunkCount: candidates.count,
            storedBytes: candidates.reduce(0) { $0 + (store.chunkSize($1) ?? 0) },
            protectedChunkCount: all.count - candidates.count, blockedReason: reason)
    }

    public func cleanReviewedCache(id: String) async throws -> GCResult {
        guard let review = cleanupReviews.removeValue(forKey: id),
            Date().timeIntervalSince(review.createdAt) < 300
        else {
            throw SharedFSError.invalidResponse("Cleanup review expired. Review the cache again.")
        }
        // These checks and deletions contain no actor suspension. A mount
        // arriving after the preview prevents cleanup of every candidate.
        if let reason = try cleanupBlockedReason() {
            throw SharedFSError.invalidResponse("Cache state changed. \(reason)")
        }
        var removed = 0
        var bytes: UInt64 = 0
        for hash in review.hashes where store.refCount(for: hash) == 0 && store.exists(hash) {
            let size = store.chunkSize(hash) ?? 0
            try store.remove(hash)
            removed += 1
            bytes += size
        }
        evictedChunksTotal += removed
        return GCResult(chunksRemoved: removed, bytesReclaimed: bytes)
    }

    /// View directories can outlive the daemon after a restart. They may
    /// still be mounted by a container, so an empty in-memory registry
    /// alone cannot authorize a manual purge. Never delete these views.
    private func cleanupBlockedReason() throws -> String? {
        if cacheKeepEnabled {
            return "Turn off Keep package cache before reviewing cleanup."
        }
        if !views.isEmpty || !sharedViews.isEmpty {
            return "Cleanup is available when all active cache mounts finish."
        }
        if try hasUntrackedViewDirectories() {
            return
                "Retained view directories may still be mounted after an agent restart. Cleanup is paused until their ownership can be verified."
        }
        return nil
    }

    private func hasUntrackedViewDirectories() throws -> Bool {
        let registered = Set(activeViews.map { $0.root.lastPathComponent })
        return try FileManager.default.contentsOfDirectory(atPath: viewsRoot.path)
            .contains { !registered.contains($0) }
    }

    // MARK: - Live sync internals (user-space, per-file, efficient)

    private func ensureWatchers(for src: URL, view: SharedView) {
        let realSrc = src.resolvingSymlinksInPath()
        let realView = view.root.resolvingSymlinksInPath()
        let key = realSrc.path
        if srcWatchers[key] == nil {
            let watcher = FSEventsWatcher(path: realSrc) { [weak self] paths in
                Task { [weak self] in await self?.handleSrcChange(paths: paths, src: realSrc) }
            }
            watcher.start()
            srcWatchers[key] = watcher
            fputs("[sharedfs] watching src \(key)\n", stderr)
        }
        let viewWatcher = FSEventsWatcher(path: realView) { [weak self] paths in
            Task { [weak self] in await self?.handleViewChange(paths: paths, view: view) }
        }
        viewWatcher.start()
        viewWatchers[view.id] = viewWatcher
        fputs("[sharedfs] watching view \(view.id.value) at \(realView.path)\n", stderr)
    }

    private func startSharedWatchers(src: URL, view: SharedView) {
        let realSrc = src.resolvingSymlinksInPath()
        let realView = view.root.resolvingSymlinksInPath()
        let key = realSrc.path
        let srcWatcher = FSEventsWatcher(path: realSrc) { [weak self] paths in
            Task { [weak self] in await self?.handleSrcChange(paths: paths, src: realSrc) }
        }
        srcWatcher.start()
        let viewWatcher = FSEventsWatcher(path: realView) { [weak self] paths in
            Task { [weak self] in await self?.handleViewChange(paths: paths, view: view) }
        }
        viewWatcher.start()
        sharedWatchers[key] = (srcWatcher, viewWatcher)
        fputs("[sharedfs] watching shared \(key) <-> \(realView.path)\n", stderr)
    }

    private func handleSrcChange(paths: [String], src: URL) async {
        let key = src.resolvingSymlinksInPath().path
        // Filter out atomic-write temp files (e.g., .sb-...) to avoid syncing
        // incomplete writes; the final file's event will arrive shortly after.
        let filtered = paths.filter {
            !$0.contains(".sb-") && !URL(fileURLWithPath: $0).lastPathComponent.hasPrefix(".")
        }
        let effective = filtered.isEmpty ? paths.filter { !$0.contains(".sb-") } : filtered
        fputs("[sharedfs] src change \(effective.first ?? "?") (\(effective.count) paths)\n", stderr)
        var targetIDs = viewsBySrc[key] ?? []
        if let shared = sharedViews[key] { targetIDs.insert(shared.id) }
        guard !targetIDs.isEmpty else { return }
        for viewID in targetIDs {
            guard let view = views[viewID] ?? sharedViews[key] else { continue }
            for changed in effective {
                synchronize(changed, viewID: view.id, fromView: false)
            }
        }
    }

    private func handleViewChange(paths: [String], view: SharedView) async {
        guard views[view.id] != nil else { return }
        let effective = paths.filter { !$0.contains(".sb-") }
        let key = view.source.resolvingSymlinksInPath().path
        let siblings = (viewsBySrc[key] ?? []).union(sharedViews[key].map { Set([$0.id]) } ?? [])
        for changed in effective {
            let propagated = synchronize(changed, viewID: view.id, fromView: true)
            // The host remains the hub. Each sibling has its own baseline;
            // applying a write to one view cannot suppress another's update.
            for siblingID in siblings where siblingID != view.id {
                for relative in propagated {
                    synchronize(view.source.appendingPathComponent(relative).path, viewID: siblingID, fromView: false)
                }
            }
        }
    }

    @discardableResult
    private func synchronize(_ path: String, viewID: ViewID, fromView: Bool) -> [String] {
        do {
            return try liveSync[viewID]?.synchronize(changedPath: path, fromView: fromView) ?? []
        } catch {
            // Leave the baseline unchanged on failure. A later event or an
            // explicit sync can retry; do not treat unreadability as deletion.
            fputs("[sharedfs] live sync deferred for view \(viewID.value)\n", stderr)
            return []
        }
    }

    /// Returns the set of chunk hashes a view's file contents resolve to,
    /// used for refcounted GC. The per-view tree is built from cloned chunks
    /// so the mapping is chunk→view; we walk and hash to recompute.
    private func chunksInUse(view: URL) -> Set<String> {
        var chunks: Set<String> = []
        var unreadable = false
        guard
            let enumerator = FileManager.default.enumerator(
                at: view, includingPropertiesForKeys: [.isRegularFileKey],
                options: [],
                errorHandler: { _, _ in
                    unreadable = true
                    return false
                })
        else { return Set(store.allChunkHashes().map(\.value)) }
        for case let url as URL in enumerator {
            do {
                guard try url.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile == true else { continue }
                let handle = try FileHandle(forReadingFrom: url)
                defer { try? handle.close() }
                // Match ingestFile's chunk boundaries, including hidden
                // package-manager data and files larger than one block.
                while let block = try handle.read(upToCount: store.blockSize), !block.isEmpty {
                    chunks.insert(try ChunkHash.compute(block).value)
                }
            } catch {
                unreadable = true
                break
            }
        }
        // An incomplete inventory cannot prove which chunks are unused.
        if unreadable { return Set(store.allChunkHashes().map(\.value)) }
        return chunks
    }
}
