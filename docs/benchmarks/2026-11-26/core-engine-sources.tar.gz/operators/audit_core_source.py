import hashlib
import json
import pathlib
import subprocess
import tarfile
import tempfile

root = pathlib.Path.cwd()
receipts = pathlib.Path('/private/tmp/mp-gamma.EuQue2/receipts')
bundle = root / 'bench/phase0-host-scheduling/docs/benchmarks/2026-11-26/core-engine-sources.tar.gz'
with tarfile.open(bundle) as src, tempfile.TemporaryDirectory(dir=receipts.parent / 'home', prefix='qa-rebuild-') as scratch:
    m = json.load(src.extractfile('manifest.json'))
    work = pathlib.Path(scratch)
    subprocess.run(['git', 'init', '-q'], cwd=work, check=True)
    entries = {p[5:]: h for p, h in m['sha256'].items() if p.startswith('core/')}
    for rel in entries:
        ref = m['outer_head'] + ':' + rel
        if subprocess.run(['git','cat-file','-e',ref], cwd=root, capture_output=True).returncode:
            continue
        dst = work / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(subprocess.check_output(['git','show',ref],cwd=root))
        mode = subprocess.check_output(['git','ls-tree',m['outer_head'],'--',rel],cwd=root).split()[0]
        if mode == b'100755':
            dst.chmod(0o755)
    patch = src.extractfile('core-changes.patch').read()
    for flags in (['--check'], []):
        subprocess.run(['git','apply','--binary',*flags,'-'],cwd=work,input=patch,check=True)
    for rel, sha in entries.items():
        assert hashlib.sha256((work / rel).read_bytes()).hexdigest() == sha, rel
    result = {'verified_files': len(entries), 'base': m['outer_head'],
              'archive_sha256': hashlib.sha256(bundle.read_bytes()).hexdigest(), 'patch_applied': True}
(receipts / 'core-rebuild-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
