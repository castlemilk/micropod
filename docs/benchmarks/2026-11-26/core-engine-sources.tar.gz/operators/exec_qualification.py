"""Compare the two Micropod CLI builds and stock Docker on an already owned container."""
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import re
import select
import signal
import statistics
import subprocess
import tempfile
import threading
import time
import uuid

def digest(buf):
    return hashlib.sha256(buf).hexdigest()

class Client:
    def __init__(self, binary, container, env, docker=False):
        self.binary, self.container, self.env, self.docker = str(binary), container, env, docker

    def argv(self, args, interactive=False):
        return [self.binary, 'exec'] + (['-i'] if interactive else []) + [self.container] + ([] if self.docker else ['--']) + list(args)

    def run(self, args, data=None, timeout=15):
        return subprocess.run(self.argv(args, data is not None), input=data, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, env=self.env, timeout=timeout)

    def popen(self, args, interactive=False):
        return subprocess.Popen(self.argv(args, interactive), stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, env=self.env, bufsize=0)

def summary(proc, out, err):
    return dict(exit=proc.returncode, stdout_bytes=len(out), stderr_bytes=len(err), stdout_sha256=digest(out), stderr_sha256=digest(err))

def gate(client, stock):
    marker = '/tmp/mp-exec-gate-' + uuid.uuid4().hex
    cmd = ['sh', '-c', 'printf ready; while [ ! -e "$1" ]; do sleep 0.02; done; printf done >&2; rm -f "$1"; exit 31','sh',marker]
    p = client.popen(cmd)
    early = b''
    try:
        if select.select([p.stdout], [], [], 1.5)[0]:
            early = os.read(p.stdout.fileno(), 5)
        stock.run(['touch', marker]).check_returncode()
        out, err = p.communicate(timeout=8)
        return dict(before_release=early.decode(errors='replace'), passed=early == b'ready' and out == b'' and
                    err == b'done' and p.returncode == 31, **summary(p,early+out,err))
    finally:
        if p.poll() is None:
            p.kill()
            p.wait()
        stock.run(['rm','-f',marker])

def early_exit(client):
    p = client.popen(['sh','-c','printf early; exit 19'], True)
    try:
        p.wait(timeout=4)
        out, err = p.stdout.read(), p.stderr.read()
        return dict(passed=(p.returncode,out,err)==(19,b'early',b''), **summary(p,out,err))
    finally:
        if p.poll() is None:
            p.kill()
            p.wait()
        for stream in (p.stdin,p.stdout,p.stderr):
            stream.close()

def vectors(client):
    a,b = bytes(range(256))*4097, bytes(reversed(range(256)))*37
    trials = []
    for args,data,out,err,code in [
        (['sh','-c',r'printf "\000\377\200Z"; printf "\375\000e" >&2; exit 37'],None,bytes([0,255,128,90]),bytes([253,0,101]),37),
        (['sh','-c','tee /dev/stderr; exit 27'],a,a,a,27),
        (['sh','-c','cat; printf eof >&2'],b'',b'',b'eof',0),
        (['sh','-c','cat >&2; printf after'],b,b'after',b,0),
    ]:
        p=client.run(args,data)
        trials.append(dict(passed=(p.returncode,p.stdout,p.stderr)==(code,out,err),expected_out=digest(out),
                           expected_err=digest(err),**summary(p,p.stdout,p.stderr)))
    return trials

def burst(client):
    def one(i):
        datum = bytes([i,255,0,128]) * 18000
        p=client.run(['sh','-c',f'cat; printf "job{i}" >&2; exit {i+10}'],datum)
        return (p.returncode,p.stdout,p.stderr)==(i+10,datum,f'job{i}'.encode())
    with concurrent.futures.ThreadPoolExecutor(8) as pool:
        return list(pool.map(one, range(8)))

def backpressure(client):
    # Fill both directions before either final EOF. The reader deliberately drains slowly.
    datum=bytes(range(256))*8192
    p=client.popen(['sh','-c','dd if=/dev/zero bs=65536 count=32 2>/dev/null; cat; printf drained >&2'],True)
    out=hashlib.sha256()
    def write():
        try:
            with p.stdin:
                view=memoryview(datum)
                while view:
                    size=os.write(p.stdin.fileno(),view[:65536])
                    view=view[size:]
        except BrokenPipeError:
            pass
    writer=threading.Thread(target=write,daemon=True)
    writer.start()
    total=0
    try:
        until=time.monotonic()+15
        while time.monotonic()<until and select.select([p.stdout],[],[],max(0,until-time.monotonic()))[0]:
            chunk=os.read(p.stdout.fileno(),65536)
            if not chunk: break
            total+=len(chunk)
            out.update(chunk)
            time.sleep(0.001)
        p.wait(timeout=3)
        writer.join(2)
        err=p.stderr.read()
        return dict(passed=p.returncode==0 and total==len(datum)*2 and out.hexdigest()==digest(bytes(len(datum))+datum)
                    and err==b'drained' and not writer.is_alive(),bytes=total,sha256=out.hexdigest(),exit=p.returncode)
    finally:
        if p.poll() is None:
            p.kill()
            p.wait()
        writer.join(2)
        p.stdout.close()
        p.stderr.close()

def measure(client,size,directory):
    with tempfile.NamedTemporaryFile(dir=directory) as receipt:
        args=['/usr/bin/time','-lp','-o',receipt.name]+client.argv(['sh','-c',f'dd if=/dev/zero bs=65536 count={size*16} 2>/dev/null'])
        begin=time.monotonic()
        p=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,env=client.env,start_new_session=True)
        try:
            _,stderr = p.communicate(timeout=12)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGTERM)
            try: p.communicate(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid,signal.SIGKILL)
                p.communicate(timeout=2)
            raise RuntimeError('Timed output did not finish in 12 seconds; private process group retired')
        elapsed=(time.monotonic()-begin)*1000
        report=Path(receipt.name).read_text()
        rss=re.search(r'^\s*(\d+)\s+maximum resident set size',report,re.M)
        return dict(mib=size,ms=round(elapsed,3),max_rss_bytes=int(rss[1]) if rss else None,exit=p.returncode,stderr=stderr.decode(errors='replace'))

def protect(fn,*args):
    try: return fn(*args)
    except Exception as e: return dict(passed=False,error=repr(e))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--hold',type=Path,required=True)
    parser.add_argument('--baseline',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--orb-host')
    args=parser.parse_args()
    owned=json.loads(args.hold.read_text())
    e=owned['environment']
    target=owned['canary']
    if args.orb_host:
        e=dict(e,DOCKER_HOST=args.orb_host,MICROPOD_HVF_ROOT=str(Path(owned['scope'])/'unused-hvf'),
               MICROPOD_RUNTIMES_CONFIG=str(Path(owned['scope'])/'unused-config'),MICROPOD_DEFAULT_RUNTIME='docker')
    stock=Client('/opt/homebrew/bin/docker',target,e,True)
    if args.orb_host:
        target='mp-exec-qual-'+uuid.uuid4().hex[:12]
        stock.container=target
        subprocess.run([stock.binary,'run','--detach','--pull=never','--name',target,'--label','micropod.qa=exec-stream',
                        'alpine:3.23','sleep','600'],env=e,capture_output=True,timeout=30,check=True)
    c={'previous':Client(args.baseline,target,e),'streaming':Client(e['MICROPOD_CLI'],target,e),'stock_docker':stock}
    result={'host':e['DOCKER_HOST'],'container':target,'semantics':{},'measurements':{},'measurement_unit':'one host CLI process',
            'benchmark_output':'/dev/null','versions':{k:dict(binary=v.binary,sha256=digest(Path(v.binary).read_bytes())) for k,v in c.items()}}
    try:
        for name,client in c.items():
            s={'gate':protect(gate,client,stock),'vectors':protect(vectors,client),'open_stdin_remote_exit':protect(early_exit,client),
               'concurrent_8':protect(burst,client),'duplex_backpressure':protect(backpressure,client)}
            result['semantics'][name]=s
            print(name,'gate',s['gate'],'concurrent',s['concurrent_8'],flush=True)
        for size in (4,32):
            samples={name:[] for name in c}
            for rep in range(3):
                order=list(c)
                for name in order[rep:]+order[:rep]:
                    samples[name].append(protect(measure,c[name],size,owned['scope']))
            result['measurements'][str(size)]=samples
        args.out.write_text(json.dumps(result,indent=2)+'\n')
    finally:
        if args.orb_host:
            subprocess.run([stock.binary,'rm','-f',target],env=e,check=True,stdout=subprocess.DEVNULL,timeout=20)
if __name__=='__main__':
    main()
