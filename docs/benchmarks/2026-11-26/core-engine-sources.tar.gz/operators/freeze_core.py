import gzip, hashlib, io, json, subprocess, tarfile
from pathlib import Path

root=Path.cwd().resolve()
w=root/'bench/phase0-host-scheduling'
s=Path('/private/tmp/mp-gamma.EuQue2/receipts')
out=w/'docs/benchmarks/2026-11-26'
files=['Package.swift','README.md','Sources/CPtyShim/exec_sink.c','Sources/CPtyShim/include/exec_sink.h','Sources/CPtyShim/include/pty_shim.h','Sources/MicropodCLI/ContainerCommands.swift','Sources/MicropodCore/Services/ContainerService.swift',
       *['Sources/MicropodRuntime/Engines/'+p+'.swift' for p in ['DockerAPINegotiation','DockerClient','DockerEngine','DockerExecAttachment','DockerTCPConnection','HVFEngine','RuntimeEngines']],
       'Tests/MicropodRuntimeTests/DockerExecTests.swift','Tests/MicropodRuntimeTests/RuntimeEngineTests.swift','Tests/MicropodRuntimeTests/DockerTCPConnectionTests.swift',
       'ci/pinned-checkout-job.sh','ci/pinned-checkout-job.md']
bits={};patch=bytearray()
def add(label,path):bits[label]=path.read_bytes()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for file in files:
    add('core/'+file,root/file)
    tracked=subprocess.run(['git','ls-files','--error-unmatch','--',file],capture_output=True).returncode==0
    args=['git','diff','--binary',head,'--',file] if tracked else ['git','diff','--binary','--no-index','--','/dev/null',file]
    p=subprocess.run(args,capture_output=True)
    assert p.returncode in (0,1),p.stderr
    patch.extend(p.stdout)
bits['core-changes.patch']=bytes(patch)
for file in ['Package.swift','Package.resolved','signing/micropod-cli.entitlements']:add('core/'+file,root/file)
for file in ['scripts/qualify_cli_exec_density.py','ci/patches/virtiofs-sync-lookup.patch','ci/patches/build-virtiofs-sync-lookup-kernel.sh',
             'guest/runner/docker_http_linux.go','guest/runner/docker_http_linux_test.go']:
    add('bench/'+file,w/file)
for file in ['outer_machine_proof.py','outer_stream_machine.py','outer_negotiated_machine.py','exec_qualification.py',
             'qualify_negotiated.py','outer_release_machine.py','qualify_release.py','prepare_release_proof.py','freeze_core.py','prepare_fixed.py','qualify_fixed.py','outer_fixed_machine.py','repeat_output_only.py','recover_release_scope.py','exec_qualification_initial.py','summarize_core.py','audit_core_source.py']:
    add('operators/'+file,s/file)
meta={'outer_head':head,'bench_head':subprocess.check_output(['git','-C',str(w),'rev-parse','HEAD'],text=True).strip(),
      'swift':subprocess.check_output(['xcrun','swift','--version'],text=True).strip(),'sha256':{k:hashlib.sha256(v).hexdigest() for k,v in bits.items()}}
bits['manifest.json']=(json.dumps(meta,indent=2)+'\n').encode()
name=out/'core-engine-sources.tar.gz'
with name.with_suffix('.tmp').open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w|') as archive:
    for k,v in sorted(bits.items()):
        t=tarfile.TarInfo(k); t.size=len(v);t.mode=0o755 if k.endswith(('.py','.sh')) else 0o644
        archive.addfile(t,io.BytesIO(v))
name.with_suffix('.tmp').replace(name)
with tarfile.open(name) as check:
    for k,h in meta['sha256'].items():
        assert hashlib.sha256(check.extractfile(k).read()).hexdigest()==h,k
(s/'core-source-freeze.json').write_text(json.dumps({'archive':str(name),'sha256':hashlib.sha256(name.read_bytes()).hexdigest(),'members':len(bits),'outer_head':head},indent=2)+'\n')
