import json, os, plistlib, shutil, signal, subprocess, sys, tarfile
from argparse import Namespace
from pathlib import Path
import outer_machine_proof as proof

mount = Path('/private/tmp/mp-gamma.EuQue2/home')
logs = mount.parent / 'receipts/core-negotiated-machine'
repo = Path.cwd()
src = Path(os.path.expanduser('~/.micropod/sandbox/images/sha256-469c9ea410b9215eaee7976ba6c0639039b444be8e5d638f7abbada189971eb2-4g.ext4'))
args = Namespace(mount=mount, repo=repo, disk_base=src, output=logs, hold=True)
os.umask(0o077)
p = proof.Proof(args)
try:
    p.result['volume'] = proof.volume_identity(mount)
    disk = p.result['volume']
    assert (mount / '.fseventsd/no_log').is_file() and (mount / '.metadata_never_index').is_file()
    p.result['spotlight'] = subprocess.check_output(['mdutil', '-s', str(mount)], text=True)
    assert 'disabled' in p.result['spotlight'].lower() or 'kMDConfigSearchLevelFSSearchOnly' in p.result['spotlight']
    p.result['defaults_before'] = proof.default_state(Path.home())
    p.result['outside_processes_before'] = proof.outside_processes(proof.process_table())
    p.result['base_input_before'] = proof.identity(src)
    base = p.scope / 'base.ext4'
    p.run('/bin/cp', '-p', src, base, timeout=60, label='copy closed disposable Alpine base')
    base.chmod(0o400)
    p.run('/bin/cp', '-p', repo / '.build/debug/micropod', p.binary, label='freeze CLI')
    for bundle in (repo / '.build/debug').glob('*.bundle'):
        if bundle.name != 'Micropod_MicropodApp.bundle':
            shutil.copytree(bundle, p.scope / bundle.name, symlinks=True)
    p.run('/usr/bin/codesign', '--force', '--sign', '-', '--entitlements', repo / 'signing/micropod-cli.entitlements', p.binary, label='sign development CLI')
    p.signature(p.binary, 'signed CLI')
    p.result['cli_sha256'] = proof.hash_file(p.binary)
    assets = mount / 'artifacts'
    vmm = assets / 'current-source/target/release/micropod-vmm'
    initrd = assets / 'current-source/target/mp-hvf-init.cpio'
    p.run(p.binary, 'machine','install','--vmm',vmm,'--kernel',assets/'Image','--initrd',initrd,'--tools',assets/'micropod-oci-tools',
          '--disk-from',base,'--cpus','4','--memory-mib','4096','--workspace',p.workspace,timeout=65,label='install private machine')
    p.seed = assets / 'seed.tar'
    p.start()
    p.run(p.binary, 'runtime','enable','hvf', label='enable scoped HVF')
    p.run(p.binary, 'run','--runtime','hvf','--name',p.name,'alpine:3.23','--','sleep','1800', label='native CLI creates probe container')
    p.wait_for_release()
except BaseException as exc:
    p.result['errors']['operation'] = repr(exc)
    print(repr(exc), file=sys.stderr, flush=True)
finally:
    try:
        p.stop_and_remove()
    except BaseException as exc:
        p.result['errors']['cleanup'] = repr(exc)
    proof.record(logs.with_suffix('.json'),p.result)
    print('errors',p.result['errors'],flush=True)
sys.exit(bool(p.result['errors']))
