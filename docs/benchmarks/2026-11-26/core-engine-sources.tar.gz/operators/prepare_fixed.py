from pathlib import Path
s=Path('/private/tmp/mp-gamma.EuQue2/receipts')
for source,target in [('outer_release_machine.py','outer_fixed_machine.py'),('qualify_release.py','qualify_fixed.py')]:
    text=(s/source).read_text().replace('core-release-','core-fixed-').replace('core-debug-current-','core-fixed-debug-')
    if target=='qualify_fixed.py':
        anchor="    h=hashlib.file_digest(client.open('rb'),'sha256').hexdigest()"
        checks="""    for suffix in ['debug-HVF','debug-Orb','CLI-HVF','CLI-Orb']:
        receipt=json.loads((s/('core-fixed-'+suffix+'.json')).read_text())
        for arm,tests in receipt['semantics'].items():
            if arm=='previous': continue
            for key,val in tests.items():
                rows=val if isinstance(val,list) else [val]
                assert all((item if isinstance(item,bool) else item.get('passed')) for item in rows),(suffix,arm,key,val)
        for size,arms in receipt['measurements'].items():
            assert all(row.get('exit')==0 for rows in arms.values() for row in rows),(suffix,size,arms)
    subprocess.run([sys.executable,'-B',str(s/'repeat_output_only.py'),'--hold',str(hold),'--output',str(s/'core-fixed-output-only.json')],check=True,timeout=135)
"""
        assert anchor in text
        text=text.replace(anchor,checks+anchor)
    (s/target).write_text(text)
