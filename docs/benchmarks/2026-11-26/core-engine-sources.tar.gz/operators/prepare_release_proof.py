from pathlib import Path
s=Path('/private/tmp/mp-gamma.EuQue2/receipts')
src=(s/'outer_stream_machine.py').read_text()
(s/'outer_release_machine.py').write_text(src.replace("'receipts/core-machine'","'receipts/core-release-machine'").replace(".build/debug",".build/release"))
src=(s/'qualify_negotiated.py').read_text()
src=src.replace("'core-negotiated-machine","'core-release-machine").replace("'core-final-CLI","'core-release-CLI").replace("'core-final-qualified.json'","'core-release-qualified.json'").replace("'core-negotiated-generic-on-HVF.json'","'core-release-generic-on-HVF.json'")
src=src.replace("('micropod-stream-'+h[:12])","('micropod-release-'+h[:12])")
# The held machine supplies the private supervisor and a protected directory for outputs.
anchor="    with (s/'core-release-CLI-HVF.log').open('w') as log:"
insert="""    from shutil import copy2, copytree
    dev = scope/'development'
    dev.mkdir()
    debug_binary = dev/'micropod'
    copy2(Path.cwd()/'.build/debug/micropod', debug_binary)
    for bundle in (Path.cwd()/'.build/debug').glob('*.bundle'):
        if bundle.name != 'Micropod_MicropodApp.bundle':
            copytree(bundle, dev/bundle.name, symlinks=True)
    subprocess.run(['codesign','-f','-s','-','--entitlements','signing/micropod-cli.entitlements',str(debug_binary)],check=True)
    subprocess.run(['codesign','--verify','--strict',str(debug_binary)],check=True)
    debug_hold = dict(owned, environment=dict(env,MICROPOD_CLI=str(debug_binary)))
    debug_info = scope/'debug-hold.json'
    debug_info.write_text(json.dumps(debug_hold))
    debug_args = [sys.executable, '-B', str(s/'exec_qualification.py'), '--hold', str(debug_info), '--baseline', baseline]
    for key,extra in [('HVF',[]),('Orb',['--orb-host','unix:///Users/benebsworth/.orbstack/run/docker.sock'])]:
        with (s/f'core-debug-current-{key}.log').open('w') as log:
            subprocess.run(debug_args+extra+['--out',str(s/f'core-debug-current-{key}.json')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=140)
    density = Path.cwd()/'bench/phase0-host-scheduling/scripts/qualify_cli_exec_density.py'
    density_env = dict(os.environ,TMPDIR=str(scope/'tmp'))
    with (s/'core-release-density.log').open('w') as log:
        subprocess.run([sys.executable,'-B',str(density),'--cli',str(client),'--hvf-root',env['MICROPOD_HVF_ROOT'],
                        '--orbstack-host','unix:///Users/benebsworth/.orbstack/run/docker.sock',
                        '--output',str(s/'core-release-density.json')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=210,env=density_env)
"""
src=src.replace(anchor,insert+anchor)
(s/'qualify_release.py').write_text(src)
