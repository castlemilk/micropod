import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path

s=Path('/private/tmp/mp-gamma.EuQue2/receipts')
hold=s/'core-fixed-machine-hold.json'
deadline=time.monotonic()+75
while not hold.exists() and time.monotonic()<deadline:
    if (s/'core-fixed-machine.json').exists(): break
    time.sleep(.2)
owned=json.loads(hold.read_text())
scope=Path(owned['scope'])
env=dict(owned['environment'])
supervisor_binary=Path(env['MICROPOD_CLI'])
client_dir=scope/'qualified-client'
client_dir.mkdir(mode=0o700)
client=client_dir/'micropod'
shutil.copy2(Path.cwd()/'.build/release/micropod',client)
for bundle in (Path.cwd()/'.build/release').glob('*.bundle'):
    if bundle.name!='Micropod_MicropodApp.bundle':
        shutil.copytree(bundle,client_dir/bundle.name,symlinks=True)
subprocess.run(['codesign','-f','-s','-','--entitlements','signing/micropod-cli.entitlements',str(client)],check=True)
subprocess.run(['codesign','--verify','--strict',str(client)],check=True)
env['MICROPOD_CLI']=str(client)
owned=dict(owned,environment=env)
hold=scope/'qualified-client-hold.json'
hold.write_text(json.dumps(owned))
(s/'core-fixed-client-role.json').write_text(json.dumps({'supervisor':str(supervisor_binary),'supervisor_sha':hashlib.file_digest(supervisor_binary.open('rb'),'sha256').hexdigest(),
 'tested_cli':str(client),'cli_sha':hashlib.file_digest(client.open('rb'),'sha256').hexdigest()},indent=2)+'\n')
baseline=str((Path.cwd()/'.build/qualified/micropod-exec-49c9db5e9245/micropod').resolve())
args=[sys.executable,'-B',str(s/'exec_qualification.py'),'--hold',str(hold),'--baseline',baseline]
def call(argv,e):
    p=subprocess.run(argv,env=e,capture_output=True,timeout=20)
    return {'argv':list(map(str,argv)),'exit':p.returncode,'out':p.stdout.hex(),'err':p.stderr.hex()}
try:
    from shutil import copy2, copytree
    dev = scope/'development'
    dev.mkdir()
    debug_binary = dev/'micropod'
    copy2(Path.cwd()/'.build/debug/micropod', debug_binary)
    for bundle in (Path.cwd()/'.build/debug').glob('*.bundle'):
        if bundle.name != 'Micropod_MicropodApp.bundle':
            copytree(bundle, dev/bundle.name, symlinks=True)
    subprocess.run(['codesign','-f','-s','-','--entitlements','signing/micropod-cli.entitlements',str(debug_binary)],check=True)
    subprocess.run(['codesign','--verify','--strict',str(debug_binary)],check=True)
    debug_hold = dict(owned, environment=dict(env,MICROPOD_CLI=str(debug_binary)))
    debug_info = scope/'debug-hold.json'
    debug_info.write_text(json.dumps(debug_hold))
    debug_args = [sys.executable, '-B', str(s/'exec_qualification.py'), '--hold', str(debug_info), '--baseline', baseline]
    for key,extra in [('HVF',[]),('Orb',['--orb-host','unix:///Users/benebsworth/.orbstack/run/docker.sock'])]:
        with (s/f'core-fixed-debug-{key}.log').open('w') as log:
            subprocess.run(debug_args+extra+['--out',str(s/f'core-fixed-debug-{key}.json')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=140)
    density = Path.cwd()/'bench/phase0-host-scheduling/scripts/qualify_cli_exec_density.py'
    density_env = dict(os.environ,TMPDIR=str(scope/'tmp'))
    with (s/'core-fixed-density.log').open('w') as log:
        subprocess.run([sys.executable,'-B',str(density),'--cli',str(client),'--hvf-root',env['MICROPOD_HVF_ROOT'],
                        '--orbstack-host','unix:///Users/benebsworth/.orbstack/run/docker.sock',
                        '--output',str(s/'core-fixed-density.json')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=210,env=density_env)
    with (s/'core-fixed-CLI-HVF.log').open('w') as log:
        subprocess.run(args+['--out',str(s/'core-fixed-CLI-HVF.json')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=140)
    e=dict(env,MICROPOD_DEFAULT_RUNTIME='docker',MICROPOD_HVF_ROOT=str(scope/'unused-hvf'),MICROPOD_RUNTIMES_CONFIG=str(scope/'docker-only.json'))
    target=owned['canary']
    command=['exec',target,'--','sh','-c',r'printf "\000\377"; printf "\376Z" >&2; exit 29']
    results={'original_forced_143':call([baseline]+command,e),
       'negotiated':call([client]+command,e),
       'pinned_144':call([client]+command,dict(e,DOCKER_API_VERSION='1.44')),
       'server':call(['/usr/bin/curl','--silent','--unix-socket',e['DOCKER_HOST'].removeprefix('unix://'),'http://docker/version'],e)}
    with (s/'core-fixed-generic-on-HVF.json').open('w') as out: json.dump(results,out,indent=2)
    assert all((r['exit'],r['out'],r['err'])==(29,'00ff','fe5a') for r in (results['negotiated'],results['pinned_144'])),results
    with (s/'core-fixed-CLI-Orb.log').open('w') as log:
        subprocess.run(args+['--orb-host','unix:///Users/benebsworth/.orbstack/run/docker.sock','--out',str(s/'core-fixed-CLI-Orb.json')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=140)
    for suffix in ['debug-HVF','debug-Orb','CLI-HVF','CLI-Orb']:
        receipt=json.loads((s/('core-fixed-'+suffix+'.json')).read_text())
        for arm,tests in receipt['semantics'].items():
            if arm=='previous': continue
            for key,val in tests.items():
                rows=val if isinstance(val,list) else [val]
                assert all((item if isinstance(item,bool) else item.get('passed')) for item in rows),(suffix,arm,key,val)
        for size,arms in receipt['measurements'].items():
            assert all(row.get('exit')==0 for rows in arms.values() for row in rows),(suffix,size,arms)
    subprocess.run([sys.executable,'-B',str(s/'repeat_output_only.py'),'--hold',str(hold),'--output',str(s/'core-fixed-output-only.json')],check=True,timeout=135)
    h=hashlib.file_digest(client.open('rb'),'sha256').hexdigest()
    dest=Path.cwd()/'.build/qualified'/('micropod-release-'+h[:12])
    dest.mkdir(mode=0o700,exist_ok=True)
    if not (dest/'micropod').exists(): shutil.copy2(client,dest/'micropod')
    for b in client_dir.glob('*.bundle'):
        if not (dest/b.name).exists(): shutil.copytree(b,dest/b.name,symlinks=True)
    assert hashlib.file_digest((dest/'micropod').open('rb'),'sha256').hexdigest()==h
    subprocess.run(['codesign','--verify','--strict',str(dest/'micropod')],check=True)
    ref={'binary':str(dest/'micropod'),'sha256':h,'reference_cli':baseline}
    (s/'core-fixed-qualified.json').write_text(json.dumps(ref,indent=2)+'\n')
    print(h)
finally:
    assert scope.parent==s.parent/'home' and scope.name.startswith('outer-machine-')
    Path(owned['release_file']).touch(exist_ok=False)
