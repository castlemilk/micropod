import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path

s=Path('/private/tmp/mp-gamma.EuQue2/receipts')
hold=s/'core-negotiated-machine-hold.json'
deadline=time.monotonic()+75
while not hold.exists() and time.monotonic()<deadline:
    if (s/'core-negotiated-machine.json').exists(): break
    time.sleep(.2)
owned=json.loads(hold.read_text())
scope=Path(owned['scope'])
env=owned['environment']
client=Path(env['MICROPOD_CLI'])
baseline=str((Path.cwd()/'.build/qualified/micropod-exec-49c9db5e9245/micropod').resolve())
args=[sys.executable,'-B',str(s/'exec_qualification.py'),'--hold',str(hold),'--baseline',baseline]
def call(argv,e):
    p=subprocess.run(argv,env=e,capture_output=True,timeout=20)
    return {'argv':list(map(str,argv)),'exit':p.returncode,'out':p.stdout.hex(),'err':p.stderr.hex()}
try:
    with (s/'core-final-CLI-HVF.log').open('w') as log:
        subprocess.run(args+['--out',str(s/'core-final-CLI-HVF.json')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=140)
    e=dict(env,MICROPOD_DEFAULT_RUNTIME='docker',MICROPOD_HVF_ROOT=str(scope/'unused-hvf'),MICROPOD_RUNTIMES_CONFIG=str(scope/'docker-only.json'))
    target=owned['canary']
    command=['exec',target,'--','sh','-c',r'printf "\000\377"; printf "\376Z" >&2; exit 29']
    results={'original_forced_143':call([baseline]+command,e),
       'negotiated':call([client]+command,e),
       'pinned_144':call([client]+command,dict(e,DOCKER_API_VERSION='1.44')),
       'server':call(['/usr/bin/curl','--silent','--unix-socket',e['DOCKER_HOST'].removeprefix('unix://'),'http://docker/version'],e)}
    with (s/'core-negotiated-generic-on-HVF.json').open('w') as out: json.dump(results,out,indent=2)
    assert all((r['exit'],r['out'],r['err'])==(29,'00ff','fe5a') for r in (results['negotiated'],results['pinned_144'])),results
    with (s/'core-final-CLI-Orb.log').open('w') as log:
        subprocess.run(args+['--orb-host','unix:///Users/benebsworth/.orbstack/run/docker.sock','--out',str(s/'core-final-CLI-Orb.json')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=140)
    h=hashlib.file_digest(client.open('rb'),'sha256').hexdigest()
    dest=Path.cwd()/'.build/qualified'/('micropod-stream-'+h[:12])
    dest.mkdir(mode=0o700,exist_ok=True)
    if not (dest/'micropod').exists(): shutil.copy2(client,dest/'micropod')
    for b in scope.glob('*.bundle'):
        if not (dest/b.name).exists(): shutil.copytree(b,dest/b.name,symlinks=True)
    assert hashlib.file_digest((dest/'micropod').open('rb'),'sha256').hexdigest()==h
    subprocess.run(['codesign','--verify','--strict',str(dest/'micropod')],check=True)
    ref={'binary':str(dest/'micropod'),'sha256':h,'reference_cli':baseline}
    (s/'core-final-qualified.json').write_text(json.dumps(ref,indent=2)+'\n')
    print(h)
finally:
    assert scope.parent==s.parent/'home' and scope.name.startswith('outer-machine-')
    Path(owned['release_file']).touch(exist_ok=False)
