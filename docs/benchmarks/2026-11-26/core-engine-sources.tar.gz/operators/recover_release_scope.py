import fcntl,json,os,signal,shutil,subprocess,time
from pathlib import Path
import outer_machine_proof as proof
s=Path('/private/tmp/mp-gamma.EuQue2/receipts')
out=s/'core-release-machine.json'
r=json.loads(out.read_text())
hold=json.loads((s/'core-release-machine-hold.json').read_text())
scope=Path(hold['scope'])
assert r['scope']==str(scope) and scope.parent==s.parent/'home' and scope.name.startswith('outer-machine-')
assert not scope.is_symlink() and scope.stat().st_dev==scope.parent.stat().st_dev
assert proof.volume_identity(scope.parent)['VolumeUUID']==r['volume']['VolumeUUID']
before=proof.process_table()
target=7662
owned=proof.scoped_processes(before,scope)
assert list(owned)==[target],owned
row=owned[target]
assert row['start']=='Thu Nov 26 02:59:12 2026' and row['parent']==1 and row['command'].startswith(str(scope/'development/micropod')+' exec mp-exec-qual-a94bca77b750 ')
shutil.copyfile(out,s/'core-release-machine-initial-cleanup.json')
os.kill(target,signal.SIGTERM)
until=time.monotonic()+5
while time.monotonic()<until and proof.process_table().get(target,{}).get('start')==row['start']:
 time.sleep(.05)
assert not proof.scoped_processes(proof.process_table(),scope)
status=json.loads(subprocess.check_output([hold['environment']['MICROPOD_CLI'],'--json','machine','status'],env=hold['environment']))
assert status['phase']=='stopped' and not status['supervisorAlive'] and status['state']['lastExitCode']==0
assert 'exit_reason=poweroff' in status['state']['lastExitReason']
r['status_stopped']=status
socket=scope/'machine/run/docker.sock'
assert not socket.exists() and not socket.is_symlink()
with (scope/'machine/run/supervisor.lock').open('r') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(lock,fcntl.LOCK_UN)
r.update(socket_removed=True,clean_shutdown=True,supervisor_lock_released=True,scoped_processes_after_stop={})
r['defaults_after']=proof.default_state(Path.home())
r['defaults_unchanged']=r['defaults_before']==r['defaults_after']
base=Path.home()/'.micropod/sandbox/images/sha256-469c9ea410b9215eaee7976ba6c0639039b444be8e5d638f7abbada189971eb2-4g.ext4'
r['base_input_after']=proof.identity(base)
r['base_input_unchanged']=r['base_input_after']==r['base_input_before']
assert r['defaults_unchanged'] and r['base_input_unchanged']
r['recovery']={'pid':target,'command':row['command'],'start':row['start'],'sample':'core-timed-out-client.sample','signal':'SIGTERM',
               'initial_cleanup_error':r['errors'].pop('cleanup')}
shutil.rmtree(scope)
r['scope_removed']=not scope.exists()
proof.record(out,r)
print(r['scope_removed'],r['errors'])
