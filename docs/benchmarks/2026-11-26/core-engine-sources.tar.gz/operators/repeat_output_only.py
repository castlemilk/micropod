import argparse,json,os,signal,subprocess,time,uuid
from pathlib import Path

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--hold',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    h=json.loads(args.hold.read_text()); e=h['environment']
    cli=Path(e['MICROPOD_CLI'])
    runs={}
    for backend,host in [('hvf',e['DOCKER_HOST']),('orb','unix:///Users/benebsworth/.orbstack/run/docker.sock')]:
        env=dict(e,DOCKER_HOST=host,MICROPOD_DEFAULT_RUNTIME='docker',MICROPOD_RUNTIMES_CONFIG=str(Path(h['scope'])/'generic.json'),
                 MICROPOD_HVF_ROOT=str(Path(h['scope'])/'unused-hvf'))
        name='mp-eof-'+uuid.uuid4().hex[:12]
        docker='/opt/homebrew/bin/docker'
        checked=lambda cmd:subprocess.run(cmd,env=env,check=True,timeout=20,capture_output=True)
        checked([docker,'run','--detach','--pull=never','--label','micropod.qa=exec-eof','--name',name,'alpine:3.23','sleep','180'])
        records=[]
        try:
            for number in range(24):
                start=time.monotonic()
                proc=subprocess.Popen([str(cli),'exec',name,'--','sh','-c','dd if=/dev/zero bs=65536 count=512 2>/dev/null'],env=env,
                                      stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,start_new_session=True)
                try:
                    _,err=proc.communicate(timeout=6)
                    records.append({'run':number+1,'ms':round((time.monotonic()-start)*1000,3),'exit':proc.returncode,'stderr':err.decode(errors='replace')})
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid,signal.SIGKILL)
                    proc.communicate()
                    records.append({'run':number+1,'timeout':6})
                    break
        finally:
            checked([docker,'rm','-f',name])
            runs[backend]={'runs':records,'cleaned':True,'payload_bytes_per_run':33554432}
            args.output.write_text(json.dumps(runs,indent=2)+'\n')
    assert all(len(row['runs'])==24 and all(run.get('exit')==0 for run in row['runs']) for row in runs.values())
if __name__=='__main__':main()
