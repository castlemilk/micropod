import hashlib,json,re,statistics,tarfile
from pathlib import Path
s=Path('/private/tmp/mp-gamma.EuQue2/receipts')
w=Path.cwd()/'bench/phase0-host-scheduling'
out=w/'docs/benchmarks/2026-11-26/core-cli-exec.json'
def read(file):return json.loads((s/file).read_text())
def digest(p):
 with p.open('rb') as h:return hashlib.file_digest(h,'sha256').hexdigest()
def summarize(prefix):
 result={}
 for endpoint in ('HVF','Orb'):
    raw=read(f'{prefix}-{endpoint}.json')
    cases=raw['semantics']
    checks={}
    for arm in cases:
      rows=[]
      for kind,value in cases[arm].items():
       if isinstance(value,dict): rows.append(bool(value.get('passed')))
       else: rows.extend(x if isinstance(x,bool) else x['passed'] for x in value)
      checks[arm]={'passed':sum(rows),'total':len(rows)}
    assert all(checks[k]=={'passed':15,'total':15} for k in ('streaming','stock_docker'))
    stats={}
    for size, arms in raw['measurements'].items():
      stats[size]={}
      for arm, samples in arms.items():
       assert len(samples)==3 and all(row['exit']==0 for row in samples)
       stats[size][arm]={'median_ms':statistics.median(row['ms'] for row in samples),'median_peak_rss_mib':round(statistics.median(row['max_rss_bytes'] for row in samples)/1048576,3),'samples':samples}
    result[endpoint]={'receipt':f'{prefix}-{endpoint}.json','versions':raw['versions'],'semantics':cases,'passed':checks,'performance':stats}
 return result
def tests(path):
 text=(s/path).read_text()
 m=re.findall(r'Executed (\d+) tests?, with (\d+) failures?',text)
 assert m and int(m[-1][1])==0,path
 return {'count':int(m[-1][0]),'failures':0,'receipt':path}
def cleanup(file):
 result=read(file)
 keys=('clean_shutdown','supervisor_lock_released','socket_removed','scope_removed','defaults_unchanged','base_input_unchanged')
 assert not result['errors'] and all(result[k] for k in keys)
 return {k:result[k] for k in keys}|{'receipt':file,'volume':result['volume'],'spotlight':result['spotlight']}
baseline=read('core-original-baseline-audit.json')
assert all(row=={'count':24,'mismatches':[]} for row in baseline.values())
density=read('core-fixed-density.json')
assert all(row['removed']==8 and row['remaining']==[] for row in density['cleanup'].values())
assert len(density['rounds'])==4 and all(len(row)==4 for row in density['rounds'])
assert all(item['bytes']==33554432 for item in density['integrity_32_mib'].values())
qualified=read('core-fixed-qualified.json')
assert digest(Path(qualified['binary']))==qualified['sha256']==density['cli_sha256']
with tarfile.open(w/'docs/benchmarks/2026-11-26/core-engine-sources.tar.gz') as archive:
 src=json.load(archive.extractfile('manifest.json'))
for p,h in src['sha256'].items():
 if p.startswith('core/'):
  assert digest(Path.cwd()/p.removeprefix('core/'))==h,p
loads={}
for at in ['before','after']:
 f=s/f'core-fixed-{at}-top.log'
 loads[at]=float(re.findall(r'([\d.]+)% idle',f.read_text())[-1]) if f.exists() else None
negotiation=read('core-fixed-generic-on-HVF.json')
for arm in ['negotiated','pinned_144']:
 assert [(negotiation[arm][k]) for k in ('exit','out','err')]==[29,'00ff','fe5a']
repeat=read('core-fixed-output-only.json')
assert set(repeat)=={'orb','hvf'} and all(x['cleaned'] and len(x['runs'])==24 and all(row.get('exit')==0 for row in x['runs']) for x in repeat.values())
native=(s/'core-native-stress/receipt.txt').read_text()
assert '7,500 early-cancel races' in native and '6,000 cancel races' in native
assert src['sha256']['core/Sources/CPtyShim/exec_sink.c'] in native
assert src['sha256']['core/Sources/CPtyShim/include/exec_sink.h'] in native
roles=read('core-fixed-client-role.json')
assert roles['cli_sha']==qualified['sha256']
audit=read('core-rebuild-audit.json')
assert audit['archive_sha256']==read('core-source-freeze.json')['sha256']
assert digest(Path(qualified['reference_cli']))=='49c9db5e92453832a58fb95b6dbe5a749e4b2426850c822db331e5c2411a2bc4'
result={'native_stress':{'receipt':'core-native-stress/receipt.txt','sink_cancel_races':7500,'input_cancel_races':6000},
 'reconstruction':audit, 'fixture_and_client':roles,'host':'Gamma-128GB.local','date_local':'2026-11-26','source_archive':read('core-source-freeze.json'),
 'qualified_release':qualified,'original_baseline':baseline,'release_window_host_idle_percent':loads,
 'tests':[tests('core-fixed-swift-tests.log'),tests('core-fixed-shim-tests.log')],'generic_docker_adapter_to_hvf':negotiation,
 'development_same_build_mode':summarize('core-fixed-debug'),'optimized_cli':summarize('core-fixed-CLI'),
 'earlier_development_measurement':summarize('core-final-CLI'),
 'prior_development_timeout':{'receipt':'core-debug-current-Orb.json','failed_sample':next(row for row in read('core-debug-current-Orb.json')['measurements']['32']['streaming'] if 'error' in row),'diagnostic':'core-timed-out-client.sample','cleanup':read('core-release-machine.json')['recovery']},'output_only_repeats':repeat,'eight_container_release':density,'cleanup':[cleanup(f) for f in ['core-machine.json','core-negotiated-machine.json','core-release-machine.json','core-fixed-machine.json']]}
out.write_text(json.dumps(result,indent=2)+'\n')
print(out,qualified['sha256'],density['median_ms'])
