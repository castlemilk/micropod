#!/usr/bin/env python3
"""Count overlapping request intervals in the two archived mounted Git captures."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import tarfile


TRACE = re.compile(
    r"^\s*.*?-(?P<pid>\d+)\s*(?:\(\s*(?:\d+|-+)\s*\)\s*)?\[\d+\]\s+"
    r"(?:[^:\s]+\s+)?(?P<sec>\d+)\.(?P<frac>[0-9]{1,9}):\s+"
    r"(?P<event>fuse_request_send|fuse_request_end):\s*(?P<body>.*)$"
)
SEND = re.compile(r"connection (\d+) req (\d+) opcode (\d+) \(([^)]+)\) len (\d+)\s*$")
END = re.compile(r"connection (\d+) req (\d+) len (\d+) error (-?\d+)\s*$")


def bounds(raw, connection, observer, window):
    events = []
    for index, line in enumerate(raw.decode().splitlines()):
        if "fuse_request_send:" not in line and "fuse_request_end:" not in line:
            continue
        event = TRACE.fullmatch(line)
        if event is None:
            raise ValueError(f"unrecognized FUSE ftrace line {line}")
        sent = event["event"] == "fuse_request_send"
        read = (SEND if sent else END).fullmatch(event["body"])
        if read is None:
            raise ValueError(f"unrecognized FUSE ftrace arguments {line}")
        if int(read[1]) != connection:
            continue
        ns = int(event["sec"]) * 1_000_000_000 + int(event["frac"].ljust(9, "0"))
        events.append((ns, index, int(event["pid"]), sent, read))

    reqs = {}
    matched = []
    for ns, _, pid, sent, read in sorted(events):
        request = read[2]
        if sent:
            if request in reqs:
                raise ValueError(f"duplicate request {request}")
            reqs[request] = ns, pid, int(read[3]), int(read[5])
        elif request in reqs:
            start, requester, opcode, size = reqs.pop(request)
            if opcode == 1 and requester != observer and window[0] <= start <= ns <= window[1]:
                matched.append((start, ns, size, requester, read[4]))

    arrivals = sorted(matched)
    active = []
    overlapping = set()
    same_size = set()
    threshold = Counter()
    for i, (start, _, size, _, _) in enumerate(arrivals):
        active = [j for j in active if arrivals[j][1] > start]
        if active:
            overlapping.update(active)
            overlapping.add(i)
        for j in active:
            if size == arrivals[j][2]:
                same_size.add(i)
                same_size.add(j)
        active.append(i)
        threshold[len(active)] += 1
    return {
        "raw_trace_sha256": hashlib.sha256(raw).hexdigest(),
        "command_window_ns": window,
        "complete_lookups": len(arrivals),
        "return_errors": dict(Counter(row[4] for row in arrivals if row[4] != "0")),
        "lookups_with_another_lookup_outstanding": len(overlapping),
        "lookups_with_another_lookup_of_identical_wire_length_outstanding": len(same_size),
        "per_send_active_lookup_counts": dict(sorted(threshold.items())),
        "observed_total_request_time_ns": sum(t - s for s, t, *_ in arrivals),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("benchmark_directory", type=Path)
    args = parser.parse_args()
    archive_root = args.benchmark_directory
    result = {}
    with tarfile.open(archive_root / "2026-11-26/mounted-ci-gamma-receipts.tar.gz") as archive:
        summary = json.load(archive.extractfile("measurement-summary.json"))["git"]
        for mode in ("baseline-git", "lookup-off-measured-git", "lookup-inline-measured-git"):
            info = summary[mode]
            capture = info["ftrace_whole_control_window"]["capture"]
            raw = archive.extractfile(mode + "-.trace-events").read()
            window = info["ftrace_git_command_window"]["time_window_ns"]
            result[mode] = bounds(raw, int(capture["connection"]), int(capture["observer_pid"]), window)

    with tarfile.open(archive_root / "2026-11-25/managed-ci-git-and-exec-receipts.tar.gz") as archive:
        info = json.load(archive.extractfile("raw/base-host-ftrace.json"))
        capture = info["capture"]
        result["older-broad-git"] = bounds(
            archive.extractfile("raw/base-host-gitstudy.trace-events.log").read(),
            int(capture["connection"]), int(capture["observer_pid"]), [0, 10**20],
        )
        replay = json.load(archive.extractfile("raw/alloc-paired-host-timing.json"))
        elapsed = replay["median_scan_ns"]["candidate"]
        files = replay["fixture_files"]
        lookups = result["older-broad-git"]["complete_lookups"]
        result["previous_host_only_handler_replay"] = {
            "files": files,
            "median_scan_ns": elapsed,
            "ns_per_lookup": elapsed / files,
            "extrapolated_entire_host_work_ms_for_2719_lookups": elapsed / files * lookups / 1e6,
        }
    result["scope"] = (
        "Send/end intervals from guest ftrace. Wire length is only a necessary condition for "
        "identical parent and name; the trace does not record either. Guest overlap does not imply "
        "overlapping admission to a single host worker. Host replay is a different run and its "
        "service-time scale is an extrapolation, not a demonstrated bound on VM wall time."
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
