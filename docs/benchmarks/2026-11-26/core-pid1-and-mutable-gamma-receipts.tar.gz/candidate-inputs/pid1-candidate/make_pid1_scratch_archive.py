import hashlib
import io
import json
from pathlib import Path
import tarfile

tag = "micropod-qa/pid1-scratch:gamma2-fmdkh0"
root = Path(__file__).parent
binary = (root / "pid1-scratch-probe").read_bytes()

def add(archive, name, data, mode=0o644):
    info = tarfile.TarInfo(name)
    info.size = len(data)
    info.mode = mode
    archive.addfile(info, io.BytesIO(data))

def encode(value):
    return json.dumps(value, separators=(",", ":")).encode()

buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode="w") as layer:
    directory = tarfile.TarInfo("fixture")
    directory.type = tarfile.DIRTYPE
    directory.mode = 0o755
    layer.addfile(directory)
    add(layer, "fixture/probe", binary, 0o755)
layer = buffer.getvalue()

config = encode({
    "architecture": "arm64", "os": "linux",
    "config": {
        "User": "1234:5678", "WorkingDir": "/fixture",
        "Env": ["PATH=/fixture", "MP_PID1_IMAGE=image env"],
        "Entrypoint": ["probe", "from image"], "Cmd": ["default arg", ""],
    },
    "rootfs": {"type": "layers", "diff_ids": ["sha256:" + hashlib.sha256(layer).hexdigest()]},
    "history": [{"created_by": "Micropod PID 1 conformance fixture"}],
})
config_name = hashlib.sha256(config).hexdigest() + ".json"
manifest = [{"Config": config_name, "RepoTags": [tag], "Layers": ["layer.tar"]}]
with tarfile.open(root / "pid1-scratch.tar", mode="w") as archive:
    add(archive, config_name, config)
    add(archive, "layer.tar", layer)
    add(archive, "manifest.json", encode(manifest))
