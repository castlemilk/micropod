package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

func main() {
	cwd, err := os.Getwd()
	if err != nil {
		fail(err)
	}
	fds := make(map[string]string)
	entries, err := os.ReadDir("/proc/self/fd")
	if err != nil {
		fail(err)
	}
	for _, e := range entries {
		target, err := os.Readlink("/proc/self/fd/" + e.Name())
		if errors.Is(err, os.ErrNotExist) {
			continue
		}
		if err != nil {
			fail(err)
		}
		fd, err := strconv.Atoi(e.Name())
		if err != nil {
			fail(err)
		}
		if fd > 2 && target != "anon_inode:[eventpoll]" && target != "anon_inode:[eventfd]" {
			fail(fmt.Errorf("unexpected inherited descriptor %d %s", fd, target))
		}
		fds[e.Name()] = target
	}
	entries, err = os.ReadDir("/dev")
	if err != nil {
		fail(err)
	}
	var launcherDirs int
	for _, e := range entries {
		if strings.HasPrefix(e.Name(), ".micropod-pid1-") {
			launcherDirs++
			if _, err := os.Lstat(filepath.Join("/dev", e.Name(), "io")); !errors.Is(err, os.ErrNotExist) {
				fail(fmt.Errorf("launcher rendezvous survived exec: %v", err))
			}
		}
	}
	term, termSet := os.LookupEnv("TERM")
	result := map[string]any{
		"pid": os.Getpid(), "uid": os.Getuid(), "gid": os.Getgid(),
		"cwd": cwd, "args": os.Args, "env": os.Getenv("MP_PID1_IMAGE"),
		"term": term, "term_set": termSet, "fds": fds, "launcher_dirs": launcherDirs,
	}
	if err := json.NewEncoder(os.Stdout).Encode(result); err != nil {
		fail(err)
	}
}

func fail(err error) {
	fmt.Fprintln(os.Stderr, err)
	os.Exit(88)
}
