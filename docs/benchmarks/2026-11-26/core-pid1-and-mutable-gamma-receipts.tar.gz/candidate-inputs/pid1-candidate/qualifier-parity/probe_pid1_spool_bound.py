#!/usr/bin/env python3
"""Prove the native PID 1 spool bound on a disposable scope."""

import argparse
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import time
from types import SimpleNamespace

from qualify_docker_pid1 import attached, docker_run
from qualify_docker_restart import LABEL, Qualification, require


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True)
    parser.add_argument("--image", required=True)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    require(args.host.startswith("unix://") and Path(args.host[7:]).is_socket(), "Provide an explicit local Unix socket")
    require(not args.out.exists(), "Choose a fresh receipt path")
    report = {"passed": False}
    with TemporaryDirectory(prefix="mp-pid1-spool-config-") as scratch:
        fixture = Qualification(Path(scratch), SimpleNamespace(host=args.host, context=None, image=args.image),
                                prefix="mp-pid1-spool-")
        fixture.env.update(DOCKER_CONFIG=scratch, DOCKER_CLI_HINTS="false", TERM="xterm")
        report["scope"] = fixture.key
        try:
            size = 126 * 65536
            script = f"head -c {size} /dev/zero; echo near-cap-stderr >&2; exit 23"
            command = docker_run(fixture, fixture.key + "-under", ("--rm", "-i"), "/bin/sh", "-ec", script)
            with attached(command, env=fixture.env, limits=(size + 1, 512)) as io:
                until = time.monotonic() + 20
                io.send(b"", until, eof=True)
                io.finish(until, 23, stderr=b"near-cap-stderr\n")
                digest = hashlib.sha256(io.stdout).hexdigest()
                require(len(io.stdout) == size and digest == hashlib.sha256(bytes(size)).hexdigest(), io.status())
            report["under"] = {"bytes": size, "sha256": digest, "exit": 23}
            name = fixture.key + "-over"
            fixture.docker("run", "-di", "--pull=never", "--network=none", "--name", name,
                           "--label", f"{LABEL}={fixture.key}", fixture.image,
                           "/bin/sh", "-ec", "head -c 8519680 /dev/zero")
            wait = fixture.docker("wait", name, check=False, timeout=20)
            state = fixture.inspect(name)["State"]
            require(state["Status"] == "dead" and "Docker log exceeded the 8 MiB limit" in state["Error"], repr(state))
            report["over"] = {"bytes_requested": 8519680, "state": state, "wait_cli_status": wait.returncode,
                              "wait_stdout": wait.stdout, "wait_stderr": wait.stderr}
            report["passed"] = True
        except Exception as error:
            report["error"] = str(error)
            raise
        finally:
            try:
                report["cleanup"] = {"owned_container_ids": fixture.ids(), **fixture.cleanup()}
            finally:
                with args.out.open("x") as handle:
                    json.dump(report, handle, indent=2)
                    handle.write("\n")


if __name__ == "__main__":
    main()
