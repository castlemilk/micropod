#!/usr/bin/env python3
"""Exercise Docker PID 1 console streams through an explicit Linux engine socket."""

import argparse
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
import signal
from tempfile import TemporaryDirectory
import time
from types import SimpleNamespace

from qualify_docker_exec import attached, engine_response, winsize
from qualify_docker_restart import LABEL, Qualification, require


LIMIT = 20
BOOT = r"""
test "$$" = 1 && test -t 0 && test -t 1 && test -t 2
test "$(tty)" != 'not a tty'
test "$(id -u):$(id -g)" = 1234:1234
test "$(pwd -P)" = /tmp && test "$MP_PID1_ENV" = 'value with spaces'
test "$0" = pid1-entry && test "$1" = 'argument with spaces'
stty -echo
printf 'early-prompt>'
while IFS= read -r line; do
    case "$line" in
        size) printf 'size '; stty size ;;
        *) printf 'line=%s\n' "$line"; printf 'merged-stderr\n' >&2 ;;
    esac
done
printf 'terminal-eof\n'
exit 37
"""
RETAINED = r"""
test "$$" = 1
stty -echo
p=/tmp/mp-pid1-generation
count=0
if test -f "$p"; then read -r count < "$p"; fi
count=$((count + 1))
printf '%s\n' "$count" > "$p"
printf 'start=%s\n' "$count"
while IFS= read -r line; do
    case "$line" in
        quit) printf 'quitting=%s\n' "$count"; exit 29 ;;
        *) printf 'generation=%s input=%s\n' "$count" "$line" ;;
    esac
done
exit 38
"""


def docker_run(fixture, name, flags, command, *args):
    return [*fixture.cli, "run", "--pull=never", "--network=none", "--name", name,
            "--label", f"{LABEL}={fixture.key}", *flags, fixture.image, command, *args]


def initial_console(fixture):
    name = fixture.key + "-initial"
    command = docker_run(fixture, name, ("--rm", "-it", "-u", "1234:1234", "-w", "/tmp",
                                         "-e", "MP_PID1_ENV=value with spaces"),
                         "/bin/sh", "-ec", BOOT, "pid1-entry", "argument with spaces")
    with attached(command, env=fixture.env, size=(31, 97)) as io:
        until = time.monotonic() + LIMIT
        io.pump(lambda: io.stdout.endswith(b"early-prompt>"), until, "waiting for a short, unterminated PID 1 prompt")
        require(io.stdout == b"early-prompt>" and not io.stderr, f"Unexpected startup bytes. {io.status()}")
        row = fixture.inspect(name)
        require(row["Config"]["Tty"] and row["Config"]["OpenStdin"], f"Missing interactive config. {row!r}")
        io.read_offset = len(io.stdout)
        io.send(b"bytes with spaces\n", until)
        io.expect_line(b"line=bytes with spaces", until)
        io.expect_line(b"merged-stderr", until)
        with engine_response(fixture.cli[-1], "POST", f"/containers/{name}/resize?h=49&w=131"):
            pass
        io.send(b"size\n", until)
        io.expect_line(b"size 49 131", until)
        winsize(io.master, (42, 113))
        while True:
            io.process.send_signal(signal.SIGWINCH)
            io.send(b"size\n", until)
            result = io.line(until)
            if result == b"size 42 113":
                break
            require(result == b"size 49 131", f"Unexpected resize state {result!r}")
        io.send(b"\x04", until)
        io.expect_line(b"terminal-eof", until)
        io.finish(until, 37)
        require(io.read_offset == len(io.stdout), f"Unexpected bytes after terminal EOF. {io.status()}")
    require(fixture.docker("inspect", name, check=False).returncode != 0, "Auto-remove retained the interactive container")
    return {"early_prompt": True, "pid": 1, "uid": 1234, "gid": 1234, "exit": 37, "removed": True,
            "cli_resize": [42, 113], "api_resize": [49, 131]}


def pipe_console(fixture):
    payload = bytes(range(256)) * 2048 + b"\x00\xfftail"
    name = fixture.key + "-pipe"
    script = r"""
test "$$" = 1 && test ! -t 0 && test ! -t 1 && test ! -t 2
printf 'out-ready\n'
printf 'err-ready\n' >&2
cat
printf 'out-eof\n'
printf 'err-eof\n' >&2
exit 23
"""
    command = docker_run(fixture, name, ("--rm", "-i"), "/bin/sh", "-ec", script)
    with attached(command, env=fixture.env, limits=(len(payload) + 128, 128)) as io:
        until = time.monotonic() + LIMIT
        io.expect_line(b"out-ready", until)
        io.send(payload, until, eof=True)
        io.finish(until, 23, b"out-ready\n" + payload + b"out-eof\n", b"err-ready\nerr-eof\n")
    return {"bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest(), "exit": 23}


def retained_console(fixture):
    name = fixture.key + "-retained"
    created = fixture.docker("run", "--detach", "-it", "--pull=never", "--network=none", "--name", name,
                             "--label", f"{LABEL}={fixture.key}", fixture.image, "/bin/sh", "-ec", RETAINED)
    cid = created.stdout.strip()
    require(fixture.inspect(name)["Id"] == cid, "Retained console identity differs")
    until = time.monotonic() + LIMIT
    with ExitStack() as clients:
        output = clients.enter_context(attached([*fixture.cli, "attach", "--no-stdin", name],
                                                env=fixture.env, size=(31, 97)))
        input_ = clients.enter_context(attached([*fixture.cli, "attach", "--detach-keys", "ctrl-x,ctrl-y", name],
                                                env=fixture.env, size=(31, 97)))
        for i in range(6):
            marker = f"generation=1 input=shared-{i}".encode()
            input_.send(f"shared-{i}\n".encode(), until)
            input_.pump(lambda: marker in input_.stdout, until, "waiting for the controlling attachment")
            ready_by = min(until, time.monotonic() + 0.25)
            try:
                output.pump(lambda: marker in output.stdout, ready_by, "waiting for the second attachment")
            except RuntimeError:
                if i == 5:
                    raise
                continue
            break
        input_.send(b"\x18\x19", until)
        input_.pump(lambda: not input_.readers, until, "waiting for stock keyboard detach")
        input_.process.wait(timeout=max(0, until - time.monotonic()))
        require(fixture.inspect(name)["State"]["Running"] and output.process.poll() is None,
                "Detaching one client stopped the retained process or its sibling attachment")
        with attached([*fixture.cli, "attach", name], env=fixture.env, size=(36, 101)) as reattached:
            reattached.send(b"quit\n", until)
            reattached.finish(until, 29)
            require(b"quitting=1" in reattached.stdout, f"Reattach lost final output. {reattached.status()}")
        output.finish(until, 29)
        require(b"quitting=1" in output.stdout, f"Read-only attachment lost final output. {output.status()}")
    stopped = fixture.inspect(name)
    require(stopped["State"]["ExitCode"] == 29, "Retained wait and inspect disagree")

    with attached([*fixture.cli, "start", "-ai", name], env=fixture.env, size=(33, 112)) as io:
        until = time.monotonic() + LIMIT
        io.expect_line(b"start=2", until)
        io.send(b"quit\n", until)
        io.expect_line(b"quitting=2", until)
        io.finish(until, 29)
    row = fixture.inspect(name)
    require(row["Id"] == cid and row["State"]["StartedAt"] != stopped["State"]["StartedAt"]
            and row["Config"]["Tty"] and row["Config"]["OpenStdin"], "Start lost retained terminal config or identity")
    log = fixture.docker("logs", name).stdout
    require(log.count("start=1\n") == log.count("start=2\n") == 1 and "quitting=2\n" in log,
            f"Retained console log lost a generation. {log!r}")
    return {"id": cid, "detach_cli_status": input_.process.returncode, "concurrent": True,
            "reattached_exit": 29, "restarted_exit": 29}


def ordinary_and_rejections(fixture, workspace):
    result = fixture.docker("run", "--rm", "--pull=never", "--network=none", "--label", f"{LABEL}={fixture.key}",
                            fixture.image, "/bin/sh", "-ec",
                            'test "$$" = 1; test ! -t 0; printf "stdout\\n"; printf "stderr\\n" >&2; exit 41',
                            check=False, timeout=LIMIT)
    require((result.returncode, result.stdout, result.stderr) == (41, "stdout\n", "stderr\n"),
            f"Ordinary foreground output changed. {result!r}")
    with TemporaryDirectory(prefix=fixture.key, dir=workspace) as scratch:
        invalid = Path(scratch) / "invalid"
        invalid.write_bytes(b"\x00\x01invalid executable format\x00")
        invalid.chmod(0o755)
        failures = {}
        for label, path, code in (
            ("missing", "/this-command-does-not-exist", 127),
            ("non_executable", "/etc/alpine-release", 126),
            ("bad_format", "/run/invalid-pid1-format", 126),
        ):
            flags = []
            if label == "bad_format":
                flags = ["--mount", f"type=bind,source={invalid},target={path},readonly"]
            out = fixture.docker("run", "--rm", "-t", "--pull=never", "--network=none",
                                 "--label", f"{LABEL}={fixture.key}", *flags, fixture.image, path,
                                 check=False, timeout=LIMIT)
            require(out.returncode == code, f"{label} returned {out.returncode}. {out.stdout!r} {out.stderr!r}")
            failures[label] = code
    return {"exit": 41, "launch_errors": failures}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True)
    parser.add_argument("--workspace", required=True, type=Path)
    parser.add_argument("--image", required=True)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    require(args.host.startswith("unix://") and Path(args.host[7:]).is_socket(), "Provide a live explicit Unix socket")
    require(not args.out.exists(), "Choose a fresh receipt path")
    report = {"passed": False}
    with TemporaryDirectory(prefix="mp-pid1-proof-") as scratch:
        fixture = Qualification(Path(scratch), SimpleNamespace(host=args.host, context=None, image=args.image),
                                prefix="mp-pid1-")
        try:
            report["initial"] = initial_console(fixture)
            report["pipe"] = pipe_console(fixture)
            report["retained"] = retained_console(fixture)
            report["ordinary"] = ordinary_and_rejections(fixture, args.workspace)
            report["passed"] = True
        except Exception as error:
            report["error"] = str(error)
            raise
        finally:
            try:
                fixture.cleanup()
            except Exception as error:
                report["passed"] = False
                report["cleanup_error"] = str(error)
                raise
            finally:
                with args.out.open("x") as out:
                    json.dump(report, out, indent=2)
                    out.write("\n")


if __name__ == "__main__":
    main()
