"""Run previously qualified eight-job Git/build/test harness against a combined public machine."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, sys
p=argparse.ArgumentParser()
p.add_argument('ready',type=Path)
p.add_argument('--name',default='combined-ci')
p.add_argument('--prime-jobs',type=int)
p.add_argument('--jobs',type=int,default=8)
p.add_argument('--pairs',type=int,default=4)
p.add_argument('--job-cpus',default='0.5')
p.add_argument('--job-memory-mib',type=int,default=384)
a=p.parse_args()
ready=json.loads(a.ready.read_bytes())
r=a.ready.parent
hub=r.parent/'home'
harness=hub/('bounded-prime-harness' if a.prime_jobs else 'evidence/prior/final-harness')
driver=harness/'scripts/bench_workspace_checkout.py'
pid1=ready['owned_artifacts']['job']['sha256']
assert ready['owned_artifacts']['cli']['sha256']=='31c78102d9a1ab7a07912cbbd89f2e3dd265889eae62663336d0fb1e595f0259'
integrated=json.loads((r/'integrated-vmm-source.json').read_bytes())
assert ready['owned_artifacts']['vmm']['sha256']==integrated['vmm_sha256']
assert ready['owned_artifacts']['kernel']['sha256']=='dba972178942b384b9eefd10dc1d92c0b9f063d5bcb2a9604e388400283f0ab6'
orb=Path('/Users/benebsworth/.orbstack/run/docker.sock')
sockets={'orbstack':orb,'hvf':Path(ready['socket'])}
assert all(s.is_socket()for s in sockets.values())
out=r/(a.name+'.json')
assert not out.exists()
args=[sys.executable,'-B',str(driver),'--hvf-socket',str(sockets['hvf']),'--orbstack-socket',str(sockets['orbstack']),
      '--workspace',ready['workspace'],'--image',ready['benchmark_image'],'--image-manifest',str(r/'image-manifest.json'),
      '--go-version','1.26.11','--pairs',str(a.pairs),'--jobs',str(a.jobs),'--job-cpus',a.job_cpus,'--job-memory-mib',str(a.job_memory_mib),'--out',str(out)]
if a.prime_jobs:
    args.extend(['--prime-jobs',str(a.prime_jobs)])
subprocess.run([sys.executable,'-B',str(r/'with_host_load.py'),'--out',str(r/(a.name+'-host-load.jsonl')),'--',*args],check=True,
               env=dict(os.environ,TMPDIR=str(hub),DOCKER_CLI_HINTS='false'))
data=json.loads(out.read_bytes()); assert len(data['pairs'])==a.pairs and data['jobs_per_engine']==a.jobs
cleanup={}
for engine, details in data['arms'].items():
    ids=[j['container_id']for j in details['jobs']]
    assert len(set(ids))==a.jobs
    existing=subprocess.check_output(['docker','--host','unix://'+str(sockets[engine]),'ps','--no-trunc','-aq'],text=True,timeout=10).splitlines()
    remaining=sorted(set(ids).intersection(existing))
    assert not remaining,(engine,remaining)
    cleanup[engine]={'owned_ids':ids,'remaining':remaining}
report={'docker_job_sha256':pid1,'harness_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'jobs':a.jobs,'pairs':a.pairs,'cpu_per_job':a.job_cpus,'memory_mib_per_job':a.job_memory_mib,'summary':data['summary'],'cleanup':cleanup,
        'overlap':{phase:{n:[row[phase][n]['peak_scored_parallelism']for row in data['pairs']]for n in sockets}for phase in ('warm','incremental')}}
assert all(all(v==a.jobs for v in values) for phase in report['overlap'].values()for values in phase.values())
(r/(a.name+'-acceptance.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['summary']))
