#!/usr/bin/env python3
"""Compare scoped native and OrbStack stock PID 1 receipts."""

import hashlib
import json
from pathlib import Path


here = Path(__file__).resolve().parent
paths = {
    "native": here / "pid1-final-agent.json",
    "orbstack": here / "pid1-parity-orb.json",
}
raw = {engine: path.read_bytes() for engine, path in paths.items()}
sides = {engine: json.loads(payload) for engine, payload in raw.items()}
for side in sides.values():
    assert side["passed"] and not side["cleanup"]["remaining_container_ids"]
assert sides["native"]["scope"] != sides["orbstack"]["scope"]
for key in ("initial", "pipe", "detach"):
    assert sides["native"][key] == sides["orbstack"][key], key
kept = lambda side: {key: value for key, value in side["retained"].items() if key != "id"}
assert kept(sides["native"]) == kept(sides["orbstack"])
detach = sides["native"]["detach"]
assert detach["status"] == 1 and bytes.fromhex(detach["stderr_hex"]) == b"read escape sequence\n"
assert detach["container_running"] and detach["sibling_attached"]
report = {
    "passed": True,
    "same_stock_cli": all(side["client_server_version"].startswith("29.7.2 ") for side in sides.values()),
    "engines": {engine: {"client_server_version": side["client_server_version"], "scope": side["scope"],
                         "receipt": paths[engine].name, "receipt_sha256": hashlib.sha256(raw[engine]).hexdigest(),
                         "cleanup": side["cleanup"]} for engine, side in sides.items()},
    "terminal": sides["native"]["initial"],
    "pipes": sides["native"]["pipe"],
    "detach": detach,
    "retained": kept(sides["native"]),
}
assert report["same_stock_cli"]
with (here / "pid1-parity-comparison.json").open("x") as file:
    json.dump(report, file, indent=2)
    file.write("\n")
