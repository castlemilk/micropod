#!/usr/bin/env python3
"""Compare scoped native and OrbStack verbose log receipts."""

import hashlib
import json
from pathlib import Path
import statistics


here = Path(__file__).resolve().parent
receipts = {
    "native": "docker-verbose-v2-native.json",
    "orbstack": "docker-verbose-v2-orbstack.json",
    "churn_previous": "docker-verbose-churn-89d4.json",
    "churn_current": "docker-verbose-churn-v2.json",
}
raw = {name: (here / path).read_bytes() for name, path in receipts.items()}
data = {name: json.loads(payload) for name, payload in raw.items()}
for receipt in data.values():
    assert receipt["passed"] and not receipt["cleanup"]["remaining_container_ids"]
native, orb = data["native"], data["orbstack"]
previous_ready = json.loads((here / "combined-ready.json").read_text())
current_ready = json.loads((here / "combined-logs-ready.json").read_text())
identities = {key: [side["owned_artifacts"][key]["sha256"] for side in (previous_ready, current_ready)]
              for key in ("cli", "initrd", "job", "kernel", "vmm")}
assert all(left == right for key, (left, right) in identities.items() if key != "job")
assert identities["job"][0] != identities["job"][1]
assert data["churn_previous"]["image"] == data["churn_current"]["image"]
result = {"passed": True, "client": "Docker 29.7.2", "engines": {},
          "receipts": {name: {"filename": path, "sha256": hashlib.sha256(raw[name]).hexdigest()}
                       for name, path in receipts.items()},
          "matched_streams": {}, "quiet_churn": {}}
for stage in ("run", "logs", "attached_start", "retained_logs", "slow_original"):
    left, right = native[stage], orb[stage]
    matched = {stream: left[stream] for stream in ("stdout", "stderr")}
    for stream, detail in matched.items():
        assert right[stream] == detail, (stage, stream)
    assert left.get("exit") == right.get("exit")
    result["matched_streams"][stage] = matched | {"exit": left.get("exit")}
for engine, side in (("native", native), ("orbstack", orb)):
    assert side["version"].startswith("29.7.2 ")
    assert side["concurrent_short"]["overlapped"] and side["concurrent_short"]["producer_stdout_advanced"]
    assert side["slow_open_at_remove"] and side["removed"] and side["restart_exit"] == 23
    result["engines"][engine] = {"version": side["version"], "image": side["image"],
                                 "default_log_config": side["default_log_config"],
                                 "elapsed_ms": {key: side[key]["elapsed_ms"] for key in result["matched_streams"]},
                                 "cleanup": side["cleanup"]}
for name in ("previous", "current"):
    values = data["churn_" + name]["churn"]["samples_ms"]
    assert len(values) == 12
    result["quiet_churn"][name] = {"samples_ms": values, "median_ms": statistics.median(values)}
churn = result["quiet_churn"]
churn["median_change_percent"] = 100 * (churn["current"]["median_ms"] / churn["previous"]["median_ms"] - 1)
churn["design"] = "One sequential 12-run arm per guest; same machine artifacts, Docker client and image; quiet --rm jobs."
churn["artifact_sha256_previous_current"] = identities
with (here / "docker-verbose-v2-comparison.json").open("x") as out:
    json.dump(result, out, indent=2)
    out.write("\n")
