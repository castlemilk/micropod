#!/bin/sh
# One shot. Installed only in the isolated worker's trusted, read-only tools.
set -eu
umask 077
workspace=${MICROPOD_ENGINE_WORKSPACE:?}
start="$workspace/.trace-start.request"
finish="$workspace/.trace-finished.request"
token=
instance=
scratch=
owned_mount=
state=error
reason=unhandled

publish() {
    output=$(mktemp "$workspace/.trace-$token.XXXXXX") || return 1
    if cat "$1" > "$output" && mv -f "$output" "$workspace/$2"; then
        return 0
    fi
    rm -f "$output"
    return 1
}

record_setup() {
    {
        printf '[%s]\n' "$1"
        for leaf in trace_clock available_tracers current_tracer trace_options buffer_size_kb tracing_on; do
            printf '%s\n' "$leaf"
            if [ -r "$2/$leaf" ]; then
                cat "$2/$leaf"
            else
                printf '%s\n' '<unavailable>'
            fi
        done
    } >> "$scratch/setup"
}

cleanup() {
    code=$?
    trap - EXIT HUP INT TERM
    set +e
    if [ -n "$instance" ]; then
        record_setup "exit:$reason" "$instance"
        if ! printf '0\n' > "$instance/tracing_on" || ! rmdir "$instance"; then
            state=error
            reason=remove_trace_instance
            code=1
        fi
    fi
    if [ -n "$owned_mount" ]; then
        if ! umount "$owned_mount" || ! rmdir "$owned_mount"; then
            state=error
            reason=unmount_private_tracefs
            code=1
        fi
    fi
    if [ -n "$token" ] && [ -n "$scratch" ]; then
        printf '[stderr]\n' >> "$scratch/setup"
        cat "$scratch/stderr" >> "$scratch/setup"
        if ! publish "$scratch/setup" .trace-observer.log; then
            printf '%s\n' '[trace-proof] could not publish .trace-observer.log' >&3
            code=1
        fi
        printf 'schema=1\ntoken=%s\nstatus=%s\nreason=%s\n' "$token" "$state" "$reason" > "$scratch/done"
        if ! publish "$scratch/done" .trace-done; then
            printf '%s\n' '[trace-proof] could not publish .trace-done' >&3
            code=1
        fi
    fi
    if [ -n "$scratch" ]; then
        rm -f "$scratch/started" "$scratch/events" "$scratch/stats" "$scratch/done" "$scratch/setup" "$scratch/stderr"
        rmdir "$scratch" || code=1
    fi
    exit "$code"
}

valid_control() {
    [ ! -L "$1" ] && [ -f "$1" ] && [ "$(stat -c %s "$1")" = 17 ] || return 1
    IFS= read -r control < "$1" || return 1
    case "$control" in ''|*[!0-9a-f]*) return 1 ;; esac
    [ "${#control}" -eq 16 ]
}

uptime_seconds() {
    IFS=' ' read -r uptime _ < /proc/uptime
    printf '%s\n' "${uptime%.*}"
}

trap cleanup EXIT
trap 'reason=interrupted; exit 1' HUP INT TERM
arm_deadline=$(($(uptime_seconds) + 300))
while [ ! -f "$start" ]; do
    [ "$(uptime_seconds)" -lt "$arm_deadline" ] || exit 0
    sleep 0.10
done
valid_control "$start" || { printf '%s\n' '[trace-proof] invalid start request' >&2; exit 1; }
token=$control
scratch=$(mktemp -d /run/mp-trace.XXXXXX)
exec 3>&2 2>"$scratch/stderr"
reason=stale_workspace_control
for leaf in .trace-finished.request .trace-started .trace-events .trace-stats .trace-done .trace-observer.log; do
    [ ! -e "$workspace/$leaf" ] && [ ! -L "$workspace/$leaf" ] || exit 1
done

reason=workspace_mount
device=$(awk '
    {
        for (i = 7; i <= NF; i++) {
            if ($i != "-") continue
            if ($(i + 1) == "virtiofs" && $(i + 2) == "workspace") print $3
            break
        }
    }
' /proc/self/mountinfo | sort -u)
connection=$(printf '%s\n' "$device" | awk -F: '
    /^[0-9]+:[0-9]+$/ && NR == 1 { value = $1 * 1048576 + $2; next }
    { invalid = 1 }
    END { if (!invalid && NR == 1 && value > 0) printf "%.0f\n", value; else exit 1 }
')

reason=mount_tracefs
root=/sys/kernel/tracing
if [ ! -d "$root/instances" ]; then
    root="$scratch/tracefs"
    mkdir "$root"
    if ! mount -t tracefs -o nosuid,nodev,noexec tracefs "$root"; then
        rmdir "$root"
        exit 1
    fi
    owned_mount=$root
fi
record_setup root_before_instance "$root"
reason=mkdir_trace_instance
name="$root/instances/mp-workspace-$token"
mkdir "$name"
instance=$name
record_setup instance_before_config "$instance"
reason=disable_instance
printf '0\n' > "$instance/tracing_on"
reason=select_nop_tracer
if [ -w "$instance/current_tracer" ] && [ "$(cat "$instance/current_tracer")" != nop ]; then
    printf 'nop\n' > "$instance/current_tracer"
fi
reason=set_buffer_capacity
printf '2048\n' > "$instance/buffer_size_kb"
reason=set_overwrite_option
overwrite=kernel-default
if [ -w "$instance/options/overwrite" ]; then
    printf '0\n' > "$instance/options/overwrite"
    overwrite=disabled
elif [ -w "$instance/trace_options" ] && (printf 'nooverwrite\n' > "$instance/trace_options"); then
    overwrite=disabled
fi
reason=select_monotonic_clock
clock=
for candidate in mono global; do
    if (printf '%s\n' "$candidate" > "$instance/trace_clock") &&
       grep -Fq "[$candidate]" "$instance/trace_clock"; then
        clock=$candidate
        break
    fi
done
[ -n "$clock" ] || exit 1
record_setup instance_after_config "$instance"

reason=configure_signal_events
signal_event="$instance/events/signal/signal_generate"
printf 'sig == 9\n' > "$signal_event/filter"
printf '1\n' > "$signal_event/enable"

reason=configure_ppoll_events
filtered=0
poll_event="$instance/events/syscalls/sys_exit_ppoll"
if [ -r "$poll_event/format" ]; then
    cat "$poll_event/format" >> "$scratch/setup"
    printf 'ret != 0\n' > "$poll_event/filter"
    printf '1\n' > "$poll_event/enable"
    filtered=1
fi

reason=publish_started
{
    printf 'schema=1\ntoken=%s\ndevice=%s\nconnection=%s\n' "$token" "$device" "$connection"
    printf 'clock=%s\noverwrite=%s\nbuffer_kib_per_cpu=2048\nmax_capture_s=145\nobserver_pid=%s\n' "$clock" "$overwrite" "$$"
    printf 'kernel_work_event_filters=%s\n' "$filtered"
    printf 'kernel_release=%s\n' "$(uname -r)"
    printf 'boot_id=%s\n' "$(cat /proc/sys/kernel/random/boot_id)"
} > "$scratch/started"

deadline=$(($(uptime_seconds) + 145))
printf '1\n' > "$instance/tracing_on"
printf 'mp-workspace-start %s\n' "$token" > "$instance/trace_marker"
publish "$scratch/started" .trace-started

reason=finish_timeout
while [ ! -f "$finish" ]; do
    if [ "$(uptime_seconds)" -ge "$deadline" ]; then
        state=timeout
        break
    fi
    sleep 0.05
done

printf 'mp-workspace-finish %s\n' "$token" > "$instance/trace_marker"
printf '0\n' > "$instance/tracing_on"
if [ "$state" != timeout ]; then
    reason=finish_token
    valid_control "$finish" && [ "$control" = "$token" ] || exit 1
    state=ok
    reason=finished
fi

saved_state=$state
saved_reason=$reason
state=error
reason=export_capture
cat "$instance/trace" > "$scratch/events"
{
    for cpu in "$instance"/per_cpu/cpu*; do
        printf '[%s]\n' "${cpu##*/}"
        cat "$cpu/stats"
    done
} > "$scratch/stats"
publish "$scratch/events" .trace-events
publish "$scratch/stats" .trace-stats
state=$saved_state
reason=$saved_reason
[ "$state" = ok ]
