"""Audit and remove this Gamma continuation's private APFS scopes; publish its receipts."""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import plistlib
import shutil
import subprocess
import sys
import tarfile
import time

import worker_apfs_drive as apfs

r = Path(__file__).resolve().parent
scope = r.parent
hub = scope / 'home'
assert scope.parent == Path('/private/tmp') and scope.name.startswith('mp-gamma2.')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('worktree', type=Path)
args = parser.parse_args()
w = args.worktree.resolve(strict=True)
out = w / 'docs/benchmarks/2026-11-26'
out.mkdir(parents=True, exist_ok=True)
archive = out / 'core-pid1-and-mutable-gamma-receipts.tar.gz'
scorecard = out / 'core-pid1-and-mutable-gamma.json'
assert not archive.exists() and not scorecard.exists()


def read(f):
    return json.loads(f.read_bytes())


def save(f, contents):
    pending = f.with_name(f.name + '.writing')
    pending.write_text(json.dumps(contents, indent=2) + '\n')
    pending.replace(f)


def sha(f):
    with f.open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()


def run(argv, *, timeout=55, check=True):
    return subprocess.run(argv, timeout=timeout, text=True, capture_output=True, check=check)


def attachments():
    listing = subprocess.check_output(['/usr/bin/hdiutil', 'info', '-plist'], timeout=45)
    return {str(Path(row['image-path']).resolve()) for row in plistlib.loads(listing)['images'] if row.get('image-path')}


def raw_archive():
    files = {file.relative_to(r).as_posix(): file for file in sorted(r.rglob('*')) if file.is_file()
             and not file.is_symlink() and '__pycache__' not in file.parts}
    manifest = {name: sha(file) for name, file in files.items()}
    payload = (json.dumps(manifest, sort_keys=True, indent=2) + '\n').encode()
    pending = out / (archive.name + '.pending')
    with pending.open('xb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w|') as tar:
            for name, file in files.items():
                info = tar.gettarinfo(file, arcname=name)
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                with file.open('rb') as src:
                    tar.addfile(info, src)
            info = tarfile.TarInfo('MANIFEST.sha256.json')
            info.mode = 0o644
            info.size = len(payload)
            tar.addfile(info, io.BytesIO(payload))
    with tarfile.open(pending) as tar:
        observed = json.load(tar.extractfile('MANIFEST.sha256.json'))
        assert observed == manifest and set(tar.getnames()) == set(manifest) | {'MANIFEST.sha256.json'}
        for name, digest in manifest.items():
            parsed = tar.extractfile(name)
            assert hashlib.file_digest(parsed, 'sha256').hexdigest() == digest, name
    pending.replace(archive)
    return {'path': archive.name, 'entries': len(manifest), 'bytes': archive.stat().st_size, 'sha256': sha(archive)}


def historical_preservation():
    old_score = out / 'mounted-ci-gamma.json'
    old_raw = out / 'mounted-ci-gamma-receipts.tar.gz'
    expected = {old_score: 'a421bb49b422f344539857a0e8e6fe4599f4da840bbddba5ab9446fe1cc54b13',
                old_raw: '774763ef36286b0d1c747c81a6c24354654e190d29a69b1f041cdcd7565f6eb0'}
    prior = w / 'docs/benchmarks/2026-11-25'
    prior_score = read(prior / 'managed-ci-git-and-exec.json')
    expected.update({prior / entry['path']: entry['sha256'] for entry in prior_score['evidence'].values()})
    for file, digest in expected.items():
        assert sha(file) == digest, file
    with tarfile.open(old_raw) as tar:
        manifest = json.load(tar.extractfile('MANIFEST.sha256.json'))
    for rel, digest in manifest.items():
        assert sha(hub / 'evidence/last' / rel) == digest
    copy = (w / 'docs/benchmarks/2026-11-24/disposable-local-fixture/'
            '20261124T101312Z-local-iad8j2_g/preserved')
    baseline = read(copy / 'manifest.json')
    for file, digest in baseline['sha256'].items():
        assert sha(copy / file) == sha(Path(baseline['source']) / file) == digest
    with gzip.open(w / 'docs/benchmarks/2026-11-21/gamma-vcpu-priority.json.gz', 'rt') as src:
        installed = json.load(src)['installation']
    bank = Path(installed['path'])
    for file, digest in installed['tools'].items():
        assert sha(bank / 'micropod-oci-tools' / file) == digest
    assert sha(bank / 'micropod') == installed['host_sha256'] and sha(bank / 'micropod-oci') == installed['oci_sha256']
    return {'archived_products_sha256': {f.name: digest for f, digest in expected.items()},
            'prior_receipt_entries_verified': len(manifest), 'original_baseline_files': len(baseline['sha256']),
            'preserved_baseline_files': len(baseline['sha256']), 'qualified_tool_files': len(installed['tools']),
            'qualified_host_binaries': 2}


def retained_runtime():
    folder = w.parent.parent / '.build/qualified/micropod-hvf-gamma2-fmdkh0'
    published = read(r / 'qualified-runtime-binaries.json')
    assert published == read(folder / 'manifest.json')
    hashes = {}
    for products in published.values():
        for item in products.values():
            file = Path(item['retained_path'])
            assert file.parent == folder and file.resolve(strict=True) == file, file
            if file.name not in hashes:
                hashes[file.name] = sha(file)
            assert hashes[file.name] == item['sha256'], file
    return {'manifest': str(folder / 'manifest.json'), 'sha256': sha(folder / 'manifest.json'), 'binaries': hashes}


def candidate_inputs():
    notices = {}
    allow = ('.json', '.log', '.patch', '.py', '.sh', '.tar.gz', '.txt', '.c', '.h', '.go', '.tar', '.config')
    for name in ('mutable-candidate', 'mutable-coherence', 'kernel-splice', 'pid1-candidate', 'docker-log-candidate',
                 'image-inspect-candidate'):
        root = hub / name
        if not root.is_dir():
            continue
        copied = {}
        for src in sorted(root.rglob('*')):
            rel = src.relative_to(root)
            if any(part in {'target', 'source', '.git', '__pycache__', 'test-tmp'} for part in rel.parts):
                continue
            has_format = src.name.endswith(allow) or (name == 'kernel-splice' and src.name in {'config', 'release', 'SHA256SUMS'})
            if not src.is_file() or src.is_symlink() or not has_format or src.stat().st_size > 8 * 2**20:
                continue
            dest = r / 'candidate-inputs' / name / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dest)
            copied[rel.as_posix()] = sha(dest)
        notices[name] = copied
    return notices


def orb_tag_preflight():
    for key in ('DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH', 'DOCKER_API_VERSION'):
        os.environ.pop(key, None)
    orb = ['/opt/homebrew/bin/docker', '--host', 'unix:///Users/benebsworth/.orbstack/run/docker.sock']
    image = read(r / 'image.json')
    assert image['tag'] == 'micropod-qa/checkout:gamma2-' + scope.name.removeprefix('mp-gamma2.').lower()
    assert run([*orb, 'image', 'inspect', '--format', '{{.Id}}', image['tag']]).stdout.strip() in (image['config_digest'], image['manifest_digest'])
    assert not run([*orb, 'ps', '-aq', '--filter', f'ancestor={image["tag"]}']).stdout.strip()
    assert not run([*orb, 'ps', '-aq', '--filter', f'label={image["label"]}']).stdout.strip()
    return orb, image


before = attachments()
worker_retirement = {}
owned_images = {str(scope / 'hub.sparseimage')}
for path in sorted(r.glob('*-worker.json')):
    worker = read(path)
    assert worker['scope_absent'] and not Path(worker['worker_directory']).exists(), path
    d = worker['drive']['detached']
    assert d['image_absent'] and d['mount_restored'] and d['image'] not in before, path
    policy = d['persisted_policy']
    assert policy['mounted_read_only'] and policy['spotlight']['disabled'] and policy['markers_unchanged'] and policy['journal_unchanged'], path
    assert policy['fsevents']['journal_files'] == policy['fsevents']['journal_bytes'] == 0, path
    assert not Path(worker['image']).exists() and not Path(worker['socket']).exists(), path
    assert not worker['machine']['scoped_processes_after_stop'] and worker['machine']['supervisor_lock_released'], path
    assert policy['raw_disk_unchanged'], path
    owned_images.add(worker['image'])
    worker_retirement[worker['label']] = {'uuid': policy['volume']['uuid'], 'image': worker['image'],
        'clean_guest_shutdown': worker['machine']['clean_shutdown'], 'suppression_markers_unchanged': policy['markers_unchanged'],
        'spotlight_disabled': policy['spotlight']['disabled'], 'fsevents_journal_files': 0, 'fsevents_journal_bytes': 0,
        'read_only_remount': policy['mounted_read_only'],
        'raw_disk_identity_preserved_at_read_only_remount': policy['raw_disk_unchanged'], 'removed': True,
        'default_micropod_state_unchanged': worker['machine']['defaults_unchanged'], 'artifacts': worker['owned_artifacts']}
assert worker_retirement
assert owned_images & before == {str(scope / 'hub.sparseimage')}

verified = historical_preservation()
retained = retained_runtime()
inputs = candidate_inputs()
orb, image = orb_tag_preflight()
summary = json.loads(run([sys.executable, '-B', str(r / 'summarize_gamma2.py')]).stdout)
save(r / 'measurement-summary.json', summary)
save(r / 'historical-preservation.json', verified)
save(r / 'retained-runtime-preservation.json', retained)
save(r / 'candidate-inputs-manifest.json', inputs)

cmd = ['/usr/sbin/lsof', '-nP', '+f', '--', str(hub)]
started = time.monotonic()
proc = run(cmd, check=False)
holders = {'argv': cmd, 'stdout': proc.stdout, 'stderr': proc.stderr, 'exit': proc.returncode,
           'elapsed_seconds': time.monotonic() - started}
save(r / 'hub-holders-final.json', holders)
assert proc.returncode == 1 and not proc.stdout.strip() and not proc.stderr.strip(), holders

live = apfs.verify(read(r / 'hub-created.json'))
save(r / 'hub-final-live.json', live)
detached = apfs.detach(read(r / 'hub-created.json'), remove_image=True, inspect_history=True)
save(r / 'hub-detached.json', detached)
policy = detached['persisted_policy']
assert detached['image_absent'] and detached['mount_restored'] and not any(hub.iterdir())
assert policy['mounted_read_only'] and policy['spotlight']['disabled'] and policy['markers_unchanged'] and policy['journal_unchanged']
assert policy['fsevents']['journal_files'] == policy['fsevents']['journal_bytes'] == 0
hub.rmdir()
assert not (attachments() & owned_images) and not any(Path(image).exists() for image in owned_images)

# Recheck after local retirement before removing the owned image tag.
assert not run([*orb, 'ps', '-aq', '--filter', f'ancestor={image["tag"]}']).stdout.strip()
run([*orb, 'image', 'rm', image['tag']])
probe = run([*orb, 'image', 'inspect', image['tag']], check=False)
assert probe.returncode and any(value in probe.stderr.lower() for value in ('no such', 'not found'))

cleanup = {'owned_worker_volumes': worker_retirement, 'hub_uuid': live['volume']['uuid'], 'hub_read_only_remounted': True,
           'hub_spotlight_disabled': True, 'hub_markers_unchanged': True, 'hub_fsevents_journal_files': 0,
           'hub_fsevents_journal_bytes': 0, 'hub_image_removed': True, 'owned_apfs_images_absent': True,
           'owned_orbstack_tag_removed': True, 'owned_orbstack_image_builder_removed': image['builder_removed']}
save(r / 'final-cleanup.json', cleanup)
proof = raw_archive()
summary.update(cleanup=cleanup, receipts=proof, historical_preservation=verified, retained_runtime_preservation=retained,
               archived_candidate_inputs=inputs)
assert list(scope.iterdir()) == [r] and not any(path.is_socket() for path in r.rglob('*'))
assert not scope.is_mount() and not r.is_mount()
shutil.rmtree(r)
scope.rmdir()
assert not scope.exists()
summary['cleanup']['private_stage_removed'] = True
save(scorecard, summary)
print(scorecard, sha(scorecard), archive, proof['sha256'], flush=True)
