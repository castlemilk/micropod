"""Run the archived guest workload with bounded attached or detached stock Docker control."""
import json
import os
from pathlib import Path
import subprocess
import time
from uuid import uuid4

import bench_workspace_checkout as bench
import bench_workspace_runner as runner

transport = os.environ.get('MP_GAMMA2_TRANSPORT', 'attached')
assert transport in ('attached', 'detached')
original_guest = bench.Arm.guest
original_start = bench.Arm.start
result_root = Path('/mp-gamma2-results')


def start(arm, stack, name, stage, args, accepted_ids, *, extra_mounts=()):
    if transport == 'detached':
        bench.require(stage is not None, 'detached proof requires a scoped host results bind')
        arm.result_dir = stage / f'.mpg2-results-{arm.name}'
        arm.result_dir.mkdir(mode=0o700)
        extra_mounts = (*extra_mounts, bench.bind_mount(arm.result_dir, result_root, read_only=False))
    return original_start(arm, stack, name, stage, args, accepted_ids, extra_mounts=extra_mounts)


def snapshot(arm, mode, started, error):
    path = os.environ.get('MP_GAMMA2_FAILURE_PREFIX')
    if not path:
        return
    failure = {'workload': list(mode), 'backend': arm.name, 'container': arm.id, 'error': repr(error),
               'started_host_realtime': started, 'failure_host_realtime': time.time(), 'checks': {}, 'snapshot_errors': {}}

    def getter(label, action):
        try:
            failure['checks'][label] = action()
        except Exception as snapshot_error:
            failure['snapshot_errors'][label] = repr(snapshot_error)

    def query(route):
        return subprocess.check_output(['/usr/bin/curl', '-fsS', '--max-time', '6', '--unix-socket', str(arm.socket),
                                        'http://localhost' + route], text=True, timeout=8)

    def events():
        payload = query(f'/events?since={int(started)-1}&until={int(time.time())+2}')
        return [row for line in payload.splitlines() if (row := json.loads(line))['Actor']['ID'] == arm.id]

    getter('engine_events', events)
    rows = failure['checks'].get('engine_events', [])
    exits = [row for row in rows if row['Action'] == 'exec_die' and row['Actor']['Attributes'].get('exitCode') == '137']
    if exits:
        ident = exits[-1]['Actor']['Attributes']['execID']
        failure['exec_id'] = ident
        getter('exec_inspect', lambda: json.loads(query(f'/exec/{ident}/json')))
        begin = next((row for row in rows if row['Action'].startswith('exec_start:') and row['Actor']['Attributes']['execID'] == ident), None)
        if begin is not None:
            failure['elapsed_guest_event_ms'] = (exits[-1]['timeNano'] - begin['timeNano']) / 1e6
    getter('container_inspect_before_cleanup', arm.read_container)
    getter('guest_cgroup_memory_before_cleanup', lambda: bench.call([*arm.docker, 'exec', arm.id, 'sh', '-ec',
        'for p in memory.events memory.peak memory.current memory.max; do printf "%s\\n" "-- $p --"; '
        'cat "/sys/fs/cgroup/$p"; done; cat /proc/meminfo'], timeout=6).stdout.decode())
    Path(path + '-' + uuid4().hex[:8] + '.json').write_text(json.dumps(failure, indent=2) + '\n')


def detached_guest(arm, mode, timeout):
    token = uuid4().hex
    base = arm.result_dir / token
    code = Path(str(base) + '.exit')
    stdout = Path(str(base) + '.out')
    stderr = Path(str(base) + '.err')
    payload = ('out=$1; shift; '
               'if python3 /checkout-ci/driver.py --guest "$@" >"$out.out" 2>"$out.err"; then rc=0; else rc=$?; fi; '
               'printf "%s\\n" "$rc" >"$out.pending"; mv "$out.pending" "$out.exit"; exit "$rc"')
    bench.call([*arm.docker, 'exec', '-d', arm.id, 'sh', '-ec', payload, 'mp-gamma2-build',
                str(result_root / token), *map(str, mode)], timeout=10)
    deadline = time.monotonic() + timeout
    while not code.is_file():
        if time.monotonic() >= deadline:
            raise TimeoutError(f'{arm.name}: detached {mode[0]} did not publish a result in {timeout}s')
        time.sleep(0.01)
    outcome = int(code.read_text().strip())
    if outcome != 0:
        raise RuntimeError(f'{arm.name}: detached {mode[0]} exited {outcome}: {stderr.read_text(errors="replace")[-3500:]}')
    result = json.loads(stdout.read_bytes())
    for member in (code, stdout, stderr):
        member.unlink()
    return result


def timed(arm, *mode, timeout=120):
    started = time.monotonic_ns()
    realtime = time.time()
    try:
        if transport == 'attached':
            result = original_guest(arm, *mode, timeout=timeout)
        else:
            result = detached_guest(arm, mode, timeout)
    except Exception as error:
        snapshot(arm, mode, realtime, error)
        raise
    result['host_call_monotonic_ns'] = [started, time.monotonic_ns()]
    result['stock_docker_transport'] = transport
    return result


bench.Arm.start = start
bench.Arm.guest = timed
runner.main()
