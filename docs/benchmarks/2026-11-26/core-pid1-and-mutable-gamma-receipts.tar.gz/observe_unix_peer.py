"""Transparent scoped Unix socket relay with first-line, byte and EOF timing receipts."""
import argparse, asyncio, json, signal, threading, time
from pathlib import Path
from uuid import uuid4

class Relay:
    def __init__(self, local, upstream, log):
        self.local = local
        self.upstream = upstream
        self.log = log
        self.loop = asyncio.new_event_loop()
        self.ready = threading.Event()
        self._thread = threading.Thread(target=self.serve)
        self._thread.start()
        assert self.ready.wait(timeout=5)

    def event(self, connection, kind, **values):
        row = dict(connection=connection, kind=kind, host_monotonic_ns=time.monotonic_ns(),
                   host_realtime_ns=time.time_ns(), **values)
        self.log.write(json.dumps(row) + '\n')
        self.log.flush()

    async def copy(self, connection, src, dest, direction):
        expected = b''
        first_line = None
        total = 0
        while True:
            try:
                data = await src.read(65536)
            except Exception as error:
                self.event(connection, 'read_error', direction=direction, error=str(error), bytes=total)
                return
            if not data:
                self.event(connection, 'read_eof', direction=direction, bytes=total, first_line=first_line)
                try:
                    dest.write_eof()
                    self.event(connection, 'forwarded_half_close', direction=direction, bytes=total)
                except Exception as error:
                    self.event(connection, 'half_close_error', direction=direction, error=str(error), bytes=total)
                return
            total += len(data)
            if first_line is None:
                expected += data[:4096 - len(expected)]
                if b'\r\n' in expected:
                    first_line = expected.partition(b'\r\n')[0].decode('ascii', errors='replace')
                    self.event(connection, 'first_line', direction=direction, line=first_line)
            try:
                dest.write(data)
                await dest.drain()
            except Exception as error:
                self.event(connection, 'write_error', direction=direction, error=str(error), bytes=total)
                return

    async def accepted(self, reader, writer):
        connection = uuid4().hex[:12]
        self.event(connection, 'accepted')
        try:
            via, destination = await asyncio.open_unix_connection(self.upstream)
            try:
                await asyncio.gather(self.copy(connection, reader, destination, 'client_to_vmm'),
                                     self.copy(connection, via, writer, 'vmm_to_client'))
            finally:
                destination.close()
                try:
                    await destination.wait_closed()
                except (BrokenPipeError, ConnectionResetError) as error:
                    self.event(connection, 'upstream_release_error', error=str(error))
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except (BrokenPipeError, ConnectionResetError) as error:
                self.event(connection, 'release_error', error=str(error))
            self.event(connection, 'socket_released')

    def serve(self):
        async def run():
            self.stop = asyncio.Event()
            self.server = await asyncio.start_unix_server(self.accepted, path=self.local)
            self.ready.set()
            async with self.server:
                await self.stop.wait()
        self.loop.run_until_complete(run())
        self.loop.close()

    def close(self):
        self.loop.call_soon_threadsafe(self.stop.set)
        self._thread.join(timeout=5)
        assert not self._thread.is_alive()
        Path(self.local).unlink(missing_ok=True)


parser=argparse.ArgumentParser(description=__doc__)
for name in ('socket', 'upstream', 'log'):
    parser.add_argument('--'+name, type=Path, required=True)
a=parser.parse_args()
assert a.upstream.is_socket() and not a.socket.exists()
stop=threading.Event()
signal.signal(signal.SIGTERM, lambda *_: stop.set())
with a.log.open('x') as log:
    relay=Relay(a.socket, a.upstream, log)
    try:
        stop.wait()
    finally:
        relay.close()
