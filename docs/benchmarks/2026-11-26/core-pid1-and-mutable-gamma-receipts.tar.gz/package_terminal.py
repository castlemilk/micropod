"""Rebuild the release package from the outer commit and verify the saved patch."""
from pathlib import Path
import gzip, hashlib, io, json, os, stat, subprocess, tarfile, tempfile

root=Path.cwd()
work=root/'bench/phase0-host-scheduling'
dated=work/'docs/benchmarks/2026-11-26'
hub=Path('/private/tmp/mp-gamma2.FMDKh0/home')
receipts=hub.parent/'receipts'
product=hub/'tty-source'
frozen=json.loads((receipts/'tty-product-source.json').read_text())
base=frozen['outer_head']
sha=lambda b: hashlib.sha256(b).hexdigest()
def git(args,wd=root): return subprocess.check_output(['git','-C',str(wd),*args])
modes={}; blobs={}
def add(name,data,mode=0o644):
    assert name not in blobs
    blobs[name]=data; modes[name]=mode
prior=dated/'core-engine-sources.tar.gz'
with tarfile.open(prior) as src:
    prior_modes={m.name[5:]:m.mode for m in src.getmembers() if m.name.startswith('core/')}
paths=sorted(set(prior_modes)|set(frozen['swift_files']))
for rel in paths:
    data=(product/rel).read_bytes()
    assert sha(data)==frozen['package_source'][rel]
    add('core/'+rel,data,prior_modes.get(rel,0o644))

# Build a patch against the exact base. New files, including executable scripts,
# use their actual archive file modes.
with tempfile.TemporaryDirectory(dir=hub,prefix='terminal-patch-') as scratch:
    stage=Path(scratch)/'selected'; stage.mkdir()
    git(['init','-q'],stage)
    for entry in git(['ls-tree','-zr',base,'--',*paths]).split(b'\0'):
        if not entry:continue
        meta,path=entry.split(b'\t',1); mode,kind,oid=meta.split(); p=stage/os.fsdecode(path)
        assert kind==b'blob'; p.parent.mkdir(exist_ok=True,parents=True)
        p.write_bytes(git(['cat-file','blob',oid.decode()])); p.chmod(int(mode,8)&0o777)
    git(['add','.'],stage)
    for rel in paths:
        p=stage/rel; p.parent.mkdir(exist_ok=True,parents=True)
        p.write_bytes(blobs['core/'+rel]); p.chmod(modes['core/'+rel])
    git(['add','-N','.'],stage)
    patch=git(['diff','--no-ext-diff','--binary'],stage)
    add('native-terminal.patch',patch)
    checked=Path(scratch)/'applied'; checked.mkdir()
    tree=git(['archive',base,'--','Package.swift','Package.resolved','Sources','Tests','sdk/swift','signing','README.md'])
    with tarfile.open(fileobj=io.BytesIO(tree)) as a: a.extractall(checked,filter='data')
    for args in (['--check'],[]):
        subprocess.run(['git','apply',*args,'-'],input=patch,cwd=checked,check=True)
    for path,expected in frozen['package_source'].items():
        assert sha((checked/path).read_bytes())==expected,path
    assert os.access(checked/'ci/pinned-checkout-job.sh',os.X_OK)
for rel in ['qualify_native_exec_tty.py','qualify_docker_exec.py','qualify_cli_exec_density.py']:
    p=work/'scripts'/rel
    add('operators/'+rel,p.read_bytes(),stat.S_IMODE(p.stat().st_mode))
old=dated.parent/'2026-11-25/managed-ci-git-and-exec-sources.tar.gz'
old_dig=sha(old.read_bytes())
differs=[]
with tarfile.open(old) as archive:
    prior_guest={m.name[13:]:archive.extractfile(m).read() for m in archive.getmembers() if m.isfile() and m.name.startswith('final-runner/')}
peer=hub/'peer-diagnostic'
actual={str(p.relative_to(peer)):p.read_bytes() for p in peer.rglob('*') if p.is_file()}
assert set(actual)==set(prior_guest)
for rel,data in sorted(actual.items()):
    if data!=prior_guest[rel]:
        differs.append(rel)
        add('peer-diagnostic/'+rel,data)
add('tty-product-source.json',(receipts/'tty-product-source.json').read_bytes())
manifest={'outer_head':base,'previous_core_sha256':sha(prior.read_bytes()),'effective_package_files_verified':len(frozen['package_source']),
          'prior_runner_archive':old.name,'prior_runner_sha256':old_dig,'runner_overlay':differs,
          'peer_effective_files':{n:sha(d) for n,d in actual.items()},'sha256':{n:sha(d) for n,d in blobs.items()}}
add('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode())
out=dated/'native-terminal-sources.tar.gz'
with tempfile.NamedTemporaryFile(dir=dated,prefix='.native-terminal-',delete=False) as temp:
    tempname=temp.name
    with gzip.GzipFile(fileobj=temp,mode='wb',mtime=0,filename='') as compress:
        with tarfile.open(mode='w|',fileobj=compress) as tar:
            for name in sorted(blobs):
                item=tarfile.TarInfo(name); item.size=len(blobs[name]); item.mode=modes[name]
                tar.addfile(item,io.BytesIO(blobs[name]))
try:
    with tarfile.open(tempname) as tar:
        assert all(sha(tar.extractfile(n).read())==h for n,h in manifest['sha256'].items())
    if out.exists(): assert out.read_bytes()==Path(tempname).read_bytes()
    else: os.link(tempname,out)
finally:
    os.unlink(tempname)
print(json.dumps({'source_archive':str(out),'sha256':sha(out.read_bytes()),'verified_package_files':len(frozen['package_source']),
                  'runner_files':len(actual),'runner_overlay':differs},indent=2))
