#!/bin/bash
set -euo pipefail

receipts=$(cd "$(dirname "$0")" && pwd -P)
hub=$(dirname "$receipts")/home
job=${1:?exact staged job path}
expected=${2:?expected SHA-256}
base_name=${3:-tools-pid1-final}
bank_name=${4:-tools-combined-logs}
[[ $base_name =~ ^tools-[a-z0-9-]+$ && $bank_name =~ ^tools-[a-z0-9-]+$ && $expected =~ ^[0-9a-f]{64}$ ]]
base="$hub/artifacts/$base_name"
bank="$hub/artifacts/$bank_name"
test -d "$base"
test -f "$job" && test ! -L "$job"
test ! -e "$bank"
resolved=$(python3 -B -c 'from pathlib import Path; import sys; print(Path(sys.argv[1]).resolve(strict=True))' "$job")
[[ $resolved == "$hub/"* ]]

digest() { /usr/bin/shasum -a 256 "$1" | /usr/bin/cut -d' ' -f1; }
test "$(digest "$job")" = "$expected"
/bin/cp -Rc "$base" "$bank"
/bin/cp -p "$job" "$bank/runner/bin/job"
test "$(digest "$bank/runner/bin/job")" = "$expected"
/usr/bin/diff -qr -x job "$base" "$bank"
/usr/bin/shasum -a 256 "$bank/runner/bin/job" > "$receipts/${bank_name#tools-}-job-sha256.txt"
