"""Retain the exact qualified runtime binaries outside the disposable APFS hub."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

receipts = Path(__file__).resolve().parent
stage = receipts.parent
hub = stage / 'home'
repo = Path('/Users/benebsworth/projects/micropod')
publish = repo / '.build/qualified/micropod-hvf-gamma2-fmdkh0'


def sha(path):
    with path.open('rb') as src:
        return hashlib.file_digest(src, 'sha256').hexdigest()


def save_product(role, artifact):
    source = Path(artifact['path']).resolve(strict=True)
    expected = artifact['sha256']
    assert source.is_relative_to(hub) and sha(source) == expected, artifact
    name = f'{role}-{expected[:12]}'
    product = publish / name
    assert not product.is_symlink()
    if not product.exists():
        staged = product.with_suffix('.partial')
        assert not staged.exists()
        shutil.copy2(source, staged)
        assert sha(staged) == expected, staged
        staged.rename(product)
    assert sha(product) == expected and product.stat().st_size == source.stat().st_size
    result = {'staged_original': str(source), 'retained_path': str(product), 'sha256': expected,
              'size_bytes': product.stat().st_size}
    if role == 'micropod-vmm':
        command = ['/usr/bin/codesign', '--verify', '--strict', '--verbose=4', str(product)]
        check = subprocess.run(command, check=True, capture_output=True, text=True)
        result['codesign_stderr'] = check.stderr
    return result


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('worker', nargs='+', help='retired owned worker label')
args = parser.parse_args()
assert hub.is_mount()
subprocess.run(['/usr/bin/git', '-C', str(repo), 'check-ignore', str(publish)], check=True, capture_output=True)
publish.mkdir(exist_ok=True)
assert publish.resolve() == publish
summary = {}
for name in args.worker:
    final = json.loads((receipts / f'{name}-worker.json').read_bytes())
    assert final['label'] == name and final['scope_absent'] and final['machine']['clean_shutdown']
    roles = {'vmm': 'micropod-vmm', 'kernel': 'Image', 'initrd': 'mp-hvf-init', 'job': 'runner-job'}
    summary[name] = {role: save_product(filename, final['owned_artifacts'][role]) for role, filename in roles.items()}
path = receipts / 'qualified-runtime-binaries.json'
previous = json.loads(path.read_bytes()) if path.is_file() else {}
previous.update(summary)
local = publish / 'manifest.json'
payload = json.dumps(previous, indent=2) + '\n'
path.write_text(payload)
local.write_text(payload)
print(local)
