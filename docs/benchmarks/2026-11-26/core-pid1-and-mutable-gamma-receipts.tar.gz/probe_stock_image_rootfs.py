"""Compare stock Docker image inspect to the frozen OCI config and OrbStack."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile

receipts = Path(__file__).resolve().parent
hub = receipts.parent / 'home'
ready = json.loads((receipts / 'combined-image-ready.json').read_bytes())
image = json.loads((receipts / 'image.json').read_bytes())
assert image['tag'] == ready['benchmark_image']
config_digest = image['config_digest']
with tarfile.open(hub / 'artifacts/seed.tar') as seed:
    with seed.extractfile('blobs/' + config_digest.replace(':', '/', 1)) as config:
        encoded = config.read()
assert config_digest == 'sha256:' + hashlib.sha256(encoded).hexdigest()
rootfs = json.loads(encoded)['rootfs']
expected = {'Type': rootfs['type'], 'Layers': rootfs['diff_ids']}
environment = {key: value for key, value in os.environ.items() if not key.startswith('DOCKER_')}
observations = {}
for engine, socket in (('hvf', Path(ready['socket'])), ('orbstack', Path('/Users/benebsworth/.orbstack/run/docker.sock'))):
    assert socket.is_socket()
    command = ['/opt/homebrew/bin/docker', '--host', f'unix://{socket}', 'image', 'inspect', '--format', '{{json .RootFS}}', image['tag']]
    proc = subprocess.run(command, check=False, text=True, capture_output=True, env=environment, timeout=10)
    observed = json.loads(proc.stdout) if proc.returncode == 0 else None
    observations[engine] = {'value': observed, 'exit': proc.returncode, 'stderr': proc.stderr, 'matches_config': observed == expected}
passed = all(item['matches_config'] for item in observations.values())
print(json.dumps({'artifact': ready['owned_artifacts']['job'], 'image': image['tag'], 'config_digest': config_digest,
                  'expected': expected, 'observations': observations, 'passed': passed}, indent=2))
raise SystemExit(0 if passed else 1)
