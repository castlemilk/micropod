#!/bin/bash
set -euo pipefail

receipts=$(cd "$(dirname "$0")" && pwd -P)
arm=${1:?owned combined worker label}
ready="$receipts/$arm-ready.json"
socket=$(jq -er .socket "$ready")
test -S "$socket"
export MP_GAMMA2_VMM_SHA
MP_GAMMA2_VMM_SHA=$(jq -er .vmm_sha256 "$receipts/integrated-vmm-source.json")
test "$MP_GAMMA2_VMM_SHA" = "$(jq -er .owned_artifacts.vmm.sha256 "$ready")"
test "$(jq -er .owned_artifacts.kernel.sha256 "$ready")" = dba972178942b384b9eefd10dc1d92c0b9f063d5bcb2a9604e388400283f0ab6
test "$(jq -er .owned_artifacts.cli.sha256 "$ready")" = 31c78102d9a1ab7a07912cbbd89f2e3dd265889eae62663336d0fb1e595f0259

set +e
/bin/bash "$receipts/qualify_splice_backport.sh" "$arm" correctness > "$receipts/$arm-filesystem-operator.log" 2>&1
filesystem=$?
python3 -B "$receipts/qualify_stock_compose.py" "$ready" --out "$receipts/stock-compose-$arm.json" \
    > "$receipts/stock-compose-$arm.log" 2>&1
compose=$?
python3 -B "$receipts/stock_pid1_probe.py" --socket "$socket" --out "$receipts/$arm-stock-pid1.json" \
    > "$receipts/$arm-stock-pid1.log" 2>&1
stock=$?
if [[ $stock == 0 ]]; then
    jq -e '.errors == {} and (.cases | length == 4 and all(.[]; .pass)) and (.remaining_owned | length == 0)' \
        "$receipts/$arm-stock-pid1.json" >> "$receipts/$arm-stock-pid1.log" 2>&1
    stock=$?
fi
set -e
printf 'filesystem=%s stock_compose=%s stock_pid1=%s\n' "$filesystem" "$compose" "$stock" |
    tee "$receipts/$arm-functional-exit.log"
(( filesystem == 0 && compose == 0 && stock == 0 ))
