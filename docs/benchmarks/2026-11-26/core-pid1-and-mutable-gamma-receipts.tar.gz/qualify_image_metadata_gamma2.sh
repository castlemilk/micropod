#!/bin/bash
set -euo pipefail

receipts=$(cd "$(dirname "$0")" && pwd -P)
hub=$(dirname "$receipts")/home
ready="$receipts/combined-image-ready.json"
socket=$(jq -er .socket "$ready")
workspace=$(jq -er .workspace "$ready")
unit="$hub/image-inspect-candidate/runner.image-rootfs.test"
bound="$workspace/runner.image-rootfs.test"
expected=ebe8278169412d43ba2f64aebe512d8ba7ca05d37e4f9579625e655035a83928
test -S "$socket"
test "$(jq -er .owned_artifacts.job.sha256 "$ready")" = a8a2da8b20a73c6da621c1fb9d7833d5c9328a624a2818853edad4df41b2d916
test "$(/usr/bin/shasum -a 256 "$unit" | /usr/bin/cut -d' ' -f1)" = "$expected"
test ! -e "$bound"
/bin/cp -p "$unit" "$bound"
trap '/bin/unlink "$bound"' EXIT
test "$(/usr/bin/shasum -a 256 "$bound" | /usr/bin/cut -d' ' -f1)" = "$expected"

unset DOCKER_CONTEXT DOCKER_HOST DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH DOCKER_API_VERSION
docker=(/opt/homebrew/bin/docker --host "unix://$socket")
label=org.micropod.gamma2.image-tests=combine-fmdkh0
test -z "$("${docker[@]}" ps -aq)"
set +e
"${docker[@]}" run --rm --pull=never --network=none --label "$label" \
  --mount "type=bind,src=$bound,dst=/runner.test,readonly" alpine:3.23 /runner.test \
  -test.run '^TestDockerImageInspect' -test.v > "$receipts/combined-image-linux-tests.log" 2>&1
focused=$?
/bin/bash "$receipts/qualify_combined_gamma2.sh" combined-image > "$receipts/combined-image-functional-operator.log" 2>&1
functional=$?
python3 -B "$receipts/probe_stock_image_rootfs.py" > "$receipts/combined-image-stock-rootfs.json" 2> "$receipts/combined-image-stock-rootfs.log"
rootfs=$?
set -e
"${docker[@]}" ps -aq > "$receipts/combined-image-container-cleanup.log"
test ! -s "$receipts/combined-image-container-cleanup.log"
printf 'focused_linux=%s functional=%s stock_rootfs=%s\n' "$focused" "$functional" "$rootfs" |
    tee "$receipts/combined-image-qualification-exits.log"
(( focused == 0 && functional == 0 && rootfs == 0 ))
