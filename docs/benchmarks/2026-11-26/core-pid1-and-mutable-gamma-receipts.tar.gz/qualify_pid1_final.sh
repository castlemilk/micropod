#!/bin/bash
set -euo pipefail

receipts=$(cd "$(dirname "$0")" && pwd -P)
stage=$(dirname "$receipts")
candidate="$stage/home/pid1-candidate"
ready="$receipts/pid1-final-ready.json"
tools_dir="$stage/home/artifacts/tools-pid1-final"
stock_image=alpine:3.23
scratch_image=micropod-qa/pid1-scratch:gamma2-fmdkh0
job_sha=89d4b15421acfa0c1b7f94e2bad6809847b71690aa2f63e1e05de71e9129a348
test_sha=01af874751dc2707fec86829f3351c9e87c040662e6b477f4fe040dbfef5c602
image_sha=46a386da16ff0124ceed9b54f56c6644b1bd0fe4311410197fbccd8c53484fbf

digest() {
    /usr/bin/shasum -a 256 "$1" | /usr/bin/cut -d' ' -f1
}

if [[ ${1:-} == prepare ]]; then
    test "$(digest "$candidate/job.drain")" = "$job_sha"
    test "$(digest "$candidate/runner.drain.test")" = "$test_sha"
    test "$(digest "$candidate/pid1-scratch.tar")" = "$image_sha"
    test ! -e "$tools_dir"
    /bin/cp -Rc "$stage/home/artifacts/tools-baseline" "$tools_dir"
    /bin/cp -p "$candidate/job.drain" "$tools_dir/runner/bin/job"
    test "$(digest "$tools_dir/runner/bin/job")" = "$job_sha"
    /usr/bin/diff -qr -x job "$stage/home/artifacts/tools-baseline" "$tools_dir"
    /usr/bin/shasum -a 256 "$tools_dir/runner/bin/job" "$candidate/runner.drain.test" "$candidate/pid1-scratch.tar" \
        > "$receipts/pid1-final-inputs-sha256.txt"
    exit
fi

unset DOCKER_HOST DOCKER_CONTEXT DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH DOCKER_API_VERSION
sock=$(jq -er .socket "$ready")
work=$(jq -er .workspace "$ready")
export DOCKER_CONFIG
DOCKER_CONFIG=$(jq -er .environment.DOCKER_CONFIG "$ready")
test -S "$sock"
test "$(jq -er .owned_artifacts.job.sha256 "$ready")" = "$job_sha"
docker=(/opt/homebrew/bin/docker --host "unix://$sock")
tests="$work/probe-final-runner.test"
label=org.micropod.gamma2.pid1-tests=final-fmdkh0
test ! -e "$tests"
test -z "$("${docker[@]}" ps -aq --filter "label=$label")"
test -z "$("${docker[@]}" ps -aq)"
trap '/bin/rm -f "$tests"' EXIT

"${docker[@]}" load -i "$candidate/pid1-scratch.tar" > "$receipts/pid1-final-scratch-load.log" 2>&1
"${docker[@]}" image inspect "$scratch_image" --format '{{json .}}' > "$receipts/pid1-final-scratch-image.json"
test "$(jq -er .Architecture "$receipts/pid1-final-scratch-image.json")" = arm64
test "$(jq -er .Id "$receipts/pid1-final-scratch-image.json")" = sha256:890add5b4d9454b3a874f9e85aaa3065ba4595eb95d25034014b4e30503c3f01
/bin/cp -p "$candidate/runner.drain.test" "$tests"
test "$(digest "$tests")" = "$test_sha"

set +e
python3 -B "$receipts/stock_pid1_probe.py" --socket "$sock" --out "$receipts/pid1-final-stock-pid1.json" \
    > "$receipts/pid1-final-stock-pid1.log" 2>&1
independent=$?
if [[ $independent == 0 ]]; then
    jq -e '.errors == {} and (.cases | length == 4 and all(.[]; .pass)) and (.remaining_owned | length == 0)' \
        "$receipts/pid1-final-stock-pid1.json" >> "$receipts/pid1-final-stock-pid1.log" 2>&1
    independent=$?
fi
"${docker[@]}" run --rm --pull=never --network=none --label "$label" \
    --mount "type=bind,src=$tests,dst=/runner.test,readonly" "$stock_image" /runner.test -test.v \
    '-test.run=TestDockerPID1|TestDockerExecOutputDrainFollowsProgress|TestDockerNativeExec|TestPollReportsDisconnection|TestDockerOptionsAndMounts|TestDockerWaitReturnsTheOriginalExitAfterReplacement|TestDockerRestartFencesOtherMutationsAndSurvivesDisconnect' \
    > "$receipts/pid1-final-linux-tests.log" 2>&1
focused=$?
python3 -B "$candidate/qualifier-parity/qualify_docker_pid1.py" --host "unix://$sock" --workspace "$work" --image "$stock_image" \
    --scratch-image "$scratch_image" --out "$receipts/pid1-final-agent.json" > "$receipts/pid1-final-agent.log" 2>&1
broad=$?
python3 -B "$candidate/qualifier-parity/probe_pid1_spool_bound.py" --host "unix://$sock" --image "$stock_image" \
    --out "$receipts/pid1-drain-spool-bound.json" > "$receipts/pid1-drain-spool-bound.log" 2>&1
spool=$?
set -e

"${docker[@]}" ps -aq > "$receipts/pid1-final-container-cleanup.log"
test ! -s "$receipts/pid1-final-container-cleanup.log"
printf 'independent=%s focused_linux=%s full_stock=%s spool_bound=%s\n' "$independent" "$focused" "$broad" "$spool" |
    tee "$receipts/pid1-final-qualification-exits.log"
(( independent == 0 && focused == 0 && broad == 0 && spool == 0 ))
