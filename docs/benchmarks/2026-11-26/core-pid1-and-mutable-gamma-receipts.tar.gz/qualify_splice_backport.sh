#!/bin/bash
set -euo pipefail

receipts=$(cd "$(dirname "$0")" && pwd -P)
stage=$(dirname "$receipts")
arm=${1:-live-reads-splice}
workload=${2:-correctness}
ready="$receipts/$arm-ready.json"
socket=$(jq -er .socket "$ready")
workspace=$(jq -er .workspace "$ready")
image=$(jq -er .benchmark_image "$ready")
test -S "$socket"
vmm_sha=${MP_GAMMA2_VMM_SHA:-400ee99ae3b957c5233737618fc776e52d9e956eb200831746debc05d45711ca}
test "$(jq -er .owned_artifacts.vmm.sha256 "$ready")" = "$vmm_sha"
test "$(jq -er .live_read_requested "$ready")" = 1
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH DOCKER_API_VERSION

if [[ $workload == material ]]; then
    export MP_GAMMA2_TRANSPORT=detached MP_GAMMA2_VISIBILITY=1
    exec "$receipts/run_public_arm.sh" "$arm" material
fi
test "$workload" = correctness
mmap=(python3 -B "$stage/home/kernel-splice/guest_splice_contract.py" --docker-host "unix://$socket" --workspace "$workspace" --image "$image")
if [[ $arm != live-rebuilt-b5* ]]; then
    mmap+=(--require-live-splice)
fi

set +e
"$receipts/run_public_arm.sh" "$arm" edits
ordinary=$?
python3 -B "$stage/home/mutable-candidate/mmap_exact_timestamp.py" --docker-host "unix://$socket" --workspace "$workspace" \
    > "$receipts/$arm-mmap-exact-mtime.json" 2> "$receipts/$arm-mmap-exact-mtime.log"
exact=$?
"${mmap[@]}" > "$receipts/$arm-guest-mmap-contract.json" 2> "$receipts/$arm-guest-mmap-contract.log"
full=$?
set -e
/opt/homebrew/bin/docker --host "unix://$socket" ps -aq > "$receipts/$arm-correctness-container-cleanup.log"
test ! -s "$receipts/$arm-correctness-container-cleanup.log"
printf 'ordinary=%s exact_mtime=%s full_splice_and_mmap=%s\n' "$ordinary" "$exact" "$full" |
    tee "$receipts/$arm-correctness-exit.log"
(( ordinary == 0 && exact == 0 && full == 0 ))
