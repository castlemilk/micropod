"""Exercise an offline two-service stock Compose project without changing the host Docker context."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import tempfile
import time
from uuid import uuid4

ROOT = Path(__file__).resolve().parent
DOCKER = '/opt/homebrew/bin/docker'
COMPOSE = Path('/Applications/Docker.app/Contents/Resources/cli-plugins/docker-compose')
ORB = Path('/Users/benebsworth/.orbstack/run/docker.sock')


def sha(path):
    with path.open('rb') as src:
        return hashlib.file_digest(src, 'sha256').hexdigest()


def qualify(socket, image, expected_image, fixture, config):
    project = 'mp-g2-compose-' + uuid4().hex[:10]
    label = 'com.docker.compose.project'
    docker_env = {key: value for key, value in os.environ.items() if not key.startswith(('DOCKER_', 'COMPOSE_'))}
    docker_env.update(DOCKER_CONFIG=str(config), DOCKER_CLI_HINTS='false', NO_COLOR='1', MP_G2_SEEDED_IMAGE=image)
    (config / 'config.json').write_text(json.dumps({'cliPluginsExtraDirs': [str(COMPOSE.parent)]}))
    docker = [DOCKER, '--host', f'unix://{socket}']
    compose = [*docker, 'compose', '--ansi', 'never', '--project-name', project, '--env-file', '/dev/null', '--file', str(fixture)]
    result = {'endpoint': str(socket), 'project': project, 'scope_label': f'{label}={project}',
              'compose_binary': {'path': str(COMPOSE), 'sha256': sha(COMPOSE)}, 'fixture_sha256': sha(fixture),
              'commands': {}, 'passed': False}

    def command(name, base, *options, check=True):
        argv = [*base, *options]
        started = time.monotonic_ns()
        timed_out = False
        with subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=docker_env,
                              start_new_session=True) as process:
            try:
                stdout, stderr = process.communicate(timeout=24)
            except subprocess.TimeoutExpired:
                timed_out = True
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                stdout, stderr = process.communicate(timeout=4)
            proc = subprocess.CompletedProcess(argv, process.returncode, stdout, stderr)
        result['commands'][name] = {'argv': argv, 'exit': proc.returncode, 'stdout': proc.stdout, 'stderr': proc.stderr,
                                    'timed_out': timed_out, 'elapsed_ms': (time.monotonic_ns() - started) / 1e6}
        if check and proc.returncode:
            raise RuntimeError(f'{name} exited {proc.returncode}: {proc.stderr.strip()}')
        return proc

    def scoped(kind, name):
        args = ['container', 'ls', '-aq'] if kind == 'container' else ['network', 'ls', '-q']
        return command(name, docker, *args, '--filter', f'label={label}={project}').stdout.splitlines()

    try:
        command('compose_version', docker, 'compose', 'version')
        plugin = command('client_plugin', docker, 'info', '--format', '{{json .ClientInfo.Plugins}}')
        installed = next(entry for entry in json.loads(plugin.stdout) if entry['Name'] == 'compose')
        if not Path(installed['Path']).samefile(COMPOSE):
            raise RuntimeError(f'unexpected Docker Compose plugin: {installed}')
        manifest = command('offline_image', docker, 'image', 'inspect', '--format', '{{json .}}', image)
        info = json.loads(manifest.stdout)
        if info['Architecture'] != 'arm64' or info['Id'] not in expected_image:
            raise RuntimeError(f'unexpected Compose image identity: {info["Id"]}/{info["Architecture"]}')
        old_objects = (scoped('container', 'containers_before'), scoped('network', 'networks_before'))
        if any(old_objects):
            raise RuntimeError(f'new Compose label is already in use: {old_objects}')
        result['owned_project_started'] = True
        command('up', compose, 'up', '--detach', '--no-build', '--pull', 'never', '--wait', '--wait-timeout', '12')
        containers = scoped('container', 'containers_running')
        networks = scoped('network', 'networks_running')
        if len(containers) != 2 or len(networks) != 1:
            raise RuntimeError(f'expected two services and one project network: {containers}, {networks}')
        command('ps', compose, 'ps', '--format', 'json')
        logs = command('logs', compose, 'logs', '--no-color', '--no-log-prefix')
        if not {'app ready', 'worker ready'}.issubset(logs.stdout.splitlines()):
            raise RuntimeError(f'missing Compose service logs: {logs.stdout!r}')
        app = command('exec_app', compose, 'exec', '-T', 'app', 'cat', '/tmp/site/ready')
        worker = command('exec_worker', compose, 'exec', '-T', 'worker', 'python3', '-c',
                         'import sys, urllib.request; sys.stdout.buffer.write(urllib.request.urlopen("http://app:18080/ready", timeout=5).read())')
        if app.stdout != 'gamma compose\n' or worker.stdout != app.stdout:
            raise RuntimeError(f'incorrect app and peer HTTP payloads: {app.stdout!r}, {worker.stdout!r}')
        result['passed'] = True
    except (RuntimeError, subprocess.TimeoutExpired, ValueError, LookupError) as error:
        result['error'] = str(error)
        if result.get('owned_project_started'):
            command('failed_service_logs', compose, 'logs', '--no-color', '--no-log-prefix', check=False)
    finally:
        if result.get('owned_project_started'):
            try:
                command('down', compose, 'down', '--remove-orphans', '--timeout', '4')
            except (RuntimeError, subprocess.TimeoutExpired) as error:
                result['teardown_error'] = str(error)
            for kind in ('container', 'network'):
                remaining = scoped(kind, f'{kind}_after_down')
                if remaining:
                    result['passed'] = False
                    for object_id in remaining:
                        row = command(f'owned_{kind}_{object_id}', docker, kind, 'inspect', '--format', '{{json .}}', object_id)
                        info = json.loads(row.stdout)
                        labels = info['Config']['Labels'] if kind == 'container' else info['Labels']
                        if labels.get(label) != project:
                            raise RuntimeError(f'ownership changed for Compose {kind} {object_id}')
                        options = ['--force'] if kind == 'container' else []
                        command(f'remove_{kind}_{object_id}', docker, kind, 'rm', *options, object_id)
                result[f'remaining_{kind}s'] = scoped(kind, f'{kind}_final')
            result['passed'] &= not bool(result.get('teardown_error') or result['remaining_containers'] or result['remaining_networks'])
    return result


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('arm_ready', type=Path)
parser.add_argument('--orbstack', action='store_true')
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
assert not args.out.exists() and COMPOSE.is_file()
ready = json.loads(args.arm_ready.read_bytes())
workspace = Path(ready['workspace'])
socket = ORB if args.orbstack else Path(ready['socket'])
assert workspace.is_dir() and workspace.is_relative_to(ROOT.parent / 'home' / 'share') and socket.is_socket()
identity = json.loads((ROOT / 'image.json').read_bytes())
assert identity['tag'] == ready['benchmark_image']
expected = {identity['config_digest'], identity['manifest_digest']}
with tempfile.TemporaryDirectory(prefix='compose-config-', dir=workspace) as config:
    results = qualify(socket, identity['tag'], expected, ROOT / 'compose-stock.yaml', Path(config))
args.out.write_text(json.dumps(results, indent=2) + '\n')
raise SystemExit(0 if results['passed'] else 1)
