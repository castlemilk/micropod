"""Correlate scoped workload events with guest signal and host Unix relay traces."""
import argparse
import hashlib
import json
from pathlib import Path
import re

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('label')
a = p.parse_args()
r = Path(__file__).resolve().parent
tracefile = r / f'{a.label}-.trace-events'
rows = tracefile.read_text().splitlines()
trace_re = re.compile(r'^\s*(?P<comm>.+?)-(?P<sender>\d+)\s+\[(?P<cpu>\d+)\]\s+\S+\s*(?P<clock>\d+\.\d+):\s+(?P<event>.*)$')

def entry(line):
    m = trace_re.match(line)
    if not m:
        return None
    seconds, fraction = m['clock'].split('.')
    return {**m.groupdict(), 'mono_ns': int(seconds) * 10**9 + int(fraction.ljust(9, '0')), 'raw': line.strip()}


def returns(events):
    for e in events:
        if e['comm'] == 'job' and (m := re.fullmatch(r'sys_ppoll -> (0x[0-9a-f]+)', e['event'])):
            raw_value = int(m[1], 16)
            yield {**e, 'result_signed': raw_value - (1 << 64) if raw_value >= (1 << 63) else raw_value}


def readf(file):
    return json.loads(file.read_bytes())


events = [e for line in rows if (e := entry(line)) is not None]
ppoll = list(returns(events))
stats = (r / f'{a.label}-.trace-stats').read_text()
counts = [int(x) for x in re.findall(r'^(?:overrun|commit overrun|dropped events):\s*(\d+)', stats, re.M)]
assert counts and not any(counts)
peer = [json.loads(line) for line in (r / f'{a.label}-peer.jsonl').read_bytes().splitlines()]
failures = {}
for mode in ('direct', 'proxy'):
    for path in sorted(r.glob(f'{a.label}-{mode}-exec-*.json')):
        d = readf(path)
        if 'exec_inspect' not in d['checks'] or d['checks']['exec_inspect'].get('ExitCode') != 137:
            continue
        pid = d['checks']['exec_inspect']['Pid']
        signal_lines = [e for e in events if f'signal_generate: sig=9 ' in e['event'] and re.search(rf'\bpid={pid}\b', e['event'])]
        assert len(signal_lines) == 1, signal_lines
        signal = signal_lines[0]
        preceding = [e for e in ppoll if 0 <= signal['mono_ns'] - e['mono_ns'] <= 5_000_000]
        obs = {'proof': path.name, 'exec_id': d['exec_id'], 'guest_process_id': pid,
               'requested_work': d['workload'], 'guest_exec_elapsed_ms': d['elapsed_guest_event_ms'],
               'signal': signal, 'preceding_nonzero_runner_ppoll_5ms': preceding,
               'pid1_state_before_rc_cleanup': d['checks']['container_inspect_before_cleanup']['State'],
               'memory_before_rc_cleanup': d['checks'].get('guest_cgroup_memory_before_cleanup')}
        if preceding:
            obs['last_ppoll_to_signal_us'] = (signal['mono_ns'] - preceding[-1]['mono_ns']) / 1000
        if mode == 'proxy':
            post = next(e for e in peer if e.get('kind') == 'first_line' and f'/exec/{d["exec_id"]}/start' in e['line'])
            connection = [e for e in peer if e['connection'] == post['connection']]
            halved = next(e for e in connection if e.get('kind') == 'forwarded_half_close' and e.get('direction') == 'client_to_vmm')
            upstream = next(e for e in connection if e.get('kind') == 'read_eof' and e.get('direction') == 'vmm_to_client')
            obs.update(host_connection=connection, client_half_close_to_upstream_eof_ms=(upstream['host_monotonic_ns'] - halved['host_monotonic_ns']) / 1e6)
        failures[mode] = obs
print(json.dumps({'trace_sha256': hashlib.sha256(tracefile.read_bytes()).hexdigest(),
                  'trace_lost_events': sum(counts), 'failures': failures}, indent=2))
