"""Check the actual HTTP/CLI contract outcomes and report only the named objects from this run."""
import argparse, collections, gzip, hashlib, json, os, shutil, subprocess
from pathlib import Path
e=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('name')
parser.add_argument('ready',type=Path)
a=parser.parse_args()
ready=json.loads(a.ready.read_bytes())
result=e/(a.name+'.json.gz')
with gzip.open(result) as stream:
    data=json.load(stream)
assert data['version']==data['cli_api_version']=='1.47' and data['profile']=='engine'
assert len(data['operations'])==107 and len(data['candidate'])==len(data['reference'])==23
assert not [k for k,v in data['reference'].items() if 'error'in v]
sockets={'reference':Path('/Users/benebsworth/.orbstack/run/docker.sock'),'candidate':Path(ready['socket'])}
environment={k:v for k,v in os.environ.items() if not k.startswith('DOCKER_')}
cleanup={}
for side,scope in data['scopes'].items():
    labels=scope['labels']
    assert list(labels)==['io.micropod.engine-qualification']
    exact=next(iter(labels.items()))
    assert exact[1].startswith('mp-engine-') and len(exact[1])==42
    cleanup[side]={}
    for kind,argv in [('container',['container','ls','-aq']),('network',['network','ls','-q']),('volume',['volume','ls','-q'])]:
        raw=subprocess.check_output(['docker','--host','unix://'+str(sockets[side]),*argv,'--filter','label='+'='.join(exact)],env=environment,timeout=10)
        ids=raw.decode().splitlines()
        assert not ids,(side,kind,ids)
        cleanup[side][kind]=ids
groups={k:v['comparison']for k,v in data['candidate'].items()}
for name in ['container-lifecycle','container-events','archive-roundtrip','volume-lifecycle','network-lifecycle','stock-cli-attach','stock-cli-exec']:
    assert groups[name]=='matched',name
out={'profile':data['profile'],'api_version':'1.47','spec_sha256':data['spec_sha256'],'spec_operations':len(data['operations']),
     'operations_probed':sum('cases'in op for op in data['operations'].values()),'case_counts':dict(collections.Counter(groups.values())),
     'observed_differences':{k:{'reference':data['reference'][k].get('observed'),'candidate':data['candidate'][k].get('observed',data['candidate'][k].get('error'))}for k,v in groups.items() if v!='matched'},
     'job_sha256':ready['owned_artifacts']['job']['sha256'],'scopes':data['scopes'],'object_cleanup':cleanup,
     'qualifier_sha256':hashlib.sha256((e/'qualify_engine_api_v147.py').read_bytes()).hexdigest(),'observations':result.name,
     'observation_sha256':hashlib.sha256(result.read_bytes()).hexdigest()}
(e/(a.name+'-acceptance.json')).write_text(json.dumps(out,indent=2)+'\n')
print(out['case_counts'], out['operations_probed'])
