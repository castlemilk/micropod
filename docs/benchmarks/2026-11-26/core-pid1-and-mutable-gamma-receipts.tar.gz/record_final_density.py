"""Validate timing, artifact identities and real CPU overlap on the disk-backed guest."""
import json, statistics
from pathlib import Path
e=Path(__file__).resolve().parent
out={}
for n in (8,16):
    key={8:'combined-final-ci8',16:'combined-final-ci16-bounded'}[n]
    data=json.loads((e/(key+'.json')).read_bytes())
    accept=json.loads((e/(key+'-acceptance.json')).read_bytes())
    assert data['jobs_per_engine']==n==accept['jobs']
    jobs=[j for arm in data['arms'].values()for j in arm['jobs']]
    target=0.5 if n==8 else 0.25
    assert len({j['container_id'] for j in jobs})==2*n
    for j in jobs:
        c=j['limits']; assert c['cpu_quota_us']/c['cpu_period_us']==target and c['memory_bytes']==accept['memory_mib_per_job']*2**20 and c['source_read_only']
    rows={}
    for phase in ['warm','incremental']:
        h='hvf';o='orbstack'
        waves=[p[phase]for p in data['pairs']]
        for wave in waves:
            assert wave[h]['artifact_sha256']==wave[o]['artifact_sha256']
            for arm in [h,o]:
                block=wave[arm]
                assert block['peak_scored_parallelism']==n and block['all_jobs_overlap_ns']>0
                assert len(block['jobs'])==n
        ratios=accept['summary'][phase]['paired_hvf_over_orbstack']
        rows[phase]={'median_ms':accept['summary'][phase]['median_makespan_ms'],'pairs':len(waves),'hvf_wins':sum(v<1 for v in ratios),
                     'min_simultaneous_overlap_ms':min(w[a]['all_jobs_overlap_ns'] for w in waves for a in (h,o))/1e6}
    ticks=[t['delta_ticks']for t in map(json.loads,(e/(key+'-host-load.jsonl')).read_text().splitlines())if 'delta_ticks'in t]
    out[str(n)]={'per_job':{'cpus':target,'memory_mib':accept['memory_mib_per_job']},'actual':rows,'load_samples':len(ticks),
                 'weighted_system_idle_pct':sum(t['idle']for t in ticks)*100/sum(sum(t.values())for t in ticks),
                 'removed':sum(len(d['owned_ids'])for d in accept['cleanup'].values()),'guest':accept['docker_job_sha256']}
    if n==16:
        primes={}
        for arm,prepared in data['priming'].items():
            assert prepared['max_parallel_jobs']==8 and len(prepared['groups'])==2
            ids=[j['container_id']for g in prepared['groups']for j in g['jobs']]
            assert len(set(ids))==n and set(ids)=={j['container_id']for j in data['arms'][arm]['jobs']}
            assert all(g['peak_scored_parallelism']==8 and g['artifact_sha256']==prepared['artifact_sha256'] for g in prepared['groups'])
            primes[arm]=prepared['host_wall_ns']/1e9
        out[str(n)]['cold_preparation_seconds']=primes
    assert all(not d['remaining']for d in accept['cleanup'].values())
(e/'combined-final-density-summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
