"""Save the signed client, source and per-container results checked on Gamma."""
from pathlib import Path
import hashlib,json,re,statistics,tarfile
root=Path.cwd()
e=Path(__file__).resolve().parent
out=root/'bench/phase0-host-scheduling/docs/benchmarks/2026-11-26'
def read(name): return json.loads((e/(name+'.json')).read_bytes())
sha=lambda data:hashlib.sha256(data).hexdigest()
release=read('tty-release-product')
assert sha(Path(release['path']).read_bytes())==release['sha256']
freeze=read('tty-product-source')['package_source']
with tarfile.open(e/'tty-before-observer-sources.tar.gz') as archive:
    compiled=json.load(archive.extractfile('tty-product-source.json'))['package_source']
changed=[n for n in sorted(set(compiled)|set(freeze)) if compiled.get(n)!=freeze.get(n)]
assert changed==['Tests/MicropodRuntimeTests/DockerExecTests.swift']
comparison={'product_sha256':release['sha256'],'effective_files':len(freeze),'changed_after_release_build':changed,
            'built_manifest_sha256':sha(json.dumps(compiled,sort_keys=True).encode()),
            'qualified_manifest_sha256':sha(json.dumps(freeze,sort_keys=True).encode()),'production_package_files_unchanged':True}
(e/'tty-release-source-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
build_proof=read('tty-source-reconstruction')
assert sha((out/'native-terminal-sources.tar.gz').read_bytes())==build_proof['sha256']
rawlog=(e/'tty-release-tests.log').read_text()
suites=re.findall(r"Test Suite '([^']+)' passed .*?\n\s*Executed (\d+) tests?, with 0 failures",rawlog)
assert ('Selected tests','372') in suites
org=read('terminal-preserved-baseline')
cases={}
labels=[('corrected_pid1_guest','tty-release-hvf','pid1-corrected-ready'),('live_reads_guest','tty-observed-hvf','live-reads-ready'),
        ('orbstack','tty-observed-orb',None)]
for qualifier, label in [('tty-combined-hvf', 'combined_guest'), ('tty-large-log-hvf', 'large_log_guest')]:
    if (e/(qualifier+'.json')).exists():
        sock=Path(read(qualifier)['endpoint'].removeprefix('unix://')).resolve()
        workers=[p.stem for p in e.glob('*-ready.json') if json.loads(p.read_bytes()).get('socket') and Path(json.loads(p.read_bytes())['socket']).resolve()==sock]
        assert len(workers)==1, (qualifier, workers)
        labels.append((label,qualifier,workers[0]))
for name,record,worker in labels:
    result=read(record)
    assert result['sha256']==release['sha256'] and result['removed']==8 and result['remaining']==[]
    for client,expected in [('docker',6),('micropod',8)]:
        block=result['cases'][client]
        assert len(block)==expected and all(v['passed']for v in block.values())
        logs=block['eight_terminals']['jobs']
        assert {j['exit'] for j in logs}==set(range(20,28))
        assert len({j['guest']for j in logs})==8
    if record!='tty-release-hvf': assert result['observer_control']['exited_in_raw_mode_detected']
    if worker:
        spec=read(worker)
        artifact={k:v['sha256']for k,v in spec['owned_artifacts'].items()if isinstance(v,dict) and 'sha256'in v}
        result['worker_artifact_sha256']=artifact
    cases[name]=result
density=read('tty-nontty-density')
assert density['cli_sha256']==release['sha256'] and len(density['rounds'])==4
assert all(c['removed']==8 and not c['remaining'] for c in density['cleanup'].values())
paired={}
for c in ['micropod','docker']:
    samples=[(row['hvf-'+c]['ms'],row['orb-'+c]['ms'])for row in density['rounds']]
    paired[c]={'median_wave_ms':{name:statistics.median(v[i]for v in samples) for i,name in enumerate(['hvf','orbstack'])},
               'hvf_wins':sum(a<b for a,b in samples),'pairs':len(samples)}
report={'host':'Gamma-128GB.local','local_date':'2026-11-26','release':release,'source_archive':build_proof,
        'production_source_check':comparison,'xctest':{'total':372,'failed':0,'suites':dict(suites)},
        'case_groups':cases,'binary_density':density,'paired_density':paired,'original_benchmark':org,
        'raw_receipts':'core-pid1-and-mutable-gamma-receipts.tar.gz'}
target=out/'native-terminal-gamma.json'
temp=target.with_suffix('.pending')
temp.write_text(json.dumps(report,indent=2)+'\n')
temp.replace(target)
print(target,sha(target.read_bytes()))
