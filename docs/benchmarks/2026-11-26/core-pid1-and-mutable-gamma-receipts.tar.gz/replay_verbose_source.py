#!/usr/bin/env python3
"""Rebuild the frozen native guest in the independent protected checkout."""

import hashlib
import json
import os
from pathlib import Path
import subprocess

receipts = Path(__file__).resolve().parent
stage = receipts.parent / "home" / "docker-log-candidate"
replay = stage / "source-replay"
repo = replay / "repo"
binary = replay / "job.verbose-v2-rebuilt"
go = "/Users/benebsworth/.local/share/mise/installs/go/1.27.2/bin/go"
env = os.environ.copy()
env.pop("GOROOT", None)
env.update(GOOS="linux", GOARCH="arm64", CGO_ENABLED="0")
flags = [go, "build", "-p=2", "-trimpath", "-o", str(binary), "."]
with (receipts / "docker-verbose-v2-rebuild.log").open("x") as out:
    build = subprocess.run(flags, cwd=repo / "guest" / "runner", env=env,
                           stdout=out, stderr=subprocess.STDOUT, timeout=30)
manifest = json.loads((stage / "verbose-v2-source.json").read_text())
expected = manifest["artifacts"]["job.verbose-v2"]
actual = hashlib.sha256(binary.read_bytes()).hexdigest() if build.returncode == 0 else None
report = {"passed": build.returncode == 0 and actual == expected, "build_exit": build.returncode,
          "expected_sha256": expected, "rebuilt_sha256": actual,
          "source_archive_sha256": manifest["artifacts"]["verbose-v2-source.tar.gz"],
          "vcs": (receipts / "docker-verbose-v2-replay-vcs.txt").read_text().strip(),
          "build": "go build -p=2 -trimpath .", "environment": {k: env[k] for k in ("GOOS", "GOARCH", "CGO_ENABLED")}}
with (receipts / "docker-verbose-v2-rebuild.json").open("x") as out:
    json.dump(report, out, indent=2)
    out.write("\n")
assert report["passed"], report
