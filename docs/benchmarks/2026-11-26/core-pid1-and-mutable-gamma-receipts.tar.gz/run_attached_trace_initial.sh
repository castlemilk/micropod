#!/bin/bash
set -euo pipefail
r=$(cd "$(dirname "$0")" && pwd -P)
s=$(dirname "$r")
e="$s/home/evidence/prior"
arm=${1:-attached-trace}
python3 -B "$r/public_machine.py" "$arm" --tools "$s/home/artifacts/tools-signal" > "$r/$arm-owner.log" 2>&1 &
owner=$!
relay=
cleanup() {
  rc=$?
  trap - EXIT
  if [ -n "$relay" ]; then
    if kill -0 "$relay" 2>/dev/null; then kill -TERM "$relay"; fi
    wait "$relay" || rc=1
  fi
  ready="$r/$arm-ready.json"
  if [ -f "$ready" ]; then
    release=$(jq -er .release_file "$ready")
    public=$(jq -er .public_scope "$ready")
    [ "$release" = "$public/release" ]
    if [ -d "$public" ]; then touch "$release"; fi
  elif kill -0 "$owner" 2>/dev/null; then
    kill -TERM "$owner"
  fi
  wait "$owner" || rc=1
  exit "$rc"
}
trap cleanup EXIT
trap 'exit 130' INT TERM
while [ ! -f "$r/$arm-ready.json" ]; do
  kill -0 "$owner" 2>/dev/null || exit 1
  sleep .25
done
sock=$(jq -er .socket "$r/$arm-ready.json")
work=$(jq -er .workspace "$r/$arm-ready.json")
image=$(jq -er .benchmark_image "$r/$arm-ready.json")
if [ -n "${MP_GAMMA2_MMAP_QUALIFIER:-}" ]; then
  python3 -B "$MP_GAMMA2_MMAP_QUALIFIER" --docker-host "unix://$sock" --workspace "$work" \
    > "$r/$arm-mmap-exact-mtime.json" 2> "$r/$arm-mmap-exact-mtime.log" || true
fi
token=$(python3 -B -c 'import secrets;print(secrets.token_hex(8))')
controller=(python3 -B "$e/trace-proof/trace_proof.py")
"${controller[@]}" start --workspace "$work" --token "$token" > "$r/$arm-trace-start.json"
proxy="$r/$arm-proxy.sock"
python3 -B "$r/observe_unix_peer.py" --socket "$proxy" --upstream "$sock" --log "$r/$arm-peer.jsonl" \
    > "$r/$arm-peer.log" 2>&1 &
relay=$!
for i in {1..60}; do
  [ ! -S "$proxy" ] || break
  kill -0 "$relay" 2>/dev/null || exit 1
  sleep .1
done
test -S "$proxy"
for mode in proxy direct; do
  endpoint="$sock"
  if [ "$mode" = proxy ]; then endpoint="$proxy"; fi
  result=0
  MP_GAMMA2_TRANSPORT=attached MP_GAMMA2_VISIBILITY=0 MP_GAMMA2_FAILURE_PREFIX="$r/$arm-$mode-exec" \
    PYTHONPATH="$e/final-harness/scripts" python3 -B "$r/with_host_load.py" --out "$r/$arm-$mode-host-load.jsonl" -- \
    python3 -B "$r/measure_main_ci.py" --hvf-socket "$endpoint" --orbstack-socket /Users/benebsworth/.orbstack/run/docker.sock \
      --workspace "$work" --source "$e/runner-vendored" --image "$image" \
      --image-manifest "$r/image-manifest.json" --pairs 2 --cpus 2 --memory-mib 1536 --out "$r/$arm-$mode-repro.json" \
      > "$r/$arm-$mode-repro.log" 2>&1 || result=$?
  printf '%s %d\n' "$mode" "$result"
done
"${controller[@]}" finish --workspace "$work" --token "$token" > "$r/$arm-trace-finish.json" || true
for f in "$work"/.trace-*; do
  [ ! -f "$f" ] || cp -p "$f" "$r/$arm-${f##*/}"
done
