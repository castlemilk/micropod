#!/bin/bash
set -euo pipefail
r=$(cd "$(dirname "$0")" && pwd -P)
name=${1:?owned arm name}
shift
python3 -B "$r/public_machine.py" "$name" "$@" > "$r/$name-owner.log" 2>&1 &
owner=$!
retire() {
  rc=$?
  trap - EXIT
  ready="$r/$name-ready.json"
  if [ -f "$ready" ]; then
    release=$(jq -er .release_file "$ready")
    root=$(jq -er .public_scope "$ready")
    [ "$release" = "$root/release" ]
    if [ -d "$root" ]; then touch "$release"; fi
  elif kill -0 "$owner" 2>/dev/null; then
    kill -TERM "$owner"
  fi
  wait "$owner" || rc=1
  exit "$rc"
}
trap retire EXIT
trap 'exit 130' INT TERM
while [ ! -f "$r/$name-ready.json" ]; do
  kill -0 "$owner" 2>/dev/null || exit 1
  sleep .25
done
rc=0
"$r/run_public_arm.sh" "$name" edits || rc=1
MP_GAMMA2_TRANSPORT=detached MP_GAMMA2_VISIBILITY=1 "$r/run_public_arm.sh" "$name" material || rc=1
if [ -n "${MP_GAMMA2_MMAP_QUALIFIER:-}" ]; then
  sock=$(jq -er .socket "$r/$name-ready.json")
  work=$(jq -er .workspace "$r/$name-ready.json")
  python3 -B "$MP_GAMMA2_MMAP_QUALIFIER" --docker-host "unix://$sock" --workspace "$work"     > "$r/$name-mmap-exact-mtime.json" 2> "$r/$name-mmap-exact-mtime.log" || rc=1
fi
exit "$rc"
