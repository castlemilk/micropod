"""Summarize scored Gamma public-machine arms and the independent correctness checks."""
from collections import Counter
import hashlib
import json
from pathlib import Path
from statistics import median

r = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_bytes())


def milliseconds(ns):
    return ns / 1e6 if ns is not None else None


def receipt(path):
    return {'path': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def load(tag):
    path = r / f'{tag}-host-load.jsonl'
    lines = [json.loads(line) for line in path.read_bytes().splitlines()]
    samples = [row for row in lines if row.get('cpu_idle_pct') is not None]
    ticks = Counter()
    for row in samples:
        ticks.update(row['delta_ticks'])
    values = [row['cpu_idle_pct'] for row in samples]
    return {'sidecar': path.name, 'observations': len(values), 'interval_s': 1.0,
            'weighted_cpu_idle_pct': 100 * ticks['idle'] / ticks.total(),
            'min_median_max_cpu_idle_pct': [min(values), median(values), max(values)],
            'min_max_load_avg_1m': [min(row['load_average'][0] for row in samples), max(row['load_average'][0] for row in samples)],
            'first_last_utc': [lines[0]['utc'], lines[-2]['utc']]}


def timing(path):
    data = read(path)
    result = {'artifact': path.name, 'fixture': data['source'], 'git_commit': data['git_commit'], 'image': data['image'],
              'pairs': len(data['pairs']), 'cpus': data['cpus'], 'memory_mib': data['memory_mib'],
              'load': load(path.stem), 'rounds': {}, 'timing_scopes': data['timing_scopes'],
              'cold_guest_milliseconds': {engine: milliseconds(values['sum_ns']) for engine, values in data['prime'].items()}}
    for phase in ('warm', 'incremental'):
        paired = [block[phase] for block in data['pairs']]
        by_eng = {}
        for engine in ('hvf', 'orbstack'):
            rows = [block[engine] for block in paired]
            timings = [row['visibility']['edit_return_to_correct_ns'] for row in rows if row['visibility']['edit_return_to_correct_ns'] is not None]
            by_eng[engine] = {'guest_median_ms': data['median_ms'][phase][engine],
                              'phase_medians_ms': {key: milliseconds(median(row['phase_ns'][key] for row in rows))
                                                   for key in rows[0]['phase_ns']},
                              'host_total_median_ms': data['host_update_wall_median_ms'][phase][engine],
                              'edit_return_to_matching_guest_bytes_median_ms': data['edit_return_to_correct_median_ms'][phase][engine],
                              'edit_return_to_matching_guest_bytes_max_ms': milliseconds(max(timings)) if timings else None,
                              'edit_through_verified_build_median_ms': data['edit_to_completed_build_median_ms'][phase][engine],
                              'first_checksum_mismatches': sum(row['visibility']['observations'][0]['sha256'] != row['visibility']['expected_sha256']
                                                               for row in rows)}
        result['rounds'][phase] = {'engines': by_eng,
                                   'paired_guest_time_hvf_wins': sum(x['hvf']['sum_ns'] < x['orbstack']['sum_ns'] for x in paired),
                                   'median_per_pair_guest_time_hvf_to_orb_ratio': median(x['hvf']['sum_ns'] / x['orbstack']['sum_ns'] for x in paired),
                                   'paired_total_host_time_hvf_wins': sum(x['hvf']['host_update_wall_ns'] < x['orbstack']['host_update_wall_ns'] for x in paired)}
    return result


def sampled_edits(path):
    data = read(path)
    return {'complete': data['complete'], 'median_observed_ms': data['median_observed_ms'],
            'outcomes': {case: dict(Counter(row['result'] for row in rows)) for case, rows in data['samples'].items()},
            'failure': data.get('edit_failure'), 'load': load(path.stem)}


def attached_control(transport):
    arm = f'peer-attached-{transport}'
    path = r / f'{arm}-repro.json'
    data = read(path)
    return {'receipt': receipt(path), 'pairs': len(data['pairs']),
            'cold_guest_milliseconds': {engine: milliseconds(row['sum_ns']) for engine, row in data['prime'].items()},
            'medians_milliseconds': data['median_ms'], 'load': load(arm)}


timings = {path.stem: timing(path) for path in sorted(r.glob('*-material.json')) if path.stat().st_size and 'timing_scopes' in read(path)}
if 'live-reads-material' in timings:
    timings['live-reads-material']['concurrent_work'] = {
        'kind': 'two warm Go cross-builds for the PID 1 worker near the start of the run',
        'duration_seconds_estimate': [1, 2], 'observed_artifact_creation_local': ['04:05:26', '04:05:27'],
        'repeat': 'live-reads-repeat-material.json',
    }
edits = {path.stem: sampled_edits(path) for path in sorted(r.glob('*-edits.json')) if path.stat().st_size}
stock = {path.stem: read(path) for path in sorted(r.glob('*-stock-pid1.json')) if path.stat().st_size}
workers = {path.stem.removesuffix('-worker'): read(path) for path in sorted(r.glob('*-worker.json')) if path.stat().st_size}
irq = {}
for arm in ('irq-control','irq-early'):
    if arm not in workers or 'vmm' not in workers[arm]['owned_artifacts']:
        continue
    marker_lines = []
    for kind in ('console','supervisor'):
        path = r / f'{arm}-{kind}.log'
        if path.is_file():
            marker_lines.extend(row for row in path.read_text(errors='replace').splitlines() if 'first_reply_irq' in row)
    irq[arm] = {'requested_mode': workers[arm].get('early_irq_requested'),
                'vmm': workers[arm]['owned_artifacts'].get('vmm'), 'observed_log_lines': marker_lines}
if len(irq) == 2:
    assert len({d['vmm']['sha256'] for d in irq.values()}) == 1

mmap = {path.stem: read(path) for path in sorted(r.glob('*-mmap-exact-mtime.json')) if path.stat().st_size}
def filesystem_qualification(arm):
    source = workers[arm]
    console = r / f'{arm}-console.log'
    contract = r / f'{arm}-guest-mmap-contract.json'
    lines = console.read_text(errors='replace').splitlines() if console.is_file() else []
    return {'requested_mode': source.get('live_read_requested'), 'artifacts': source['owned_artifacts'], 'worker_errors': source['errors'],
            'observed_log_lines': [row for row in lines if 'direct_io_mmap' in row],
            'guest_mmap_contract': {'receipt': receipt(contract), 'result': read(contract)}
            if contract.is_file() and contract.stat().st_size else None}


filesystem_windows = {'live-reads', 'live-rebuilt-b5-retry', 'live-reads-splice', 'combined'}
fs_qualifications = {arm: filesystem_qualification(arm) for arm, worker in workers.items()
                     if worker.get('scope_absent') and (arm in filesystem_windows or arm.startswith('combined-'))}
assert fs_qualifications['live-reads']['observed_log_lines']
peer_lines = (r / 'peer-attached-.trace-events').read_text().splitlines()
peer_console = (r / 'peer-attached-console.log').read_text(errors='replace').splitlines()
peer = {'frozen_job': workers['peer-attached']['owned_artifacts']['job'],
        'arms': {kind: attached_control(kind) for kind in ('direct', 'proxy')},
        'trace': receipt(r / 'peer-attached-.trace-events'),
        'trace_lost_events': read(r / 'peer-attached-trace-finish.json'),
        'observed_sigkill_python': [row for row in peer_lines if 'signal_generate: sig=9' in row and 'comm=python3 ' in row],
        'observed_nonzero_runner_ppoll': [row for row in peer_lines if 'job-' in row and 'sys_ppoll -> ' in row
                                          and row.rsplit('sys_ppoll -> ', 1)[1] != '0x0'],
        'observed_disconnect_lines': [row for row in peer_console if 'peer disconnect' in row.lower()]}
pid1_qualifiers = [r / name for name in ('pid1-initial-agent.json', 'pid1-corrected-agent-readonly.json', 'pid1-parity-orb.json',
                                        'pid1-final-agent.json', 'pid1-final-linux-tests.log', 'pid1-drain-spool-bound.json')]
pid1 = {path.stem: {'receipt': receipt(path), 'result': read(path)} if path.suffix == '.json' else {'receipt': receipt(path)}
        for path in pid1_qualifiers if path.is_file() and path.stat().st_size}
for arm in ('pid1-initial', 'pid1-corrected', 'pid1-final'):
    if arm in workers:
        pid1[arm] = {'job': workers[arm]['owned_artifacts']['job'], 'ready_receipt': receipt(r / f'{arm}-ready.json')}
compose = {path.stem: {'receipt': receipt(path), 'passed': read(path)['passed'], 'observations': read(path).get('error')}
           for path in sorted(r.glob('stock-compose-*.json')) if path.stat().st_size}
integrated_ci = {}
for path in sorted(r.glob('combined*ci*-acceptance.json')):
    arm = path.stem.removesuffix('-acceptance')
    integrated_ci[arm] = {'acceptance_receipt': receipt(path), 'measurements': receipt(r / f'{arm}.json'),
                          'result': read(path), 'load': load(arm)}
integrated_ci_failures = {}
for path in sorted(r.glob('combined*ci*-failure-events.json')):
    arm = path.stem.removesuffix('-failure-events')
    log = r / f'{arm}.log'
    lines = log.read_text().splitlines()
    integrated_ci_failures[arm] = {'events_receipt': receipt(path), 'log_receipt': receipt(log),
                                   'workload_errors': list(dict.fromkeys(line for line in lines if line.startswith('RuntimeError: '))),
                                   'load': load(arm),
                                   'engine_events': {engine: {'actions': dict(Counter(row['action'] for row in data['scoped_events'])),
                                                              'observed_container_count': len(data['observed_ids']),
                                                              'remaining_ids': data['remaining_from_run']}
                                                     for engine, data in read(path).items()}}
    kernel_log = r / f'{arm}-oom-console.log'
    if kernel_log.is_file():
        records = kernel_log.read_text().splitlines()
        integrated_ci_failures[arm]['kernel_oom'] = {'receipt': receipt(kernel_log), 'lines': len(records),
                                                   'global_oom_compile': sum('global_oom' in row and 'task=compile' in row for row in records),
                                                   'cgroup_oom_compile': sum('CONSTRAINT_MEMCG' in row and 'task=compile' in row for row in records)}
log_receipts = sorted(r.glob('docker-verbose-*.json'))
reference = r / 'candidate-inputs/docker-log-candidate/orbstack-verbose.json'
if reference.is_file():
    log_receipts.append(reference)
verbose_logging = {path.relative_to(r).as_posix(): {'sha256': receipt(path)['sha256'], 'result': read(path)}
                   for path in log_receipts if path.stat().st_size}
release_qualifiers = {}
api_and_packaging = [*sorted(r.glob('docker-engine-api-1.47*acceptance.json')), r / 'packaging-signature-proof.json',
                     r / 'combined-image-stock-rootfs.json', r / 'combined-final-density-summary.json',
                     r / 'bounded-cold-prime-source.json']
for path in api_and_packaging:
    if path.is_file() and path.stat().st_size:
        release_qualifiers[path.stem] = {'receipt': receipt(path), 'result': read(path)}
for path in sorted([*r.glob('tty-combined*.json'), *r.glob('tty-large-log-*.json')]):
    if path.stat().st_size:
        release_qualifiers[path.stem] = {'receipt': receipt(path), 'result': read(path)}
capacity = r / 'combined-logs-capacity.txt'
output = {'host': 'Gamma-128GB.local', 'date_melbourne': '2026-11-26',
          'frozen_vmm': read(r / 'current-vmm-source.json'), 'checkout_image': read(r / 'image.json'),
          'splice_kernel_build': read(r / 'virtiofs-splice-kernel-build.json'),
          'stock_pid1_alpine_platform': read(r / 'stock-pid1-alpine-image-identity.json'),
          'material': timings, 'mutable_edits': edits, 'mmap_exact_timestamp': mmap,
          'stock_pid1_lifecycle': stock, 'pid1_qualification': pid1, 'irq_controls': irq, 'filesystem_qualifications': fs_qualifications,
          'stock_compose_qualification': compose, 'combined_ci': integrated_ci, 'combined_ci_failures': integrated_ci_failures,
          'docker_verbose_logging': verbose_logging,
          'release_qualifiers': release_qualifiers,
          'pre_density_guest_capacity': {'receipt': receipt(capacity), 'observation': capacity.read_text().splitlines()},
          'combined_vmm_source': read(r / 'integrated-vmm-source.json'), 'retained_runtime_binaries': read(r / 'qualified-runtime-binaries.json'),
          'attached_failure_replay': read(r / 'baseline-attached-exits.json'),
          'attached_syscall_reconciliation': read(r / 'e057-attached-reconciliation.json'),
          'attached_peer_diagnostic': peer}
if (r / 'baseline-detached-material.log').is_file():
    output['initial_no_visibility_gate_error'] = (r / 'baseline-detached-material.log').read_text().strip().splitlines()[-1]
print(json.dumps(output, indent=2))
