from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

root = Path.cwd()
base = '76a329b6e464441ec1f6f0263940b0a327b7fa39'
stage = Path('/private/tmp/mp-gamma2.FMDKh0')
toolroot = stage/'home/tty-source'
receipts = stage/'receipts'
prior = root/'bench/phase0-host-scheduling/docs/benchmarks/2026-11-26/core-engine-sources.tar.gz'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(prior.read_bytes())=='9e92d3bbd192a4adb194c5b6b1f4fbcd4b2a94909e95ed757d4c76dbc82a0503'
toolroot.mkdir(exist_ok=True)
if not (toolroot/'Package.swift').exists():
    git=subprocess.check_output(['git','archive',base,'--','Package.swift','Package.resolved','Sources','Tests','sdk/swift','signing','README.md'])
    with tarfile.open(fileobj=io.BytesIO(git)) as ar:
        ar.extractall(toolroot,filter='data')
    with tarfile.open(prior) as ar:
        manifest = json.load(ar.extractfile('manifest.json'))['sha256']
        for name,h in manifest.items():
            if name.startswith('core/'):
                contents=ar.extractfile(name).read()
                assert sha(contents)==h
                dst=toolroot/name[5:]; dst.parent.mkdir(exist_ok=True,parents=True);dst.write_bytes(contents)
files=[
 'Sources/MicropodCLI/ArgParser.swift','Sources/MicropodCLI/TerminalSignals.swift',
 'Sources/MicropodCLI/MicropodCLI.swift','Sources/MicropodCLI/ContainerCommands.swift',
 'Sources/MicropodRuntime/Engines/HVFEngine.swift','Sources/MicropodRuntime/Engines/DockerEngine.swift','Sources/MicropodRuntime/Engines/DockerExecAttachment.swift',
 'Sources/MicropodRuntime/Engines/EngineResources.swift','Sources/MicropodRuntime/Engines/HVFEngineResources.swift',
 'Sources/MicropodRuntime/Engines/DockerExecTerminal.swift','Tests/MicropodCLITests/ArgParserTests.swift',
 'Tests/MicropodRuntimeTests/DockerExecTests.swift']
for file in files:
    data=(root/file).read_bytes()
    if file=='Sources/MicropodCLI/MicropodCLI.swift':
        # Other sessions are updating the service registry and help. Isolate the command-line entry point.
        source=data.decode()
        original=subprocess.check_output(['git','show',base+':'+file],text=True)
        head='    static func main() async {'; tail='    static func isTTY()'
        data=(original[:original.index(head)]+source[source.index(head):source.index(tail)]+original[original.index(tail):]).encode()
    (toolroot/file).write_bytes(data)
def all_hashes():
    paths=[p for item in toolroot.iterdir() if item.name != '.build'
           for p in (item.rglob('*') if item.is_dir() else (item,)) if p.is_file()]
    return {str(p.relative_to(toolroot)):sha(p.read_bytes()) for p in sorted(paths)}
manifest={'outer_head':base,'prior_core_bundle':sha(prior.read_bytes()),'swift_files':files,'package_source':all_hashes()}
(receipts/'tty-product-source.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(toolroot,len(manifest['package_source']))
