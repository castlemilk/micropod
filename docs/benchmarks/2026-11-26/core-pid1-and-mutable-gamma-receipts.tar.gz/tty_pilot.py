import json,os,subprocess,sys,time,uuid,signal
from pathlib import Path
p=Path('/private/tmp/mp-gamma2.FMDKh0/receipts')
sys.path.insert(0,str(Path.cwd()/'bench/phase0-host-scheduling/scripts'))
from qualify_docker_exec import attached,TTY_COMMAND,winsize
r=json.loads((p/'baseline-ready.json').read_text());env=r['environment']
name='mp-tty-pilot-'+uuid.uuid4().hex[:12];docker='/opt/homebrew/bin/docker'
d=lambda args:subprocess.run([docker,*args],env=env,timeout=20,capture_output=True,check=True)
report={}
d(['run','--pull=never','--detach','--name',name,'--label','io.micropod.qa='+name,'--entrypoint','/bin/sleep','alpine:3.23','240'])
try:
 for key,cli in [('baseline',env['MICROPOD_CLI']),('stock',docker),('dev',str(Path('.build/debug/micropod').resolve()))]:
  row={};report[key]=row
  try:
   with attached([cli,'exec','-it',name,'/bin/sh','-c',TTY_COMMAND],size=(31,97),env=env) as io:
    end=time.monotonic()+5
    io.expect_line(b'initial 31 97',end);io.expect_line(b'tty stderr',end);row['early']=True
    winsize(io.master,(42,113))
    for _ in range(20):
     io.process.send_signal(signal.SIGWINCH); io.send(b'size\n',end);size=io.line(end)
     if size==b'size 42 113':break
     time.sleep(.04)
    assert size==b'size 42 113',size
    row['resize']=True
    io.send(b'\x04',end);io.expect_line(b'tty eof',end);io.finish(end,37)
    row['exit']=37
  except Exception as exc:row['error']=str(exc)
finally:
 d(['rm','-f',name])
 report['remaining']=d(['ps','-aq','--filter','label=io.micropod.qa='+name]).stdout.decode().strip()
 (p/'tty-pilot.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
