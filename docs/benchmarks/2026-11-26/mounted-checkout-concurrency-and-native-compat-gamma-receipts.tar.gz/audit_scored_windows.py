"""Cross-check measurements against recorded, owned candidate builds."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re

receipts = Path(__file__).resolve().parent


def identity(path):
    return {'path': path.relative_to(receipts).as_posix(),
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def timepoint(value):
    return datetime.fromisoformat(value)


def row(start, finish, paths):
    start, finish = map(timepoint, (start, finish))
    assert finish >= start
    return {'started_utc': start.isoformat(), 'finished_utc': finish.isoformat(),
            'receipts': [identity(path) for path in paths]}


def build_windows():
    result = {}
    for name, receipt in (('compact-preview', 'kernel-compact/build-1.json'),
                          ('compact-v1', 'kernel-compact/final/build.json'),
                          ('compact-v2', 'kernel-compact/lookup/build.json')):
        path = receipts / receipt
        data = json.loads(path.read_bytes())
        result[name] = row(data['started'], data['finished'], [path])
    for name, receipt in (('coalescer-v1', 'host-coalesce/build.log'),
                          ('coalescer-v2', 'host-coalesce/v2/build.log')):
        path = receipts / receipt
        parts = dict(re.findall(r'^(start_utc|end_utc)=(\S+)$', path.read_text(), re.M))
        result[name] = row(parts['start_utc'], parts['end_utc'], [path])
    for name, receipt in (('ryuk-cleanup', 'testcontainers/ryuk-network-source'),
                          ('create-conflict', 'stock-services/create-conflict-source')):
        directory = receipts / receipt
        paths = [directory / name for name in ('build-start.txt', 'build-end.txt')]
        result[name] = row(*(path.read_text().strip() for path in paths), paths)
    return result


def score_windows():
    result = {}
    patterns = ('*-material-host-load.jsonl', '*-density-host-load.jsonl',
                'stock-services/services-pair-*-load.jsonl', 'stock-services/*/services-*-host-load.jsonl',
                'stock-services/quiet-*/*-load.jsonl')
    for pattern in patterns:
        for path in sorted(receipts.glob(pattern)):
            data = [json.loads(line) for line in path.read_bytes().splitlines()]
            assert data[0]['edge'] == 'before_work' and data[-2]['edge'] == 'after_work' and data[-1]['edge'] == 'command_exit'
            key = path.relative_to(receipts).as_posix()
            result[key] = row(data[0]['utc'], data[-2]['utc'], [path]) | {'exit': data[-1]['code']}
    return result


def main():
    builds, scores = build_windows(), score_windows()
    overlaps = []
    for measurement, score in scores.items():
        for name, build in builds.items():
            start = max(timepoint(score['started_utc']), timepoint(build['started_utc']))
            finish = min(timepoint(score['finished_utc']), timepoint(build['finished_utc']))
            if start < finish:
                overlaps.append({'score': measurement, 'build': name, 'overlap_ms': (finish - start).total_seconds() * 1000})
    result = {'scope': 'Recorded build intervals for owned compact, coalescer and follow-up Docker runner candidates. Host load is sampled independently.',
              'builds': builds, 'scored_windows': scores, 'overlaps': overlaps}
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
