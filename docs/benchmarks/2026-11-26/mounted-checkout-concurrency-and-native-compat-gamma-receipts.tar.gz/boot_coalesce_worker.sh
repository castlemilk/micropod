#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
H=$(dirname "$D")/home
arm=${1:?owned arm label}
vmm=${2:?staged signed VMM}
expected=${3:?exact signed binary digest}
case "$arm" in coalesce-off) enabled=0 ;; coalesce-on|coalesce-on-terminal) enabled=1 ;; *) exit 2 ;; esac
bank="$H/artifacts/tools-baseline"
if [[ $arm == coalesce-on-terminal ]]; then bank="$H/artifacts/tools-terminal"; fi
test "$(/usr/bin/shasum -a 256 "$vmm" | cut -d ' ' -f 1)" = "$expected"
exec python3 -B "$D/public_machine.py" "$arm" --vmm "$vmm" --workspace-queues 1 --live-read 1 \
    --kernel-arg virtiofs.workspace_async_release=1 --workspace-coalesce "$enabled" \
    --tools "$bank" > "$D/$arm-owner.log" 2>&1
