#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
H=$(dirname "$D")/home
arm=${1:?owned arm label}
kernel=${2:?staged kernel Image}
expected=${3:?exact signed-build source digest}
case "$arm" in compact-off|compact-off-diag) enabled=0 ;; compact-on|compact-on-diag) enabled=1 ;; *) exit 2 ;; esac
toolbank="$H/artifacts/tools-baseline"
if [[ $arm == *-diag ]]; then toolbank="$H/artifacts/tools-compact-diagnostic"; fi
test "$(/usr/bin/shasum -a 256 "$kernel" | cut -d ' ' -f 1)" = "$expected"
exec python3 -B "$D/public_machine.py" "$arm" --kernel "$kernel" --workspace-queues 1 --live-read 1 \
    --kernel-arg virtiofs.workspace_async_release=1 --kernel-arg virtiofs.workspace_inline_completion=0 \
    --kernel-arg "virtiofs.workspace_compact_requests=$enabled" --tools "$toolbank" > "$D/$arm-owner.log" 2>&1
