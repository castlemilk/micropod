#!/bin/sh
# One shot. Installed only in the isolated worker's trusted, read-only tools.
set -eu
umask 077
workspace=${MICROPOD_ENGINE_WORKSPACE:?}
start="$workspace/.trace-start.request"
finish="$workspace/.trace-finished.request"
token=
instance=
scratch=
owned_mount=
probe_group=
enqueue_probe=0
submit_probe=0
state=error
reason=unhandled

publish() {
    output=$(mktemp "$workspace/.trace-$token.XXXXXX") || return 1
    if cat "$1" > "$output" && mv -f "$output" "$workspace/$2"; then
        return 0
    fi
    rm -f "$output"
    return 1
}

record_setup() {
    {
        printf '[%s]\n' "$1"
        for leaf in trace_clock available_tracers current_tracer trace_options buffer_size_kb tracing_on; do
            printf '%s\n' "$leaf"
            if [ -r "$2/$leaf" ]; then
                cat "$2/$leaf"
            else
                printf '%s\n' '<unavailable>'
            fi
        done
    } >> "$scratch/setup"
}

cleanup() {
    code=$?
    trap - EXIT HUP INT TERM
    set +e
    if [ -n "$instance" ]; then
        record_setup "exit:$reason" "$instance"
        if ! printf '0\n' > "$instance/tracing_on" || ! rmdir "$instance"; then
            state=error
            reason=remove_trace_instance
            code=1
        fi
    fi
    if [ "$submit_probe" = 1 ]; then
        printf '%s\n' "-:$probe_group/mp_sg_submit" >> "$root/kprobe_events" || { code=1; state=error; reason=remove_submit_probe; }
    fi
    if [ "$enqueue_probe" = 1 ]; then
        printf '%s\n' "-:$probe_group/mp_sg_enqueue" >> "$root/kprobe_events" || { code=1; state=error; reason=remove_enqueue_probe; }
    fi
    if [ -n "$owned_mount" ]; then
        if ! umount "$owned_mount" || ! rmdir "$owned_mount"; then
            state=error
            reason=unmount_private_tracefs
            code=1
        fi
    fi
    if [ -n "$token" ] && [ -n "$scratch" ]; then
        printf '[stderr]\n' >> "$scratch/setup"
        cat "$scratch/stderr" >> "$scratch/setup"
        if ! publish "$scratch/setup" .trace-observer.log; then
            printf '%s\n' '[trace-proof] could not publish .trace-observer.log' >&3
            code=1
        fi
        printf 'schema=1\ntoken=%s\nstatus=%s\nreason=%s\n' "$token" "$state" "$reason" > "$scratch/done"
        if ! publish "$scratch/done" .trace-done; then
            printf '%s\n' '[trace-proof] could not publish .trace-done' >&3
            code=1
        fi
    fi
    if [ -n "$scratch" ]; then
        rm -f "$scratch/started" "$scratch/events" "$scratch/stats" "$scratch/done" "$scratch/setup" "$scratch/stderr"
        rmdir "$scratch" || code=1
    fi
    exit "$code"
}

valid_control() {
    [ ! -L "$1" ] && [ -f "$1" ] && [ "$(stat -c %s "$1")" = 17 ] || return 1
    IFS= read -r control < "$1" || return 1
    case "$control" in ''|*[!0-9a-f]*) return 1 ;; esac
    [ "${#control}" -eq 16 ]
}

uptime_seconds() {
    IFS=' ' read -r uptime _ < /proc/uptime
    printf '%s\n' "${uptime%.*}"
}

trap cleanup EXIT
trap 'reason=interrupted; exit 1' HUP INT TERM
arm_deadline=$(($(uptime_seconds) + 300))
while [ ! -f "$start" ]; do
    [ "$(uptime_seconds)" -lt "$arm_deadline" ] || exit 0
    sleep 0.10
done
valid_control "$start" || { printf '%s\n' '[trace-proof] invalid start request' >&2; exit 1; }
token=$control
scratch=$(mktemp -d /run/mp-trace.XXXXXX)
exec 3>&2 2>"$scratch/stderr"
reason=stale_workspace_control
for leaf in .trace-finished.request .trace-started .trace-events .trace-stats .trace-done .trace-observer.log; do
    [ ! -e "$workspace/$leaf" ] && [ ! -L "$workspace/$leaf" ] || exit 1
done

reason=workspace_mount
device=$(awk '
    {
        for (i = 7; i <= NF; i++) {
            if ($i != "-") continue
            if ($(i + 1) == "virtiofs" && $(i + 2) == "workspace") print $3
            break
        }
    }
' /proc/self/mountinfo | sort -u)
connection=$(printf '%s\n' "$device" | awk -F: '
    /^[0-9]+:[0-9]+$/ && NR == 1 { value = $1 * 1048576 + $2; next }
    { invalid = 1 }
    END { if (!invalid && NR == 1 && value > 0) printf "%.0f\n", value; else exit 1 }
')

reason=mount_tracefs
root=/sys/kernel/tracing
if [ ! -d "$root/instances" ]; then
    root="$scratch/tracefs"
    mkdir "$root"
    if ! mount -t tracefs -o nosuid,nodev,noexec tracefs "$root"; then
        rmdir "$root"
        exit 1
    fi
    owned_mount=$root
fi
record_setup root_before_instance "$root"
reason=mkdir_trace_instance
name="$root/instances/mp-workspace-$token"
mkdir "$name"
instance=$name
record_setup instance_before_config "$instance"
reason=disable_instance
printf '0\n' > "$instance/tracing_on"
reason=select_nop_tracer
if [ -w "$instance/current_tracer" ] && [ "$(cat "$instance/current_tracer")" != nop ]; then
    printf 'nop\n' > "$instance/current_tracer"
fi
reason=set_buffer_capacity
printf '8192\n' > "$instance/buffer_size_kb"
reason=set_overwrite_option
overwrite=kernel-default
if [ -w "$instance/options/overwrite" ]; then
    printf '0\n' > "$instance/options/overwrite"
    overwrite=disabled
elif [ -w "$instance/trace_options" ] && (printf 'nooverwrite\n' > "$instance/trace_options"); then
    overwrite=disabled
fi
reason=select_monotonic_clock
clock=
for candidate in mono global; do
    if (printf '%s\n' "$candidate" > "$instance/trace_clock") &&
       grep -Fq "[$candidate]" "$instance/trace_clock"; then
        clock=$candidate
        break
    fi
done
[ -n "$clock" ] || exit 1
record_setup instance_after_config "$instance"

reason=configure_fuse_events
for event in fuse_request_send fuse_request_end; do
    point="$instance/events/fuse/$event"
    printf 'connection == %s\n' "$connection" > "$point/filter"
    printf '1\n' > "$point/enable"
done

reason=configure_layout_probes
compact_mode=$(cat /sys/module/virtiofs/parameters/workspace_compact_requests)
case "$compact_mode" in N|Y) ;; *) exit 1 ;; esac
probe_group=mp_sg_$token
# ARM64 arguments and fuse_req.in.h offsets verified in this Image's driver DWARF.
printf 'p:%s/mp_sg_enqueue virtio_fs_enqueue_req key=%%x1:x64 unique=+64(%%x1):u64 op=+60(%%x1):u32\n' "$probe_group" >> "$root/kprobe_events"
enqueue_probe=1
printf 'p:%s/mp_sg_submit virtqueue_add_sgs key=%%x4:x64 out=%%x2:u32 in=%%x3:u32\n' "$probe_group" >> "$root/kprobe_events"
submit_probe=1
for layout_event in mp_sg_enqueue mp_sg_submit; do
    printf '1\n' > "$instance/events/$probe_group/$layout_event/enable"
done

reason=configure_workqueue_events
address=$(awk '$3 == "virtio_fs_requests_done_work" && $1 ~ /[1-9a-f]/ {print $1}' /proc/kallsyms | sort -u)
case "$address" in ''|*[!0-9a-f]*) address= ;; esac
filtered=0
for event in workqueue_queue_work workqueue_execute_start workqueue_execute_end; do
    point="$instance/events/workqueue/$event"
    if [ -n "$address" ] && (printf 'function == 0x%s\n' "$address" > "$point/filter") 2>/dev/null; then
        filtered=$((filtered + 1))
    else
        printf '0\n' > "$point/filter"
    fi
    printf '1\n' > "$point/enable"
done

reason=configure_close_events
close_events_enabled=0
for event in sys_enter_close sys_exit_close; do
    point="$instance/events/syscalls/$event/enable"
    if [ -w "$point" ]; then
        printf '1\n' > "$point"
        close_events_enabled=$((close_events_enabled + 1))
    fi
done
release_parameter=/sys/module/virtiofs/parameters/workspace_async_release
if [ -r "$release_parameter" ]; then
    release_mode=$(cat "$release_parameter")
else
    release_mode=unavailable
fi

local_parameter=/sys/module/virtiofs/parameters/workspace_local_completion
if [ -r "$local_parameter" ]; then
    local_completion=$(cat "$local_parameter")
else
    local_completion=unavailable
fi

inline_parameter=/sys/module/virtiofs/parameters/workspace_inline_completion
inline_completion=$(cat "$inline_parameter")
case "$inline_completion" in N|Y) ;; *) exit 1 ;; esac

reason=publish_started
{
    printf 'schema=1\ntoken=%s\ndevice=%s\nconnection=%s\n' "$token" "$device" "$connection"
    printf 'clock=%s\noverwrite=%s\nbuffer_kib_per_cpu=8192\nmax_capture_s=30\nobserver_pid=%s\n' "$clock" "$overwrite" "$$"
    printf 'kernel_work_event_filters=%s\n' "$filtered"
    printf 'kernel_release=%s\n' "$(uname -r)"
    printf 'close_syscall_events_enabled=%s\n' "$close_events_enabled"
    printf 'workspace_async_release=%s\n' "$release_mode"
    printf 'workspace_local_completion=%s\n' "$local_completion"
    printf 'workspace_inline_completion=%s\n' "$inline_completion"
    printf 'workspace_compact_requests=%s\n' "$compact_mode"
    printf 'boot_id=%s\n' "$(cat /proc/sys/kernel/random/boot_id)"
} > "$scratch/started"

deadline=$(($(uptime_seconds) + 30))
printf '1\n' > "$instance/tracing_on"
printf 'mp-workspace-start %s\n' "$token" > "$instance/trace_marker"
publish "$scratch/started" .trace-started

reason=finish_timeout
while [ ! -f "$finish" ]; do
    if [ "$(uptime_seconds)" -ge "$deadline" ]; then
        state=timeout
        break
    fi
    sleep 0.05
done

printf 'mp-workspace-finish %s\n' "$token" > "$instance/trace_marker"
printf '0\n' > "$instance/tracing_on"
if [ "$state" != timeout ]; then
    reason=finish_token
    valid_control "$finish" && [ "$control" = "$token" ] || exit 1
    state=ok
    reason=finished
fi

saved_state=$state
saved_reason=$reason
state=error
reason=export_capture
cat "$instance/trace" > "$scratch/events"
{
    for cpu in "$instance"/per_cpu/cpu*; do
        printf '[%s]\n' "${cpu##*/}"
        cat "$cpu/stats"
    done
} > "$scratch/stats"
publish "$scratch/events" .trace-events
publish "$scratch/stats" .trace-stats
state=$saved_state
reason=$saved_reason
[ "$state" = ok ]
