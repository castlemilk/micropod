"""Collect actual VMM transport counters from an owned, retired Gamma7 console."""
import hashlib
import json
from pathlib import Path
import re
import sys

label=sys.argv[1]
assert re.fullmatch('[a-z0-9-]{1,22}',label)
receipts=Path(__file__).resolve().parent
worker_path=receipts/f'{label}-worker.json'
console=receipts/f'{label}-console.log'
worker=json.loads(worker_path.read_bytes())
assert worker['label']==label and worker['scope_absent'] and worker['machine']['clean_shutdown']
assert not Path(worker['socket']).exists()
raw=console.read_bytes()
events=[]
coalescer=[]
coalesce_names=('coalesce_batches','coalesce_multi_batches','coalesce_lookup_requests','coalesce_lookup_saved',
                'coalesce_read_requests','coalesce_read_saved')
for number,line in enumerate(raw.splitlines(),1):
    if line.startswith(b'[virtiofs-workspace] coalesce_batches='):
        items=dict(word.split('=',1) for word in line.decode().split()[1:])
        assert items.keys()==set(coalesce_names), items
        coalescer.append({'console_line':number, 'counters':{field:int(items[field]) for field in coalesce_names}})
    if not line.startswith(b'{"exit_reason"'):
        continue
    row=json.loads(line)
    if row['exit_reason']=='poweroff' and row['exit_code']==0:
        events.append((number,row))
record={'label':label,'console':console.name,'console_sha256':hashlib.sha256(raw).hexdigest(),
        'available':bool(events),'event_idx_requested':worker.get('workspace_event_idx_requested'),
        'coalesce_requested':worker.get('workspace_coalesce_requested'),'coalescer_records':coalescer,
        'workspace':worker['virtiofs_sysfs']['devices']['workspace'],
        'vmm_sha256':worker['owned_artifacts']['vmm']['sha256']}
if record['coalesce_requested'] is False:
    assert not coalescer
if record['coalesce_requested'] is True:
    assert len(coalescer)==1, coalescer
if events:
    line,counters=events[-1]
    record.update(console_line=line,json=counters)
    fields=('workspace_kicks','workspace_used_batches','workspace_irq_requests','mmio_exits','fs_requests')
    record['available_workspace_fields']=sorted(set(fields)&counters.keys())
    assert all(type(counters[name]) is int and counters[name]>=0 for name in record['available_workspace_fields'])
    if all(name in counters for name in fields) and counters['fs_requests']:
        record['per_1000_total_fs_requests']={name:1000*counters[name]/counters['fs_requests'] for name in fields[:-1]}
with (receipts/f'{label}-vmm-metrics.json').open('x') as output:
    json.dump(record,output,indent=2)
    output.write('\n')
