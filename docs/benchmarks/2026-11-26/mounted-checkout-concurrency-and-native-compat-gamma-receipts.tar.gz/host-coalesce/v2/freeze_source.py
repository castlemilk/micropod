"""Freeze the exact matched single-file VirtioFS batch experiment."""
from hashlib import sha256
import gzip
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

scope = Path(sys.argv[1])
vendor = scope / "home" / "host-coalesce"
receipts = scope / "receipts" / "host-coalesce" / "v2"
control = vendor / "control"
source = vendor / "candidate-v2"
delta = receipts / "workspace-coalesce.patch"
observed = "crates/vmm-virtio/src/virtiofs.rs"
prior = json.loads((vendor / "prior-control-sources.json").read_text())
files = sorted((str(path.relative_to(source)), path.read_bytes()) for path in source.rglob("*") if path.is_file())
assert len(files) == len(prior) == 42
assert set(prior) == {name for name, _ in files}
archive_hash = lambda path: sha256(path.read_bytes()).hexdigest()
assert all(archive_hash(control / file) == dig for file, dig in prior.items())
assert [name for name, body in files if sha256(body).hexdigest() != prior[name]] == [observed]
archive = receipts / "candidate-source.tar.gz"
with archive.open("xb") as physical:
    with gzip.GzipFile(fileobj=physical, filename="", mode="wb", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as logical:
            for name, body in files:
                meta = tarfile.TarInfo(name)
                meta.size = len(body)
                meta.mode = (source / name).stat().st_mode & 0o777
                logical.addfile(meta, io.BytesIO(body))
with tarfile.open(archive) as replay:
    assert [(entry.name, replay.extractfile(entry).read()) for entry in replay.getmembers()] == files
reconstructed = control.parent / "proof-replay-v2"
subprocess.run(["cp", "-cRp", control, reconstructed], check=True)
for mode in [("--check",), ()]:
    subprocess.run(["git", "apply", *mode, delta], cwd=reconstructed, check=True)
assert all((reconstructed / name).read_bytes() == body for name, body in files)

def machine_code(path):
    lines = subprocess.check_output(["otool", "-l", path], text=True).splitlines()
    pos = next(i for i, row in enumerate(lines) if row.strip() == "sectname __text" and
               lines[i + 1].strip() == "segname __TEXT")
    length = int(lines[pos + 3].split()[-1], 16)
    start = int(lines[pos + 4].split()[-1])
    return sha256(path.read_bytes()[start:start + length]).hexdigest()

retained = Path("/Users/benebsworth/projects/micropod/.build/qualified/micropod-hvf-gamma7-bmjh3u/micropod-vmm-f0747277714e")
relink = control.parent / "builds" / "replayed-control"
official_code = machine_code(retained)
assert machine_code(relink) == official_code
binary = control.parent / "builds" / "micropod-vmm-coalesce-v2"
attestation = {
    "source_files": len(files),
    "patch_sha256": archive_hash(delta),
    "archive_sha256": archive_hash(archive),
    "binary_sha256": archive_hash(binary),
    "only_changed": [observed],
    "source_sha256": {name: sha256(body).hexdigest() for name, body in files},
    "control_source_all_hashes_match": True,
    "archived_binary_sha256": archive_hash(retained),
    "control_replay_binary_sha256": archive_hash(relink),
    "control_machine_code_sha256_both": official_code,
    "control_binary_relink_only": True,
    "signing": "ad-hoc, hypervisor entitlement, strict verification",
    "activation": "MICROPOD_VIRTIOFS_WORKSPACE_COALESCE=1, writable workspace, one normal request queue",
    "shared_read_scope": "local APFS root and same st_dev from successful OPEN; ARM64 allowed open flags; supported READ flags and active 64-bit lock owner",
    "test_passed": 56,
}
(receipts / "candidate-source.json").write_text(json.dumps(attestation, indent=2) + "\n")
