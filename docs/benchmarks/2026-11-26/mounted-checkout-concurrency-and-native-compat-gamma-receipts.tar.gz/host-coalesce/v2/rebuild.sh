#!/bin/bash
set -euo pipefail

receipts=$(cd "$(dirname "$0")" && pwd -P)
source_dir=$(cd "${1:?provide the unpacked candidate source directory}" && pwd -P)
build_dir=${2:?provide a new build directory on local APFS}
mkdir "$build_dir"
build_dir=$(cd "$build_dir" && pwd -P)
mkdir "$build_dir/tmp"

python3 - "$source_dir" "$receipts/candidate-source.json" <<'PY'
from hashlib import sha256
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
manifest = json.loads(Path(sys.argv[2]).read_text())
actual = {
    str(path.relative_to(root)): sha256(path.read_bytes()).hexdigest()
    for path in root.rglob("*")
    if path.is_file()
}
assert actual == manifest["source_sha256"], "Source does not match the frozen candidate"
PY

cd "$source_dir"
export CARGO_TARGET_DIR="$build_dir/target"
export TMPDIR="$build_dir/tmp"
export SDKROOT=/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk
export MACOSX_DEPLOYMENT_TARGET=11.0

date -u '+start_utc=%Y-%m-%dT%H:%M:%SZ'
cargo -V
rustc -Vv
xcrun --sdk macosx --show-sdk-version
cargo test -j2 --offline --locked -p vmm-virtio --lib -- --test-threads=2
cargo build -j2 --offline --locked --release -p micropod-vmm
artifact="$build_dir/micropod-vmm-coalesce-v2"
cp "$CARGO_TARGET_DIR/release/micropod-vmm" "$artifact"
strings "$artifact" | rg -o 'coalesce_read_saved='
codesign --force --sign - --identifier micropod-vmm-workspace-host-coalesce-v2 \
  --entitlements entitlements.plist "$artifact"
codesign --verify --strict --verbose=2 "$artifact"
codesign -d --entitlements - "$artifact"
shasum -a 256 "$artifact"
date -u '+end_utc=%Y-%m-%dT%H:%M:%SZ'
