"""Compile the candidate's actual SG, verification, copy-back and release routines."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tempfile

root, output = map(Path, sys.argv[1:])
code = (root / "src/fs/fuse/virtio_fs.c").read_text()


def function(name):
    at = code.index(name + "(")
    start = code.rfind("\nstatic ", 0, at) + 1
    end = code.index("\n}", at) + 2
    return code[start:end]


shim = r"""
#include <assert.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stddef.h>
typedef unsigned int gfp_t;
#define __GFP_NOWARN 1
#define NAME_MAX 255
#define FUSE_LOOKUP 1
#define FUSE_GETATTR 3
#define FUSE_OPEN 14
#define FUSE_READ 15
#define FUSE_RELEASE 18
#define FR_ISREPLY 0
#define ERESTARTSYS 512
#define pr_warn(...) ((void)0)
#define ALIGN(n, a) (((n) + (a) - 1) & ~((a) - 1))
#define container_of(p,t,m) ((t *)((char *)(p) - offsetof(t,m)))
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
struct fuse_arg { unsigned int size; void *value; };
struct fuse_args {
    unsigned int in_numargs, out_numargs;
    bool in_pages, out_pages, out_argvar;
    struct fuse_arg in_args[4], out_args[2];
};
struct fuse_args_pages { struct fuse_args args; void **folios; unsigned *descs; unsigned num_folios; };
struct fuse_in_header { uint32_t len, opcode; uint64_t unique, nodeid; unsigned char tail[16]; };
struct fuse_out_header { uint32_t len; int32_t error; uint64_t unique; };
struct fuse_entry_out { char data[128]; };
struct fuse_req {
    struct fuse_args *args;
    unsigned long flags;
    struct { struct fuse_in_header h; } in;
    struct { struct fuse_out_header h; } out;
    void *argbuf;
    unsigned int argbuf_out_header;
};
struct scatterlist { void *ptr; unsigned len; };
static unsigned alignment = 128;
static bool fail_alloc;
static unsigned dma_get_cache_alignment(void) { return alignment; }
static bool test_bit(int bit, unsigned long *flags) { return (*flags & (1UL << bit)) != 0; }
static void *kmalloc(size_t n, gfp_t f) {
    void *p = NULL;
    (void)f;
    assert(n % alignment == 0);
    if (fail_alloc || posix_memalign(&p, alignment, n)) return NULL;
    memset(p, 0xa5, n);
    return p;
}
static void kfree(void *p) { free(p); }
static void sg_init_one(struct scatterlist *s, void *p, unsigned n) { s->ptr = p; s->len = n; }
static unsigned fuse_len_args(unsigned n, const struct fuse_arg *v) {
    unsigned total = 0; for (unsigned i = 0; i < n; i++) total += v[i].size; return total;
}
static unsigned sg_init_fuse_folios(struct scatterlist *sg, void **pages, unsigned *lens, unsigned n, unsigned bytes) {
    unsigned i = 0;
    for (; i < n && bytes; i++) {
        unsigned size = lens[i] < bytes ? lens[i] : bytes;
        sg_init_one(sg + i, pages[i], size); bytes -= size;
    }
    return i;
}
"""

exercise = r"""
static void check(unsigned op, unsigned size, bool pages, unsigned error_case) {
    unsigned char arg[256], output[128], page0[31], page1[57];
    unsigned lens[] = {sizeof(page0), sizeof(page1)};
    void *folios[] = {page0, page1};
    memset(arg, 0x71, sizeof(arg)); memset(output, 0x49, sizeof(output));
    struct fuse_args_pages ap = {.folios = folios, .descs = lens, .num_folios = 2};
    struct fuse_args *args = &ap.args;
    args->in_numargs = 1; args->in_args[0] = (struct fuse_arg){size, arg};
    if (op == FUSE_LOOKUP) {
        args->in_numargs = 3;
        args->in_args[0] = (struct fuse_arg){0, NULL};
        args->in_args[1] = (struct fuse_arg){size - 1, arg};
        arg[size - 1] = 0;
        args->in_args[2] = (struct fuse_arg){1, arg + size - 1};
    }
    args->out_numargs = op != FUSE_RELEASE;
    args->out_pages = args->out_argvar = pages;
    unsigned body = pages ? 76 : (args->out_numargs ? sizeof(output) : 0);
    args->out_args[0] = (struct fuse_arg){body, output};
    struct fuse_req req = {.args=args,.flags=1,.in.h={.opcode=op,.unique=7654321,.len=sizeof(req.in.h)+size}};
    struct scatterlist sg[5] = {0};
    unsigned count = virtio_fs_pack_request(&req, sg, 0);
    assert(count == (pages ? 3 : 1));
    assert(sg[0].len == sizeof(req.in.h) + size && !memcmp(sg[0].ptr,&req.in.h,sizeof(req.in.h)));
    assert(!memcmp((char *)sg[0].ptr + sizeof(req.in.h),arg,size));
    assert((uintptr_t)sg[0].ptr % alignment == 0 && (uintptr_t)sg[1].ptr % alignment == 0);
    assert((char *)sg[1].ptr >= (char *)sg[0].ptr + sg[0].len);
    assert(sg[1].len == sizeof(req.out.h) + (pages ? 0 : body));
    struct fuse_out_header *oh = sg[1].ptr;
    *oh = (struct fuse_out_header){.unique=req.in.h.unique,.len=sizeof(*oh)+body};
    if (pages) {
        assert(sg[2].ptr == page0 && sg[2].len == 31 && sg[3].ptr == page1 && sg[3].len == 45);
        oh->len -= 7; /* valid short direct read */
    } else {
        memset(oh + 1, 0xba, body);
    }
    unsigned used = oh->len;
    switch (error_case) {
    case 1: oh->unique++; break;
    case 2: used--; break;
    case 3: oh->error = -2; oh->len = used = sizeof(*oh); break;
    case 4: oh->error = 1; break;
    case 5: used = sizeof(*oh)-1; break;
    }
    bool valid = virtio_fs_verify_response(&req, used, false);
    assert(valid == (error_case == 0 || error_case == 3));
    if (!valid) req.out.h.error = -5;
    copy_args_from_argbuf(args, &req);
    assert(!req.argbuf && !req.argbuf_out_header);
    if (!error_case && pages) assert(args->out_args[0].size == body - 7);
    for (unsigned i=0; i<sizeof(output); i++)
        assert(output[i] == ((!error_case && !pages && i<body) ? 0xba : 0x49));
}
int main(void) {
    unsigned ops[] = {FUSE_LOOKUP,FUSE_OPEN,FUSE_GETATTR,FUSE_READ,FUSE_RELEASE};
    unsigned sizes[] = {1, 8, 24, 40, 255, 256};
    unsigned count=0;
    for (alignment=16; alignment<=256; alignment*=2)
        for (unsigned op=0; op<5; op++)
            for (unsigned sz=0; sz<6; sz++)
                for (unsigned err=0; err<6; err++,count++)
                    check(ops[op],sizes[sz],ops[op]==FUSE_READ,err);
    alignment=128;
    unsigned char in=1;
    struct fuse_args a = {.in_numargs=1,.in_args={{1,&in}}};
    struct fuse_req r = {.args=&a,.flags=1,.in.h={.opcode=FUSE_OPEN}};
    struct scatterlist sg[4]={0};
    fail_alloc=true; assert(!virtio_fs_pack_request(&r,sg,0) && !r.argbuf); fail_alloc=false;
    assert(virtio_fs_pack_request(&r,sg,0)); virtio_fs_free_argbuf(&r);
    r.flags=0; assert(!virtio_fs_pack_request(&r,sg,0)); r.flags=1;
    r.in.h.opcode=999; assert(!virtio_fs_pack_request(&r,sg,0)); r.in.h.opcode=FUSE_OPEN;
    a.in_args[0].size=257; assert(!virtio_fs_pack_request(&r,sg,0)); a.in_args[0].size=1;
    a.in_pages=true; assert(!virtio_fs_pack_request(&r,sg,0)); a.in_pages=false;
    a.out_pages=true; assert(!virtio_fs_pack_request(&r,sg,0)); a.out_pages=false;
    a.out_numargs=2; assert(!virtio_fs_pack_request(&r,sg,0));
    a.out_numargs=0; r.in.h.opcode=FUSE_LOOKUP;
    unsigned char prefix[] = {1,2}, name[] = {3,4}, zero=0;
    a.in_numargs=3; a.in_args[0]=(struct fuse_arg){2,prefix};
    a.in_args[1]=(struct fuse_arg){2,name}; a.in_args[2]=(struct fuse_arg){1,&zero};
    assert(virtio_fs_pack_request(&r,sg,0));
    assert(!memcmp((char *)sg[0].ptr+sizeof(r.in.h),(unsigned char[]){1,2,3,4,0},5));
    virtio_fs_free_argbuf(&r);
    a.in_args[1].size=255; assert(!virtio_fs_pack_request(&r,sg,0));
    a.in_args[1].size=UINT32_MAX; assert(!virtio_fs_pack_request(&r,sg,0));
    a.in_numargs=5; assert(!virtio_fs_pack_request(&r,sg,0));
    printf("%u packed cases including the real three-argument LOOKUP, optional prefix, overflow, allocation fallback, retry and shape guards passed\n",count);
}
"""

functions = ("virtio_fs_free_argbuf", "copy_args_from_argbuf", "virtio_fs_verify_response", "virtio_fs_pack_request")
with tempfile.TemporaryDirectory(dir=output.parent) as temporary:
    base = Path(temporary)
    src, binary = base / "exercise.c", base / "exercise"
    src.write_text(shim + "\n" + "\n".join(map(function, functions)) + "\n" + exercise)
    subprocess.run(["clang", "-std=gnu11", "-O1", "-Wall", "-Werror", "-fsanitize=address,undefined", str(src), "-o", str(binary)], check=True)
    result = subprocess.run([binary], check=True, text=True, capture_output=True)
    record = {"source_sha256": hashlib.sha256(code.encode()).hexdigest(), "extracted": functions,
              "harness_sha256": hashlib.sha256(src.read_bytes()).hexdigest(), "result": result.stdout.strip()}
    output.write_text(json.dumps(record, indent=2) + "\n")
    print(result.stdout.strip())
