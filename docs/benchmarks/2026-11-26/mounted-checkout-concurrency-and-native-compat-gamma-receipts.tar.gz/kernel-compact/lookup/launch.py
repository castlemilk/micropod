"""Build the scoped arm64 candidate on Gamma after the operator clears the timing lane."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess

evidence = Path(__file__).resolve().parent
staging = evidence.parents[2] / "home/kernel-compact-lookup"
command = ["sh", str(staging / "controls/run-workspace-compact-build.sh"), "mp-gamma8-compact-lookup-meb28u"]
env = dict(os.environ, MICROPOD_KERNEL_DOCKER_HOST="unix:///Users/benebsworth/.orbstack/run/docker.sock")
clock = lambda: datetime.now(timezone.utc).isoformat()
started = clock()
with (evidence / "build.log").open("xb") as log:
    proc = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, env=env)
with (evidence / "build.json").open("x") as out:
    json.dump({"command": command, "started": started, "finished": clock(), "exit": proc.returncode}, out, indent=2)
    out.write("\n")
print("Gamma lookup Image build exit", proc.returncode)
raise SystemExit(proc.returncode)
