#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
H=$(dirname "$D")/home
arm=${1:?owned compatibility arm}
[[ $arm =~ ^[a-z0-9-]{1,22}$ ]]
ready="$D/$arm-ready.json"
sock=$(jq -er .socket "$ready")
test -S "$sock"
test "$(jq -er .label "$ready")" = "$arm"
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_API_VERSION DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH
export DOCKER_CLI_HINTS=false
client=(/opt/homebrew/bin/docker --host "unix://$sock")
test -z "$("${client[@]}" ps -aq)"
file="$H/artifacts/ryuk-0.13.0.tar"
test "$(/usr/bin/shasum -a 256 "$file" | cut -d ' ' -f 1)" = 39dd306cd8131bf29d674c8049d8923b9e518c478d900091b6d234b3af3b74f4
if "${client[@]}" image inspect testcontainers/ryuk:0.13.0 > "$D/$arm-ryuk-preload-initial.log" 2>&1; then exit 1; fi
"${client[@]}" image load --input "$file" > "$D/$arm-ryuk-load.log" 2>&1
"${client[@]}" image inspect --format '{{json .}}' testcontainers/ryuk:0.13.0 > "$D/$arm-ryuk-load-inspect.json"
jq -e '.Architecture=="arm64" and .Os=="linux" and .Id=="sha256:f04fd744b5d50f8c88d9d4938c54e05a9adb56d520542f899a7d6873fa7280f2"' \
    "$D/$arm-ryuk-load-inspect.json"
