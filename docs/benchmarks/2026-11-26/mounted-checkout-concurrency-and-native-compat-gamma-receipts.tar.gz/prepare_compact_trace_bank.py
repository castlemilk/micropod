"""Prepare an isolated workspace trace and lifecycle tools bank for owned diagnostic boots."""
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess

receipts=Path(__file__).resolve().parent
hub=receipts.parent/'home'
artifacts=hub/'artifacts'
source=artifacts/'tools-baseline'
target=artifacts/'tools-compact-diagnostic'
assert hub.is_mount() and not target.exists()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def copy_script(src, dst, expected):
    path=receipts/'kernel-compact'/src
    assert sha(path)==expected
    staged=runner/dst
    staged.write_bytes(path.read_bytes())
    staged.chmod(0o755)
    assert sha(staged)==expected
    return staged

subprocess.run(['/bin/cp','-cRp',source,target],check=True)
runner=target/'runner'
start=runner/'start.sh'
data=start.read_text()
original='service=\napi=\n'
assert data.count(original)==1
data=data.replace(original,original+'observer=\n')
original='${api:+"$api"} 2>/dev/null || true\' EXIT'
assert data.count(original)==1
data=data.replace(original,'${api:+"$api"} ${observer:+"$observer"} 2>/dev/null || true\' EXIT')
original='"$tools/runner/bin/job" recover\n'
assert data.count(original)==1
chain='''(
    if ! "$tools/runner/trace-observer.sh"; then
        printf '%s\\n' 'The scoped virtiofs trace failed' >&2
    fi
    exec "$tools/runner/qualify_virtiofs_inline_completion.sh"
) &
observer=$!
'''
start.write_text(data.replace(original,original+chain))
observer=copy_script('compact-trace-observer.sh','trace-observer.sh',
                     '74b07af7a3f2ecd8525b1038862e9ac4bfd839bed01a7d0dec7f396398dbe34d')
source_lifecycle='qualify_virtiofs_inline_completion.sh'
lifecycle=copy_script(source_lifecycle,source_lifecycle,
                      'b8064c6c44f0734ab113cf2d81724ba11f342754df1304719b38b3aa4fafb14c')
secret=runner/'.workspace-inline-completion.owner'
with os.fdopen(os.open(secret,os.O_WRONLY|os.O_EXCL|os.O_CREAT,0o400),'w') as file:
    file.write(secrets.token_hex(16)+'\n')
for script in (start,observer,lifecycle):
    subprocess.run(['/bin/sh','-n',script],check=True)
job=runner/'bin/job'
assert sha(job)=='55f2ae080a601a84fd10123f6a717e880a0da6f1f2d9f827f7bf249fa79ca4d0'
lineage={str(file.relative_to(target)):sha(file) for file in (job,start,observer,lifecycle)}
with (receipts/'compact-diagnostic-bank-lineage.json').open('x') as output:
    json.dump(lineage,output,indent=2)
    output.write('\n')
