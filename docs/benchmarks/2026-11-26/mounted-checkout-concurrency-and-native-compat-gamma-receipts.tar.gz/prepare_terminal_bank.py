"""Clone the exact control tools into an unscored terminal lifecycle bank."""
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess

receipts=Path(__file__).resolve().parent
hub=receipts.parent/'home'
artifacts=hub/'artifacts'
source=artifacts/'tools-baseline'
target=artifacts/'tools-terminal'
assert hub.is_mount() and not target.exists()
subprocess.run(['/bin/cp','-cRp',source,target],check=True)
runner=target/'runner'
start=runner/'start.sh'
data=start.read_text()
original='service=\napi=\n'
assert data.count(original)==1
data=data.replace(original,original+'observer=\n')
original='${api:+"$api"} 2>/dev/null || true\' EXIT'
assert data.count(original)==1
data=data.replace(original,'${api:+"$api"} ${observer:+"$observer"} 2>/dev/null || true\' EXIT')
original='"$tools/runner/bin/job" recover\n'
assert data.count(original)==1
data=data.replace(original,original+'"$tools/runner/qualify_virtiofs_local_completion.sh" --allow-unavailable &\nobserver=$!\n')
start.write_text(data)
helper=runner/'qualify_virtiofs_local_completion.sh'
helper.write_bytes((receipts/helper.name).read_bytes())
helper.chmod(0o755)
secret=runner/'.workspace-local-completion.owner'
with os.fdopen(os.open(secret,os.O_WRONLY|os.O_EXCL|os.O_CREAT,0o400),'w') as file:
    file.write(secrets.token_hex(16)+'\n')
subprocess.run(['/bin/sh','-n',start],check=True)
subprocess.run(['/bin/sh','-n',helper],check=True)
cohort=(runner/'bin/job',start,helper)
lineage={str(item.relative_to(target)):hashlib.sha256(item.read_bytes()).hexdigest() for item in cohort}
assert lineage['runner/bin/job']=='55f2ae080a601a84fd10123f6a717e880a0da6f1f2d9f827f7bf249fa79ca4d0'
with (receipts/'terminal-bank-lineage.json').open('x') as output:
    json.dump(lineage,output,indent=2)
    output.write('\n')
