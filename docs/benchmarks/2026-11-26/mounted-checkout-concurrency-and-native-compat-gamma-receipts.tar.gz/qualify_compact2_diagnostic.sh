#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
H=$(dirname "$D")/home
arm=${1:?owned diagnostic label}
mode=${2:?expected kernel mode}
[[ $arm == compact2-off-diag || $arm == compact2-on-diag ]]
[[ $mode == N || $mode == Y ]]
ready="$D/$arm-ready.json"
socket=$(jq -er .socket "$ready")
workspace=$(jq -er .workspace "$ready")
image=$(jq -er .benchmark_image "$ready")
test "$(jq -er .virtiofs_sysfs.parameters.workspace_compact_requests "$ready")" = "$mode"
test "$(jq -er .virtiofs_sysfs.parameters.workspace_inline_completion "$ready")" = N
test "$(jq -er .virtiofs_sysfs.parameters.workspace_async_release "$ready")" = Y
traceproof="$H/evidence/trace-compact"
bench="$H/evidence/prior"
trace=0
python3 -B "$D/kernel-compact/trace_stock_git_completion.py" --socket "$socket" --workspace "$workspace" \
    --source "$bench/runner-vendored" --helpers "$bench/final-harness/scripts" --observer "$traceproof" \
    --image "$image" --image-manifest "$D/image-manifest.json" --expected-mode Y --expected-local-mode unavailable \
    --samples 4 --trace --out "$D/$arm-git.json" > "$D/$arm-git.log" 2>&1 || trace=$?
layout=0
python3 -B "$D/kernel-compact/lookup/analyze_virtiofs_request_layout.py" --run "$D/$arm-git.json" \
    --raw "$D/$arm-git-raw" --expected "$mode" --out "$D/$arm-layout.json" \
    > "$D/$arm-layout.log" 2>&1 || layout=$?
lifecycle=0
python3 -B "$D/trigger_inline_completion_lifecycle.py" --ready "$ready" --observer "$traceproof" --expected N \
    --owner "$H/artifacts/tools-compact-diagnostic/runner/.workspace-inline-completion.owner" \
    --out "$D/$arm-lifecycle.json" > "$D/$arm-lifecycle.log" 2>&1 || lifecycle=$?
printf 'raw_trace=%s request_layout=%s terminal_lifecycle=%s\n' "$trace" "$layout" "$lifecycle" |
    tee "$D/$arm-qualification-exit.log"
(( trace == 0 && layout == 0 && lifecycle == 0 ))
