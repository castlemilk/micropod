#!/bin/bash
set -euo pipefail

receipts=$(cd "$(dirname "$0")" && pwd -P)
hub=$(dirname "$receipts")/home
arm=${1:?private worker}
binary=${2:?staged Linux test executable}
expected=${3:?test SHA-256}
filter=${4:?Go test filter}
limit=${5:-30}
receipt=${6:-linux-test}
[[ $limit =~ ^[1-9][0-9]{0,2}$ && $receipt =~ ^[a-z0-9-]+$ ]]
ready="$receipts/$arm-ready.json"
socket=$(jq -er .socket "$ready")
workspace=$(jq -er .workspace "$ready")
resolved=$(python3 -B -c 'from pathlib import Path; import sys; print(Path(sys.argv[1]).resolve(strict=True))' "$binary")
[[ $resolved == "$hub/"* && $expected =~ ^[0-9a-f]{64}$ ]]
test -S "$socket" && test -d "$workspace"
test "$(/usr/bin/shasum -a 256 "$binary" | /usr/bin/cut -d' ' -f1)" = "$expected"

stage=$(/usr/bin/mktemp -d "$workspace/linux-test.XXXXXX")
installed="$stage/runner.test"
trap 'if [[ -f $installed ]]; then /bin/unlink "$installed"; fi; /bin/rmdir "$stage"' EXIT
/bin/cp -p "$binary" "$installed"
test "$(/usr/bin/shasum -a 256 "$installed" | /usr/bin/cut -d' ' -f1)" = "$expected"

unset DOCKER_CONTEXT DOCKER_HOST DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH DOCKER_API_VERSION
docker=(/opt/homebrew/bin/docker --host "unix://$socket")
token=${stage##*.}
name="mpg8-test-$arm-$token"
label="io.micropod.gamma8.linux-test=$name"
test -z "$("${docker[@]}" ps -aq --filter "label=$label")"
set +e
python3 -B - "$limit" "${docker[@]}" run --rm --pull=never --network=none --name "$name" --label "$label" \
  --mount "type=bind,src=$installed,dst=/runner.test,readonly" --entrypoint /bin/sh alpine:3.23 \
  -ec 'mkdir -p /run/micropod-oci; exec /runner.test "$@"' gamma-linux-test -test.v -test.run "$filter" <<'PY'
import subprocess
import sys

try:
    result = subprocess.run(sys.argv[2:], timeout=int(sys.argv[1]))
except subprocess.TimeoutExpired:
    print(f'Owned Docker test exceeded {sys.argv[1]} seconds', file=sys.stderr)
    raise SystemExit(124)
raise SystemExit(result.returncode)
PY
status=$?
set -e
remaining=$("${docker[@]}" ps --no-trunc -aq --filter "label=$label")
if [[ -n $remaining ]]; then
  test "$remaining" = "$("${docker[@]}" inspect --format '{{.Id}}' "$name")"
  "${docker[@]}" container rm --force "$name" > "$receipts/$arm-$receipt-recovery.log"
fi
"${docker[@]}" ps -aq --filter "label=$label" > "$receipts/$arm-$receipt-cleanup.log"
test ! -s "$receipts/$arm-$receipt-cleanup.log"
exit "$status"
