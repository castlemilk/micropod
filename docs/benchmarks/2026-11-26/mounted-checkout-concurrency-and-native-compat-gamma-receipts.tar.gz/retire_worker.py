"""Ask one admitted, empty, private Gamma worker to shut down gracefully."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import subprocess

receipts = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('label')
    args = parser.parse_args()
    label = args.label
    assert re.fullmatch('[a-z0-9-]{1,22}', label)
    ready = json.loads((receipts / f'{label}-ready.json').read_bytes())
    worker = Path(ready['worker_directory']).resolve(strict=True)
    assert worker.parent == Path('/private/tmp') and worker.name.startswith(f'mpg8-{label}-')
    scope = Path(ready['public_scope']).resolve(strict=True)
    assert scope.parent == worker / 'home' and scope.name.startswith('outer-machine-')
    assert Path(ready['worker_volume']).is_mount()
    socket = Path(ready['socket']).resolve(strict=True)
    assert socket == scope / 'machine/run/docker.sock' and socket.is_socket()
    release = Path(ready['release_file'])
    assert release == scope / 'release' and not os.path.lexists(release)
    env = {key: value for key, value in os.environ.items()
           if key not in ('DOCKER_CONTEXT', 'DOCKER_HOST', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY',
                          'DOCKER_CERT_PATH', 'DOCKER_API_VERSION')}
    checked = subprocess.run(['/opt/homebrew/bin/docker', '--host', 'unix://' + str(socket), 'ps', '--no-trunc', '-aq'],
                             capture_output=True, text=True, env=env, timeout=10, check=True)
    assert not checked.stdout.strip(), ('remaining private containers', checked.stdout)
    with (receipts / f'{label}-release-request.json').open('x') as log:
        json.dump({'release': str(release), 'utc': datetime.now(timezone.utc).isoformat(), 'remaining_containers': []}, log)
        log.write('\n')
    release.open('x').close()


if __name__ == '__main__':
    main()
