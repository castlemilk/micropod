"""Trace the eight-job stock workload after obtaining a quiet Gamma admission."""
import json
from pathlib import Path
import subprocess
import sys
import time

evidence = Path(__file__).resolve().parent
stage = evidence.parent / "home"
ready = json.loads(Path(sys.argv[1]).read_bytes())
expected = {"vmm": "f0747277714ef1520de32e7e5d398a0b88aded8a52c8f8076dc7daaafde1d3c4",
            "kernel": "61b4e143b26039e4642f48b3819e0233f22b44f5c3e88e109cbc9c17508cc85f",
            "job": "55f2ae080a601a84fd10123f6a717e880a0da6f1f2d9f827f7bf249fa79ca4d0"}
assert all(ready["owned_artifacts"][k]["sha256"] == v for k, v in expected.items())
assert Path(ready["socket"]).is_socket()
profile = "quiet"
for attempt in range(1, 23):
    name = f"quiet-git-profile-attempt-{attempt}"
    admission = evidence / f"{name}-preflight.json"
    assert not admission.exists()
    gate = subprocess.run(["bash", str(evidence / "probe_quiet_admission.sh"), name, "3.2"])
    if gate.returncode == 0 and json.loads(admission.read_bytes())["quiet_prestart_observed"]:
        break
    time.sleep(1)
else:
    profile = "postbuild-ambient"
    print("Quiet admission unavailable across 22 preflights. Recording compiler-free ambient diagnostic.", flush=True)
out = evidence / f"{profile}-git-profile.json"
assert not out.exists()
python = [sys.executable, "-B"]
args = [*python, str(evidence / "with_host_load.py"), "--out", str(evidence / f"{profile}-profile-host-load.jsonl"), "--",
        *python, str(evidence / "profile_git_density.py"), "--hvf-socket", ready["socket"],
        "--orbstack-socket", "/Users/benebsworth/.orbstack/run/docker.sock", "--workspace", ready["workspace"],
        "--source", str(stage / "evidence/prior/runner-vendored"), "--helpers", str(stage / "evidence/prior/final-harness/scripts"),
        "--image-manifest", str(evidence / "image-manifest.json"), "--image", ready["benchmark_image"],
        "--pairs", "4", "--out", str(out)]
subprocess.run(args, check=True)
subprocess.run([*python, str(evidence / "summarize_git_profiles.py"), "--run", str(out), "--admission",
                str(admission), "--out", str(evidence / f"{profile}-git-profile-summary.json")], check=True)
print(profile, "Git diagnostic complete", flush=True)
