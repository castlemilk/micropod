"""Compare Docker v1.47 duplicate-name responses for two private fixture names."""
import argparse
import json
from pathlib import Path
import re
from urllib.parse import urlencode
from uuid import uuid4

from qualify_testcontainers_go import CONTAINER_ID, OWNER, Engine, Probe, checked_image, require


def compare(socket, result):
    engine = Engine(socket, 'alpine:3.23', None, None, api_version='1.47')
    scope = 'mp-tc-conflict-' + uuid4().hex
    result.update(socket=str(socket), name=scope, manual_cleanup=[])
    probe = Probe(engine, scope, result)
    route = '/containers/create?' + urlencode({'name': scope})
    inspect = '/containers/' + scope + '/json'
    spec = {'Image': 'alpine:3.23', 'Cmd': ['/bin/true'], 'Labels': {OWNER: scope},
            'HostConfig': {'NetworkMode': 'none'}}
    result['preloaded_image'] = checked_image(engine, 'alpine:3.23')
    require(not any(probe.scope_rows().values()) and probe.request('GET', inspect)[0] == 404,
            'Generated fixture scope already exists')
    try:
        status, _, data = engine.request('POST', route, body=spec)
        result['first_create'] = {'status': status, 'body_utf8': data.decode()}
        require(status == 201, 'Initial owned create failed')
        owned = json.loads(data)['Id']
        require(CONTAINER_ID.fullmatch(owned), 'Expected complete container ID')
        status, inspected = probe.request('GET', inspect)
        require(status == 200 and inspected['Id'] == owned and inspected['Name'] == '/' + scope
                and inspected['Config']['Labels'][OWNER] == scope, 'Owned identity changed')
        status, headers, data = engine.request('POST', route, body=spec)
        result['duplicate_create'] = {'status': status, 'content_type': headers.get('content-type'),
                                      'body_utf8': data.decode(), 'body': json.loads(data)}
        require(status == 409, 'Duplicate name was not rejected')
        message = result['duplicate_create']['body']['message']
        result['sdk_reaper_retries_message'] = bool(re.search(
            r'Conflict. The container name .* is already in use by container .*', message))
        result['names_owned_winner'] = f'"/{scope}"' in message and f'"{owned}"' in message
        status, still_owned = probe.request('GET', inspect)
        require(status == 200 and still_owned['Id'] == owned, 'Duplicate attempt displaced the winner')
    finally:
        probe.recover_scope()
        result['remaining'] = probe.scope_rows()
        result['name_after_cleanup'] = probe.request('GET', inspect)[0]
        require(not any(result['remaining'].values()) and result['name_after_cleanup'] == 404
                and checked_image(engine, 'alpine:3.23') == result['preloaded_image'], 'Scope cleanup failed')


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    for option in ('native', 'stock', 'out'):
        cli.add_argument('--' + option, type=Path, required=True)
    args = cli.parse_args()
    require(args.native.is_socket() and args.stock.is_socket() and not args.native.samefile(args.stock)
            and not args.out.exists(), 'Expected distinct explicit sockets and a fresh receipt')
    report = {'api_version': '1.47', 'native': {}, 'stock': {}}
    try:
        for name in ('native', 'stock'):
            compare(getattr(args, name), report[name])
    finally:
        with args.out.open('x') as stream:
            json.dump(report, stream, indent=2)
            stream.write('\n')


if __name__ == '__main__':
    main()
