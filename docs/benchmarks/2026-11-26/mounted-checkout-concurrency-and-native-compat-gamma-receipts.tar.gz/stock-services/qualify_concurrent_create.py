#!/usr/bin/env python3
"""Verify Docker v1.47 name ownership across concurrent and stopped duplicate creates."""

import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import re
from threading import Barrier
from urllib.parse import urlencode
from uuid import uuid4

from qualify_testcontainers_go import CONTAINER_ID, Engine, OWNER, Probe, checked_image, require

SDK_CONFLICT = re.compile(r"Conflict. The container name .* is already in use by container .*")
IMAGE = "alpine:3.23"
CLIENTS = 8


def expected_message(name, owner):
    return (f'Conflict. The container name "/{name}" is already in use by container "{owner}". '
            'You have to remove (or rename) that container to be able to reuse that name.')


def record(engine, method, path, spec=None):
    status, headers, data = engine.request(method, path, body=spec)
    return {"method": method, "path": engine.prefix + path, "status": status,
            "content_type": headers.get("content-type"), "body_utf8": data.decode()}


def check_conflict(response, message):
    require(response["status"] == 409 and response["content_type"].startswith("application/json"),
            "Duplicate create did not return a JSON conflict")
    body = json.loads(response["body_utf8"])
    require(body == {"message": message} and SDK_CONFLICT.search(body["message"]),
            "Duplicate create did not identify the exact owner with the stock SDK retry message")


def exercise(socket, result):
    engine = Engine(socket, IMAGE, None, None, api_version="1.47")
    scope = "mp-tc-parallel-" + uuid4().hex
    result.update(socket=str(socket), scope=scope, manual_cleanup=[])
    probe = Probe(engine, scope, result)
    route = "/containers/create?" + urlencode({"name": scope})
    inspect = "/containers/" + scope + "/json"
    spec = {"Image": IMAGE, "Cmd": ["/bin/sleep", "120"], "Labels": {OWNER: scope},
            "HostConfig": {"NetworkMode": "none"}}
    result["image_before"] = checked_image(engine, IMAGE)
    require(not any(probe.scope_rows().values()) and probe.request("GET", inspect)[0] == 404,
            "Generated fixture scope already exists")
    owner = None
    barrier = Barrier(CLIENTS)

    def create():
        barrier.wait(timeout=10)
        return record(engine, "POST", route, spec)

    def checked_owner(phase):
        status, row = probe.request("GET", inspect)
        require(status == 200 and row["Id"] == owner and row["Name"] == "/" + scope
                and row["Config"]["Labels"][OWNER] == scope and row["State"]["Status"] == phase,
                "Container name no longer identifies the original owned " + phase + " object")
        return {"id": owner, "state": phase, "name": row["Name"], "labels": row["Config"]["Labels"]}

    try:
        with ThreadPoolExecutor(max_workers=CLIENTS) as group:
            pending = [group.submit(create) for _ in range(CLIENTS)]
            result["parallel_create"] = [request.result() for request in pending]
        statuses = [response["status"] for response in result["parallel_create"]]
        result["parallel_statuses"] = statuses
        require(sorted(statuses) == [201] + [409] * (CLIENTS - 1), "Expected one winner and seven conflicts")
        winner, = (response for response in result["parallel_create"] if response["status"] == 201)
        owner = json.loads(winner["body_utf8"])["Id"]
        require(CONTAINER_ID.fullmatch(owner), "Expected a full owner container ID")
        result["created_owner"] = checked_owner("created")
        message = expected_message(scope, owner)
        for response in result["parallel_create"]:
            if response["status"] != 201:
                check_conflict(response, message)

        base = "/containers/" + owner
        result["start"] = record(engine, "POST", base + "/start")
        require(result["start"]["status"] == 204, "Could not start the owned fixture")
        result["running_owner"] = checked_owner("running")
        result["stop"] = record(engine, "POST", base + "/stop?t=1")
        require(result["stop"]["status"] == 204, "Could not stop the owned fixture")
        result["duplicate_stopped"] = record(engine, "POST", route, spec)
        check_conflict(result["duplicate_stopped"], message)
        result["stopped_owner"] = checked_owner("exited")
    finally:
        probe.recover_scope()
        result["remaining"] = probe.scope_rows()
        result["name_after_cleanup"] = probe.request("GET", inspect)[0]
        if owner and CONTAINER_ID.fullmatch(owner):
            result["owner_after_cleanup"] = probe.request("GET", "/containers/" + owner + "/json")[0]
        result["image_after"] = checked_image(engine, IMAGE)
        require(not any(result["remaining"].values()) and result["name_after_cleanup"] == 404
                and result.get("owner_after_cleanup", 404) == 404 and result["image_after"] == result["image_before"],
                "Scoped cleanup failed or the shared image changed")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("native", "stock", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    require(args.native.is_socket() and args.stock.is_socket() and not args.native.samefile(args.stock)
            and not args.out.exists(), "Expected two distinct explicit Unix sockets and an unused receipt path")
    report = {"api_version": "1.47", "clients_per_engine": CLIENTS}
    passed = True
    for role in ("stock", "native"):
        result = report[role] = {}
        try:
            exercise(getattr(args, role), result)
            result["passed"] = True
        except Exception as error:
            result["passed"] = passed = False
            result["error"] = f"{type(error).__name__}: {error}"
    with args.out.open("x") as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write("\n")
    return int(not passed)


if __name__ == "__main__":
    raise SystemExit(main())
