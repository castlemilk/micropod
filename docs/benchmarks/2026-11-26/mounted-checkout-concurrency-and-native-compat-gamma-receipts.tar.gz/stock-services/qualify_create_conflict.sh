#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")/.." && pwd -P)
platform="$D/stock-services"
arm=tc-create-conflict
ready="$D/$arm-ready.json"
runner=0b20a6f006ca61efa323287777e51466833b21c649982d287948d4b1bf506af8
sock=$(jq -er .socket "$ready")
orb=/Users/benebsworth/.orbstack/run/docker.sock
test -S "$sock" && test -S "$orb"
test "$(jq -er .owned_artifacts.job.sha256 "$ready")" = "$runner"
test "$(cat "$D/$arm-linux-exit.log")" = 'linux_focused=0 linux_full=0'
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_API_VERSION DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH
export DOCKER_CLI_HINTS=false
native=(/opt/homebrew/bin/docker --host "unix://$sock")
test -z "$("${native[@]}" ps -aq)"
jq -e '.Architecture=="arm64" and .Id=="sha256:f04fd744b5d50f8c88d9d4938c54e05a9adb56d520542f899a7d6873fa7280f2"' \
    "$D/$arm-ryuk-load-inspect.json" >/dev/null
python3 -B "$platform/compare_duplicate_create.py" --native "$sock" --stock "$orb" \
    --out "$platform/duplicate-create-after.json"
jq -e '[.native,.stock] | all(.sdk_reaper_retries_message and .names_owned_winner and .name_after_cleanup==404)' \
    "$platform/duplicate-create-after.json" >/dev/null
test -z "$("${native[@]}" ps -aq)"
result=0
python3 -B "$platform/run_candidate_pairs.py" --ready "$ready" --runner-sha256 "$runner" \
    > "$platform/final-pair-run.log" 2>&1 || result=$?
printf '%s\n' "$result" > "$platform/final-pair-run.exit"
"${native[@]}" ps -aq > "$platform/final-corrected-native-owned-containers.log"
test ! -s "$platform/final-corrected-native-owned-containers.log"
cat "$platform/final-pair-run.log"
exit "$result"
