"""Compare four alternating pairs of stock eight-service starts on a fresh runner."""
import argparse
import hashlib
import json
from pathlib import Path
import re
from statistics import median
import subprocess
import sys


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ready", type=Path, required=True)
    parser.add_argument("--runner-sha256", required=True)
    args = parser.parse_args()
    runner = args.runner_sha256
    assert re.fullmatch("[0-9a-f]{64}", runner)
    source = Path(__file__).resolve().parent
    evidence = source.parent
    ready = read(args.ready)
    assert args.ready.resolve().parent == evidence and ready["owned_artifacts"]["job"]["sha256"] == runner
    client = evidence.parent / "home/testcontainers-client-nc/testcontainers-fixture"
    probe = source / "bench_testcontainers_services.py"
    controls = {e: read(source / f"{e}-check.json") for e in ("native", "stock")}
    for control in controls.values():
        assert control["passed"] and control["client_sha256"] == digest(client) and control["driver_sha256"] == digest(probe)
    for name, native in controls["native"]["images_before"].items():
        stock = controls["stock"]["images_before"][name]
        assert native["RootFS"]["Layers"] == stock["RootFS"]["Layers"]
        assert {r.rsplit("@", 1)[1] for r in native["RepoDigests"]} == {r.rsplit("@", 1)[1] for r in stock["RepoDigests"]}
    directory = source / runner[:12]
    directory.mkdir()
    python = [sys.executable, "-B"]
    pairs = []
    for index in range(4):
        order = ["stock", "native"] if index % 2 else ["native", "stock"]
        waves = {}
        pairs.append({"order": order, "engines": waves})
        for engine in order:
            stem = f"services-{runner[:8]}-{index + 1}-{engine}"
            for attempt in range(1, 5):
                gate = f"{stem}-admission-{attempt}"
                path = evidence / f"{gate}-preflight.json"
                proc = subprocess.run(["bash", str(evidence / "probe_quiet_admission.sh"), gate, "3.2"])
                admission = read(path)
                if proc.returncode == 0 and admission["quiet_prestart_observed"]:
                    break
            endpoint = ready["socket"] if engine == "native" else controls[engine]["socket"]
            expected_images = controls[engine]["images_before"]
            result_path = directory / f"{stem}.json"
            load_path = directory / f"{stem}-host-load.jsonl"
            command = [*python, str(evidence / "with_host_load.py"), "--out", str(load_path), "--",
                       *python, str(probe), "--socket", endpoint, "--image", "alpine:3.23", "--client", str(client),
                       "--ryuk-id", expected_images["testcontainers/ryuk:0.13.0"]["Id"], "--out", str(result_path)]
            proc = subprocess.run(command)
            report = read(result_path)
            assert report["images_before"] == expected_images == report["images_after"]
            assert len(report["remaining"]) == 8 and not any(any(x.values()) for x in report["remaining"])
            assert not any(report["remaining_reapers"])
            assert report["client_sha256"] == digest(client) and report["driver_sha256"] == digest(probe)
            assert bool(report["passed"]) == (proc.returncode == 0)
            entry = {"passed": report["passed"], "receipt": result_path.name, "sha256": digest(result_path),
                     "load_receipt": load_path.name, "load_sha256": digest(load_path),
                     "admission_receipt": path.name, "quiet_prestart_observed": admission["quiet_prestart_observed"]}
            if report["passed"]:
                assert report["automatic_removal_status"] == [404] * 9 and not report["manual_cleanup"]
                assert len({j["endpoint"] for j in report["jobs"]}) == len({j["id"] for j in report["jobs"]}) == 8
                assert len({j["session"] for j in report["jobs"]}) == 1
                entry.update({k: report[k] for k in ("start_to_last_ready_ms", "to_verified_cleanup_ms")})
            else:
                entry.update(error=report["error"], rollback_actions=len(report["manual_cleanup"]))
            waves[engine] = entry
            print(index + 1, engine, entry["passed"], entry.get("start_to_last_ready_ms"), flush=True)
    passed = all(w["passed"] for row in pairs for w in row["engines"].values())
    summary = {"passed": passed, "runner_sha256": runner, "pairs": pairs, "client_sha256": digest(client),
               "driver_sha256": digest(probe), "quiet_arms": sum(w["quiet_prestart_observed"] for row in pairs for w in row["engines"].values())}
    if passed:
        for engine in controls:
            summary[engine] = {k: median(row["engines"][engine][k] for row in pairs)
                               for k in ("start_to_last_ready_ms", "to_verified_cleanup_ms")}
        summary["native_readiness_wins"] = sum(row["engines"]["native"]["start_to_last_ready_ms"] <
                                              row["engines"]["stock"]["start_to_last_ready_ms"] for row in pairs)
    with (directory / "paired-summary.json").open("x") as output:
        json.dump(summary, output, indent=2)
        output.write("\n")
    return int(not passed)


if __name__ == "__main__":
    raise SystemExit(main())
