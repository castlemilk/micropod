"""Run counterbalanced eight-service Testcontainers waves on the qualified endpoints."""
import argparse
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--ready", type=Path, required=True)
args = parser.parse_args()
directory = Path(__file__).resolve().parent
evidence = directory.parent
hub = evidence.parent / "home"
ready = json.loads(args.ready.read_bytes())
expected = "d5a08b48f07feb9a71d68837b7ebe3c17f08d4cf4567af13c0e47dd15f07a77a"
assert args.ready.resolve().parent == evidence and expected in args.ready.read_text()
assert (hub / "testcontainers-client-nc/testcontainers-fixture").is_file()
assert not (directory / 'paired-summary.json').exists()
client = hub / 'testcontainers-client-nc/testcontainers-fixture'
controls = {}
for engine in ('native','stock'):
    control = json.loads((directory / f'{engine}-check.json').read_bytes())
    assert control['passed'] and not control['manual_cleanup']
    controls[engine] = control
for name, image in controls['native']['images_before'].items():
    stock = controls['stock']['images_before'][name]
    assert image['RootFS']['Layers'] == stock['RootFS']['Layers']
    assert {r.rsplit('@', 1)[1] for r in image['RepoDigests']} == {r.rsplit('@', 1)[1] for r in stock['RepoDigests']}

rows = []
for pair in range(1, 5):
    engines = ('native', 'stock') if pair % 2 else ('stock', 'native')
    results = {}
    for engine in engines:
        stem = f'services-pair-{pair}-{engine}'
        admission = None
        for attempt in range(1, 5):
            gate = f'{stem}-admission-{attempt}'
            probe = subprocess.run(['bash', str(evidence / 'probe_quiet_admission.sh'), gate, '3.2'])
            observation = json.loads((evidence / f'{gate}-preflight.json').read_bytes())
            if probe.returncode == 0 and observation['quiet_prestart_observed']:
                admission = {'receipt': gate + '-preflight.json', **observation}
                break
        if admission is None:
            admission = {'quiet_prestart_observed': False, 'receipt': gate + '-preflight.json'}
        control = controls[engine]
        socket = ready['socket'] if engine == 'native' else control['socket']
        ryuk_id = control['images_before']['testcontainers/ryuk:0.13.0']['Id']
        output = directory / f'{stem}.json'
        subprocess.run([sys.executable, '-B', str(evidence / 'with_host_load.py'), '--out',
                        str(directory / f'{stem}-load.jsonl'), '--', sys.executable, '-B',
                        str(directory / 'bench_testcontainers_services.py'), '--socket', socket, '--image', 'alpine:3.23',
                        '--client', str(client), '--ryuk-id', ryuk_id, '--out', str(output)], check=True)
        content = output.read_bytes()
        report = json.loads(content)
        assert report['passed'] and not report['manual_cleanup'] and report['automatic_removal_status'] == [404]*9
        assert len({j['endpoint'] for j in report['jobs']}) == len({j['id'] for j in report['jobs']}) == 8
        assert len({j['session'] for j in report['jobs']}) == 1
        assert report['images_before'] == report['images_after'] == control['images_before']
        assert report['client_sha256'] == control['client_sha256'] and report['driver_sha256'] == control['driver_sha256']
        results[engine] = {k:report[k] for k in ('start_to_last_ready_ms','to_verified_cleanup_ms')}
        results[engine].update(admission=admission, receipt=output.name, sha256=hashlib.sha256(content).hexdigest())
        print(pair,engine,'ready ms',results[engine]['start_to_last_ready_ms'],'quiet',admission['quiet_prestart_observed'],flush=True)
    rows.append({'order':engines,'engines':results})

summary={'pairs':rows,'runner_sha256':expected,'admitted_arms':sum(r['admission']['quiet_prestart_observed'] for row in rows for r in row['engines'].values())}
for engine in controls:
    summary[engine]={key:statistics.median(row['engines'][engine][key] for row in rows)
                     for key in ('start_to_last_ready_ms','to_verified_cleanup_ms')}
with (directory / 'paired-summary.json').open('x') as f:
    json.dump(summary,f,indent=2);f.write('\n')
