"""Take a separately admitted, reference-first eight-service pair on the final worker."""
from pathlib import Path
import subprocess
import sys
import time
import json
from run_candidate_pairs import read, digest

source = Path(__file__).resolve().parent
evidence = source.parent
ready_path = Path(sys.argv[1])
alternating = read(source / "0b20a6f006ca/paired-summary.json")
ready = read(ready_path)
assert alternating["passed"] and ready_path.resolve().parent == evidence
assert alternating["runner_sha256"] == ready["owned_artifacts"]["job"]["sha256"]
driver = source / "bench_testcontainers_services.py"
client = evidence.parent / "home/testcontainers-client-nc/testcontainers-fixture"
assert digest(driver) == alternating["driver_sha256"] and digest(client) == alternating["client_sha256"]
directory = source / "quiet-0b20a6f006ca"
directory.mkdir()
python = [sys.executable, "-B"]
summary = {"runner_sha256": alternating["runner_sha256"], "order": ["stock", "native"], "arms": {}}
for engine in summary["order"]:
    deadline = time.monotonic() + 60
    for attempt in range(1, 25):
        label = f"quiet-services-{engine}-attempt-{attempt}"
        gate = subprocess.run(["bash", str(evidence / "probe_quiet_admission.sh"), label, "3.2"])
        gate_path = evidence / f"{label}-preflight.json"
        admission = read(gate_path)
        if gate.returncode == 0 and admission["quiet_prestart_observed"]:
            break
        if time.monotonic() >= deadline:
            break
    qualified = gate.returncode == 0 and admission["quiet_prestart_observed"]
    arm = summary["arms"][engine] = {"admitted": qualified, "attempts": attempt, "preflight": gate_path.name}
    if not qualified:
        print(engine, "quiet admission unavailable", flush=True)
        continue
    baseline = read(source / f"{engine}-check.json")
    endpoint = ready["socket"] if engine == "native" else baseline["socket"]
    path = directory / f"{engine}.json"
    load = directory / f"{engine}-load.jsonl"
    result = subprocess.run([*python, str(evidence / "with_host_load.py"), "--out", str(load), "--", *python,
                             str(driver), "--socket", endpoint, "--image", "alpine:3.23", "--client", str(client),
                             "--ryuk-id", baseline["images_before"]["testcontainers/ryuk:0.13.0"]["Id"], "--out", str(path)])
    wave = read(path)
    assert wave["images_before"] == wave["images_after"] == baseline["images_before"]
    assert len(wave["remaining"]) == 8 and not any(any(x.values()) for x in wave["remaining"]) and not any(wave["remaining_reapers"])
    arm.update(receipt=path.name, sha256=digest(path), load_sha256=digest(load), passed=wave["passed"])
    if wave["passed"]:
        assert result.returncode == 0 and not wave["manual_cleanup"] and wave["automatic_removal_status"] == [404] * 9
        arm.update({k: wave[k] for k in ("start_to_last_ready_ms", "to_verified_cleanup_ms")})
    else:
        arm.update(error=wave["error"], rollback_actions=len(wave["manual_cleanup"]))
    print(engine, arm, flush=True)
summary["complete_matched_pair"] = all(arm.get("passed") for arm in summary["arms"].values())
with (directory / "summary.json").open("x") as output:
    json.dump(summary, output, indent=2)
    output.write("\n")
raise SystemExit(any(arm["admitted"] and not arm["passed"] for arm in summary["arms"].values()))
