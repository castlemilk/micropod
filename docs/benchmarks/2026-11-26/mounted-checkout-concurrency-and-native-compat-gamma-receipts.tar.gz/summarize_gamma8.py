"""Summarize Gamma8 mounted checkout, workspace candidates and native Docker evidence."""
from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
import gzip
import json
from pathlib import Path
from statistics import median

receipts = Path(__file__).resolve().parent
archive_calculator = receipts / 'inherited-gamma6/summarize_gamma6.py'
spec = spec_from_file_location('baseline_reducer', archive_calculator)
calculator = module_from_spec(spec)
spec.loader.exec_module(calculator)
calculator.receipts = receipts
read, receipt = calculator.read, calculator.receipt


def load_admission(label):
    path = receipts / (label + '-preflight.json')
    if not path.is_file():
        return {'classification': 'ambient', 'preflight': None}
    raw = read(path)
    return {'classification': 'quiet-admitted' if raw['quiet_prestart_observed'] else 'ambient',
            'preflight': {'receipt': receipt(path), **raw}}


def score_alias(name, prefix):
    return name == prefix or name.startswith(prefix + '-retry')


def matched(scorecard, titles):
    arms = {}
    for prefix in titles:
        matching = [label for label in scorecard['material'] if score_alias(label, prefix)
                    and label in scorecard['density'] and scorecard['density'][label]['pass']]
        if not matching:
            return None
        assert len(matching) == 1, matching
        arms[prefix] = matching[0]
    assert len(set(arms.values())) == len(titles)
    assert all(scorecard['boots'][name]['artifacts'] == scorecard['boots'][titles[0]]['artifacts'] for name in titles)
    data = {'arm_receipt_labels': arms, 'material': {}, 'density': {}}
    for name, receipt_label in arms.items():
        ci = scorecard['material'][receipt_label]
        data['material'][name] = {'phase_engine_medians': {stage: row['engines'] for stage, row in ci['rounds'].items()},
                                  'paired_hvf_orb_ratios': {phase: row['median_hvf_to_orbstack_ratio']
                                                           for phase, row in ci['rounds'].items()},
                                  'individual_pairs': ci['individual_pairs'],
                                  'hvf_wins': {phase: row['hvf_wins'] for phase, row in ci['rounds'].items()},
                                  'scored_weighted_idle_pct': ci['load']['weighted_cpu_idle_pct'],
                                  'admission': ci['admission']}
        wave = scorecard['density'][receipt_label]
        ratios = wave['paired_hvf_to_orbstack']['guest_to_last_ms']
        data['density'][name] = {'wave_medians': {engine: item['wave_median'] for engine, item in wave['summary'].items()},
                                 'paired_hvf_orb_guest_ratio': median(ratios), 'individual_pair_ratios': ratios,
                                 'hvf_wins': sum(ratio < 1 for ratio in ratios),
                                 'overlaps_ms': wave['overlaps'],
                                 'scored_weighted_idle_pct': wave['load']['weighted_cpu_idle_pct'],
                                 'admission': wave['admission']}
    return data


def pinned_api():
    result = {}
    for path in sorted(receipts.glob('**/docker-api*1.47.json.gz')):
        with gzip.open(path, 'rt') as stream:
            row = json.load(stream)
        if 'candidate' not in row or 'operations' not in row:
            continue
        state = Counter(case.get('comparison','unclassified') for case in row['candidate'].values())
        ops = sorted({op for case in row['candidate'].values() for op in case.get('operations', [])})
        assert set(ops) <= row['operations'].keys()
        result[path.relative_to(receipts).as_posix()] = {
            'receipt': receipt(path), 'groups': dict(state), 'operations_in_spec': len(row['operations']),
            'exercised_operations': ops}
    return result


def service_waves():
    directory = receipts / 'stock-services'
    earlier = directory / 'services-pair-1-native.json'
    result = {'attempts': {}}
    if earlier.is_file():
        first = read(earlier)
        assert not first['passed'] and not any(first['remaining_reapers'])
        assert not any(any(scope.values()) for scope in first['remaining'])
        result['first_native_attempt'] = {'receipt': receipt(earlier), 'error': first['error'],
            'rollback_actions': len(first['manual_cleanup']),
            'load': calculator.load(earlier.with_name(earlier.stem + '-load.jsonl'))}
    for filename in ('duplicate-create-before.json', 'duplicate-create-after.json',
                     'stock-reference-after-native-conflict.json'):
        path = directory / filename
        if path.is_file():
            result[path.stem] = {'receipt': receipt(path), 'contents': read(path)}
    for path in sorted(directory.glob('*/paired-summary.json')):
        summary = read(path)
        runner = summary['runner_sha256']
        assert runner.startswith(path.parent.name) and len(summary['pairs']) == 4
        for index, pair in enumerate(summary['pairs'], 1):
            assert pair['order'] == (['native', 'stock'] if index % 2 else ['stock', 'native'])
            assert set(pair['engines']) == {'native', 'stock'}
            for data in pair['engines'].values():
                payload = path.parent / data['receipt']
                assert receipt(payload)['sha256'] == data['sha256']
                raw = read(payload)
                assert raw['passed'] == data['passed'] and not any(raw['remaining_reapers'])
                assert not any(any(scope.values()) for scope in raw['remaining'])
                load = path.parent / data['load_receipt']
                assert receipt(load)['sha256'] == data['load_sha256']
                data['load'] = calculator.load(load)
                admission = receipts / data['admission_receipt']
                assert read(admission)['quiet_prestart_observed'] == data['quiet_prestart_observed']
                data['admission'] = {'receipt': receipt(admission), **read(admission)}
                if data['passed']:
                    assert raw['automatic_removal_status'] == [404] * 9 and not raw['manual_cleanup']
                    assert len(raw['jobs']) == 8
                    data['fully_overlapping_services'] = len(raw['jobs'])
        summary['receipt'] = receipt(path)
        result['attempts'][runner] = summary
    quiet = directory / 'quiet-0b20a6f006ca/summary.json'
    if quiet.is_file():
        summary = read(quiet)
        assert summary['order'] == ['stock', 'native'] and set(summary['arms']) == {'stock', 'native'}
        assert summary['runner_sha256'] in result['attempts']
        for engine, arm in summary['arms'].items():
            profile = receipts / arm['preflight']
            assert arm['admitted'] == read(profile)['quiet_prestart_observed']
            arm['admission'] = {'receipt': receipt(profile), **read(profile)}
            if arm['admitted']:
                payload = quiet.parent / arm['receipt']
                raw = read(payload)
                assert receipt(payload)['sha256'] == arm['sha256'] and raw['passed'] == arm['passed']
                assert not any(any(scope.values()) for scope in raw['remaining']) and not any(raw['remaining_reapers'])
                load = quiet.parent / f'{engine}-load.jsonl'
                assert receipt(load)['sha256'] == arm['load_sha256']
                arm['load'] = calculator.load(load)
                if arm['passed']:
                    assert raw['automatic_removal_status'] == [404] * 9 and not raw['manual_cleanup']
        assert summary['complete_matched_pair'] == all(arm.get('passed') for arm in summary['arms'].values())
        result['quiet_pair'] = {'receipt': receipt(quiet), **summary}
    return result


def main():
    result = {'host': 'Gamma-128GB.local', 'date_melbourne': '2026-11-26', 'fixture': read(receipts/'baseline-lineage.json'),
              'matched_image': read(receipts/'image.json'), 'boots': {}, 'material': {}, 'density': {},
              'diagnostics': {}, 'linux_tests': {}, 'exceptions': {}, 'recovered_retirements': {}, 'matched_comparisons': {},
              'pinned_api_audits': pinned_api()}
    for path in sorted(receipts.glob('*-ready.json')):
        row = read(path)
        if 'owned_artifacts' not in row:
            continue
        result['boots'][row['label']] = {'receipt':receipt(path), 'artifacts':row['owned_artifacts'],
                                         'virtiofs_sysfs':row['virtiofs_sysfs'],
                                         'requested_kernel_arguments':row['kernel_arguments_requested'],
                                         'requested_workspace_event_idx':row.get('workspace_event_idx_requested'),
                                         'requested_workspace_coalesce':row.get('workspace_coalesce_requested')}
    for path in sorted(receipts.glob('*-material.json')):
        row = read(path)
        if row.get('workspace_mode') != 'independent byte-identical raw host checkouts':
            continue
        label = path.stem.removesuffix('-material')
        pairs = {phase: [{engine: pair[phase][engine]['sum_ns']/1e6 for engine in ('hvf','orbstack')}
                         for pair in row['pairs']] for phase in ('warm','incremental')}
        result['material'][label] = calculator.material(path,row) | {'admission':load_admission(label),
                                                                      'individual_pairs': pairs}
    for path in sorted(receipts.glob('*-density.json')):
        row = read(path)
        if row.get('execution') != 'stock unpinned Git':
            continue
        result['density'][path.stem.removesuffix('-density')] = calculator.density(path,row) | {
            'admission':load_admission(path.stem),
            'container_create_and_preparation_ms':{engine: setup['wall_ms'] for engine, setup in row['preparation'].items()}}
    comparisons = (
        ('readonly_workspace_coalescing', ('coalesce-off', 'coalesce-on')),
        ('compact_workspace_requests', ('compact-off', 'compact-on')),
        ('compact_workspace_requests_with_lookup', ('compact2-off', 'compact2-on')),
    )
    for name, arms in comparisons:
        summary = matched(result,arms)
        if summary:
            result['matched_comparisons'][name] = summary
    bindings = {'control': 'control'}
    for _, arms in comparisons:
        bindings.update({label: label for label in arms})
    bindings.update({label:label.split('-retry')[0] for label in result['material'] if '-retry' in label})
    result['measurement_worker_bindings'] = {label: result['boots'][arm]['receipt'] for label,arm in bindings.items()
                                             if label in result['material'] and arm in result['boots']}
    for pattern in ('*-lifecycle.json','*-vmm-metrics.json','*-dispatch.json','*-recovery.json','*-prepare-discrepancy.json',
                    '*-guest-splice.json','*-mmap-exact.json','*-stock-pid1.json','*-stock-pid1-retry.json',
                    'compact*-layout*.json','quiet-git-profile-summary.json','control-git-profile-summary.json',
                    'postbuild-ambient-git-profile-summary.json','owned-build-timing-audit.json'):
        for path in sorted(receipts.glob(pattern)):
            result['diagnostics'][path.stem] = {'receipt': receipt(path), 'contents': read(path)}
    for path in sorted(receipts.glob('*-linux-exit.log')):
        arm = path.name.removesuffix('-linux-exit.log')
        outputs = {stage: receipts/f'{arm}-linux-{stage}.log' for stage in ('focused','full')}
        result['linux_tests'][arm] = {'exit': path.read_text().strip(), 'logs': {
            stage: {'receipt':receipt(log), **calculator.read_linux_test(log)} for stage,log in outputs.items()}}
    for pattern in ('*-material.exit','*-density.exit','*-qualification-exit.log'):
        for path in sorted(receipts.glob(pattern)):
            status = path.read_text().strip()
            if status != '0' and not (status and all(token.endswith('=0') for token in status.split())):
                result['exceptions'][path.name] = {'receipt': receipt(path), 'exit': status}
    for path in sorted(receipts.glob('*-worker.json')):
        row = read(path)
        if row['errors']:
            result['exceptions'][path.name] = {'receipt': receipt(path), 'errors': row['errors']}
        if row.get('recovery'):
            result['recovered_retirements'][path.name] = {'receipt': receipt(path), 'recovery': row['recovery']}
    result['testcontainers_service_waves'] = service_waves()
    result['testcontainers_protocol_evidence'] = {}
    for short, arm in (('d5a08b', 'testcontainers-ryuk'), ('0b20a6', 'tc-create-conflict')):
        profiles = receipts / f'testcontainers/final-{short}/summary.json'
        coverage = receipts / f'testcontainers/pinned-api/{short}/coverage.json'
        if profiles.is_file() and coverage.is_file():
            exact = result['boots'][arm]['artifacts']['job']['sha256']
            assert exact.startswith(short)
            result['testcontainers_protocol_evidence'][exact] = {}
            for key, path in (('sdk_profiles', profiles), ('engine_coverage', coverage)):
                payload = read(path)
                assert payload['job_sha256'] == exact
                result['testcontainers_protocol_evidence'][exact][key] = {
                    'receipt': receipt(path), 'contents': payload}
    result['qualification_files'] = calculator.scoped_evidence('testcontainers/**/*','host-coalesce/**/*','kernel-compact/**/*',
        'compact-*','compact2-*','control-*profile*','quiet-*profile*','postbuild-*profile*','ryuk-*','stock-services/**/*')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
