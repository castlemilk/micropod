"""Summarize Trace2 regions and per-child getrusage for the eight-Git fixture."""

import argparse
import hashlib
import json
from pathlib import Path
from statistics import median

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--run", required=True, type=Path)
parser.add_argument("--out", required=True, type=Path)
parser.add_argument("--admission", type=Path)
args = parser.parse_args()
raw = args.run.read_bytes()
run = json.loads(raw)
assert run["passed"] and run["workspace_removed"] and run["jobs_per_wave"] == 8 and run["pairs"] == 4
src = run["source"]
assert src["files"] == 1058 and src["tree_sha256"] == "d963fc6e9f0a6a636fb0819065d7184a05ac9f6c2c3828b0f69afaf6b30980bd"
out = {"receipt": args.run.name, "sha256": hashlib.sha256(raw).hexdigest(), "source": src,
       "admission": json.loads(args.admission.read_bytes()) if args.admission else None,
       "engines": {}, "driver_sha256": run["driver_sha256"]}
counts = {"preload/sum_lstat": 1058, "refresh/sum_lstat": 1058, "refresh/sum_scan": 1058, "directories-visited": 181}
for engine in ("hvf", "orbstack"):
    waves = [row["waves"][engine] for row in run["rounds"]]
    jobs = [job for wave in waves for job in wave["jobs"]]
    assert len(jobs) == 32 and not run["cleanup"][engine]["remaining"]
    for job in jobs:
        assert job["exit"] == 0 and job["stdout_hex"] == job["stderr_hex"] == ""
        data = {r["key"]: int(r["value"]) for r in job["git_trace2"] if r.get("key") in counts}
        assert data == counts and len(job["allowed_cpus"]) == 4
    regions = {}
    for region in ("do_read_index", "preload", "refresh", "read_directory", "untracked"):
        samples = [[r["t_rel"] for r in job["git_trace2"] if r["event"] == "region_leave" and r.get("label") == region]
                   for job in jobs]
        assert all(len(row) == 1 for row in samples)
        regions[region] = median(1000 * row[0] for row in samples)
    out["engines"][engine] = {
        "jobs": len(jobs), "counters_each_job": counts, "median_trace2_region_ms": regions,
        "median_child_rusage": {k: median(j["child_rusage"][k] for j in jobs) for k in jobs[0]["child_rusage"]},
        "median_cgroup_delta": {k: median(j["cgroup_delta"][k] for j in jobs) for k in jobs[0]["cgroup_delta"]},
        "median_guest_wave_ms": median(w["guest_to_last_ms"] for w in waves),
        "median_job_ms": median(j["guest_ms"] for j in jobs),
    }
with args.out.open("x") as stream:
    json.dump(out, stream, indent=2)
    stream.write("\n")
