#!/usr/bin/env python3
"""Run pinned Docker API and concurrent name ownership controls for the final Testcontainers guest."""
import argparse
import gzip
import json
from pathlib import Path
import re
import subprocess
import sys

from replay_create_conflict import JOB, CLIENT, read, sha, verified_cleanup, write


def complete(ready_path, reference):
    received = read(ready_path)
    assert received['owned_artifacts']['job']['sha256'] == JOB
    native = Path(received['socket'])
    assert native.is_socket() and reference.is_socket() and not native.samefile(reference)
    out = Path(__file__).resolve().parent
    hub = out.parents[1]/'home'
    client = hub/'testcontainers-client-nc/testcontainers-fixture'
    assert sha(client) == CLIENT
    coverage = out/'pinned-api'
    api_results = coverage/'0b20a6'
    api_results.mkdir(mode=0o700)
    final = out/'final-0b20a6'
    commands = {
        'testcontainers': [sys.executable,'-B',str(out/'replay_create_conflict.py'),'--ready',str(ready_path),'--reference',str(reference)],
        'pinned-api': [sys.executable,'-B',str(coverage/'drivers/run_final_api_audit.py'),'--ready',str(ready_path),'--reference',str(reference),
                       '--job-sha',JOB,'--client',str(hub/'testcontainers-create-conflict/audit-client'),'--output-directory',str(api_results)],
    }
    commands['duplicate-create'] = [sys.executable, '-B', str(out.parent/'stock-services/qualify_concurrent_create.py'),
                                    '--native', str(native), '--stock', str(reference),
                                    '--out', str(api_results/'duplicate-create.json')]
    for side,socket,code in [('stock',reference,200),('native',native,501)]:
        commands[f'{side}-network-api'] = [sys.executable,'-B',str(out/'fixture-v4/qualify_testcontainers_go.py'),'--client',str(client),
                                          '--socket',str(socket),'--image','alpine:3.23','--preserve-image',received['benchmark_image'],
                                          '--mode','network-api','--network-connect-status',str(code),'--output',str(api_results/f'{side}-network-api.json')]
    write(api_results/'argv.json',commands)
    stages = ('duplicate-create','testcontainers','stock-network-api','native-network-api','pinned-api')
    outcomes = {}
    for name in stages:
        with (api_results/(name+'.log')).open('xb') as log:
            run = subprocess.run(commands[name],stdout=log,stderr=subprocess.STDOUT,check=False)
        outcomes[name] = run.returncode
        write(api_results/'stages.json',outcomes)
        print(name,run.returncode,flush=True)
    profile=read(final/'summary.json')
    assert profile['job_sha256']==JOB and profile['full_scope_cleanup_verified']
    raw=api_results/'docker-api-v1.47.json.gz'; audit=json.loads(gzip.decompress(raw.read_bytes()))
    summary=read(api_results/'summary.json')
    control=read(coverage/'control-operation-coverage.json')
    assert control['count_operations_exercised']==46 and control['strict']=={'matched':16,'different':11}
    assert len(audit['operations'])==control['operation_denominator']==107 and len(audit['candidate'])==27
    assert summary['job_sha256']==JOB and summary['exits']['cleanup']==0
    previous=read(coverage/'d5a08b/coverage.json')
    assert previous['job_sha256']=='d5a08b48f07feb9a71d68837b7ebe3c17f08d4cf4567af13c0e47dd15f07a77a'
    assert previous['current_matched_groups']==summary['strict']=={'matched':16,'different':11}
    previous_audit=json.loads(gzip.decompress((coverage/'d5a08b/docker-api-v1.47.json.gz').read_bytes()))
    assert {name: item['comparison'] for name,item in audit['candidate'].items()} == {
        name: item['comparison'] for name,item in previous_audit['candidate'].items()}
    duplicate_path=api_results/'duplicate-create.json'
    duplicate=read(duplicate_path)
    for side in ('stock','native'):
        trace=duplicate[side]
        assert trace['passed'] and sorted(trace['parallel_statuses'])==[201]+[409]*7
        assert trace['duplicate_stopped']['status']==409 and trace['stopped_owner']['state']=='exited'
        assert not any(trace['remaining'].values()) and trace['name_after_cleanup']==trace['owner_after_cleanup']==404
    assert audit['operations']['ContainerCreate']['cases'] and audit['operations']['ContainerCreate']['method']=='POST'
    original=set(control['union_operations_exercised'])
    old_current={name for name,row in audit['operations'].items() if row.get('cases')}
    assert old_current==set(control['pinned_operations']) and len(old_current)==39
    addition={}
    pattern={'NetworkConnect':('network_connect',r'/v1\.47/networks/[0-9a-f]{64}/connect',{'stock':200,'native':501}),
             'ContainerStop':('container_stop',r'/v1\.47/containers/[0-9a-f]{64}/stop\?t=1',{'stock':204,'native':204})}
    for op,(field,valid,statuses) in pattern.items():
        assert op not in original and audit['operations'][op]['method']=='POST'
        addition[op]={}
        for side,status in statuses.items():
            trace_path=api_results/f'{side}-network-api.json'; trace=read(trace_path)
            route=trace[field]; assert trace['passed'] and verified_cleanup(trace) and route['status']==status and route['method']=='POST' and re.fullmatch(valid,route['path'])
            addition[op][side]={'wire':route,'receipt_sha256':sha(trace_path)}
    union=original | set(addition)
    assert len(union)==48 and union==set(previous['cumulative_exercised_operations']) and union <= audit['operations'].keys()
    proof={'job_sha256':JOB,'stock_testcontainers_client_sha256':CLIENT,'ready_sha256':sha(ready_path),
           'prior_matched_groups':control['strict'],'current_matched_groups':summary['strict'],'strict_groups_total':27,
           'current_pinned_groups_changed':summary['changed_groups'],'pinned_operations_mapped':sorted(old_current),
           'prior_exercised_count':len(original),'operation_total':len(audit['operations']),'cumulative_exercised_count':len(union),
           'cumulative_exercised_operations':sorted(union),'new_wire_operations':addition,
           'raw_api_sha256':sha(raw),'pinned_cleanup_sha256':sha(api_results/'cleanup.json'),
           'testcontainers_summary_sha256':sha(final/'summary.json'),'script_stage_results':outcomes,
           'preceding_runner_sha256':previous['job_sha256'],'preceding_audit_sha256':previous['raw_api_sha256'],
           'duplicate_create_sha256':sha(duplicate_path),
           'supplementary_operation_already_counted':'ContainerCreate'}
    write(api_results/'coverage.json',proof)
    print('Strict',summary['strict'],'pinned',len(old_current),'cumulative',len(union),flush=True)
    return int(any(outcomes.values()))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--ready',type=Path,required=True)
    p.add_argument('--reference',type=Path,required=True)
    args=p.parse_args()
    return complete(args.ready,args.reference)


if __name__=='__main__':
    raise SystemExit(main())
