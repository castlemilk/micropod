#!/usr/bin/env python3
"""Run pinned Docker API and live network lifecycle controls for the final Testcontainers guest."""
import argparse
import gzip
import json
from pathlib import Path
import re
import subprocess
import sys

from replay_final import JOB, CLIENT, read, sha, verified_cleanup, write


def complete(ready_path, reference):
    received = read(ready_path)
    assert received['owned_artifacts']['job']['sha256'] == JOB
    native = Path(received['socket'])
    assert native.is_socket() and reference.is_socket() and not native.samefile(reference)
    out = Path(__file__).resolve().parent
    hub = out.parents[1]/'home'
    client = hub/'testcontainers-client-nc/testcontainers-fixture'
    assert sha(client) == CLIENT
    coverage = out/'pinned-api'
    api_results = coverage/'d5a08b'
    api_results.mkdir(mode=0o700)
    final = out/'final-d5a08b'
    commands = {
        'testcontainers': [sys.executable,'-B',str(out/'replay_final.py'),'--ready',str(ready_path),'--reference',str(reference)],
        'pinned-api': [sys.executable,'-B',str(coverage/'drivers/run_final_api_audit.py'),'--ready',str(ready_path),'--reference',str(reference),
                       '--job-sha',JOB,'--client',str(hub/'testcontainers-audit-client'),'--output-directory',str(api_results)],
    }
    for side,socket,code in [('stock',reference,200),('native',native,501)]:
        commands[f'{side}-network-api'] = [sys.executable,'-B',str(out/'fixture-v4/qualify_testcontainers_go.py'),'--client',str(client),
                                          '--socket',str(socket),'--image','alpine:3.23','--preserve-image',received['benchmark_image'],
                                          '--mode','network-api','--network-connect-status',str(code),'--output',str(api_results/f'{side}-network-api.json')]
    write(api_results/'argv.json',commands)
    stages = ('testcontainers','stock-network-api','native-network-api','pinned-api')
    outcomes = {}
    for name in stages:
        with (api_results/(name+'.log')).open('xb') as log:
            run = subprocess.run(commands[name],stdout=log,stderr=subprocess.STDOUT,check=False)
        outcomes[name] = run.returncode
        write(api_results/'stages.json',outcomes)
        print(name,run.returncode,flush=True)
    profile=read(final/'summary.json')
    assert profile['job_sha256']==JOB and profile['full_scope_cleanup_verified']
    raw=api_results/'docker-api-v1.47.json.gz'; audit=json.loads(gzip.decompress(raw.read_bytes()))
    summary=read(api_results/'summary.json')
    control=read(coverage/'control-operation-coverage.json')
    assert control['count_operations_exercised']==46 and control['strict']=={'matched':16,'different':11}
    assert len(audit['operations'])==control['operation_denominator']==107 and len(audit['candidate'])==27
    assert summary['job_sha256']==JOB and summary['exits']['cleanup']==0
    original=set(control['union_operations_exercised'])
    old_current={name for name,row in audit['operations'].items() if row.get('cases')}
    assert old_current==set(control['pinned_operations']) and len(old_current)==39
    addition={}
    pattern={'NetworkConnect':('network_connect',r'/v1\.47/networks/[0-9a-f]{64}/connect',{'stock':200,'native':501}),
             'ContainerStop':('container_stop',r'/v1\.47/containers/[0-9a-f]{64}/stop\?t=1',{'stock':204,'native':204})}
    for op,(field,valid,statuses) in pattern.items():
        assert op not in original and audit['operations'][op]['method']=='POST'
        addition[op]={}
        for side,status in statuses.items():
            trace_path=api_results/f'{side}-network-api.json'; trace=read(trace_path)
            route=trace[field]; assert trace['passed'] and verified_cleanup(trace) and route['status']==status and route['method']=='POST' and re.fullmatch(valid,route['path'])
            addition[op][side]={'wire':route,'receipt_sha256':sha(trace_path)}
    union=original | set(addition)
    assert len(union)==48 and union <= audit['operations'].keys()
    proof={'job_sha256':JOB,'stock_testcontainers_client_sha256':CLIENT,'ready_sha256':sha(ready_path),
           'prior_matched_groups':control['strict'],'current_matched_groups':summary['strict'],'strict_groups_total':27,
           'current_pinned_groups_changed':summary['changed_groups'],'pinned_operations_mapped':sorted(old_current),
           'prior_exercised_count':len(original),'operation_total':len(audit['operations']),'cumulative_exercised_count':len(union),
           'cumulative_exercised_operations':sorted(union),'new_wire_operations':addition,
           'raw_api_sha256':sha(raw),'pinned_cleanup_sha256':sha(api_results/'cleanup.json'),
           'testcontainers_summary_sha256':sha(final/'summary.json'),'script_stage_results':outcomes}
    write(api_results/'coverage.json',proof)
    print('Strict',summary['strict'],'pinned',len(old_current),'cumulative',len(union),flush=True)
    return int(any(outcomes.values()))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--ready',type=Path,required=True)
    p.add_argument('--reference',type=Path,required=True)
    args=p.parse_args()
    return complete(args.ready,args.reference)


if __name__=='__main__':
    raise SystemExit(main())
