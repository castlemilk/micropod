#!/usr/bin/env python3
"""Replay stock Go Testcontainers against the exact final native candidate and OrbStack."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

JOB = 'd5a08b48f07feb9a71d68837b7ebe3c17f08d4cf4567af13c0e47dd15f07a77a'
CLIENT = 'a0747d1ad92d7b13fbf5c8883d8b42e73457083aebc4455a615cdda0f267000e'
STOCK_RYUK = 'sha256:31b31269d06603366cbfd0284708dcd2e281e8a4188e53fce3d3304439d0df3d'
NATIVE_RYUK = 'sha256:f04fd744b5d50f8c88d9d4938c54e05a9adb56d520542f899a7d6873fa7280f2'
MODES = ('core', 'name-filters', 'single-network', 'multi-network', 'ryuk-resources')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def write(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True)+'\n')


def verified_cleanup(result):
    return (result['baselines_before'] == result['baselines_after'] and not any(result['remaining'].values())
            and not result['remaining_reapers'] and 'cleanup_error' not in result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ready', type=Path, required=True)
    parser.add_argument('--reference', type=Path, required=True)
    opt = parser.parse_args()
    received = read(opt.ready)
    assert received['owned_artifacts']['job']['sha256'] == JOB
    sockets = {'stock': opt.reference, 'native': Path(received['socket'])}
    assert all(path.is_socket() for path in sockets.values()) and not sockets['native'].samefile(sockets['stock'])
    directory = Path(__file__).resolve().parent
    client = directory.parents[1]/'home/testcontainers-client-nc/testcontainers-fixture'
    assert sha(client)==CLIENT
    original = directory/'fixture-v2/qualify_testcontainers_go.py'
    extended = directory/'fixture-v3/qualify_testcontainers_go.py'
    results = directory/'final-d5a08b'
    results.mkdir(mode=0o700)
    summary = {'job_sha256': JOB, 'ready_sha256': sha(opt.ready), 'go_client_sha256': CLIENT, 'sockets': {k: str(v) for k,v in sockets.items()},
               'profiles': {}, 'run_reports_sha256': {}, 'commands': {}}
    fixture_image = received['benchmark_image']
    for mode in MODES:
        for side, sock in sockets.items():
            supplemental = mode == 'ryuk-resources'
            py = extended if supplemental else original
            route = 'ryuk-abandon' if supplemental else mode
            output = results/f'{side}-{mode}.json'
            ryu = STOCK_RYUK if side == 'stock' else NATIVE_RYUK
            argv = [sys.executable, '-B', str(py), '--socket', str(sock), '--client', str(client), '--image', 'alpine:3.23',
                    '--preserve-image', fixture_image, '--mode', route, '--api-version', '1.47', '--output', str(output), '--ryuk-image-id', ryu]
            if supplemental:
                argv += ['--abandon-resources']
            step = f'{side}-{mode}'
            summary['commands'][step] = argv
            with (results/f'{step}.log').open('xb') as log:
                status = subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT, check=False).returncode
            summary['run_reports_sha256'][step] = sha(output)
            observation = read(output)
            summary['profiles'][step] = {'exit': status, 'fixture_passed': observation['passed'], 'scope_clean': verified_cleanup(observation)}
            if observation.get('error'):
                summary['profiles'][step]['error'] = observation['error']
            write(results/'summary.json', summary)
            print(step, summary['profiles'][step], flush=True)
    expected = {step: {'exit': int(step == 'native-multi-network'), 'fixture_passed': step != 'native-multi-network', 'scope_clean': True}
                for step in summary['profiles']}
    assert all({key:value for key,value in actual.items() if key!='error'}==expected[step] for step,actual in summary['profiles'].items())
    assert 'network connect:' in summary['profiles']['native-multi-network']['error']
    assert 'unsupported network operation' in summary['profiles']['native-multi-network']['error']
    for side in sockets:
        core = read(results/f'{side}-core.json')
        reused, = (event for event in core['events'] if event['event'] == 'reused-stopped')
        same, = (event for event in core['events'] if event['event'] == 'reused-running')
        assert same['id'] == reused['id'] and reused['marker'] == core['scope']
        selectors = read(results/f'{side}-name-filters.json')['selectors']
        assert len(selectors) == 9 and all(value['passed'] for value in selectors.values())
        stock_ryuk = read(results/f'{side}-ryuk-resources.json')
        assert stock_ryuk['automatic_cleanup'] == {'fixture_status':404,'ryuk_status':404,'used_manual_cleanup':False,
                                                   'named_resources':{'active':{'network':404,'volume':404},'control':{'network':200,'volume':200}}}
    summary['full_scope_cleanup_verified'] = True
    write(results/'summary.json', summary)
    return 0


if __name__=='__main__':
    raise SystemExit(main())
