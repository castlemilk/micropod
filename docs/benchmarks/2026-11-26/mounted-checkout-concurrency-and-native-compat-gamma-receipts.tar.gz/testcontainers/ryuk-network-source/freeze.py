#!/usr/bin/env python3
"""Freeze and replay the exact native Testcontainers resolver delta."""
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile
from tempfile import TemporaryDirectory

BASE = 'e7b6d60a49fe8e8c1b9895cd9e63313f175adc220ef8efb9d22e1174e0fd72f7'
FILES = ('docker_networks_linux.go', 'docker_reaper_linux.go', 'docker_reaper_linux_test.go')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(payload):
    result = {}
    with tarfile.open(fileobj=io.BytesIO(payload)) as tar:
        for entry in tar:
            assert entry.isfile() and PurePosixPath(entry.name).parts[:-1] == ('guest', 'runner')
            assert entry.name not in result
            result[entry.name] = tar.extractfile(entry).read()
    return result


def expand(to, files):
    (to / 'guest' / 'runner').mkdir(parents=True)
    for name, data in files.items():
        (to / name).write_bytes(data)


def main():
    worktree, prior, stage, receipts = map(Path, sys.argv[1:])
    provenance = json.loads((prior/'source.json').read_bytes())
    assert (prior/'build.sha256').read_text().splitlines()[0].split()[0] == BASE
    payload = (prior/'source.tar.gz').read_bytes()
    assert provenance['source_archive_sha256'] == sha(payload)
    baseline = read(payload)
    assert {path: sha(data) for path, data in baseline.items()} == provenance['source_files']
    names = tuple('guest/runner/' + f for f in FILES)
    delta = {name: (worktree / name).read_bytes() for name in names}
    assert all(data != baseline.get(name) for name, data in delta.items())
    current = baseline | delta
    with TemporaryDirectory(dir=stage, prefix='source-replay-') as temp:
        scratch = Path(temp)
        expand(scratch/'previous', baseline)
        expand(scratch/'current', current)
        diff = subprocess.run(['git','diff','--no-index','--binary','previous/guest','current/guest'],
                              cwd=scratch, capture_output=True, check=False)
        assert diff.returncode == 1, diff.stderr
        patch = diff.stdout.replace(b'a/previous/guest/',b'a/guest/').replace(b'a/current/guest/',b'a/guest/').replace(b'b/current/guest/',b'b/guest/')
        (receipts/'source.patch').write_bytes(patch)
    expand(stage/'source', baseline)
    args = ['git','apply','--whitespace=error-all']
    subprocess.run(args + ['--check'], cwd=stage/'source', input=patch, check=True)
    subprocess.run(args, cwd=stage/'source', input=patch, check=True)
    assert all((stage/'source'/name).read_bytes()==data for name,data in current.items())
    archive = receipts/'source.tar.gz'
    with tarfile.open(archive,'w:gz') as tar:
        for path,data in sorted(current.items()):
            member=tarfile.TarInfo(path); member.size=len(data); tar.addfile(member, io.BytesIO(data))
    assert read(archive.read_bytes())==current
    proof={'base_runner_sha256':BASE,'base_source_archive_sha256':sha(payload),'source_archive_sha256':sha(archive.read_bytes()),
           'patch_sha256':sha(patch),'changed':{name:sha(data) for name,data in delta.items()},
           'source_files':{name:sha(data) for name,data in sorted(current.items())},'patch_replay_verified':True}
    (receipts/'source.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n')
    print(len(current),len(delta),proof['source_archive_sha256'],proof['patch_sha256'])


if __name__=='__main__':
    main()
