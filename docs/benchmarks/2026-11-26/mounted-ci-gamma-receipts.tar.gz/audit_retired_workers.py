"""Verify that every managed worker drive has been audited and removed."""
import json
from pathlib import Path
import plistlib
import subprocess

receipts = Path(__file__).resolve().parent
stage = receipts.parent
attachments = plistlib.loads(subprocess.check_output(['/usr/bin/hdiutil', 'info', '-plist'], timeout=45))['images']
attached = {str(Path(item['image-path']).resolve()) for item in attachments if item.get('image-path')}
workers = {}
for f in sorted(receipts.glob('*-worker.json')):
    data = json.loads(f.read_bytes())
    if 'worker_directory' not in data:
        continue
    drive = data['drive']
    persisted = drive['detached']['persisted_policy']
    image = drive['created']['image']
    assert not any(persisted['fsevents'][field] for field in ('journal_files', 'journal_bytes'))
    assert persisted['spotlight']['disabled'] and set(persisted['markers']) == {'metadata_never_index', 'no_log'}
    assert persisted['markers_unchanged'] and persisted['journal_unchanged'] and persisted['raw_disk_unchanged']
    assert drive['shutdown']['process_group_absent'] and drive['shutdown']['disk_holders'] == []
    assert drive['detached']['image_absent'] and drive['detached']['mount_restored']
    assert not Path(image).exists() and image not in attached
    assert not Path(data['socket']).exists() and not Path(data['worker_directory']).exists()
    workers[data['arm']] = {'volume_uuid': persisted['volume']['uuid'], 'image': image,
                            'live_and_readonly_policy_equivalent': True,
                            'observed_journal_files': persisted['fsevents']['journal_files'],
                            'observed_journal_bytes': persisted['fsevents']['journal_bytes'],
                            'spotlight_disabled': True, 'image_absent': True,
                            'shutdown_exit': drive['shutdown']['process_exit_code']}
assert workers and str(stage / 'hub.sparseimage') in attached
print(json.dumps(dict(workers=workers, count=len(workers), protected_hub_still_attached=True), indent=2))
