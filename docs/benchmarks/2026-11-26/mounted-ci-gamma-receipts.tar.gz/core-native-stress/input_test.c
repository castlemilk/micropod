#include "exec_sink.h"

#include <CommonCrypto/CommonDigest.h>
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static void read_exactly(int fd, void *buffer, size_t count) {
    unsigned char *bytes = buffer;
    while (count) {
        ssize_t read_count = read(fd, bytes, count);
        assert(read_count > 0);
        bytes += read_count;
        count -= (size_t)read_count;
    }
}

static void binary_and_eof(void) {
    int socketfd[2];
    assert(socketpair(AF_UNIX, SOCK_STREAM, 0, socketfd) == 0);
    char path[] = "input-pump-file.XXXXXX";
    int fd = mkstemp(path);
    assert(fd >= 0 && unlink(path) == 0);
    unsigned char expected[90000], actual[sizeof(expected)], one;
    for (size_t i = 0; i < sizeof(expected); i++) expected[i] = (unsigned char)(i * 7);
    assert(write(fd, expected, sizeof(expected)) == sizeof(expected));
    assert(lseek(fd, 0, SEEK_SET) == 0);
    int flags = fcntl(fd, F_GETFL);
    int socket_flags = fcntl(socketfd[0], F_GETFL);
    micropod_exec_input *input = NULL;
    assert(micropod_exec_input_start(fd, socketfd[0], &input) == 0);
    read_exactly(socketfd[1], actual, sizeof(actual));
    assert(memcmp(expected, actual, sizeof(expected)) == 0);
    assert(read(socketfd[1], &one, 1) == 0);
    assert(write(socketfd[1], "x", 1) == 1 && read(socketfd[0], &one, 1) == 1 && one == 'x');
    assert(micropod_exec_input_stop(input) == 0);
    assert(fcntl(fd, F_GETFL) == flags && fcntl(socketfd[0], F_GETFL) == socket_flags);
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    assert(CC_SHA256(actual, sizeof(actual), digest));
    printf("binary input %zu sha256 ", sizeof(actual));
    for (size_t i = 0; i < sizeof(digest); i++) printf("%02x", digest[i]);
    printf("\ninput flags %#x and socket flags %#x preserved\n", flags, socket_flags);

    close(fd);
    close(socketfd[0]);
    close(socketfd[1]);
}

static void competing_pipe_readers(void) {
    int pipefd[2], socketfd[2][2];
    assert(pipe(pipefd) == 0);
    int flags = fcntl(pipefd[0], F_GETFL);
    micropod_exec_input *pump[2] = {0};
    struct pollfd available[2];
    for (int reader = 0; reader < 2; reader++) {
        assert(socketpair(AF_UNIX, SOCK_STREAM, 0, socketfd[reader]) == 0);
        available[reader] = (struct pollfd) { .fd = socketfd[reader][1], .events = POLLIN };
        assert(micropod_exec_input_start(pipefd[0], socketfd[reader][0], &pump[reader]) == 0);
    }
    assert(write(pipefd[1], "a", 1) == 1);
    assert(poll(available, 2, 1000) == 1);
    int winner = available[0].revents ? 0 : 1;
    unsigned char one;
    assert(read(socketfd[winner][1], &one, 1) == 1 && one == 'a');
    assert(micropod_exec_input_stop(pump[1 - winner]) == 0);
    assert(micropod_exec_input_stop(pump[winner]) == 0);
    assert(fcntl(pipefd[0], F_GETFL) == flags);

    for (int reader = 0; reader < 2; reader++) {
        close(socketfd[reader][0]);
        close(socketfd[reader][1]);
    }
    close(pipefd[0]);
    close(pipefd[1]);
}

static size_t full_socket(int fd) {
    int flags = fcntl(fd, F_GETFL);
    assert(fcntl(fd, F_SETFL, flags | O_NONBLOCK) == 0);
    unsigned char bytes[8192] = {0};
    size_t total = 0;
    ssize_t count;
    while ((count = write(fd, bytes, sizeof(bytes))) > 0) total += (size_t)count;
    assert(count < 0 && (errno == EAGAIN || errno == EWOULDBLOCK));
    assert(fcntl(fd, F_SETFL, flags) == 0);
    return total;
}

static void cancellation_boundaries(void) {
    int pipefd[2], socketfd[2];
    assert(pipe(pipefd) == 0 && socketpair(AF_UNIX, SOCK_STREAM, 0, socketfd) == 0);
    int flags = fcntl(pipefd[0], F_GETFL) | O_NONBLOCK;
    assert(fcntl(pipefd[0], F_SETFL, flags) == 0);
    for (int i = 0; i < 150; i++) {
        micropod_exec_input *input = NULL;
        assert(micropod_exec_input_start(pipefd[0], socketfd[0], &input) == 0);
        if (i % 30 == 0) usleep(1000);
        assert(micropod_exec_input_stop(input) == 0);
        assert(fcntl(pipefd[0], F_GETFL) == flags);
    }
    size_t fill = full_socket(socketfd[0]);
    assert(fill > 0);
    assert(write(pipefd[1], "blocked", 7) == 7);
    micropod_exec_input *input = NULL;
    assert(micropod_exec_input_start(pipefd[0], socketfd[0], &input) == 0);
    usleep(20000);
    assert(micropod_exec_input_stop(input) == 0);
    unsigned char drain[8192];
    while (fill) {
        size_t size = fill < sizeof(drain) ? fill : sizeof(drain);
        read_exactly(socketfd[1], drain, size);
        fill -= size;
    }
    assert(write(socketfd[0], "z", 1) == 1);
    assert(read(socketfd[1], drain, 1) == 1 && drain[0] == 'z');

    close(pipefd[0]);
    close(pipefd[1]);
    close(socketfd[0]);
    close(socketfd[1]);
}

static void invalid_sources(void) {
    int pipefd[2], socketfd[2];
    unsigned char one;
    assert(pipe(pipefd) == 0 && socketpair(AF_UNIX, SOCK_STREAM, 0, socketfd) == 0);
    micropod_exec_input *input = NULL;
    assert(micropod_exec_input_start(-2, socketfd[0], &input) == EBADF && !input);
    assert(micropod_exec_input_start(pipefd[1], socketfd[0], &input) == 0);
    assert(read(socketfd[1], &one, 1) == 0);
    assert(micropod_exec_input_stop(input) == EBADF);
    close(socketfd[0]);
    close(socketfd[1]);

    assert(socketpair(AF_UNIX, SOCK_STREAM, 0, socketfd) == 0);
    assert(micropod_exec_input_start(-1, socketfd[0], &input) == 0);
    assert(read(socketfd[1], &one, 1) == 0);
    assert(micropod_exec_input_stop(input) == 0);
    close(socketfd[0]);
    close(socketfd[1]);
    close(pipefd[0]);
    close(pipefd[1]);
}

int main(void) {
    binary_and_eof();
    competing_pipe_readers();
    cancellation_boundaries();
    invalid_sources();
    puts("input checks passed including two competing readers and 150 cancel races");
}
