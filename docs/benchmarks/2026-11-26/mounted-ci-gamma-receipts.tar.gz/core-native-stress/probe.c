#include <assert.h>
#include <dispatch/dispatch.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

static const char byte = 'x';

static void fill(int fd) {
    char bytes[4096];
    memset(bytes, 'a', sizeof(bytes));
    int flags = fcntl(fd, F_GETFL);
    assert(flags >= 0 && (flags & O_NONBLOCK) == 0);
    assert(fcntl(fd, F_SETFL, flags | O_NONBLOCK) == 0);
    ssize_t result;
    while ((result = write(fd, bytes, sizeof(bytes))) > 0) {}
    assert(result == -1 && (errno == EAGAIN || errno == EWOULDBLOCK));
    while ((result = write(fd, &byte, 1)) > 0) {}
    assert(result == -1 && (errno == EAGAIN || errno == EWOULDBLOCK));
    assert(fcntl(fd, F_SETFL, flags) == 0);
}

struct NativeProbe {
    int fd;
    bool do_read;
    dispatch_semaphore_t entered;
    dispatch_semaphore_t finished;
    int error;
    ssize_t count;
};

static void native_exit(void *input) {
    struct NativeProbe *probe = input;
    dispatch_semaphore_signal(probe->finished);
}

static void *native_operation(void *input) {
    struct NativeProbe *probe = input;
    sigset_t blocked;
    sigemptyset(&blocked);
    sigaddset(&blocked, SIGPIPE);
    assert(pthread_sigmask(SIG_BLOCK, &blocked, NULL) == 0);
    pthread_cleanup_push(native_exit, probe);
    dispatch_semaphore_signal(probe->entered);
    char data = byte;
    probe->count = probe->do_read ? read(probe->fd, &data, 1) : write(probe->fd, &data, 1);
    probe->error = probe->count < 0 ? errno : 0;
    pthread_cleanup_pop(1);
    return NULL;
}

static void cancellation_check(const char *name, int fd, bool read_mode) {
    int before = fcntl(fd, F_GETFL);
    int alias = fcntl(fd, F_DUPFD_CLOEXEC, 0);
    assert(alias >= 0);
    struct NativeProbe probe = {
        .fd = alias,
        .do_read = read_mode,
        .entered = dispatch_semaphore_create(0),
        .finished = dispatch_semaphore_create(0),
    };
    pthread_t thread;
    assert(pthread_create(&thread, NULL, native_operation, &probe) == 0);
    assert(dispatch_semaphore_wait(probe.entered, dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC)) == 0);
    assert(dispatch_semaphore_wait(probe.finished, dispatch_time(DISPATCH_TIME_NOW, 30 * NSEC_PER_MSEC)) != 0);
    int during = fcntl(fd, F_GETFL);
    struct timeval start, end;
    gettimeofday(&start, NULL);
    assert(pthread_cancel(thread) == 0);
    assert(dispatch_semaphore_wait(probe.finished, dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC)) == 0);
    void *status = NULL;
    assert(pthread_join(thread, &status) == 0 && status == PTHREAD_CANCELED);
    gettimeofday(&end, NULL);
    int after = fcntl(fd, F_GETFL);
    assert(before == during && before == after);
    double ms = (end.tv_sec - start.tv_sec) * 1000.0 + (end.tv_usec - start.tv_usec) / 1000.0;
    printf("%s pthread_cancel+join %.3f ms, flags %#x -> %#x -> %#x\n", name, ms, before, during, after);
    dispatch_release(probe.entered);
    dispatch_release(probe.finished);
    close(alias);
}

static void dispatch_check(int fd) {
    int before = fcntl(fd, F_GETFL);
    int alias = fcntl(fd, F_DUPFD_CLOEXEC, 0);
    assert(alias >= 0);
    dispatch_queue_t queue = dispatch_queue_create("micropod.exec.dispatch", DISPATCH_QUEUE_SERIAL);
    dispatch_semaphore_t cleaned = dispatch_semaphore_create(0);
    dispatch_semaphore_t finished = dispatch_semaphore_create(0);
    __block int result = 0;
    dispatch_io_t channel = dispatch_io_create(DISPATCH_IO_STREAM, alias, queue, ^(int error) {
        assert(error == 0);
        close(alias);
        dispatch_semaphore_signal(cleaned);
    });
    assert(channel != NULL);
    dispatch_data_t data = dispatch_data_create(&byte, 1, queue, DISPATCH_DATA_DESTRUCTOR_DEFAULT);
    dispatch_io_write(channel, 0, data, queue, ^(bool done, dispatch_data_t pending, int error) {
        (void)pending;
        if (done) {
            result = error;
            dispatch_semaphore_signal(finished);
        }
    });
    bool changed = false;
    int during = before;
    for (int i = 0; i < 50; i++) {
        int flags = fcntl(fd, F_GETFL);
        if (flags != before) {
            changed = true;
            during = flags;
        }
        usleep(1000);
    }
    dispatch_io_close(channel, DISPATCH_IO_STOP);
    assert(dispatch_semaphore_wait(finished, dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC)) == 0);
    assert(dispatch_semaphore_wait(cleaned, dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC)) == 0);
    int after = fcntl(fd, F_GETFL);
    printf("DispatchIO result %d, borrowed flags %#x -> %#x -> %#x, changed=%d\n",
           result, before, during, after, changed);
    dispatch_release(channel);
    dispatch_release(data);
    dispatch_release(finished);
    dispatch_release(cleaned);
    dispatch_release(queue);
}

static void reopen_check(int fd) {
    char path[32];
    snprintf(path, sizeof(path), "/dev/fd/%d", fd);
    int original = fcntl(fd, F_GETFL);
    int reopened = open(path, O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (reopened < 0) {
        printf("open(%s, O_NONBLOCK): %s\n", path, strerror(errno));
        return;
    }
    int flags = fcntl(reopened, F_GETFL);
    long observed = fcntl(fd, F_GETFL);
    assert(fcntl(reopened, F_SETFL, flags | O_NONBLOCK) == 0);
    int changed = fcntl(fd, F_GETFL);
    printf("reopen flags %#x, borrowed before %#x after open %#lx after F_SETFL %#x\n",
           flags, original, observed, changed);
    assert(fcntl(fd, F_SETFL, original) == 0);
    close(reopened);
}

static void sigpipe_check(void) {
    int pipefd[2];
    assert(pipe(pipefd) == 0);
    close(pipefd[0]);
    struct NativeProbe probe = {
        .fd = pipefd[1],
        .entered = dispatch_semaphore_create(0),
        .finished = dispatch_semaphore_create(0),
    };
    pthread_t thread;
    assert(pthread_create(&thread, NULL, native_operation, &probe) == 0);
    assert(pthread_join(thread, NULL) == 0);
    assert(probe.count < 0 && probe.error == EPIPE);
    puts("native writer got EPIPE with thread-local SIGPIPE mask");
    dispatch_release(probe.entered);
    dispatch_release(probe.finished);
    close(pipefd[1]);
}

int main(int argc, char **argv) {
    (void)argv;
    setvbuf(stdout, NULL, _IONBF, 0);
    if (argc > 1) {
        sigpipe_check();
        return 0;
    }
    int output[2], sock[2], input[2];
    assert(pipe(output) == 0);
    assert(socketpair(AF_UNIX, SOCK_STREAM, 0, sock) == 0);
    assert(pipe(input) == 0);
    fill(output[1]);
    fill(sock[0]);
    cancellation_check("full pipe writer", output[1], false);
    cancellation_check("full socket writer", sock[0], false);
    cancellation_check("empty pipe reader", input[0], true);
    reopen_check(output[1]);
    dispatch_check(output[1]);
    close(output[0]);
    close(output[1]);
    close(sock[0]);
    close(sock[1]);
    close(input[0]);
    close(input[1]);
}
