#!/bin/sh
set -eu

source_dir=$(cd "$(dirname "$0")" && pwd)
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
cd "$work"
for name in probe sink_test input_test; do
    if [ "$name" = probe ]; then
        clang -std=c17 -Wall -Wextra -Wpedantic -Werror -fblocks -pthread \
            "$source_dir/probe.c" -o "$name"
    else
        clang -std=c17 -Wall -Wextra -Wpedantic -Werror -pthread -I "$source_dir/subject" \
            "$source_dir/$name.c" "$source_dir/subject/exec_sink.c" -o "$name"
    fi
done
uname -smr
clang --version | sed -n '1p'
(cd "$source_dir" && shasum -a 256 subject/* probe.c sink_test.c input_test.c)
python3 - <<'PY'
import signal
import subprocess

subprocess.run(["./probe"], check=True, timeout=6)
sigpipe_probe = subprocess.run(["./probe", "sigpipe"], timeout=6)
assert sigpipe_probe.returncode == -signal.SIGPIPE
print("Darwin thread-local SIGPIPE mask leaves process-directed pipe SIGPIPE", flush=True)
for binary in ("sink_test", "input_test"):
    subprocess.run(["./" + binary], check=True, timeout=6)
PY
