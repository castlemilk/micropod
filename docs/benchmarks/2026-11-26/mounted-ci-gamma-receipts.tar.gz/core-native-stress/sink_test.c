#include "exec_sink.h"

#include <CommonCrypto/CommonDigest.h>
#include <assert.h>
#include <dispatch/dispatch.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pthread.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static const unsigned char binary[] = { 0, 0xfe, 0x88, 2, 3 };

static void record_hash(const char *label, const void *bytes, size_t count) {
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    assert(CC_SHA256(bytes, (CC_LONG)count, digest));
    printf("%s %zu sha256 ", label, count);
    for (size_t i = 0; i < sizeof(digest); i++) printf("%02x", digest[i]);
    putchar('\n');
}

static void fill(int fd) {
    unsigned char block[4096] = {0};
    int flags = fcntl(fd, F_GETFL);
    assert(fcntl(fd, F_SETFL, flags | O_NONBLOCK) == 0);
    ssize_t n;
    while ((n = write(fd, block, sizeof(block))) > 0) {}
    assert(n == -1 && (errno == EAGAIN || errno == EWOULDBLOCK));
    while ((n = write(fd, block, 1)) > 0) {}
    assert(n == -1 && (errno == EAGAIN || errno == EWOULDBLOCK));
    assert(fcntl(fd, F_SETFL, flags) == 0);
}

static void read_exactly(int fd, void *ptr, size_t count) {
    unsigned char *bytes = ptr;
    while (count) {
        ssize_t n = read(fd, bytes, count);
        assert(n > 0);
        bytes += n;
        count -= (size_t)n;
    }
}

struct Request {
    micropod_exec_sink *sink;
    const void *bytes;
    size_t count;
    dispatch_semaphore_t entering;
    dispatch_semaphore_t done;
    int result;
};

static const char *context;

static void *submit(void *data) {
    struct Request *request = data;
    dispatch_semaphore_signal(request->entering);
    request->result = micropod_exec_sink_write(request->sink, 1, request->bytes, request->count);
    dispatch_semaphore_signal(request->done);
    return NULL;
}

static struct Request request_for(micropod_exec_sink *sink) {
    return (struct Request) {
        .sink = sink, .bytes = binary, .count = sizeof(binary),
        .entering = dispatch_semaphore_create(0), .done = dispatch_semaphore_create(0),
    };
}

static void finish_request(struct Request *request, pthread_t thread, int expected_error) {
    if (dispatch_semaphore_wait(request->done, dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC)) != 0) {
        fprintf(stderr, "timeout in %s (process %d)\n", context, getpid());
        if (getenv("PAUSE_FOR_SAMPLE")) sleep(8);
        abort();
    }
    assert(pthread_join(thread, NULL) == 0);
    assert(request->result == expected_error);
    dispatch_release(request->entering);
    dispatch_release(request->done);
}

static void test_discard(void) {
    micropod_exec_sink *sink = NULL;
    assert(micropod_exec_sink_create(-2, -1, &sink) == EBADF && !sink);
    assert(micropod_exec_sink_create(-1, -1, &sink) == 0);
    assert(micropod_exec_sink_write(sink, 1, binary, sizeof(binary)) == 0);
    assert(micropod_exec_sink_write(sink, 2, binary, sizeof(binary)) == 0);
    assert(micropod_exec_sink_write(sink, 0, binary, sizeof(binary)) == EINVAL);
    assert(micropod_exec_sink_write(sink, 1, NULL, sizeof(binary)) == EINVAL);
    micropod_exec_sink_cancel(sink);
    assert(micropod_exec_sink_write(sink, 2, binary, sizeof(binary)) == ECANCELED);
    micropod_exec_sink_destroy(sink);
}

static void test_reuse_and_order(void) {
    int fd[2], foreign[2];
    assert(pipe(fd) == 0 && pipe(foreign) == 0);
    micropod_exec_sink *sink = NULL;
    assert(micropod_exec_sink_create(fd[1], fd[1], &sink) == 0);
    assert(close(fd[1]) == 0 && dup2(foreign[1], fd[1]) == fd[1]);
    assert(micropod_exec_sink_write(sink, 2, binary, sizeof(binary)) == 0);
    assert(micropod_exec_sink_write(sink, 1, "extra", 5) == 0);
    micropod_exec_sink_destroy(sink);
    unsigned char actual[10];
    read_exactly(fd[0], actual, sizeof(actual));
    assert(!memcmp(actual, binary, sizeof(binary)));
    assert(!memcmp(actual + sizeof(binary), "extra", 5));
    close(fd[1]);
    close(foreign[1]);
    unsigned char unrelated;
    assert(read(foreign[0], &unrelated, 1) == 0);
    close(fd[0]);
    close(foreign[0]);
}

static void test_cancellation(int output, bool check_busy) {
    micropod_exec_sink *sink = NULL;
    int flags = fcntl(output, F_GETFL);
    int no_sigpipe = fcntl(output, F_GETNOSIGPIPE);
    assert(micropod_exec_sink_create(output, -1, &sink) == 0);

    pthread_t blocked;
    struct Request request = request_for(sink);
    assert(pthread_create(&blocked, NULL, submit, &request) == 0);
    assert(dispatch_semaphore_wait(request.entering, dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC)) == 0);
    assert(dispatch_semaphore_wait(request.done, dispatch_time(DISPATCH_TIME_NOW, 20 * NSEC_PER_MSEC)) != 0);
    assert(fcntl(output, F_GETFL) == flags);
    assert(fcntl(output, F_GETNOSIGPIPE) == no_sigpipe);
    if (check_busy) assert(micropod_exec_sink_write(sink, 1, binary, sizeof(binary)) == EBUSY);
    micropod_exec_sink_cancel(sink);
    micropod_exec_sink_cancel(sink);
    finish_request(&request, blocked, ECANCELED);
    micropod_exec_sink_destroy(sink);
    assert(fcntl(output, F_GETFL) == flags && fcntl(output, F_GETNOSIGPIPE) == no_sigpipe);
    printf("%s F_GETFL %#x and F_GETNOSIGPIPE %d preserved\n", context, flags, no_sigpipe);
}

static void test_full_descriptors(void) {
    int pipefd[2], socketfd[2];
    assert(pipe(pipefd) == 0 && socketpair(AF_UNIX, SOCK_STREAM, 0, socketfd) == 0);
    fill(pipefd[1]);
    fill(socketfd[0]);
    context = "blocking pipe";
    test_cancellation(pipefd[1], true);
    context = "blocking socket";
    test_cancellation(socketfd[0], false);
    int flags = fcntl(pipefd[1], F_GETFL);
    assert(fcntl(pipefd[1], F_SETFL, flags | O_NONBLOCK) == 0);
    context = "nonblocking pipe";
    test_cancellation(pipefd[1], false);

    context = "early cancel loop";
    for (int i = 0; i < 250; i++) {
        micropod_exec_sink *sink = NULL;
        assert(micropod_exec_sink_create(pipefd[1], -1, &sink) == 0);
        pthread_t blocked;
        struct Request request = request_for(sink);
        assert(pthread_create(&blocked, NULL, submit, &request) == 0);
        if (i & 1) {
            assert(dispatch_semaphore_wait(request.entering, dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC)) == 0);
        }
        micropod_exec_sink_cancel(sink);
        finish_request(&request, blocked, ECANCELED);
        micropod_exec_sink_destroy(sink);
    }
    close(pipefd[0]);
    close(pipefd[1]);
    close(socketfd[0]);
    close(socketfd[1]);
}

static void test_errors(void) {
    int fds[2];
    micropod_exec_sink *sink = NULL;
    assert(socketpair(AF_UNIX, SOCK_STREAM, 0, fds) == 0);
    assert(close(fds[0]) == 0);
    assert(micropod_exec_sink_create(fds[1], -1, &sink) == 0);
    assert(micropod_exec_sink_write(sink, 1, binary, sizeof(binary)) == EPIPE);
    assert(fcntl(fds[1], F_GETNOSIGPIPE) == 0);
    micropod_exec_sink_destroy(sink);
    close(fds[1]);

    void (*original)(int) = signal(SIGPIPE, SIG_IGN);
    assert(original != SIG_ERR);
    assert(pipe(fds) == 0);
    assert(close(fds[0]) == 0);
    assert(micropod_exec_sink_create(fds[1], -1, &sink) == 0);
    assert(micropod_exec_sink_write(sink, 1, binary, sizeof(binary)) == EPIPE);
    micropod_exec_sink_destroy(sink);
    close(fds[1]);
    assert(signal(SIGPIPE, original) != SIG_ERR);

    int readonly = open("/dev/null", O_RDONLY);
    assert(readonly >= 0);
    assert(micropod_exec_sink_create(-1, readonly, &sink) == 0);
    assert(micropod_exec_sink_write(sink, 2, binary, sizeof(binary)) == EBADF);
    micropod_exec_sink_destroy(sink);
    close(readonly);
}

static void test_large_write(void) {
    context = "large pipe/file copies";
    int fds[2];
    assert(pipe(fds) == 0);
    size_t size = 32 * 1024 * 1024;
    unsigned char *expected = malloc(size), *actual = malloc(size);
    assert(expected && actual);
    for (size_t i = 0; i < size; i++) expected[i] = (unsigned char)(i / 103 + i % 19);

    micropod_exec_sink *sink = NULL;
    assert(micropod_exec_sink_create(fds[1], -1, &sink) == 0);
    struct Request request = request_for(sink);
    request.bytes = expected;
    request.count = size;
    pthread_t thread;
    assert(pthread_create(&thread, NULL, submit, &request) == 0);
    read_exactly(fds[0], actual, size);
    finish_request(&request, thread, 0);
    assert(memcmp(expected, actual, size) == 0);
    record_hash("pipe output", actual, size);
    micropod_exec_sink_destroy(sink);
    close(fds[1]);
    close(fds[0]);

    char path[] = "sink-test-output.XXXXXX";
    int file = mkstemp(path);
    assert(file >= 0 && unlink(path) == 0);
    assert(micropod_exec_sink_create(file, -1, &sink) == 0);
    assert(micropod_exec_sink_write(sink, 1, expected, size) == 0);
    assert(lseek(file, 0, SEEK_CUR) == (off_t)size);
    assert(lseek(file, 0, SEEK_SET) == 0);
    read_exactly(file, actual, size);
    assert(memcmp(expected, actual, size) == 0);
    record_hash("regular file output", actual, size);
    micropod_exec_sink_destroy(sink);
    close(file);

    int discard = open("/dev/null", O_WRONLY);
    assert(discard >= 0);
    assert(micropod_exec_sink_create(-1, discard, &sink) == 0);
    assert(micropod_exec_sink_write(sink, 2, expected, size) == 0);
    micropod_exec_sink_destroy(sink);
    close(discard);
    printf("real /dev/null accepted a %zu-byte write and rejected a read-only handle\n", size);
    free(expected);
    free(actual);
}

int main(void) {
    test_discard();
    test_reuse_and_order();
    test_full_descriptors();
    test_errors();
    test_large_write();
    puts("sink checks passed including 250 early-cancel races");
}
