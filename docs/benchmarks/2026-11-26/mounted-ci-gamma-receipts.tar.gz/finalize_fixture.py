"""Retire only this Gamma fixture and publish its hashed evidence into the worktree."""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import plistlib
import subprocess
import sys
import tarfile

here = Path(__file__).resolve().parent
stage = here.parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('worktree', type=Path)
a = p.parse_args()
worktree = a.worktree.resolve(strict=True)
assert stage.name.startswith('mp-gamma.') and stage.parent == Path('/private/tmp')
output = worktree / 'docs/benchmarks/2026-11-26'
output.mkdir(parents=True, exist_ok=True)
archive = output / 'mounted-ci-gamma-receipts.tar.gz'
scorecard = output / 'mounted-ci-gamma.json'
assert not archive.exists() and not scorecard.exists()

import worker_apfs_drive as apfs


def read(path):
    return json.loads(path.read_bytes())


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def run(argv, timeout=60, check=True):
    return subprocess.run(argv, timeout=timeout, check=check, text=True, capture_output=True)


def gone(proc, text):
    return proc.returncode != 0 and any(term in (proc.stdout + proc.stderr).lower() for term in text)


def sha(path):
    with path.open('rb') as fp:
        return hashlib.file_digest(fp, 'sha256').hexdigest()


def write_archive(destination):
    paths = {path.relative_to(here).as_posix(): path for path in sorted(here.rglob('*')) if path.is_file()
             and '__pycache__' not in path.parts and not path.name.endswith('-stop')}
    checks = {name: sha(file) for name, file in paths.items()}
    manifest = (json.dumps(checks, sort_keys=True, indent=2) + '\n').encode()
    temporary = destination.with_suffix('.pending')
    with temporary.open('xb') as raw, gzip.GzipFile(filename='', mode='wb', mtime=0, fileobj=raw) as zip_out:
        with tarfile.open(fileobj=zip_out, mode='w|') as tar:
            for name, path in paths.items():
                info = tar.gettarinfo(path, name)
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                with path.open('rb') as data:
                    tar.addfile(info, data)
            info = tarfile.TarInfo('MANIFEST.sha256.json')
            info.mode = 0o644
            info.size = len(manifest)
            tar.addfile(info, io.BytesIO(manifest))
    with tarfile.open(temporary) as tar:
        recorded = json.load(tar.extractfile('MANIFEST.sha256.json'))
        assert recorded == checks and set(tar.getnames()) == set(checks) | {'MANIFEST.sha256.json'}
        assert all(hashlib.sha256(tar.extractfile(name).read()).hexdigest() == digest for name, digest in checks.items())
    temporary.replace(destination)
    return {'path': destination.name, 'entries': len(checks), 'bytes': destination.stat().st_size, 'sha256': sha(destination)}


for variable in ('DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH', 'DOCKER_API_VERSION'):
    os.environ.pop(variable, None)
workers = {}
images = {str(stage / 'hub.sparseimage')}
for file in sorted(here.glob('*-worker.json')):
    worker = read(file)
    if not {'drive', 'socket', 'worker_directory'} <= worker.keys():
        continue
    drive = worker['drive']
    assert drive['detached']['image_absent'] and drive['detached']['persisted_policy']['fsevents']['journal_files'] == 0, file
    assert drive['shutdown']['process_group_absent'] and not drive['shutdown']['disk_holders'], file
    assert not Path(worker['socket']).exists() and not Path(worker['worker_directory']).exists(), file
    images.add(drive['created']['image'])
    policy = drive['detached']['persisted_policy']
    assert policy['spotlight']['disabled'] and policy['fsevents']['journal_bytes'] == 0
    assert policy['markers_unchanged'] and policy['journal_unchanged'] and policy['raw_disk_unchanged']
    workers[worker['arm']] = {'image': drive['created']['image'], 'uuid': drive['created']['volume']['uuid'],
                              'retired': drive['shutdown'], 'read_only_rechecked': 'persisted_policy' in drive['detached'],
                              'drive_detached': drive['detached']['detached'], 'image_removed': drive['detached']['image_absent'],
                              'spotlight_disabled': policy['spotlight']['disabled'],
                              'fsevents_journal_files': policy['fsevents']['journal_files'],
                              'fsevents_journal_bytes': policy['fsevents']['journal_bytes']}
assert workers

# Before detaching the hub, reverify all historical source bytes and summarize the live runs.
final_provenance = json.loads(run([sys.executable, '-B', str(here / 'record_provenance.py'), str(worktree)]).stdout)
initial_provenance = read(here / 'input-provenance.json')
assert all(final_provenance[key] == initial_provenance[key] for key in ('archives', 'preserved_baseline', 'tools', 'artifacts'))
save(here / 'final-provenance.json', final_provenance)
summary = json.loads(run([sys.executable, '-B', str(here / 'summarize.py')]).stdout)
save(here / 'measurement-summary.json', summary)

# Preserve reproducibility artifacts, omitting the upstream tarball and built Image.
kernel_path = stage / 'home/kernel-build'
if kernel_path.is_dir():
    kernel_evidence = here / 'kernel-build'
    kernel_evidence.mkdir(exist_ok=True)
    for relative in ('build.log', 'build-first.log', 'toolchain.txt', 'run-container.sh', 'output/config', 'output/release',
                     'output/SHA256SUMS', 'output/build-inputs.txt', 'inputs/build-virtiofs-sync-lookup-kernel.sh',
                     'inputs/bounded-buddy.patch', 'inputs/idle-poll-bounded.patch', 'inputs/sync-colocate.patch',
                     'inputs/virtiofs-sync-lookup.patch'):
        original = kernel_path / relative
        if original.is_file():
            destination = kernel_evidence / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(original.read_bytes())

image = read(here / 'image.json')
orb = ['docker', '--host', 'unix://' + str(Path.home() / '.orbstack/run/docker.sock')]
assert image['tag'] == 'micropod-qa/checkout:gamma-' + stage.name.removeprefix('mp-gamma.').lower()
probed = run([*orb, 'image', 'inspect', '--format', '{{.Id}}', image['tag']]).stdout.strip()
assert probed in (image['config_digest'], image['manifest_digest'])
assert not run([*orb, 'ps', '-aq', '--filter', f'ancestor={image["tag"]}']).stdout.strip()
assert not run([*orb, 'ps', '-aq', '--filter', f'label={image["label"]}']).stdout.strip()
assert not run([*orb, 'ps', '-aq', '--filter', 'label=org.micropod.experiment=virtiofs-lookup-20261126']).stdout.strip()
run([*orb, 'image', 'rm', image['tag']])
image_removed = gone(run([*orb, 'image', 'inspect', image['tag']], check=False), ('no such', 'not found'))
assert image_removed

live = apfs.verify(read(here / 'hub-created.json'))
save(here / 'hub-final-live.json', live)
retired = apfs.detach(read(here / 'hub-created.json'), remove_image=True, inspect_history=True)
save(here / 'hub-detached.json', retired)
assert retired['image_absent'] and retired['mount_restored']
persisted = retired['persisted_policy']
assert persisted['spotlight']['disabled'] and persisted['markers_unchanged'] and persisted['journal_unchanged']
assert not any(persisted['fsevents'][field] for field in ('journal_files', 'journal_bytes'))
assert not any((stage / 'home').iterdir())
(stage / 'home').rmdir()

current = plistlib.loads(subprocess.check_output(['/usr/bin/hdiutil', 'info', '-plist'], timeout=60))
attached = {str(Path(item['image-path']).resolve()) for item in current['images'] if item.get('image-path')}
assert not attached & images and not any(Path(image).exists() for image in images)
cleanup = {'owned_protected_workers': workers, 'protected_hub_uuid': live['volume']['uuid'],
           'hub_read_only_rechecked': 'persisted_policy' in retired, 'hub_image_removed': retired['image_absent'],
           'hub_spotlight_disabled': persisted['spotlight']['disabled'],
           'hub_suppression_markers_unchanged': persisted['markers_unchanged'],
           'hub_fsevents_journal_files': persisted['fsevents']['journal_files'],
           'hub_fsevents_journal_bytes': persisted['fsevents']['journal_bytes'],
           'all_owned_apfs_images_absent': True, 'none_of_owned_apfs_images_attached': True,
           'orbstack_tag_removed': image_removed, 'orbstack_builder_removed': image['builder_removed'],
           'orbstack_kernel_builder_absent': True,
           'all_qualified_baseline_hashes_preserved': True}
save(here / 'final-cleanup.json', cleanup)
raw = write_archive(archive)
summary.update(host=final_provenance['host'], artifacts=final_provenance['artifacts'],
               historical_preservation={'baseline': final_provenance['preserved_baseline'], 'archives': final_provenance['archives'],
                                        'upstream_tool_files_verified': final_provenance['tools']['upstream_files_verified']},
               image=image, cleanup=cleanup, receipts=raw, date_melbourne='2026-11-26')
save(scorecard, summary)
print(scorecard, archive, raw['sha256'], flush=True)
