#!/bin/bash
# Freeze source and products into an already-protected, fresh APFS hub.
set -euo pipefail
w=$(cd "${1:?worktree path}" && pwd -P)
s=$(cd "${2:?private fixture path}" && pwd -P)
r="$s/receipts"
a="$s/home/artifacts"
e="$s/home/evidence"
root=$(cd "$w/../.." && pwd -P)
[ -f "$r/hub-created.json" ] && [ -f "$s/home/.fseventsd/no_log" ] && [ -f "$s/home/.metadata_never_index" ]
python3 -B "$r/worker_apfs_drive.py" verify "$r/hub-created.json" > "$r/hub-live.json"
mkdir "$a" "$e" "$s/home/share" "$a/current-source" "$a/managed"
for receipt in managed-ci-git-and-exec-sources managed-ci-git-and-exec-receipts; do
    tar -xzf "$w/docs/benchmarks/2026-11-25/$receipt.tar.gz" -C "$e"
done
/usr/bin/git -C "$root" archive 7a30d9aebc0eb3235e680b257f775613e6ebe0f2:vmm | tar -xf - -C "$a/current-source"
cp -p "$w/dist/vmlinux-hvf" "$a/Image"
cp -p "$w/.build/arm64-apple-macosx/debug/micropod" "$a/managed/micropod"
codesign --force --sign - --entitlements "$w/signing/micropod-cli.entitlements" "$a/managed/micropod"
codesign --verify --strict "$a/managed/micropod"
qualified=$(python3 - "$w" <<'PY'
import gzip, json, sys
from pathlib import Path
source = Path(sys.argv[1]) / 'docs/benchmarks/2026-11-21/gamma-vcpu-priority.json.gz'
with gzip.open(source, 'rt') as fp:
    print(json.load(fp)['installation']['path'])
PY
)
cp -pR "$qualified/micropod-oci-tools" "$a/micropod-oci-tools"
for script in start.sh published-ports.sh; do
    cp -p "$e/tools-final/runner/$script" "$a/micropod-oci-tools/runner/"
done
build_go() {
    directory=$1
    executable=$2
    package=$3
    (cd "$directory" && env -u GOROOT GOOS=linux GOARCH=arm64 CGO_ENABLED=0 GOWORK=off \
        go build -trimpath -ldflags='-s -w' -o "$executable" "$package")
}
build_go "$e/final-runner" "$a/micropod-oci-tools/runner/bin/job" .
build_go "$e/final-harness/scripts/workspacebench" "$a/fsprobe" main.go
(cd "$a/current-source" && bash ./build.sh) > "$r/current-vmm-build.log" 2>&1
codesign --verify --strict "$a/current-source/target/release/micropod-vmm"
cp -pR "$a/micropod-oci-tools" "$a/trace-tools"
cp -p "$e/tools-trace/runner/start.sh" "$e/tools-trace/runner/trace-observer.sh" "$a/trace-tools/runner/"
chmod +x "$a/trace-tools/runner/trace-observer.sh"
cp -p "$e/host/fixture-observability.yaml" "$r/fixture-observability.yaml"
python3 -B "$r/record_provenance.py" "$w" > "$r/input-provenance.json"
