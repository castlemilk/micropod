from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import csv
import hashlib
import io
import json
import os
import shutil
import subprocess
import time
from uuid import uuid4

receipts = Path(__file__).parent
base = receipts.parent / "home/share/baseline-trace/git-index-probe"
host_helper = Path("/Users/benebsworth/projects/micropod/ci/mounted-git-job.sh")
fixture = base / ("contract-" + uuid4().hex[:10])
fixture.mkdir()
worktree = fixture / "source"
original = b"\x00\xff\x19\r\n\x00original"
atomic = b"\xff\x00\x19\r\n\x00replaced"
inplace = b"\x00\xfe\x19\r\n\x00rewrites"
image = "micropod-qa/checkout:gamma-euque2"
sockets = {
    "hvf": "/private/tmp/mp-tune-gamma-baseline-trace-9v4gendl/home/docker.sock",
    "orb": "/Users/benebsworth/.orbstack/run/docker.sock",
}
receipt = {"fixture": str(fixture), "engine": {}, "edits": {}}


def run(*args, code=0):
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15)
    if result.returncode != code:
        raise RuntimeError((args, result.returncode, result.stdout[-1000:], result.stderr[-1000:]))
    return result.stdout


def mount(source, destination):
    out = io.StringIO()
    csv.writer(out, lineterminator="").writerow(
        ["type=bind", f"source={source}", f"target={destination}", "readonly"])
    return out.getvalue()


def git(*args, root=worktree):
    return run("git", "-C", str(root), *args).decode().strip()


def commit(root, label):
    git("add", "tracked.bin", root=root)
    git("-c", "user.name=Micropod", "-c", "user.email=ci@example.invalid",
        "-c", "commit.gpgsign=false", "commit", "-qm", label, root=root)
    return git("rev-parse", "--verify", "HEAD", root=root)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def prepare():
    run("git", "init", "-q", "--template=", "--object-format=sha1", str(worktree))
    (worktree / "tracked.bin").write_bytes(original)
    head = commit(worktree, "pinned source")
    git("bundle", "create", str(fixture / "seed.bundle"), "HEAD")
    nested = worktree / "nested"
    run("git", "init", "-q", "--template=", "--object-format=sha1", str(nested))
    (nested / "tracked.bin").write_bytes(b"NESTED ROOT")
    nested_head = commit(nested, "different nested repo")
    shutil.copyfile(host_helper, fixture / "entrypoint.sh")
    return head, nested_head


def exec_job(cli, name, *args, workdir="/workspace", code=0):
    return run(*cli, "exec", "--workdir", workdir, name, *args, code=code)


def verify(name, cli, head, nested, expected, contents):
    report = json.loads(exec_job(cli, name, "python3", "-c", """import hashlib,json,os,subprocess
def git(*args): return subprocess.check_output(['git',*args]).decode()
try:
    with open('write-through-is-a-failure', 'xb'): pass
except OSError as error:
    denied = error.errno
else:
    denied = 0
with open('tracked.bin','rb') as f:
    digest = hashlib.file_digest(f, 'sha256').hexdigest()
st = os.stat('tracked.bin')
index = os.stat('.git/index')
print(json.dumps({
    'git_head': git('rev-parse','--verify','HEAD').strip(),
    'git_top': git('rev-parse','--show-toplevel').strip(),
    'nested_head': git('-C', 'nested', 'rev-parse','--verify','HEAD').strip(),
    'nested_top': git('-C', 'nested', 'rev-parse','--show-toplevel').strip(),
    'git_env': {key: os.environ[key] for key in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE') if key in os.environ},
    'status': git('status','--porcelain=v1','--untracked-files=no'),
    'full_status': git('status','--porcelain=v1','--untracked-files=all'),
    'sha256': digest, 'ino': st.st_ino, 'source_dev': st.st_dev,
    'index_dev': index.st_dev, 'mtime_ns': st.st_mtime_ns, 'ctime_ns': st.st_ctime_ns,
    'size': st.st_size, 'write_errno': denied,
}))"""))
    assert report["git_head"] == head and report["git_top"] == "/workspace", report
    assert report["nested_head"] == nested and report["nested_top"] == "/workspace/nested", report
    assert report["status"] == expected and report["sha256"] == sha(contents), report
    assert report["full_status"] == expected + "?? nested/\n", report
    assert report["source_dev"] != report["index_dev"] and not report["git_env"], report
    assert report["write_errno"] == 30, report
    return report


def verify_all(jobs, head, nested, expected, contents):
    return {
        engine: [verify(job, cli, head, nested, expected, contents) for job in names]
        for engine, (cli, names) in jobs.items()
    }


def start(cli, name, head, metadata=True):
    flags = ["--tmpfs", "/workspace/.git:rw,nosuid,nodev,noexec,size=32m,mode=0700"] if metadata else []
    return run(*cli, "run", "--detach", "--rm", "--pull=never", "--network=none", "--name", name,
               "--mount", mount(worktree, "/workspace"), "--mount", mount(fixture / "seed.bundle", "/run/seed.bundle"),
               "--mount", mount(fixture / "entrypoint.sh", "/run/mounted-git-job.sh"), *flags,
               "--entrypoint", "/bin/sh", image, "/run/mounted-git-job.sh", "/workspace",
               "/run/seed.bundle", head, "--", "sleep", "120")


def await_prepare(cli, name, head):
    # State can become running before the actual entrypoint has written the index.
    for _ in range(20):
        try:
            assert exec_job(cli, name, "test", "-s", ".git/index") == b""
            if exec_job(cli, name, "git", "rev-parse", "--verify", "HEAD").decode().strip() == head:
                return
        except (RuntimeError, AssertionError):
            time.sleep(0.03)
    raise RuntimeError(f"{name} did not initialize")


try:
    head, nested = prepare()
    source = worktree / "tracked.bin"
    initial = source.stat()
    host_paths = [worktree / ".git" / part for part in ("HEAD", "index", "config")]
    steady_host = {str(path): sha(path.read_bytes()) for path in host_paths}
    jobs = {}
    for engine, sock in sockets.items():
        cli = ("docker", "--host", "unix://" + sock)
        names = [f"mp-git-contract-{uuid4().hex[:10]}-{side}" for side in ("a", "b")]
        jobs[engine] = (cli, [])
        for name in names:
            start(cli, name, head)
            jobs[engine][1].append(name)
            await_prepare(cli, name, head)
    receipt["engine"]["baseline"] = verify_all(jobs, head, nested, "", original)
    for engine, rows in receipt["engine"]["baseline"].items():
        assert rows[0]["index_dev"] != rows[1]["index_dev"], (engine, rows)
    pending = fixture / "replacement"
    pending.write_bytes(atomic)
    os.utime(pending, ns=(initial.st_atime_ns, initial.st_mtime_ns))
    pending.replace(source)
    atomic_stat = source.stat()
    assert atomic_stat.st_size == initial.st_size and atomic_stat.st_mtime_ns == initial.st_mtime_ns
    assert atomic_stat.st_ino != initial.st_ino
    receipt["edits"]["atomic"] = {"size": atomic_stat.st_size, "mtime_ns": atomic_stat.st_mtime_ns,
                                    "ctime_ns": atomic_stat.st_ctime_ns, "ino": atomic_stat.st_ino}
    time.sleep(0.05)
    receipt["engine"]["atomic"] = verify_all(jobs, head, nested, " M tracked.bin\n", atomic)
    source.write_bytes(inplace)
    os.utime(source, ns=(initial.st_atime_ns, initial.st_mtime_ns))
    inplace_stat = source.stat()
    assert inplace_stat.st_ino == atomic_stat.st_ino and inplace_stat.st_size == initial.st_size
    assert inplace_stat.st_mtime_ns == initial.st_mtime_ns and inplace_stat.st_ctime_ns != atomic_stat.st_ctime_ns
    receipt["edits"]["inplace"] = {"size": inplace_stat.st_size, "mtime_ns": inplace_stat.st_mtime_ns,
                                     "ctime_ns": inplace_stat.st_ctime_ns, "ino": inplace_stat.st_ino}
    time.sleep(0.05)
    receipt["engine"]["inplace"] = verify_all(jobs, head, nested, " M tracked.bin\n", inplace)
    receipt["engine"]["concurrent"] = {}
    for engine, (cli, (a, b)) in jobs.items():
        held = "set -C; : > .git/index.lock"
        exec_job(cli, a, "/bin/sh", "-ec", held)
        exec_job(cli, b, "git", "add", "tracked.bin")
        assert exec_job(cli, a, "git", "diff", "--cached", "--name-only") == b""
        assert exec_job(cli, b, "git", "diff", "--cached", "--name-only") == b"tracked.bin\n"
        exec_job(cli, a, "rm", "--", ".git/index.lock")
        with ThreadPoolExecutor(max_workers=2) as tasks:
            left = tasks.submit(exec_job, cli, a, "git", "update-index", "--force-remove", "tracked.bin")
            right = tasks.submit(exec_job, cli, b, "git", "add", "tracked.bin")
            left.result()
            right.result()
        status_a = exec_job(cli, a, "git", "status", "--porcelain=v1", "--untracked-files=no").decode()
        status_b = exec_job(cli, b, "git", "status", "--porcelain=v1", "--untracked-files=no").decode()
        assert status_a == "D  tracked.bin\n" and status_b == "M  tracked.bin\n", (status_a, status_b)
        assert exec_job(cli, b, "git", "show", ":tracked.bin") == inplace
        receipt["engine"]["concurrent"][engine] = {"a": status_a, "b": status_b,
                                                    "staged_b_sha256": sha(inplace)}
    assert {str(path): sha(path.read_bytes()) for path in host_paths} == steady_host
    assert git("rev-parse", "--verify", "HEAD") == head
    assert git("rev-parse", "--verify", "HEAD", root=worktree / "nested") == nested
    assert source.read_bytes() == inplace and not (worktree / "write-through-is-a-failure").exists()
    receipt["host"] = {"head": head, "nested_head": nested, "git_files_sha256": steady_host,
                       "worktree_sha256": sha(inplace)}
    receipt["pass"] = True
finally:
    if "jobs" in globals():
        for cli, names in jobs.values():
            for name in names:
                run(*cli, "rm", "-f", name)
    (receipts / ("git-index-probe-" + fixture.name + ".json")).write_text(json.dumps(receipt, indent=2) + "\n")
