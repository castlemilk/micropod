import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
from tempfile import TemporaryDirectory

original = Path(".git/index").read_bytes()
assert struct.unpack_from(">4sII", original) == (b"DIRC", 2, 1)
assert hashlib.sha1(original[:-20]).digest() == original[-20:]
fields = ("ctime_seconds", "ctime_ns", "mtime_seconds", "mtime_ns", "device",
          "inode", "mode", "uid", "gid", "size")
results = {}
with TemporaryDirectory() as temp:
    for field in ("unchanged", *fields):
        data = bytearray(original)
        values = {}
        if field != "unchanged":
            position = 12 + fields.index(field) * 4
            prior, = struct.unpack_from(">I", data, position)
            if field == "mode":
                replacement = prior ^ 0o100
            elif field in ("ctime_ns", "mtime_ns"):
                replacement = (prior + 1) % 1_000_000_000
            else:
                replacement = (prior + 1) % 2**32
            struct.pack_into(">I", data, position, replacement)
            data[-20:] = hashlib.sha1(data[:-20]).digest()
            values.update(index=prior, diagnostic=replacement)
        index = Path(temp) / (field + ".index")
        trace = Path(temp) / (field + ".jsonl")
        index.write_bytes(data)
        env = os.environ | {"GIT_OPTIONAL_LOCKS": "0", "GIT_INDEX_FILE": str(index),
                            "GIT_TRACE2_EVENT": str(trace)}
        status = subprocess.check_output(
            ["git", "status", "--porcelain=v1", "--untracked-files=no"], env=env
        ).decode()
        events = [json.loads(line) for line in trace.read_bytes().splitlines()]
        values.update(status=status, **{
            event["key"]: event["value"] for event in events
            if event.get("key", "").startswith(("refresh/", "preload/"))
        })
        results[field] = values
print(json.dumps({"version": subprocess.check_output(["git", "version", "--build-options"]).decode(),
                  "results": results}, indent=2))
