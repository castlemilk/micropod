from contextlib import ExitStack
from hashlib import sha256
from pathlib import Path
import argparse
import csv
import io
import json
import shutil
import subprocess
import tempfile
import time
from uuid import uuid4


def run(*argv, check=True):
    return subprocess.run(argv, check=check, capture_output=True, timeout=20)


def git(repo, *argv, check=True):
    return run("git", "-C", str(repo), *argv, check=check)


def mount(path, destination, read_only=True):
    stream = io.StringIO()
    row = ["type=bind", f"source={path}", f"target={destination}"]
    if read_only:
        row.append("readonly")
    csv.writer(stream, lineterminator="").writerow(row)
    return ("--mount", stream.getvalue())


def commit_file(root, text):
    (root / "tracked.bin").write_bytes(text)
    git(root, "init", "--quiet", "--template=")
    git(root, "add", "tracked.bin")
    git(root, "-c", "user.name=Micropod", "-c", "user.email=ci@example.invalid",
        "-c", "commit.gpgsign=false", "commit", "--quiet", "-m", "fixture")
    return git(root, "rev-parse", "HEAD").stdout.decode().strip()


def verify_engine(cli, args, stage, head, nested, source, payload):
    scope = ("mp-pinned-contract-" + uuid4().hex[:12])
    seed = stage / "seed.bundle"
    entry = stage / "entry.sh"
    user_tmpfs = "/checkout/.git:rw,nosuid,nodev,noexec,size=16m,mode=0700"

    def launch(name, command, *, private=user_tmpfs, read_only=True, detach=False, wrapper=False):
        flags = ["--tmpfs", private] if private else []
        mode = ["--detach"] if detach else []
        helper = "/run/pinned-checkout-job.sh"
        job_args = [helper, "--immutable", "/checkout", "/run/pin.bundle", head, "--", *command]
        if wrapper:
            job_args = ["-ec", 'touch /checkout/.git/occupied; exec /bin/sh "$@"', "setup", *job_args]
        return run(*cli, "run", "--rm", "--pull=never", "--network=none", "--name", name, *mode,
                   *mount(source, "/checkout", read_only), *mount(seed, "/run/pin.bundle"),
                   *mount(entry, helper), *flags, "--entrypoint", "/bin/sh", args.image, *job_args, check=detach)

    def execute(name, *argv, check=True):
        return run(*cli, "exec", "--workdir", "/checkout", name, *argv, check=check)

    with ExitStack() as cleanup:
        a, b = (scope + "-a", scope + "-b")
        for job in (a, b):
            cleanup.callback(run, *cli, "rm", "-f", job, check=False)
            launch(job, ["sh", "-ec", "touch /tmp/pinned-checkout-ready; exec sleep 60"], detach=True)
            for _ in range(20):
                if execute(job, "test", "-e", "/tmp/pinned-checkout-ready", check=False).returncode == 0:
                    break
                time.sleep(.03)
            else:
                raise RuntimeError(f"Job {job} did not initialize")
            assert execute(job, "git", "rev-parse", "HEAD").stdout.decode().strip() == head
            assert execute(job, "git", "symbolic-ref", "-q", "HEAD", check=False).returncode == 1
            assert execute(job, "git", "-C", "nested", "rev-parse", "HEAD").stdout.decode().strip() == nested
            assert execute(job, "git", "rev-parse", "--show-toplevel").stdout == b"/checkout\n"
            assert execute(job, "git", "status", "--porcelain=v1", "--untracked-files=no").stdout == b""
            assert execute(job, "sh", "-ec", 'test -z "${GIT_DIR+x}${GIT_WORK_TREE+x}${GIT_INDEX_FILE+x}"').returncode == 0
        execute(a, "sh", "-ec", "set -C; : > .git/index.lock")
        staged_blob = execute(b, "sh", "-ec", "printf '\\000\\377job-private' | git hash-object -w --stdin").stdout.decode().strip()
        execute(b, "git", "update-index", "--cacheinfo", f"100644,{staged_blob},tracked.bin")
        assert execute(b, "git", "show", ":tracked.bin").stdout == b"\x00\xffjob-private"
        assert execute(a, "git", "show", ":tracked.bin").stdout == payload
        assert execute(b, "cat", "tracked.bin").stdout == payload
        execute(b, "git", "-c", "user.name=Micropod", "-c", "user.email=ci@example.invalid",
                "commit", "--quiet", "-m", "Job-local commit")
        b_head = execute(b, "git", "rev-parse", "HEAD").stdout.decode().strip()
        assert b_head != head and execute(a, "git", "rev-parse", "HEAD").stdout.decode().strip() == head
        assert execute(b, "git", "-C", "nested", "rev-parse", "HEAD").stdout.decode().strip() == nested
        assert execute(b, "git", "status", "--porcelain=v1", "--untracked-files=no").stdout == b" M tracked.bin\n"
        out = {"private_commit": b_head, "host_pinned_commit": head, "nested_commit": nested}
    for case, config, expected in (
        ("writable-source", {"read_only": False}, b"Mount the immutable worktree read-only"),
        ("missing-private-mount", {"private": None}, b"Mount a private filesystem"),
        ("other-owner", {"private": user_tmpfs + ",uid=12345"}, b"The job user must own"),
        ("nonempty", {"wrapper": True}, b"The private Git directory must start empty"),
    ):
        result = launch(scope + "-" + case, ["true"], **config)
        assert result.returncode == 1 and expected in result.stderr, (case, result)
        out[case] = result.stderr.decode().strip()
    (source / "tracked.bin").write_bytes(payload[::-1])
    try:
        result = launch(scope + "-dirty", ["true"])
        assert result.returncode == 1 and b"The mounted tracked files differ" in result.stderr, result
        out["dirty-start"] = result.stderr.decode().strip()
    finally:
        (source / "tracked.bin").write_bytes(payload)
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--hvf-socket", required=True)
    p.add_argument("--orbstack-socket", required=True)
    p.add_argument("--workspace", type=Path, required=True)
    p.add_argument("--entrypoint", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--image", required=True)
    args = p.parse_args()
    evidence = {"pass": False, "engines": {}}
    try:
        with tempfile.TemporaryDirectory(prefix="pinned-contract-", dir=args.workspace) as tmp:
            stage = Path(tmp)
            source = stage / "source"
            nested_path = source / "nested"
            nested_path.mkdir(parents=True)
            payload = b"\x00\xffimmutable"
            head = commit_file(source, payload)
            nested = commit_file(nested_path, b"\x19nested\x00")
            git(source, "bundle", "create", str(stage / "seed.bundle"), "HEAD")
            shutil.copyfile(args.entrypoint, stage / "entry.sh")
            host_git_files = [(repo / ".git" / part) for repo in (source, nested_path)
                              for part in ("index", "HEAD", "config")]
            before = [sha256(path.read_bytes()).hexdigest() for path in host_git_files]
            for engine, socket in (("hvf", args.hvf_socket), ("orbstack", args.orbstack_socket)):
                cli = ("docker", "--host", "unix://" + socket)
                evidence["engines"][engine] = verify_engine(cli, args, stage, head, nested, source, payload)
            assert before == [sha256(path.read_bytes()).hexdigest() for path in host_git_files]
            assert (source / "tracked.bin").read_bytes() == payload
            evidence["host_git_sha256"] = before
            evidence["entrypoint_sha256"] = sha256((stage / "entry.sh").read_bytes()).hexdigest()
            evidence["pass"] = True
    except BaseException as error:
        evidence["error"] = str(error)
        raise
    finally:
        with args.out.open("x") as f:
            json.dump(evidence, f, indent=2)
            f.write("\n")


if __name__ == "__main__":
    main()
