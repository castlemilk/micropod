from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time
from uuid import uuid4

receipts = Path(__file__).parent
fixture = receipts.parent / ("home/share/baseline-trace/git-index-probe/one-second-" + uuid4().hex[:8])
fixture.mkdir()
source = fixture / "source"
source.mkdir()
name = "mp-git-exact-second-" + uuid4().hex[:10]
cli = ("docker", "--host", "unix:///private/tmp/mp-tune-gamma-baseline-trace-9v4gendl/home/docker.sock")
image = "micropod-qa/checkout:gamma-euque2"
path = source / "tracked.bin"
original = b"\x00\xffsame-size\x11"
modified = b"\x00\xfesame-size\x10"
old_ns = 1_600_000_000_123_456_789
receipt = {"attempts": []}


def run(*cmd):
    return subprocess.run(cmd, capture_output=True, check=True, timeout=10).stdout


def git(*cmd):
    return run("git", "-C", str(source), *cmd)


def guest(*cmd):
    return run(*cli, "exec", name, *cmd)


def worktree_write(payload):
    path.write_bytes(payload)
    os.utime(path, ns=(old_ns, old_ns))
    return path.stat()


def sample():
    return json.loads(guest("python3", "-c", """
from pathlib import Path
import hashlib,json,subprocess
def status(location):
    return subprocess.check_output([
        'git','-C',location,'status','--porcelain=v1','--untracked-files=no'
    ]).decode()
path = Path('/workspace/tracked.bin')
actual = hashlib.sha256(path.read_bytes()).hexdigest()
st = path.stat()
print(json.dumps({'private': status('/workspace'), 'raw': status('/raw'),
                  'sha256': actual, 'stat': {'mtime_ns':st.st_mtime_ns,
                  'ctime_ns':st.st_ctime_ns, 'ino':st.st_ino, 'size':st.st_size}}))
"""))


run("git", "init", "-q", "--template=", "--object-format=sha1", str(source))
worktree_write(original)
git("add", "tracked.bin")
git("-c", "user.name=Micropod", "-c", "user.email=ci@example.invalid", "-c", "commit.gpgsign=false",
    "commit", "-qm", "same-second binary case")
head = git("rev-parse", "HEAD").decode().strip()
git("bundle", "create", str(fixture / "seed.bundle"), "HEAD")
shutil.copyfile("/Users/benebsworth/projects/micropod/ci/mounted-git-job.sh", fixture / "entrypoint.sh")
started = False
try:
    run(*cli, "run", "--detach", "--rm", "--pull=never", "--network=none", "--name", name,
        "--mount", f"type=bind,src={source},dst=/workspace,readonly",
        "--mount", f"type=bind,src={source},dst=/raw,readonly",
        "--mount", f"type=bind,src={fixture / 'seed.bundle'},dst=/run/seed.bundle,readonly",
        "--mount", f"type=bind,src={fixture / 'entrypoint.sh'},dst=/run/entrypoint.sh,readonly",
        "--tmpfs", "/workspace/.git:rw,nosuid,nodev,noexec,size=32m,mode=0700",
        "--entrypoint", "/bin/sh", image, "/run/entrypoint.sh", "/workspace", "/run/seed.bundle",
        head, "--", "sleep", "60")
    started = True
    time.sleep(0.12)
    for _ in range(4):
        # Establish both host writes after the boundary and a long mtime in the past.
        # The refresh in between uses the genuine guest file stats and Git index writer.
        time.sleep(1.025 - (time.time() % 1))
        before = worktree_write(original)
        time.sleep(0.04)
        assert guest("git", "-C", "/workspace", "status", "--porcelain=v1", "--untracked-files=no") == b""
        index_entry = guest("git", "-C", "/workspace", "ls-files", "--debug").decode()
        after = worktree_write(modified)
        assert before.st_ino == after.st_ino and before.st_size == after.st_size
        assert before.st_mtime_ns == after.st_mtime_ns and before.st_ctime_ns != after.st_ctime_ns
        time.sleep(0.05)
        observed = sample()
        receipt["attempts"].append({"before_ctime_ns": before.st_ctime_ns, "after_ctime_ns": after.st_ctime_ns,
                                    "index_entry_before_edit": index_entry, "observed": observed})
        if before.st_ctime_ns // 10**9 != after.st_ctime_ns // 10**9:
            continue
        assert observed["sha256"] == hashlib.sha256(modified).hexdigest()
        assert observed["stat"]["mtime_ns"] == after.st_mtime_ns
        assert observed["stat"]["ctime_ns"] == after.st_ctime_ns
        receipt["same_second"] = observed
        break
    assert receipt["same_second"]["private"] == ""
    assert receipt["same_second"]["raw"] == " M tracked.bin\n"
finally:
    if started:
        run(*cli, "rm", "-f", name)
    out = receipts / "git-index-probe-same-second.json"
    with out.open("x") as f:
        json.dump(receipt, f, indent=2)
        f.write("\n")
