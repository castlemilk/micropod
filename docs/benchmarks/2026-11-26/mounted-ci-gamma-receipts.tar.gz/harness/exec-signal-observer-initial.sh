#!/bin/sh
# Trusted fixture-only observer installed in the read-only runner tools share.
set -eu
umask 077
work=${MICROPOD_ENGINE_WORKSPACE:?}
start=$work/.signal-start.request
finish=$work/.signal-finish.request
scratch=$(mktemp -d /run/mp-signal.XXXXXX)
instance=
owned_mount=
status=error
reason=wait_start
publish() {
    from=$1
    to=$2
    pending=$(mktemp "$work/.signals.XXXXXX") || return 1
    if cat "$from" > "$pending" && mv "$pending" "$work/$to"; then return 0; fi
    rm -f "$pending"
    return 1
}
cleanup() {
    code=$?
    trap - EXIT HUP INT TERM
    if [ -n "$instance" ]; then
        printf '0\n' > "$instance/tracing_on" || code=1
        rmdir "$instance" || code=1
    fi
    if [ -n "$owned_mount" ]; then
        umount "$owned_mount" || code=1
    fi
    publish "$scratch/setup" .signal-setup || code=1
    printf 'status=%s\nreason=%s\n' "$status" "$reason" > "$scratch/done"
    publish "$scratch/done" .signal-done || code=1
    rm -rf "$scratch"
    exit "$code"
}
seconds() { cut -d. -f1 /proc/uptime; }
exec 2>"$scratch/setup"
set -x
trap cleanup EXIT
trap 'reason=interrupted; exit 1' HUP INT TERM
limit=$(($(seconds) + 120))
while [ ! -f "$start" ]; do
    [ "$(seconds)" -lt "$limit" ] || exit 1
    sleep .10
done
reason=mount_tracefs
root=/sys/kernel/tracing
if [ ! -d "$root/instances" ]; then
    root="$scratch/tracefs"
    mkdir "$root"
    mount -t tracefs -o nosuid,nodev,noexec tracefs "$root"
    owned_mount=$root
fi
reason=create_trace_instance
path="$root/instances/mp-exec-signal"
mkdir "$path"
instance=$path
printf '0\n' > "$instance/tracing_on"
printf '2048\n' > "$instance/buffer_size_kb"
reason=clock
printf 'mono\n' > "$instance/trace_clock"
reason=signal_events
printf 'sig == 9\n' > "$instance/events/signal/signal_generate/filter"
printf '1\n' > "$instance/events/signal/signal_generate/enable"
reason=poll_events
if [ -f "$instance/events/syscalls/sys_exit_ppoll/format" ]; then
    printf 'ret != 0\n' > "$instance/events/syscalls/sys_exit_ppoll/filter"
    printf '1\n' > "$instance/events/syscalls/sys_exit_ppoll/enable"
else
    printf '%s\n' 'ppoll tracepoint missing' >&2
fi
boot_id=$(cat /proc/sys/kernel/random/boot_id)
{ printf 'boot_id=%s\nrelease=%s\n' "$boot_id" "$(uname -r)"; cat "$instance/trace_clock"; } > "$scratch/started"
printf '1\n' > "$instance/tracing_on"
printf 'mp-exec-signal-start\n' > "$instance/trace_marker"
publish "$scratch/started" .signal-started
reason=finish_wait
limit=$(($(seconds) + 75))
while [ ! -f "$finish" ]; do
    [ "$(seconds)" -lt "$limit" ] || break
    sleep .10
done
printf 'mp-exec-signal-finish\n' > "$instance/trace_marker"
printf '0\n' > "$instance/tracing_on"
cat "$instance/trace" > "$scratch/events"
for cpu in "$instance"/per_cpu/cpu[0-9]*; do
    printf '[%s]\n' "${cpu##*/}"
    cat "$cpu/stats"
done > "$scratch/stats"
publish "$scratch/events" .signal-events
publish "$scratch/stats" .signal-stats
status=ok
reason=captured
