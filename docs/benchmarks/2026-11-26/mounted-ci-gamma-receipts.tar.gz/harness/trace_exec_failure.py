"""Run an exact cold control with a stock CLI and optional transparent Unix relay."""
import argparse
import asyncio
from contextlib import ExitStack
from datetime import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import threading
import time
from types import SimpleNamespace
from uuid import uuid4

import bench_mounted_git_job as pinned
import bench_workspace_checkout as bench
import bench_workspace_edits as edits
import bench_workspace_runner as runner


class Relay:
    def __init__(self, local, upstream, log):
        self.local = local
        self.upstream = upstream
        self.log = log
        self.loop = asyncio.new_event_loop()
        self.ready = threading.Event()
        self._thread = threading.Thread(target=self.serve)
        self._thread.start()
        assert self.ready.wait(timeout=5)

    def event(self, connection, kind, **values):
        row = dict(connection=connection, kind=kind, host_monotonic_ns=time.monotonic_ns(),
                   host_realtime_ns=time.time_ns(), **values)
        self.log.write(json.dumps(row) + '\n')
        self.log.flush()

    async def copy(self, connection, src, dest, direction):
        expected = b''
        first_line = None
        total = 0
        while True:
            try:
                data = await src.read(65536)
            except Exception as error:
                self.event(connection, 'read_error', direction=direction, error=str(error), bytes=total)
                return
            if not data:
                self.event(connection, 'read_eof', direction=direction, bytes=total, first_line=first_line)
                try:
                    dest.write_eof()
                    self.event(connection, 'forwarded_half_close', direction=direction, bytes=total)
                except Exception as error:
                    self.event(connection, 'half_close_error', direction=direction, error=str(error), bytes=total)
                return
            total += len(data)
            if first_line is None:
                expected += data[:4096 - len(expected)]
                if b'\r\n' in expected:
                    first_line = expected.partition(b'\r\n')[0].decode('ascii', errors='replace')
                    self.event(connection, 'first_line', direction=direction, line=first_line)
            try:
                dest.write(data)
                await dest.drain()
            except Exception as error:
                self.event(connection, 'write_error', direction=direction, error=str(error), bytes=total)
                return

    async def accepted(self, reader, writer):
        connection = uuid4().hex[:12]
        self.event(connection, 'accepted')
        try:
            via, destination = await asyncio.open_unix_connection(self.upstream)
            try:
                await asyncio.gather(self.copy(connection, reader, destination, 'client_to_vmm'),
                                     self.copy(connection, via, writer, 'vmm_to_client'))
            finally:
                destination.close()
                await destination.wait_closed()
        finally:
            writer.close()
            await writer.wait_closed()
            self.event(connection, 'socket_released')

    def serve(self):
        async def run():
            self.stop = asyncio.Event()
            self.server = await asyncio.start_unix_server(self.accepted, path=self.local)
            self.ready.set()
            async with self.server:
                await self.stop.wait()
        self.loop.run_until_complete(run())
        self.loop.close()

    def close(self):
        self.loop.call_soon_threadsafe(self.stop.set)
        self._thread.join(timeout=5)
        assert not self._thread.is_alive()
        Path(self.local).unlink(missing_ok=True)


def event_snapshot(socket, job, earliest, latest):
    url = f'http://localhost/events?since={int(earliest) - 1}&until={int(latest) + 2}'
    stream = subprocess.check_output(['curl', '-fsS', '--max-time', '8', '--unix-socket', socket, url], text=True)
    return [row for line in stream.splitlines() if (row := json.loads(line))['Actor']['ID'] == job.id]


def run_case(args, via, stage):
    config = SimpleNamespace(**vars(args), cpus=2, memory_mib=1536)
    source, commit = runner.prepare_checkout(stage, args.source)
    bench.git(['bundle', 'create', stage / runner.BUNDLE_NAME, 'refs/heads/main'], source, bench.git_env())
    for file in ('pinned-checkout-job.sh', 'bench_mounted_git_job.py', 'bench_workspace_runner.py', 'bench_workspace_edits.py'):
        original = Path(__file__).with_name(file)
        shutil.copy2(original, stage / file)
    job = pinned.Job('hvf', via, args.image)
    accepted_ids = set(bench.image_identity(args.image_manifest, [job.image_id]).values())
    scope = 'mp-gamma-exec-trace-' + uuid4().hex[:14]
    result = {'source': runner.inventory(source), 'commit': commit, 'name': scope, 'proxy': via != args.socket}
    earliest = time.time()
    with ExitStack() as cleanup:
        job.start_job(cleanup, scope, stage, config, accepted_ids, 'host-git')
        result['container'] = job.id
        result['prepare'] = job.guest('prepare', 'host-git', 2, 1536, commit)
        start = time.monotonic_ns()
        try:
            result['build'] = job.guest('build', 2, timeout=40)
            result['build_ok'] = True
        except (RuntimeError, subprocess.TimeoutExpired) as error:
            result['build_ok'] = False
            result['error'] = str(error)
            result['failed_container_state'] = job.read_container()['State']
            result['failed_memory_events'] = bench.call([
                *job.docker, 'exec', job.id, '/bin/sh', '-c',
                'cat /sys/fs/cgroup/memory.events /sys/fs/cgroup/memory.peak /proc/meminfo',
            ], timeout=10).stdout.decode()
        result['build_host_ns'] = time.monotonic_ns() - start
        result['engine_events'] = event_snapshot(str(args.socket), job, earliest, time.time())
        builds = [row for row in result['engine_events'] if row['Action'].startswith('exec_create: ') and
                  '--guest build 2' in row['Action']]
        if len(builds) == 1:
            identity = builds[0]['Actor']['Attributes']['execID']
            result['build_exec_id'] = identity
            query = subprocess.check_output(['curl', '-fsS', '--max-time', '6', '--unix-socket', str(args.socket),
                                             f'http://localhost/exec/{identity}/json'], text=True)
            result['build_exec_inspect'] = json.loads(query)
    return result


parser = argparse.ArgumentParser(description=__doc__)
for name in ('socket', 'workspace', 'source', 'image-manifest', 'out'):
    parser.add_argument('--' + name, type=Path, required=True)
parser.add_argument('--image', required=True)
parser.add_argument('--proxy', action='store_true')
args = parser.parse_args()
assert args.socket.is_socket() and not args.out.exists()
for key in ('DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH', 'DOCKER_API_VERSION'):
    os.environ.pop(key, None)
with ExitStack() as cleanup:
    path = args.socket
    if args.proxy:
        log = cleanup.enter_context(args.out.with_suffix('.proxy.jsonl').open('x'))
        path = args.out.with_suffix('.sock')
        relay = Relay(path, args.socket, log)
        cleanup.callback(relay.close)
    stage = cleanup.enter_context(tempfile.TemporaryDirectory(prefix='mounted-git-', dir=args.workspace))
    evidence = run_case(args, path, Path(stage))
args.out.write_text(json.dumps(evidence, indent=2) + '\n')
print(args.out, evidence['build_ok'], flush=True)
