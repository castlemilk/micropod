#!/bin/sh
set -eu
docker --host unix:///Users/benebsworth/.orbstack/run/docker.sock run --rm --pull never \
    --name mp-virtiofs-lookup-build-20261126 --label org.micropod.experiment=virtiofs-lookup-20261126 \
    --cpus=4 --memory=6g --platform linux/arm64 --env JOBS=4 \
    --mount type=bind,src=/private/tmp/mp-gamma.EuQue2/home/kernel-build,dst=/artifacts \
    469c9ea410b9 sh -eu -c '
    apk add --no-cache build-base bc bison flex perl openssl-dev elfutils-dev linux-headers xz zstd bash coreutils pahole gmp-dev mpc1-dev mpfr-dev cpio python3 gawk perl-utils diffutils findutils file rsync
    { uname -a; gcc --version; ld --version; make --version; apk info -vv; } > /artifacts/toolchain.txt
    cd /artifacts
    /artifacts/inputs/build-virtiofs-sync-lookup-kernel.sh inputs/linux-7.3.5.tar.xz inputs/b5.config inputs/bounded-buddy.patch output
    '
