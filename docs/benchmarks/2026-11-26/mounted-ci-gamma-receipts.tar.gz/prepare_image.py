"""Recreate the local Linux ARM64 benchmark image and load the same save on every arm."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile

here = Path(__file__).resolve().parent
stage = here.parent
artifacts = stage / 'home/artifacts'
engine = ['docker', '--host', 'unix:///Users/benebsworth/.orbstack/run/docker.sock']
suffix = stage.name.lower().removeprefix('mp-gamma.')
tag = f'micropod-qa/checkout:gamma-{suffix}'
name = f'mp-checkout-builder-{suffix}'
label = f'io.micropod.checkout-image=gamma-{suffix}'
base = 'micropod-gamma-bench:20261120'
expected_base = 'sha256:c197a3a1748f629fcccda258ebffb2f7c1a1d3b05828e2fc2f24ff13e6f904f9'

def call(*args, check=True, timeout=180):
    completed = subprocess.run([*engine, *map(str, args)], text=True, capture_output=True, timeout=timeout)
    if check:
        if completed.returncode:
            raise RuntimeError(f'{args!r}: {completed.returncode}: {completed.stdout[-5000:]}\n{completed.stderr[-1200:]}')
    return completed


def absent(kind, target):
    probe = call(kind, 'inspect', target, check=False)
    return probe.returncode != 0 and any(s in probe.stderr.lower() for s in ('no such', 'not found'))


assert absent('container', name) and absent('image', tag)
assert call('image', 'inspect', '--format', '{{.Id}}', base).stdout.strip() == expected_base
receipt = dict(tag=tag, label=label, name=name, base=base, source_config=expected_base)
container = None
try:
    install = ('apt-get -qq update && DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends '
               'git=1:2.39.5-0+deb12u3 git-man=1:2.39.5-0+deb12u3 && git --version && go version && python3 --version')
    container = call('create', '--name', name, '--label', label, '--pull=never', '--platform', 'linux/arm64',
                     '--entrypoint', '/bin/sh', base, '-ec', install).stdout.strip()
    receipt['builder_container'] = container
    result = call('start', '--attach', container, timeout=230)
    (here / 'image-build.log').write_text(result.stdout + result.stderr)
    assert call('inspect', '--format', '{{.State.ExitCode}}', container).stdout.strip() == '0'
    receipt['commit_reported_digest'] = call('commit', '--change', 'ENTRYPOINT []', '--change', 'CMD ["/bin/sh"]', container, tag).stdout.strip()
    versions = call('run', '--rm', '--pull=never', '--network=none', '--label', label, '--entrypoint', 'sh', tag, '-ec',
                    'go version; git --version; python3 --version; uname -m; git version --build-options')
    receipt['versions'] = versions.stdout.splitlines()
    assert receipt['versions'][:4] == ['go version go1.26.11 linux/arm64', 'git version 2.39.5', 'Python 3.12.16', 'aarch64']
    receipt['installed_git'] = call('run', '--rm', '--pull=never', '--network=none', '--label', label, '--entrypoint', 'sh', tag, '-ec',
                                    'dpkg-query -W git git-man; sha256sum "$(command -v git)" "$(command -v go)" "$(command -v python3)"').stdout.splitlines()
    image = artifacts / 'seed.tar'
    call('image', 'save', '--output', image, tag, 'alpine:3.23', 'registry.k8s.io/pause:3.10.2', timeout=200)
    with image.open('rb') as source:
        receipt['seed_sha256'] = hashlib.file_digest(source, 'sha256').hexdigest()
    with tarfile.open(image) as saved:
        index = json.load(saved.extractfile('index.json'))
        descriptor = next(m for m in index['manifests'] if
                          m.get('annotations', {}).get('io.containerd.image.name') == 'docker.io/' + tag)
        manifest_digest = descriptor['digest']
        manifest = saved.extractfile('blobs/' + manifest_digest.replace(':', '/', 1)).read()
        assert 'sha256:' + hashlib.sha256(manifest).hexdigest() == manifest_digest
        parsed = json.loads(manifest)
        config_digest = parsed['config']['digest']
        config = saved.extractfile('blobs/' + config_digest.replace(':', '/', 1)).read()
        assert 'sha256:' + hashlib.sha256(config).hexdigest() == config_digest
        assert receipt['commit_reported_digest'] in (config_digest, manifest_digest)
        (here / 'image-manifest.json').write_bytes(manifest)
        receipt.update(config_digest=config_digest, manifest_digest=manifest_digest,
                       layers=[layer['digest'] for layer in parsed['layers']])
finally:
    if container:
        call('rm', '-f', container)
        receipt['builder_removed'] = absent('container', name)
    (here / 'image.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(tag, receipt['config_digest'], receipt['manifest_digest'], flush=True)
