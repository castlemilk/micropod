"""Hash the protected fixture inputs and verify preserved historical evidence."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile

here = Path(__file__).resolve().parent
stage = here.parent
hub = stage / 'home'
artifacts = hub / 'artifacts'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('worktree', type=Path)
args = parser.parse_args()
worktree = args.worktree.resolve(strict=True)
root = worktree.parent.parent
historical = worktree / 'docs/benchmarks/2026-11-25'
prior = json.loads((historical / 'managed-ci-git-and-exec.json').read_bytes())
reference = Path.home() / '.orbstack/run/docker.sock'

def file_sha(path):
    with path.open('rb') as fp:
        return hashlib.file_digest(fp, 'sha256').hexdigest()


def inventory(folder, exclude=()):
    return {file.relative_to(folder).as_posix(): file_sha(file) for file in sorted(folder.rglob('*'))
            if file.is_file() and not set(file.relative_to(folder).parts) & set(exclude)}


def verify(folder, expected):
    for rel, checksum in expected.items():
        assert file_sha(folder / rel) == checksum, folder / rel
    return len(expected)


def command(*args):
    return subprocess.check_output(args, text=True).strip()


def report_archives():
    output = {}
    for role in ('raw', 'sources'):
        archived = prior['evidence'][role]
        path = historical / archived['path']
        assert path.stat().st_size == archived['bytes'] and file_sha(path) == archived['sha256']
        with tarfile.open(path) as source:
            checks = json.load(source.extractfile('MANIFEST.sha256.json'))
        assert len(checks) == archived['manifest_entries']
        output[role] = {**archived, 'extracted_files_verified': verify(hub / 'evidence', checks)}
    return output


def baseline():
    copy = (worktree / 'docs/benchmarks/2026-11-24/disposable-local-fixture/'
            '20261124T101312Z-local-iad8j2_g/preserved')
    record = json.loads((copy / 'manifest.json').read_bytes())
    expected = record['sha256']
    return {'manifest_sha256': file_sha(copy / 'manifest.json'),
            'original_files_verified': verify(Path(record['source']), expected),
            'preserved_files_verified': verify(copy, expected)}


def tools():
    with gzip.open(worktree / 'docs/benchmarks/2026-11-21/gamma-vcpu-priority.json.gz', 'rt') as fp:
        installed = json.load(fp)['installation']
    bank = Path(installed['path'])
    expect = installed['tools']
    bank_copy = inventory(artifacts / 'micropod-oci-tools')
    unchanged = [key for key in expect if expect[key] == bank_copy.get(key)]
    assert verify(bank / 'micropod-oci-tools', expect) == 37
    assert file_sha(bank / 'micropod') == installed['host_sha256']
    assert file_sha(bank / 'micropod-oci') == installed['oci_sha256']
    assert set(expect) == set(bank_copy)
    return {'upstream_files_verified': len(expect), 'upstream_host_binaries_verified': 2,
            'current_bank_inventory': bank_copy, 'changed_upstream_paths': sorted(set(expect) - set(unchanged)),
            'trace_bank_inventory': inventory(artifacts / 'trace-tools')}


def source():
    sw = json.loads((hub / 'evidence/raw/restore-guard-build.json').read_bytes())
    current_cli = artifacts / 'managed/micropod'
    frozen = artifacts / 'current-source'
    manifest = inventory(frozen, ('target',))
    vmm_commit = command('git', '-C', str(root), 'rev-parse', '7a30d9ae')
    return {'vmm_git_commit': vmm_commit, 'vmm_git_tree': command('git', '-C', str(root), 'rev-parse', f'{vmm_commit}:vmm'),
            'vmm_frozen_source_sha256': manifest,
            'vmm_built_sha256': file_sha(frozen / 'target/release/micropod-vmm'),
            'initrd_built_sha256': file_sha(frozen / 'target/mp-hvf-init.cpio'),
            'kernel_bytes_sha256': file_sha(artifacts / 'Image'),
            'managed_cli_sha256': file_sha(current_cli),
            'managed_cli_matches_prior_guarded': file_sha(current_cli) == sw['binary_sha256'],
            'runner_matches_prior': file_sha(artifacts / 'micropod-oci-tools/runner/bin/job') == prior['integrated_artifacts']['runner_sha256'],
            'archived_final_runner_source_sha256': inventory(hub / 'evidence/final-runner'),
            'prior_fixture': prior['integrated_artifacts']}


result = {
    'host': {'macos': command('sw_vers'),
             'hardware': command('sysctl', '-n', 'hw.model', 'machdep.cpu.brand_string', 'hw.logicalcpu', 'hw.memsize').splitlines(),
             'python': sys.version, 'rust': command('rustc', '--version'), 'cargo': command('cargo', '--version'),
             'go_host': command('go', 'version'), 'go_build_flags': command('go', 'env', 'GOFLAGS'),
             'orbstack_app_version': command('/usr/libexec/PlistBuddy', '-c', 'Print :CFBundleShortVersionString', '/Applications/OrbStack.app/Contents/Info.plist'),
             'orbstack_app_build': command('/usr/libexec/PlistBuddy', '-c', 'Print :CFBundleVersion', '/Applications/OrbStack.app/Contents/Info.plist'),
             'docker': json.loads(command('docker', '--host', 'unix://' + str(reference), 'version', '--format', '{{json .}}'))},
    'archives': report_archives(), 'preserved_baseline': baseline(), 'tools': tools(), 'artifacts': source(),
}
assert result['artifacts']['runner_matches_prior'] and result['artifacts']['managed_cli_matches_prior_guarded']
print(json.dumps(result, indent=2))
