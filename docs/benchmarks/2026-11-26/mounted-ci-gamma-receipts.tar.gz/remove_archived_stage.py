"""Remove this one temporary scope after validating its durable evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import stat
import tarfile

here = Path(__file__).resolve().parent
stage = here.parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('scorecard', type=Path)
args = parser.parse_args()
scorecard = args.scorecard.resolve(strict=True)
assert scorecard.name == 'mounted-ci-gamma.json' and not scorecard.is_relative_to(stage)
assert stage.parent == Path('/private/tmp') and stage.name.startswith('mp-gamma.')
assert stat.S_ISDIR(stage.lstat().st_mode) and stage.lstat().st_mode & 0o777 == 0o700
assert list(stage.iterdir()) == [here] and not any(path.is_mount() for path in [stage, here])
assert not any(path.is_socket() for path in here.rglob('*'))

data = json.loads(scorecard.read_bytes())
archive = scorecard.with_name(data['receipts']['path'])
assert archive.name == 'mounted-ci-gamma-receipts.tar.gz'
with archive.open('rb') as source:
    assert hashlib.file_digest(source, 'sha256').hexdigest() == data['receipts']['sha256']
with tarfile.open(archive) as tar:
    archived = json.load(tar.extractfile('MANIFEST.sha256.json'))
assert len(archived) == data['receipts']['entries']
assert data['cleanup']['hub_image_removed'] and data['cleanup']['all_owned_apfs_images_absent']
for local in here.rglob('*'):
    if local.is_file() and not local.name.endswith('-stop') and '__pycache__' not in local.parts:
        with local.open('rb') as source:
            assert hashlib.file_digest(source, 'sha256').hexdigest() == archived[local.relative_to(here).as_posix()]
shutil.rmtree(here)
stage.rmdir()
assert not stage.exists()
replacement = scorecard.with_suffix('.complete.pending')
data['cleanup']['private_staging_directory_removed'] = True
with replacement.open('x') as target:
    json.dump(data, target, indent=2)
    target.write('\n')
replacement.replace(scorecard)
print(scorecard)
