#!/bin/bash
set -euo pipefail
receipts=$(cd "$(dirname "$0")" && pwd -P)
stage=$(dirname "$receipts")
evidence="$stage/home/evidence"
arm=${1:?arm name}
workload=${2:?material, git, or edits}
label=${3:-$arm}
endpoint=$(jq -er .socket "$receipts/$arm-ready.json")
workspace=$(jq -er .workspace "$receipts/$arm-ready.json")
image=$(jq -er .tag "$receipts/image.json")
orb=/Users/benebsworth/.orbstack/run/docker.sock
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH DOCKER_API_VERSION
before="$receipts/$label-$workload-before-top.log"
after="$receipts/$label-$workload-after-top.log"
/usr/bin/top -l 2 -s 1 -n 0 > "$before"
case "$workload" in
  material)
    driver="$evidence/final-harness/scripts/bench_workspace_runner.py"
    command=(python3 -B "$driver" --hvf-socket "$endpoint" --orbstack-socket "$orb" --workspace "$workspace" \
      --source "$evidence/runner-vendored" --image "$image" --image-manifest "$receipts/image-manifest.json" \
      --pairs "${PAIRS:-4}" --cpus 2 --memory-mib 1536 --out "$receipts/$label-$workload.json")
    ;;
  git)
    export PYTHONPATH="$evidence/final-harness/scripts"
    command=(python3 -B "$receipts/harness/bench_workspace_git.py" --hvf-socket "$endpoint" --orbstack-socket "$orb" \
      --workspace "$workspace" --source "$evidence/runner-vendored" --image "$image" --image-manifest "$receipts/image-manifest.json" \
      --pairs "${PAIRS:-6}" --out "$receipts/$label-$workload.json")
    if [ "${TRACE:-1}" = 1 ]; then
      command+=(--trace-mode guest-clone --trace-helper "$evidence/trace-proof/trace_proof.py")
    fi
    ;;
  edits)
    command=(python3 -B "$evidence/final-harness/scripts/bench_workspace_edits.py" --host "unix://$endpoint" \
      --workspace "$workspace" --probe "$stage/home/artifacts/fsprobe" --rounds "${PAIRS:-4}")
    ;;
  *) exit 2 ;;
esac
status=0
if [ "$workload" = edits ]; then
  "${command[@]}" > "$receipts/$label-$workload.json" 2> "$receipts/$label-$workload.log" || status=$?
else
  "${command[@]}" > "$receipts/$label-$workload.log" 2>&1 || status=$?
fi
/usr/bin/top -l 2 -s 1 -n 0 > "$after"
if [ "$workload" = git ]; then
  for file in "$workspace"/.trace-*; do
    [ -f "$file" ] || continue
    cp -p "$file" "$receipts/$label-$workload-${file##*/}"
  done
fi
exit "$status"
