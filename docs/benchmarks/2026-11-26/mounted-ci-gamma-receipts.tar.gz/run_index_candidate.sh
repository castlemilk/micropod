#!/bin/bash
set -euo pipefail
r=$(cd "$(dirname "$0")" && pwd -P)
s=$(dirname "$r")
worker=${1:-baseline-trace}
label=${2:-git-index-probe-material}
ready="$r/$worker-ready.json"
socket=$(jq -er .socket "$ready")
workspace=$(jq -er .workspace "$ready")
image=$(jq -er .tag "$r/image.json")
/usr/bin/top -l 2 -s 1 -n 0 > "$r/$label-before-top.log"
status=0
PYTHONDONTWRITEBYTECODE=1 python3 -B "$r/harness/bench_mounted_git_job.py" \
  --hvf-socket "$socket" --orbstack-socket /Users/benebsworth/.orbstack/run/docker.sock \
  --source "$s/home/evidence/runner-vendored" --workspace "$workspace" \
  --entrypoint "$r/harness/pinned-checkout-job.sh" --image "$image" --image-manifest "$r/image-manifest.json" \
  --pairs "${PAIRS:-4}" --out "$r/$label.json" > "$r/$label.log" 2>&1 || status=$?
/usr/bin/top -l 2 -s 1 -n 0 > "$r/$label-after-top.log"
exit "$status"
