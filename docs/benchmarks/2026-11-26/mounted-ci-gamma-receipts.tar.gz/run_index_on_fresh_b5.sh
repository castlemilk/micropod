#!/bin/bash
set -euo pipefail
receipts=$(cd "$(dirname "$0")" && pwd -P)
arm=${1:-pinned-index-measured}
python3 -B "$receipts/serve_worker.py" "$arm" > "$receipts/$arm-owner.log" 2>&1 &
owner=$!
release() {
  result=$?
  trap - EXIT
  touch "$receipts/$arm-stop"
  wait "$owner" || result=1
  exit "$result"
}
trap release EXIT
trap 'exit 130' INT TERM
until [ -f "$receipts/$arm-ready.json" ]; do
  kill -0 "$owner" 2>/dev/null || exit 1
  sleep .25
done
"$receipts/run_index_candidate.sh" "$arm" git-index-probe-material-measured
