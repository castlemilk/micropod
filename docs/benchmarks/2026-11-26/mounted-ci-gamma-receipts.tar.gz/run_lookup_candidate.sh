#!/bin/bash
set -euo pipefail
receipts=$(cd "$(dirname "$0")" && pwd -P)
stage=$(dirname "$receipts")
arm=${1:?private arm name}
mode=${2:?boot parameter 0 or 1}
kernel=${3:?protected candidate Image}
shift 3
[ "$#" -gt 0 ]
tools="$stage/home/artifacts/micropod-oci-tools"
for workload in "$@"; do
  if [ "$workload" = git ]; then tools="$stage/home/artifacts/trace-tools"; fi
done
python3 -B "$receipts/serve_worker.py" "$arm" --kernel "$kernel" --tools "$tools" \
  --kernel-extra "virtiofs.sync_lookup_completion=$mode" > "$receipts/$arm-owner.log" 2>&1 &
owner=$!
release() {
  status=$?
  trap - EXIT
  touch "$receipts/$arm-stop"
  wait "$owner" || status=1
  exit "$status"
}
trap release EXIT
trap 'exit 130' INT TERM
until [ -f "$receipts/$arm-ready.json" ]; do
  kill -0 "$owner" 2>/dev/null || exit 1
  sleep .25
done
printf '%s started with parameter %s\n' "$arm" "$(jq -er .kernel_sync_lookup_completion "$receipts/$arm-ready.json")"
status=0
for workload in "$@"; do
  printf '%s running %s\n' "$arm" "$workload"
  "$receipts/run_arm.sh" "$arm" "$workload" || status=1
  printf '%s completed %s\n' "$arm" "$workload"
done
exit "$status"
