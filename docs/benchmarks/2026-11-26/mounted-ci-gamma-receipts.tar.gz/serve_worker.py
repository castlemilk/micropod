"""Own a protected Micropod worker until its run-specific stop request appears."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import sys
import time

receipt_dir = Path(__file__).resolve().parent
stage = receipt_dir.parent
hub = stage / 'home'
artifacts = hub / 'artifacts'
# The prior qualification archive provides the exact independently hashed helper.
sys.path.insert(0, str(hub / 'evidence/final-harness/scripts'))
import bench_engine_tuning as bench

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('arm')
parser.add_argument('--kernel', type=Path, default=artifacts / 'Image')
parser.add_argument('--vmm', type=Path, default=artifacts / 'current-source/target/release/micropod-vmm')
parser.add_argument('--initrd', type=Path, default=artifacts / 'current-source/target/mp-hvf-init.cpio')
parser.add_argument('--tools', type=Path, default=artifacts / 'micropod-oci-tools')
parser.add_argument('--kernel-extra', default='')
args = parser.parse_args()
assert re.fullmatch('[a-z0-9-]{1,24}', args.arm) and hub.is_mount()
for key in ('kernel', 'vmm', 'initrd', 'tools'):
    assert getattr(args, key).resolve(strict=True).is_relative_to(hub)
record = receipt_dir / f'{args.arm}-worker.json'
ready = receipt_dir / f'{args.arm}-ready.json'
stop = receipt_dir / f'{args.arm}-stop'
assert not any(path.exists() for path in (record, ready, stop))
workspace = hub / 'share' / args.arm
workspace.mkdir(mode=0o700)
image = json.loads((receipt_dir / 'image.json').read_text())
cli = artifacts / 'managed/micropod'

def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def save(path, data):
    scratch = path.with_suffix('.partial')
    scratch.write_text(json.dumps(data, indent=2) + '\n')
    scratch.replace(path)


def interrupted(sig, _frame):
    raise InterruptedError(f'worker owner received signal {sig}')


class ManagedWorker(bench.WorkerHandle):
    def env(self):
        env = super().env()
        for key in list(env):
            if key.startswith(('DOCKER_', 'MICROPOD_')) and key not in (
                'MICROPOD_CI_CPUS', 'MICROPOD_CI_MEMORY_MIB', 'MICROPOD_CI_OCI_TOOLS',
                'MICROPOD_CI_KERNEL', 'MICROPOD_CI_PUBLISHED_PATH', 'MICROPOD_CI_PORT_RELAY',
                'MICROPOD_CI_PORT_RELAY_WORKERS', 'MICROPOD_SANDBOX_KERNEL_ARGS',
                'MICROPOD_CI_ENGINE', 'MICROPOD_CI_HOME', 'MICROPOD_CI_WORKSPACE',
            ):
                env.pop(key)
        env.update(MICROPOD_CI_VMM='hvf', MICROPOD_CI_DISK_GIB='8', MICROPOD_CI_HVF_BIN=str(args.vmm),
                   MICROPOD_CI_HVF_INITRD=str(args.initrd), MICROPOD_TRACE='0',
                   MICROPOD_OBSERVABILITY_CONFIG=str(receipt_dir / 'fixture-observability.yaml'))
        return env


signal.signal(signal.SIGTERM, interrupted)
worker = ManagedWorker('gamma-' + args.arm, cli, args.tools, args.kernel,
                       ('idle_poll_us=150 ' + args.kernel_extra).rstrip(), workspace)
artifact_paths = {'cli': cli, 'kernel': args.kernel, 'vmm': args.vmm, 'initrd': args.initrd,
                  'runner': args.tools / 'runner/bin/job', 'runner_start': args.tools / 'runner/start.sh'}
data = { 'arm': args.arm, 'owner_pid': os.getpid(), 'host': os.uname().nodename,
         'worker_directory': str(worker.dir), 'workspace': str(workspace), 'socket': str(worker.sock),
         'image': image['tag'], 'artifacts': {name: {'path': str(path), 'sha256': sha(path)}
                                             for name, path in artifact_paths.items()} }
assert data['artifacts']['runner']['sha256'] == 'e0573601f2d0a4178b830186f7145dbc8f2d3c841e6f82c90f26f81b688d46f0'
assert data['artifacts']['cli']['sha256'] == 'b489425ac2c62dd562893885be4d9a37160660331be6cfb3f4ce587931c5a823'
save(record, data)
try:
    data['boot_s'] = worker.start()
    data['drive'] = worker.drive.receipts
    data['pid'] = worker.proc.pid
    data['status'] = json.loads(bench.run([cli, 'ci', 'runner-status'], env=worker.env()).stdout)
    assert data['status']['vmm'] == 'hvf'
    bench.load_images(worker.sock, artifacts / 'seed.tar')
    data['image_on_guest'] = bench.docker(worker.sock, 'image', 'inspect', '--format', '{{.Id}}', image['tag']).stdout.strip()
    assert data['image_on_guest'] in (image['config_digest'], image['manifest_digest'])
    probe = bench.docker(worker.sock, 'run', '--rm', '--pull=never', '--network=none', '--entrypoint', 'sh',
                         image['tag'], '-ec', 'uname -r; uname -m; cat /proc/cmdline; go version; git --version; python3 --version; '
                         'sha256sum "$(command -v git)" "$(command -v go)" "$(command -v python3)"')
    data['guest'] = probe.stdout.splitlines()
    data['kernel_cmdline'] = data['guest'][2]
    assert 'idle_poll_us=150' in data['kernel_cmdline'] and all(arg in data['kernel_cmdline'].split() for arg in args.kernel_extra.split())
    assert data['guest'][3:6] == image['versions'][:3] and data['guest'][6:] == image['installed_git'][2:]
    parameter = 'virtiofs.sync_lookup_completion='
    settings = [arg.removeprefix(parameter) for arg in args.kernel_extra.split() if arg.startswith(parameter)]
    if settings:
        assert len(settings) == 1 and settings[0] in ('0', '1')
        observed = bench.docker(worker.sock, 'run', '--rm', '--pull=never', '--network=none',
                                'alpine:3.23', 'cat', '/sys/module/virtiofs/parameters/sync_lookup_completion').stdout.strip()
        data['kernel_sync_lookup_completion'] = observed
        assert observed == {'0': 'N', '1': 'Y'}[settings[0]]
    # Identify the direct VMM child before checking its file table. Scanning
    # every host process here can block on unrelated mounts under ambient load.
    procpath = ctypes.CDLL('/usr/lib/libproc.dylib').proc_pidpath
    launched = bench.run(['/usr/bin/pgrep', '-P', str(worker.proc.pid)], timeout=5).stdout.split()
    holders = {}
    for raw in launched:
        pid, buf = int(raw), ctypes.create_string_buffer(4096)
        if procpath(pid, buf, len(buf)) <= 0:
            continue
        exe = Path(os.fsdecode(buf.value))
        if not exe.exists() or not exe.samefile(args.vmm):
            continue
        files = bench.run(['/usr/sbin/lsof', '-nP', '-p', str(pid), '-Fn'], timeout=15).stdout.splitlines()
        match = [line[1:] for line in files if line.startswith('n') and line[1:].endswith('/worker.ext4')]
        assert match and all(Path(item).samefile(worker.drive.disk) for item in match), (pid, match)
        data['live_disk_file_table_references'] = len(match)
        holders[pid] = str(exe)
    assert len(holders) == 1
    data['disk_holders_live'] = holders
    data['live_disk_attestation'] = 'scoped file table of the exact VMM child process'
    save(record, data)
    save(ready, data)
    print(worker.sock, workspace, image['tag'], flush=True)
    while not stop.is_file() and worker.proc.poll() is None:
        time.sleep(0.25)
    if worker.proc.poll() is not None:
        raise RuntimeError(f'worker exited before stop request: {worker.proc.returncode}')
finally:
    worker_log = worker.dir / 'serve.log'
    if worker_log.is_file():
        shutil.copyfile(worker_log, receipt_dir / f'{args.arm}-serve.log')
    try:
        data['drive'] = worker.stop()
    finally:
        save(record, data)
