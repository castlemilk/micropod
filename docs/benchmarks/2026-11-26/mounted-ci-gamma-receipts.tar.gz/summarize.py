"""Summarize the explicitly paired mounted CI and stock-kernel evidence."""
from collections import Counter, defaultdict
import json
from pathlib import Path
import re
from statistics import median
import sys

receipts = Path(__file__).resolve().parent
sys.path.insert(0, str(receipts.parent / 'home/evidence/trace-proof'))
import trace_proof as trace


def read(path):
    return json.loads(path.read_bytes())


def load_samples(label):
    result = {}
    for when in ('before', 'after'):
        path = receipts / f'{label}-{when}-top.log'
        if path.is_file():
            output = path.read_text()
            result[when] = {
                'idle_pct': [float(p) for p in re.findall(r'([\d.]+)% idle', output)][-1],
                'load_averages': [float(p) for p in re.findall(r'Load Avg: ([\d., ]+)', output)[-1].split(',')],
            }
    return result


def material(path):
    result = {'source': None, 'fixture_commit': None, 'pairs': {}, 'load': load_samples(path.stem)}
    evidence = read(path)
    result['source'] = evidence['source']
    result['fixture_commit'] = evidence['git_commit']
    result['image'] = evidence['image']
    result['limits'] = {name: value['limits'] for name, value in evidence['preparation'].items()}
    for mode in ('warm', 'incremental'):
        rows = [pair[mode] for pair in evidence['pairs']]
        result['pairs'][mode] = {
            'n': len(rows),
            'hvf_wins': sum(p['hvf']['sum_ns'] < p['orbstack']['sum_ns'] for p in rows),
            'medians_total_ms': {name: median(p[name]['sum_ns'] for p in rows) / 1e6 for name in ('hvf', 'orbstack')},
            'median_hvf_orb_ratio': median(p['hvf']['sum_ns'] / p['orbstack']['sum_ns'] for p in rows),
            'median_pair_difference_ms': median(p['hvf']['sum_ns'] - p['orbstack']['sum_ns'] for p in rows) / 1e6,
            'medians_by_phase_ms': {name: {phase: median(p[name]['phase_ns'][phase] for p in rows) / 1e6
                                           for phase in rows[0][name]['phase_ns']} for name in ('hvf', 'orbstack')},
        }
    return result


def request_context(events, connection, observer, window_ns):
    requests = defaultdict(dict)
    for ev in events:
        kind = 'send' if ev.name == 'fuse_request_send' else 'end' if ev.name == 'fuse_request_end' else None
        if kind is None:
            continue
        match = (trace.SEND if kind == 'send' else trace.END).fullmatch(ev.body)
        if match and int(match[1]) == connection:
            assert kind not in requests[int(match[2])], f'duplicate {kind} for request {match[2]}'
            requests[int(match[2])][kind] = (ev, match)
    in_scope = {op: {'total': 0, 'same_pid': 0, 'errors': Counter(), 'delays_ns': [], 'same_pid_ns': [], 'other_pid_ns': []}
                for op in ('LOOKUP', 'OPEN', 'READ', 'RELEASE', 'READDIRPLUS')}
    completions = {}
    for req in requests.values():
        if set(req) != {'send', 'end'}:
            continue
        send, request = req['send']
        end, response = req['end']
        op = request[4].removeprefix('FUSE_')
        if op not in in_scope or not window_ns[0] <= send.ns <= end.ns <= window_ns[1] or send.pid == observer:
            continue
        row = in_scope[op]
        row['total'] += 1
        row['same_pid'] += int(send.pid == end.pid)
        row['delays_ns'].append(end.ns - send.ns)
        row['same_pid_ns' if send.pid == end.pid else 'other_pid_ns'].append(end.ns - send.ns)
        if int(response[4]):
            row['errors'][response[4]] += 1
        completions[end.line] = (send.ns, op)
    _, _, queue_ns, linked = trace.work_pairs(events, completions)
    for op, row in in_scope.items():
        row['send_to_end'] = trace.distribution(row.pop('delays_ns'))
        row['send_to_end_same_pid'] = trace.distribution(row.pop('same_pid_ns'))
        row['send_to_end_other_pid'] = trace.distribution(row.pop('other_pid_ns'))
        row['workqueue_linked'] = linked[op]
    return {'scope': 'Request send and end timestamps both inside the monotonic guest git subprocess window',
            'time_window_ns': window_ns, 'opcodes': in_scope, 'linked_enqueue_to_work_start': trace.distribution(queue_ns)}


def git(path):
    evidence = read(path)
    data = {'load': load_samples(path.stem), 'complete': evidence['complete'], 'source': evidence['source'],
            'fixture_commit': evidence['head'], 'image': evidence['image'], 'modes': {}}
    for mode in ('host-index', 'guest-index', 'guest-clone'):
        rows = [run for pair in evidence['pairs'] for run in pair if run['mode'] == mode]
        data['modes'][mode] = {
            'all_status_observations': len(rows) * 2,
            'correct_observations': sum(row[engine]['correct'] for row in rows for engine in ('hvf', 'orbstack')),
            'median_ms': {('edited' if edited else 'warm'): {engine: median(row[engine]['elapsed_ns'] / 1e6 for row in rows
                                                                        if row['edited'] == edited)
                                                           for engine in ('hvf', 'orbstack')} for edited in (False, True)},
            'batched_warm_ns': {engine: trace.distribution([x for row in evidence['batched_status'] if row['mode'] == mode
                                                             for x in row['observations'][engine]['elapsed_ns']])
                                for engine in ('hvf', 'orbstack')},
            'trace2': {engine: {'preload_config': row['core_preload_index'],
                                'counts': {item['key']: int(item['value']) for item in row['trace2'] if item.get('key') in
                                           ('preload/sum_lstat', 'refresh/sum_scan', 'refresh/sum_lstat')},
                                'regions_ms': {entry['label']: entry['t_rel'] * 1000 for entry in row['trace2']
                                               if entry.get('label') in ('preload', 'refresh', 'untracked')}}
                       for engine, modes in evidence['diagnostics'].items() if (row := modes[mode])},
        }
    row = evidence['diagnostics']['hvf']['guest-clone']
    if 'ftrace' in row:
        ftrace = row['ftrace']
        data['ftrace_whole_control_window'] = ftrace
        raw = (receipts / f'{path.stem}-.trace-events').read_text()
        events, bad, lost, _ = trace.parse_events(raw)
        assert not bad and not lost and ftrace['complete'] and ftrace['capture']['clock'] == 'mono'
        data['ftrace_git_command_window'] = request_context(events, int(ftrace['capture']['connection']),
                                                             int(ftrace['capture']['observer_pid']), row['git_time_window_ns'])
    return data


def edits(path):
    evidence = read(path)
    return {'complete': evidence['complete'], 'median_observed_ms': evidence['median_observed_ms'],
            'cases': {case: dict(Counter(row['result'] for row in rows)) for case, rows in evidence['samples'].items()},
            'scans': evidence['scans']}



def private_index(path):
    evidence = read(path)
    result = {'complete': evidence['complete'], 'load': load_samples(path.stem),
              'pairs_recorded': len(evidence.get('pairs', []))}
    if not evidence['complete']:
        return {**result, 'error': evidence.get('error')}
    pack = evidence['preparation']
    result.update(source=evidence['source'], fixture_commit=evidence['commit'], image=evidence['image'],
                  preparation={'host_checkout_and_inventory_ms': pack['common_source_ns'] / 1e6,
                               'host_bundle_pack_ms': pack['bundle_pack_ns'] / 1e6, 'bundle': pack['bundle']},
                  medians_ms=evidence['median_ms'], cold={}, paired_private_index={})
    for k, row in evidence['cold'].items():
        result['cold'][k] = {'first_ci_wall_ms': row['first_ci_wall_ns'] / 1e6,
                             'first_ci_wall_with_bundle_pack_ms': row['with_bundle_pack_ns'] / 1e6,
                             'container_start_ms': row['container_start_ns'] / 1e6,
                             'mount_and_metadata_prepare_wall_ms': row['prepare_wall_ns'] / 1e6,
                             'guest_bundle_and_index_init_ms': row['prepare']['init_ns'] / 1e6}
    rows = [block["jobs"] for block in evidence['pairs']]
    for engine in ('hvf', 'orbstack'):
        raw = engine + '/host-git'
        nested = engine + '/private-git'
        result['paired_private_index'][engine] = {
            'wins': sum(row[nested]['sum_ns'] < row[raw]['sum_ns'] for row in rows),
            'median_private_over_host_git': median(row[nested]['sum_ns'] / row[raw]['sum_ns'] for row in rows),
            'median_git_saving_ms': median(row[raw]['phase_ns']['git_status'] - row[nested]['phase_ns']['git_status']
                                           for row in rows) / 1e6,
        }
    return result


def exec_diagnostics():
    failed = {}
    for file in sorted((receipts / 'exec-failure-events').glob('*.jsonl')):
        rows = [json.loads(line) for line in file.read_text().splitlines()]
        begin = next(row for row in rows if row['Action'].startswith('exec_start:') and '--guest build 2' in row['Action'])
        exec_id = begin['Actor']['Attributes']['execID']
        done = next(row for row in rows if row['Action'] == 'exec_die' and row['Actor']['Attributes']['execID'] == exec_id)
        failed[file.stem] = {'exec_id': exec_id, 'exit': int(done['Actor']['Attributes']['exitCode']),
                             'guest_elapsed_ms': (done['timeNano'] - begin['timeNano']) / 1e6}
    retries = {}
    for mode in ('direct', 'proxy'):
        path = receipts / f'exec-signal-{mode}.json'
        if path.is_file():
            record = read(path)
            start = next(row for row in record['engine_events'] if row['Action'].startswith('exec_start:') and '--guest build 2' in row['Action'])
            identity = start['Actor']['Attributes']['execID']
            retries[mode] = {'build_ok': record['build_ok'], 'build_exec_id': identity,
                             'build_host_wall_ms': record['build_host_ns'] / 1e6}
    raw = receipts / 'exec-signal-final-.trace-events'
    signals, syscall_counts, runner_calls = [], {}, {}
    if raw.is_file():
        original = raw.read_text()
        normalized = original.replace(': sys_ppoll -> ', ': sys_exit_ppoll: ')
        events, bad, lost, _ = trace.parse_events(normalized)
        sigs = [event for event in events if event.name == 'signal_generate']
        lines = original.splitlines()
        signals = [{'sender_pid': event.pid, 'raw': lines[event.line - 1].strip()} for event in sigs]
        syscall_counts = dict(Counter(event.body for event in events if event.name == 'sys_exit_ppoll'))
        runner_calls = dict(Counter(event.body for event in events if event.name == 'sys_exit_ppoll'
                                    and re.match(r'\s*job-\d+', lines[event.line - 1])))
        assert not lost and not bad
    memory_path = receipts / 'git-index-probe-material-retry.json'
    memory = read(memory_path).get('failed_cell_memory', '').splitlines()[:8] if memory_path.is_file() else []
    return {'original_failures': failed, 'retry_cgroup_memory_first_eight_lines': memory,
            'fresh_same_binary_repro_attempts': retries, 'sigkill_trace_records': signals,
            'nonzero_ppoll_returns': syscall_counts, 'runner_nonzero_ppoll_returns': runner_calls,
            'physical_failure_sender': 'unresolved; failures did not reproduce on the fresh traced worker'}


data = {'material': {}, 'git': {}, 'mutable_edit_checks': {}, 'private_index': {}}
for glob, key, callback in (('*-material.json', 'material', material), ('*-git.json', 'git', git),
                            ('*-edits.json', 'mutable_edit_checks', edits),
                            ('git-index-probe-material*.json', 'private_index', private_index)):
    data[key] = {path.stem: callback(path) for path in sorted(receipts.glob(glob))
                 if path.stat().st_size and (key != "material" or not path.name.startswith("git-index-probe-"))}
data["isolated_exec_failure_diagnostic"] = exec_diagnostics()
controls = {}
for label in ('lookup-off-measured', 'lookup-inline-measured'):
    path = receipts / f'{label}-ready.json'
    if path.is_file():
        row = read(path)
        controls[label] = {'observed_parameter': row['kernel_sync_lookup_completion'],
                           'guest_kernel_release': row['guest'][0], 'startup_seconds': row['boot_s'],
                           'sha256': {name: record['sha256'] for name, record in row['artifacts'].items()}}
if len(controls) == 2:
    left, right = controls.values()
    assert left['observed_parameter'] == 'N' and right['observed_parameter'] == 'Y'
    assert left['sha256'] == right['sha256']
data['same_image_lookup_controls'] = controls
print(json.dumps(data, indent=2))
