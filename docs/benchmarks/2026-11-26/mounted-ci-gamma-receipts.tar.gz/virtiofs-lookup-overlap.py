#!/usr/bin/env python3
"""Reconcile LOOKUP overlap and guest CPU placement within the exact Git window."""

import argparse
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

TRACE = re.compile(
    r"^\s*.*?-(?P<pid>\d+)\s*(?:\(\s*(?:\d+|-+)\s*\)\s*)?\[(?P<cpu>\d+)\]\s+"
    r"(?:[^:\s]+\s+)?(?P<sec>\d+)\.(?P<frac>[0-9]{1,9}):\s+"
    r"(?P<event>fuse_request_send|fuse_request_end):\s*(?P<body>.*)$"
)
SEND = re.compile(r"connection (\d+) req (\d+) opcode (\d+) \(([^)]+)\) len (\d+)\s*$")
END = re.compile(r"connection (\d+) req (\d+) len (\d+) error (-?\d+)\s*$")


def percentile_latency(delays):
    values = sorted(delays)
    return {f"p{p}_ns": values[(p * len(values) + 99) // 100 - 1] for p in (50, 95, 99)}


def reconcile(receipts, name, window):
    prefix = receipts / name
    started = dict(
        line.split("=", 1)
        for line in Path(f"{prefix}-.trace-started").read_text().splitlines()
    )
    observer = int(started["observer_pid"])
    stats = Path(f"{prefix}-.trace-stats").read_text()
    losses = re.findall(r"^(?:overrun|commit overrun|dropped events): (\d+)$", stats, re.M)
    if not losses or any(int(count) for count in losses):
        raise ValueError(f"{name}: missing trace loss stats or nonzero loss")
    raw = Path(f"{prefix}-.trace-events").read_bytes()
    events = []
    for line in raw.decode().splitlines():
        if "fuse_request_send:" not in line and "fuse_request_end:" not in line:
            continue
        event = TRACE.fullmatch(line)
        if not event:
            raise ValueError(f"{name}: unreadable FUSE ftrace line")
        send = event["event"] == "fuse_request_send"
        body = (SEND if send else END).fullmatch(event["body"])
        if not body:
            raise ValueError(f"{name}: unreadable FUSE trace arguments")
        if body[1] != started["connection"]:
            continue
        ns = int(event["sec"]) * 1_000_000_000 + int(event["frac"].ljust(9, "0"))
        events.append((ns, int(event["cpu"]), int(event["pid"]), body, send))

    active = {}
    overlap = set()
    rows = defaultdict(lambda: {"counts": Counter(), "cpu": Counter(), "senders": Counter(), "delays": []})
    for now, cpu, pid, body, send in events:
        req = body[2]
        if send:
            if req in active:
                raise ValueError(f"{name}: duplicate request {req}")
            if active:
                overlap.update(active)
                overlap.add(req)
            active[req] = (now, cpu, pid, body[4])
            continue
        if req not in active:
            continue
        sent, sender_cpu, sender, opcode = active.pop(req)
        shared = req in overlap
        overlap.discard(req)
        if opcode != "FUSE_LOOKUP" or sender == observer or sent < window[0] or now > window[1]:
            continue
        row = rows["requester_pid" if sender == pid else "other_pid"]
        row["counts"]["overlap" if shared else "no_observed_overlap"] += 1
        row["cpu"][f"{sender_cpu}->{cpu}"] += 1
        row["senders"][str(sender)] += 1
        row["delays"].append(now - sent)

    return {
        "trace_sha256": hashlib.sha256(raw).hexdigest(),
        "connection": int(started["connection"]),
        "window_ns": window,
        "lookup_end_context": {
            context: {
                "count": len(row["delays"]),
                "overlap_counts": row["counts"],
                "send_cpu_to_end_cpu": row["cpu"],
                "sender_task_ids": row["senders"],
                "latency": percentile_latency(row["delays"]),
            }
            for context, row in rows.items()
        },
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("receipts", type=Path)
    args = parser.parse_args()
    base = json.loads((args.receipts / "measurement-summary.json").read_text())["git"]
    result = {
        "scope": "FUSE send-to-end overlap on one connection. Lack of observed overlap does not establish an empty virtqueue.",
    }
    for arm in ("off", "inline"):
        name = f"lookup-{arm}-measured-git"
        window = base[name]["ftrace_git_command_window"]["time_window_ns"]
        result[arm] = reconcile(args.receipts, name, window)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
