import json
from pathlib import Path
root = Path.cwd()
d = root/'bench/phase0-host-scheduling/docs/benchmarks/2026-11-26'
r = json.loads((d/'core-cli-exec.json').read_text())
name=d/'mounted-ci-gamma.md'
contents=name.read_text()
dens=r['eight_container_release']
for ep in ('HVF','Orb'):
    assert r['optimized_cli'][ep]['versions']['streaming']['sha256']==r['qualified_release']['sha256']
wall=lambda row:f"{row['median_ms']:,.1f} ms | {row['median_peak_rss_mib']:,.1f} MiB"
def make_table(key, historical):
    rows=['| Endpoint and client | 4 MiB wall | 4 MiB peak RSS | 32 MiB wall | 32 MiB peak RSS |',
          '|---|---:|---:|---:|---:|']
    for endpoint,label in [('HVF','HVF'),('Orb','OrbStack')]:
        data=r[key][endpoint]['performance']
        clients=([('previous','previous debug CLI'),('streaming','current debug CLI')] if historical
                 else [('streaming','Micropod release CLI'),('stock_docker','stock Docker CLI')])
        for arm,client in clients:
            rows.append(f"| {label}, {client} | {wall(data['4'][arm])} | {wall(data['32'][arm])} |")
    return '\n'.join(rows)
load=r['release_window_host_idle_percent']
wins={k:sum(x['hvf-'+k]['ms']<x['orb-'+k]['ms'] for x in dens['rounds']) for k in ['micropod','docker']}
med=dens['median_ms']
counts=[row['count'] for row in r['tests']]
first=f"""# Core Docker compatibility and mounted CI on Gamma

The native Micropod CLI streams binary output during exec, pipes stdin into the guest, preserves stderr and returns the guest exit code. On a raw 1,058-file mounted checkout, OrbStack still completed the warm Git, Go build and Go test sequence sooner. [Core CLI results](core-cli-exec.json) · [Mounted CI results](mounted-ci-gamma.json)

## The public CLI

The supervisor started a private four-vCPU, 4 GiB HVF machine through `micropod machine install` and `machine start`. Stock Docker and Micropod used its published Unix socket. The same Micropod CLI used OrbStack through the generic Docker adapter. The release client and supervisor had separate executable paths and recorded digests. All release client measurements used the ad-hoc-signed Swift release binary `{r['qualified_release']['sha256'][:16]}`. The source archive reconstructs the core changes against commit `{r['reconstruction']['base'][:12]}`. [Command, signing and machine receipts](mounted-ci-gamma-receipts.tar.gz) · [Reconstructable source](core-engine-sources.tar.gz)

A guest command waited for the host to receive its first output before it could finish. The new client exposed that output immediately, preserved stderr and returned exit 31. Other cases included NUL and invalid UTF-8 on both streams, empty stdin, a slow reader, and a guest exiting while its host stdin remained open. Eight simultaneous execs returned distinct bytes and exit codes. The Micropod release and stock Docker each passed all 15 checks on each endpoint. The previous client buffered the first marker and rejected piped stdin on HVF. [Byte hashes, exit codes and readiness checks](core-cli-exec.json)

### Single-client output

{make_table('optimized_cli',False)}

For the effect of the implementation change, both Micropod binaries below were compiled in debug mode. The comparison includes stdout writes to the host's real null device. Each cell is the median of three rotating client orders. Wall time includes process launch, exec creation, transfer and final exit inspection. RSS is peak host client memory. [Individual observations and executable hashes](core-cli-exec.json)

{make_table('development_same_build_mode',True)}

### Eight simultaneous CI containers

Each endpoint ran eight distinct Alpine containers, each limited to one CPU and 128 MiB. The harness waited until all eight guest processes reported ready, then sent each a different 2 MiB binary input. Every job returned its exact bytes, stderr marker and exit status. The table gives wall time for all eight jobs, from the first client launch until the last exit. All four engine/client combinations also returned the same 32 MiB SHA-256 digest into a regular host file. [Harness](../../../..//scripts/qualify_cli_exec_density.py) · [Paired rounds and per-job checks](core-cli-exec.json)

| Same client on both endpoints | Micropod HVF | OrbStack | HVF paired wins |
|---|---:|---:|---:|
| Micropod release CLI | {med['hvf-micropod']:,.1f} ms | {med['orb-micropod']:,.1f} ms | {wins['micropod']} of 4 |
| Stock Docker CLI | {med['hvf-docker']:,.1f} ms | {med['orb-docker']:,.1f} ms | {wins['docker']} of 4 |

The four counterbalanced rounds exercised 128 scored attachments, with an additional warmup for each combination. Both engines removed their eight test containers and returned an empty run-label query. The host was {load['before']:.1f}% idle before qualification and {load['after']:.1f}% idle afterward. [Raw timings and cleanup](core-cli-exec.json)

### Failure handling and API negotiation

An earlier development build timed out on OrbStack after sending all 32 MiB to the host null device. Its process sample showed a socket read waiting for the peer. The timing wrapper initially left its client alive. The operator identified and retired that client and verified the VM shutdown, released lock and removed socket. The wrapper now terminates its owned process group on timeout. After the HTTP upgrade the client now closes its write half when running output-only, matching the stock client's EOF behavior. The final release finished 24 further 32 MiB transfers on each engine, each with a six-second deadline. The sample identifies where the earlier process waited, but cannot establish what prevented peer EOF. [Original failure, process sample and repeats](mounted-ci-gamma-receipts.tar.gz) · [Stock Docker stream handling](https://github.com/docker/cli/blob/master/cli/command/container/hijack.go)

The generic adapter previously sent API 1.43 to a Micropod daemon advertising 1.44 through 1.47. Its container ownership lookup fell through to the disabled Apple backend. The adapter now negotiates a common API version before the first mutation and honors an explicit `DOCKER_API_VERSION`. Automatic selection and an explicit 1.44 pin both returned stdout `00 ff`, stderr `fe 5a` and exit 29 through the native guest. The runtime also rejects truncated HTTP responses, unfinished execs and malformed exit codes. {counts[0]} focused runtime and machine tests and {counts[1]} Docker shim tests passed. Native stress tests covered 7,500 output cancellation races and 6,000 input cancellation races while preserving the caller's descriptor flags. [Wire receipts, tests and native stress](mounted-ci-gamma-receipts.tar.gz) · [Docker Engine API versioning](https://docs.docker.com/reference/api/engine/)

"""
first=first.replace('../../../..//scripts/','../../../scripts/')
name.write_text(first+contents[contents.index('## Host-mounted CI'):])
e=Path('/Users/benebsworth/.gemini/antigravity-cli/brain/21a43f43-d653-48e2-b889-4bb93e3455f6')
score=root/'bench/phase0-host-scheduling/docs/benchmarks/2026-11-26/mounted-ci-gamma.md'
new=f"""The release CLI passed all 15 binary exec checks on both the public Micropod HVF socket and OrbStack, then completed 24 output-only 32 MiB transfers on each engine. With eight independent CI containers, the same release CLI completed each wave in a median {med['hvf-micropod']:.1f} ms on HVF and {med['orb-micropod']:.1f} ms on OrbStack. The raw 1,058-file mounted Git/build/test sequence took 926.8 and 825.8 ms warm. Native terminal exec, stock Docker PID 1 attach, a sustained soak and clean signed installation remain release gates. [Gamma qualification]({score})"""
q=e/'walkthrough.md'
before=q.read_text()
import re
before, count = re.subn(r'(## Binary CLI exec and host-mounted CI\n\n)[^\n]+',lambda m:m[1]+new,before,count=1)
assert count == 1
q.write_text(before)
q=e/'implementation_plan.md'
text=q.read_text()
if '## Signed release CLI qualification' not in text:
    q.write_text(text.rstrip()+'\n\n## Signed release CLI qualification\n\n'+new+'\n')
