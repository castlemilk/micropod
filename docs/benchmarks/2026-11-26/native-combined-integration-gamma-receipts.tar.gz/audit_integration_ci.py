"""Confirm all stock CI containers are absent on both explicit endpoints."""
import json
import os
from pathlib import Path
import subprocess

receipts = Path(__file__).resolve().parent
ready = json.loads((receipts / 'combined-ready.json').read_bytes())
env = {key: value for key, value in os.environ.items()
       if key not in ('DOCKER_CONTEXT', 'DOCKER_HOST', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY',
                      'DOCKER_CERT_PATH', 'DOCKER_API_VERSION')}
engines = {
    'orbstack': '/Users/benebsworth/.orbstack/run/docker.sock',
    'hvf': ready['socket'],
}


def run(prefix, *args):
    return subprocess.run([*prefix, *args], capture_output=True, text=True, timeout=20, env=env)


for jobs in (8, 16):
    path = receipts / f'combined-ci{jobs}.json'
    raw = json.loads(path.read_bytes()) if path.is_file() else {}
    result = {}
    for engine, socket in engines.items():
        docker = ['/opt/homebrew/bin/docker', '--host', 'unix://' + socket]
        if raw:
            known = [job['container_id'] for job in raw['arms'][engine]['jobs']]
            assert len(known) == len(set(known)) == jobs
            inspected = run(docker, 'container', 'inspect', *known)
            assert inspected.returncode and (not inspected.stdout.strip() or json.loads(inspected.stdout) == [])
            for key in known:
                if key in inspected.stderr:
                    continue
                missing = run(docker, 'container', 'inspect', key)
                assert missing.returncode and key in missing.stderr, (engine, key, missing.stderr)
                assert not missing.stdout.strip() or json.loads(missing.stdout) == []
        else:
            known = []
        filters = ['--filter', f'ancestor={ready["benchmark_image"]}'] if engine == 'orbstack' else []
        listed = run(docker, 'ps', '--no-trunc', '-aq', *filters)
        assert listed.returncode == 0 and not listed.stdout.strip(), (engine, listed.stderr)
        result[engine] = {'owned_ids': known, 'remaining': listed.stdout.splitlines()}
    with (receipts / f'combined-ci{jobs}-cleanup.json').open('x') as output:
        json.dump(result, output, indent=2)
        output.write('\n')
