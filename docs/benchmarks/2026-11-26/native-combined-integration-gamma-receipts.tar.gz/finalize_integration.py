"""Retire the combined integration worker and archive its exact CI and stock wire evidence."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import plistlib
import shutil
import subprocess
import sys
import tarfile
import time

import worker_apfs_drive as apfs

receipts = Path(__file__).resolve().parent
scope = receipts.parent
hub = scope / 'home'
assert scope.parent == Path('/private/tmp') and scope.name.startswith('mp-gamma5.')
suffix = scope.name.removeprefix('mp-gamma5.').lower()
worktree = Path(sys.argv[1]).resolve(strict=True)
results = worktree / 'docs/benchmarks/2026-11-26'
scorecard = results / 'native-combined-integration-gamma.json'
archive = results / 'native-combined-integration-gamma-receipts.tar.gz'
assert not scorecard.exists() and not archive.exists()


def read(path):
    return json.loads(path.read_bytes())


def write(path, data):
    pending = path.with_name(path.name + '.writing')
    pending.write_text(json.dumps(data, indent=2) + '\n')
    pending.replace(path)


def sha(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()


def run(argv, *, check=True, timeout=55):
    return subprocess.run(argv, text=True, capture_output=True, timeout=timeout, check=check)


def mounted_images():
    payload = subprocess.check_output(['/usr/bin/hdiutil', 'info', '-plist'], timeout=40)
    return {image['image-path'] for image in plistlib.loads(payload)['images'] if image.get('image-path')}


def archive_receipts():
    items = {path.relative_to(receipts).as_posix(): path for path in sorted(receipts.rglob('*'))
             if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts}
    assert all('registry-fixture' not in path.parts and not path.name.endswith('.key')
               and 'workspace-irq-token' not in path.name for path in items.values())
    manifest = {name: sha(path) for name, path in items.items()}
    payload = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    pending = archive.with_suffix(archive.suffix + '.pending')
    with pending.open('xb') as file, gzip.GzipFile(filename='', fileobj=file, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w|') as raw:
            for name, path in items.items():
                row = raw.gettarinfo(path, arcname=name)
                row.uid = row.gid = row.mtime = 0
                row.uname = row.gname = ''
                with path.open('rb') as source:
                    raw.addfile(row, source)
            row = tarfile.TarInfo('MANIFEST.sha256.json')
            row.size = len(payload)
            row.mode = 0o644
            raw.addfile(row, io.BytesIO(payload))
    with tarfile.open(pending) as raw:
        assert read_manifest(raw) == manifest and set(raw.getnames()) == set(manifest) | {'MANIFEST.sha256.json'}
        for name, digest in manifest.items():
            with raw.extractfile(name) as content:
                assert hashlib.file_digest(content, 'sha256').hexdigest() == digest, name
    pending.replace(archive)
    return {'path': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size, 'entries': len(manifest)}


def read_manifest(raw):
    with raw.extractfile('MANIFEST.sha256.json') as data:
        return json.load(data)


def worker_audit():
    workers = {}
    attached = mounted_images()
    for path in sorted(receipts.glob('*-worker.json')):
        worker = read(path)
        retirement = worker['drive']['detached']
        policy = retirement['persisted_policy']
        machine = worker['machine']
        assert not worker['errors'] and worker['scope_absent'] and machine['clean_shutdown'], path
        assert not machine['scoped_processes_after_stop'] and machine['supervisor_lock_released'] and machine['defaults_unchanged'], path
        assert retirement['image_absent'] and retirement['mount_restored'] and worker['image'] not in attached, path
        assert not any(Path(worker[key]).exists() for key in ('socket', 'image', 'worker_directory')), path
        assert policy['mounted_read_only'] and policy['spotlight']['disabled'] and policy['raw_disk_unchanged'], path
        assert policy['markers_unchanged'] and policy['journal_unchanged'], path
        assert policy['fsevents']['journal_files'] == policy['fsevents']['journal_bytes'] == 0, path
        workers[worker['label']] = {'image': worker['image'], 'uuid': policy['volume']['uuid'], 'clean_shutdown': True,
                                    'read_only': True, 'spotlight_disabled': True, 'fsevents_files': 0, 'fsevents_bytes': 0,
                                    'raw_identity_preserved': True, 'defaults_unchanged': True, 'removed': True,
                                    'artifacts': worker['owned_artifacts']}
    assert workers and str(scope / 'hub.sparseimage') in attached
    return workers


def audit_reference(docker, image):
    assert image['tag'] == f'micropod-qa/checkout:gamma5-{suffix}'
    assert run([*docker, 'image', 'inspect', '--format', '{{.Id}}', image['tag']]).stdout.strip() in (
        image['config_digest'], image['manifest_digest'])
    assert not run([*docker, 'ps', '-aq', '--filter', f'ancestor={image["tag"]}']).stdout.strip()
    assert not run([*docker, 'ps', '-aq', '--filter', f'label={image["label"]}']).stdout.strip()
    assert run([*docker, 'image', 'inspect', '--format', '{{.Id}}', image['base']]).stdout.strip() == image['source_config']


def previous_products():
    preceding = results / 'native-push-and-fuse-gamma.json'
    archive_path = results / 'native-push-and-fuse-gamma-receipts.tar.gz'
    expected = {
        preceding: '4f25412cb1d7bf9f51537aafcaddf7498f7b4459a9f29dae5696f17c1894e60b',
        archive_path: '951a630fffc76a5ded5f13a9e8372effca3a645b69813c4e4ff4f6d53dd4c21a',
    }
    lineage = read(receipts / 'integration-lineage.json')
    for role, artifact in lineage['artifacts'].items():
        expected[Path(artifact['source'])] = artifact['sha256']
        if role in ('cli', 'vmm'):
            run(['/usr/bin/codesign', '--verify', '--strict', '--verbose=4', artifact['source']])
    for category in ('retained_manifest', 'source_archive'):
        row = lineage[category]
        expected[Path(row['path'])] = row['sha256']
    original = read(preceding)
    expected.update({Path(path): digest for path, digest in original['prior_preservation'].items()})
    for path, digest in expected.items():
        assert sha(path) == digest, path
    return {str(path): digest for path, digest in expected.items()}


def copy_exact_fixture():
    base = hub / 'evidence/prior'
    lineage = read(receipts / 'integration-lineage.json')
    original = base / 'final-harness'
    fixed = base / 'bounded-harness'
    proof = {}
    for path in sorted(original.rglob('*')):
        if not path.is_file():
            continue
        assert path.resolve(strict=True) == path and '__pycache__' not in path.parts
        name = path.relative_to(base).as_posix()
        assert sha(path) == lineage['source_archive']['files'][name], name
        target = receipts / 'fixture-source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        proof[target.relative_to(receipts).as_posix()] = sha(target)
    source = fixed / 'scripts/bench_workspace_checkout.py'
    assert source.resolve(strict=True) == source and sha(source) == lineage['drivers']['ci16']
    target = receipts / 'fixture-source' / source.relative_to(base)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    proof[target.relative_to(receipts).as_posix()] = sha(target)
    startup = hub / 'artifacts/tools-combined/runner/start.sh'
    target = receipts / 'fixture-source/tools-combined-start.sh'
    assert startup.resolve(strict=True) == startup
    shutil.copy2(startup, target)
    proof[target.relative_to(receipts).as_posix()] = sha(target)
    return proof


def retire_hub(workers, created):
    argv = ['/usr/sbin/lsof', '-nP', '+f', '--', str(hub)]
    try:
        scan = run(argv, check=False)
    except subprocess.TimeoutExpired as error:
        write(receipts / 'hub-holders-first-timeout.json', {'argv': argv, 'failure': repr(error)})
        scan = run(argv, check=False)
    write(receipts / 'hub-holders-final.json', {'argv': argv, 'exit': scan.returncode,
                                             'stdout': scan.stdout, 'stderr': scan.stderr})
    assert scan.returncode == 1 and not scan.stdout.strip() and not scan.stderr.strip()
    live = apfs.verify(created)
    write(receipts / 'hub-final-live.json', live)
    result = apfs.detach(created, remove_image=True, inspect_history=True)
    write(receipts / 'hub-detached.json', result)
    persisted = result['persisted_policy']
    assert result['image_absent'] and result['mount_restored'] and persisted['mounted_read_only']
    assert persisted['spotlight']['disabled'] and persisted['markers_unchanged'] and persisted['journal_unchanged']
    assert persisted['fsevents']['journal_files'] == persisted['fsevents']['journal_bytes'] == 0
    hub.rmdir()
    owned = {worker['image'] for worker in workers.values()} | {created['image']}
    assert not (mounted_images() & owned) and not any(Path(path).exists() for path in owned)
    return {'uuid': live['volume']['uuid'], 'read_only_remount': True, 'spotlight_disabled': True,
            'fsevents_files': 0, 'fsevents_bytes': 0, 'image_removed': True}


def main():
    workers = worker_audit()
    assert set(workers) == {'combined'}
    assert not (hub / 'registry-fixture').exists(), 'the registry fixture owner has not released its private inputs'
    preservation = previous_products()
    source = copy_exact_fixture()
    summary = json.loads(run([sys.executable, '-B', str(receipts / 'summarize_integration.py')]).stdout)
    write(receipts / 'integration-summary.json', summary)
    write(receipts / 'prior-artifacts-final.json', preservation)
    write(receipts / 'fixture-source-manifest.json', source)

    for key in ('DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH', 'DOCKER_API_VERSION'):
        os.environ.pop(key, None)
    docker = ['/opt/homebrew/bin/docker', '--host', 'unix:///Users/benebsworth/.orbstack/run/docker.sock']
    image = read(receipts / 'image.json')
    audit_reference(docker, image)
    hub_result = retire_hub(workers, read(receipts / 'hub-created.json'))
    audit_reference(docker, image)
    run([*docker, 'image', 'rm', image['tag']])
    absent = run([*docker, 'image', 'inspect', image['tag']], check=False)
    assert absent.returncode and any(marker in absent.stderr.lower() for marker in ('no such', 'not found'))
    assert run([*docker, 'image', 'inspect', '--format', '{{.Id}}', image['base']]).stdout.strip() == image['source_config']
    cleanup = {'worker_volumes': workers, 'hub': hub_result, 'owned_orbstack_tag_removed': True,
               'owned_orbstack_builder_removed': image['builder_removed'], 'preexisting_orbstack_base_preserved': True}
    write(receipts / 'final-cleanup.json', cleanup)
    result = archive_receipts()
    assert list(scope.iterdir()) == [receipts] and not any(path.is_socket() for path in receipts.rglob('*'))
    assert not scope.is_mount() and not receipts.is_mount()
    shutil.rmtree(receipts)
    scope.rmdir()
    cleanup['private_stage_removed'] = not scope.exists()
    summary.update(cleanup=cleanup, receipts=result, prior_preservation=preservation, archived_fixture_sources=source)
    write(scorecard, summary)
    print(scorecard, sha(scorecard), archive, result['sha256'], flush=True)


if __name__ == '__main__':
    main()
