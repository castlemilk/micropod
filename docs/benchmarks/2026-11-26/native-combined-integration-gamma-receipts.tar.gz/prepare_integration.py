"""Stage only the exact combined runtime and prior seven-file CI fixtures."""
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tarfile

receipts = Path(__file__).resolve().parent
hub = receipts.parent / 'home'
repo = Path('/Users/benebsworth/projects/micropod')
reports = repo / 'bench/phase0-host-scheduling/docs/benchmarks'
qualified = repo / '.build/qualified/micropod-hvf-gamma4-vuwhjq/manifest.json'
artifacts = hub / 'artifacts'
suite = hub / 'evidence/prior/final-harness'
assert hub.is_mount() and artifacts.is_dir()
(hub / 'share').mkdir(mode=0o700)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


source_archive = reports / '2026-11-25/managed-ci-git-and-exec-sources.tar.gz'
assert sha(source_archive) == '052718b726d6d494c64e772615107df563472151042d6862b991d3d6f623b9e7'
source_entries = {
    'scripts/bench_workspace_checkout.py', 'scripts/bench_workspace_edits.py',
    'scripts/workspacebench/main.go',
    *{f'guest/{file}' for file in ('files.go', 'go.mod', 'go.sum', 'guest_test.go', 'idle.go', 'main.go', 'watch.go')},
}
selected = {}
with tarfile.open(source_archive) as archive:
    manifest = json.load(archive.extractfile('MANIFEST.sha256.json'))
    for suffix in sorted(source_entries):
        name = f'final-harness/{suffix}'
        assert '..' not in PurePosixPath(name).parts
        row = archive.getmember(name)
        assert row.isfile()
        payload = archive.extractfile(row).read()
        assert hashlib.sha256(payload).hexdigest() == manifest[name]
        target = suite / suffix
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(payload)
        selected[name] = manifest[name]

driver = suite / 'scripts/bench_workspace_checkout.py'
unbounded = 'aeafda39ff303636ec58f02d6f4d55d55158720417ed62c06e65924232ceeb12'
bounded = '33ee9434bdc452785ca8cacb6bedbeaeceaa067ae0f3399de0b3e696f747c1ac'
assert sha(driver) == unbounded
fork = suite.parent / 'bounded-harness'
shutil.copytree(suite, fork)
with (receipts / 'bounded-cold-prime.patch').open('rb') as patch:
    subprocess.run(['/usr/bin/patch', '-p1', '-f', '--fuzz=0'], cwd=fork, stdin=patch, check=True)
assert sha(fork / 'scripts/bench_workspace_checkout.py') == bounded

assert sha(qualified) == '663498e4addca168e129e01703a660e2422b624a6819f40f759eb013d8352a8f'
index = json.loads(qualified.read_bytes())
refs = {role: index['production_lineage'][role] for role in ('vmm', 'initrd', 'cli')}
refs['kernel'] = index['artifacts']['matched_fuse_release_experiment_kernel']
refs['job'] = index['artifacts']['runner_with_native_registry_push_and_auth']
paths = {'vmm': 'micropod-vmm', 'initrd': 'mp-hvf-init.cpio', 'cli': 'cli-baseline/micropod',
         'kernel': 'Image', 'job': 'tools-baseline/runner/bin/job'}
with gzip.open(reports / '2026-11-21/gamma-vcpu-priority.json.gz', 'rt') as data:
    installation = json.load(data)['installation']
tools = Path(installation['path']) / 'micropod-oci-tools'
shutil.copytree(tools, artifacts / 'tools-baseline', symlinks=True)
for name, digest in installation['tools'].items():
    assert sha(artifacts / 'tools-baseline' / name) == sha(tools / name) == digest, name
shutil.copytree(Path(refs['cli']['path']).parent, artifacts / 'cli-baseline', symlinks=True)
roles = {}
for role, item in refs.items():
    source = Path(item['path'])
    target = artifacts / paths[role]
    assert sha(source) == item['sha256']
    if role != 'cli':
        shutil.copy2(source, target)
    assert sha(target) == item['sha256']
    roles[role] = {'source': str(source), 'staged': str(target), 'sha256': item['sha256']}
for role in ('cli', 'vmm'):
    subprocess.run(['/usr/bin/codesign', '--verify', '--strict', roles[role]['staged']], check=True)
probe = suite / 'scripts/workspacebench/main.go'
env = dict(os.environ, GOOS='linux', GOARCH='arm64', CGO_ENABLED='0')
subprocess.run(['go', 'build', '-trimpath', '-o', artifacts / 'fsprobe', probe], env=env, check=True)
lineage = {'retained_manifest': {'path': str(qualified), 'sha256': sha(qualified)}, 'artifacts': roles,
           'source_archive': {'path': str(source_archive), 'sha256': sha(source_archive), 'files': selected},
           'drivers': {'ci8': unbounded, 'ci16': bounded}, 'tool_bank_entries': len(installation['tools']),
           'tool_bank_source': str(tools), 'fsprobe': {'source_sha256': sha(probe), 'binary_sha256': sha(artifacts / 'fsprobe')}}
(receipts / 'integration-lineage.json').write_text(json.dumps(lineage, indent=2) + '\n')
