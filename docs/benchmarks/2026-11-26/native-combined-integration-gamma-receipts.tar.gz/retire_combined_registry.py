"""Retire the integrated worker's private test CA and verified registry archive."""
import hashlib
import json
from pathlib import Path
import stat
import sys

e = Path(__file__).resolve().parent
h = e.parent / "home"
fixture = h / "registry-fixture"
assert h.is_mount() and fixture.resolve(strict=True) == fixture
release = sys.argv[1]
assert release.isalnum() and release.isascii()
out = e / ("docker-" + release)
for name in ("retention", "registry"):
    case = json.loads((out / (name + ".json")).read_bytes())
    assert case["passed"] and all(case["cleanup"].values())
    if name == "registry":
        assert not case["private_image_ids_until_worker_disposal"] and case["removal_during_push"]["absent_during_push"]
files = {"ca-openssl.log","registry-release.tar.gz","test-ca.crt","test-ca.key"}
assert {p.name for p in fixture.iterdir()} == files and all(stat.S_ISREG((fixture/n).lstat().st_mode) for n in files)
assert hashlib.sha256((fixture/"registry-release.tar.gz").read_bytes()).hexdigest() == "09d26f88d2c0f161bd1b8bfc6c123571cc3d291dcca8af5477b3cacc4ec95e73"
for file in sorted(files):
    (fixture / file).unlink()
fixture.rmdir()
assert not fixture.exists()
with (e / "registry-fixture-removed.json").open("x") as receipt:
    json.dump({"directory_absent":True,"owned_files_removed":len(files),"final_wire":release}, receipt, indent=2)
    receipt.write("\n")
