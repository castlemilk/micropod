"""Check the integrated public worker, then replay stock Docker image and registry exercises."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from uuid import uuid4

e = Path(__file__).resolve().parent
h = e.parent / "home"
repo = Path("/Users/benebsworth/projects/micropod/bench/phase0-host-scheduling")
scripts = repo / "scripts"
release = sys.argv[1]
assert release.isascii() and release.isalnum()
ready = json.loads((e / "combined-ready.json").read_bytes())
socket = Path(ready["socket"])
assert socket.is_socket() and socket.is_relative_to(Path(ready["worker_directory"])) and ready["label"] == "combined"
expected = {"kernel": "61b4e143b26039e4642f48b3819e0233f22b44f5c3e88e109cbc9c17508cc85f",
            "vmm": "4b25f7d3ae9a43ff4dbfdbfc13b30834e928fda7ac3b429ff4564a7cf3099264",
            "job": "e00d6da9b0b2f95fbc0cb9a5609972df2f479ddec8ffb3340e2f7cbb80db2072"}
actual = {k: ready["owned_artifacts"][k]["sha256"] for k in expected}
assert actual == expected
out = e / ("docker-" + release)
out.mkdir()
fixture = h / "registry-fixture"
env = {k:v for k,v in os.environ.items() if not k.startswith("DOCKER_")}
env.update(DOCKER_CLI_HINTS="false")
docker = ["docker", "--host", "unix://" + str(socket)]
label = "io.micropod.combined-mode=" + uuid4().hex
try:
    bits = subprocess.check_output([*docker, "run", "--rm", "--label", label, "--pull=never", "--network", "none",
        "--entrypoint", "/bin/sh", ready["benchmark_image"], "-ec",
        'cat /sys/module/virtiofs/parameters/workspace_async_release; uname -r'], env=env, timeout=20).decode().splitlines()
    assert bits == ["Y", "7.3.5-micropod-b5"], bits
finally:
    retained = subprocess.check_output([*docker, "ps", "-aq", "--filter", "label=" + label], timeout=10, env=env).splitlines()
    if retained:
        subprocess.run([*docker, "rm", "-f", *[x.decode() for x in retained]], check=True, timeout=10, env=env)
    assert not subprocess.check_output([*docker,"ps","-aq","--filter","label="+label],env=env,timeout=10).strip()
inputs = {}
for name in ("qualify_docker_push.py", "qualify_docker_image_id.py", "qualify_engine_api.py", "qualify_docker_image_history.py", "ci_benchmark_store.py"):
    shutil.copyfile(scripts / name, out / name)
    inputs[name] = hashlib.sha256((out / name).read_bytes()).hexdigest()
(out / "live-combination.json").write_text(json.dumps({"artifacts":actual,"sysfs_async_release":bits[0],"uname":bits[1],"drivers":inputs},indent=2)+"\n")
for name,argv in (("retention",[out/"qualify_docker_image_id.py","--native"]),
                  ("registry",[out/"qualify_docker_push.py","--active-removal","--worker-image",ready["benchmark_image"],
                               "--ca-cert",fixture/"test-ca.crt","--ca-key",fixture/"test-ca.key","--registry-archive",fixture/"registry-release.tar.gz"])):
    with (out/(name+".log")).open("xb") as log:
        subprocess.run([sys.executable,"-B",*argv,"--socket",socket,"--output",out/(name+".json")],
                       check=True,stdout=log,stderr=subprocess.STDOUT,timeout=100,env=env)
    row=json.loads((out/(name+".json")).read_bytes())
    assert row["passed"] and all(row["cleanup"].values())
print("combined worker passed stock retention and private TLS registry")
