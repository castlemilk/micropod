#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
H="$(dirname "$D")/home"
r="$D/combined-ready.json"
orb=/Users/benebsworth/.orbstack/run/docker.sock
sock=$(jq -er .socket "$r")
work=$(jq -er .workspace "$r")
image=$(jq -er .benchmark_image "$r")
test -S "$sock" && test -S "$orb"
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH DOCKER_API_VERSION
docker=(/opt/homebrew/bin/docker --host "unix://$sock")
"${docker[@]}" run --rm --network=none --pull=never --entrypoint /bin/cat "$image" \
    /sys/module/virtiofs/parameters/workspace_async_release > "$D/combined-async-release-mode.txt"
test "$(cat "$D/combined-async-release-mode.txt")" = Y
test -z "$("${docker[@]}" ps -aq)"
base="$H/evidence/prior"
common=(--hvf-socket "$sock" --orbstack-socket "$orb" --workspace "$work" --image "$image"
        --image-manifest "$D/image-manifest.json" --go-version 1.26.11 --pairs 4 --job-memory-mib 384)
status=0
for jobs in 8 16; do
    if [[ $jobs == 8 ]]; then
        driver="$base/final-harness/scripts/bench_workspace_checkout.py"
        sha=aeafda39ff303636ec58f02d6f4d55d55158720417ed62c06e65924232ceeb12
        flags=(--job-cpus 0.5)
    else
        driver="$base/bounded-harness/scripts/bench_workspace_checkout.py"
        sha=33ee9434bdc452785ca8cacb6bedbeaeceaa067ae0f3399de0b3e696f747c1ac
        flags=(--job-cpus 0.25 --prime-jobs 8)
    fi
    test "$(shasum -a 256 "$driver" | cut -d' ' -f1)" = "$sha"
    phase="combined-ci$jobs"
    set +e
    python3 -B "$D/with_host_load.py" --out "$D/$phase-host-load.jsonl" -- \
        python3 -B "$driver" "${common[@]}" --jobs "$jobs" --out "$D/$phase.json" "${flags[@]}" \
        > "$D/$phase.log" 2>&1
    result=$?
    set -e
    printf '%s\n' "$result" > "$D/$phase.exit"
    "${docker[@]}" ps --no-trunc -aq > "$D/$phase-native-cleanup.txt"
    test ! -s "$D/$phase-native-cleanup.txt"
    if [[ $result != 0 ]]; then status=1; fi
done
set +e
bash "$D/run_gamma4_arm.sh" combined correctness > "$D/combined-stock-held.log" 2>&1
ordinary=$?
set -e
if [[ $ordinary != 0 ]]; then status=1; fi
printf 'ci8=%s ci16=%s stock_held=%s\n' "$(cat "$D/combined-ci8.exit")" "$(cat "$D/combined-ci16.exit")" "$ordinary" |
    tee "$D/combined-qualification-exit.log"
exit "$status"
