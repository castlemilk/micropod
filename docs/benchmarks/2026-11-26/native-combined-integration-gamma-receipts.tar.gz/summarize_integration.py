"""Reconcile the actual combined public worker's CI waves and stock protocol receipts."""
from collections import Counter
import hashlib
import json
from pathlib import Path
from statistics import median

receipts = Path(__file__).resolve().parent


def data(path):
    return json.loads(path.read_bytes())


def digest(path):
    with path.open('rb') as raw:
        return hashlib.file_digest(raw, 'sha256').hexdigest()


def proof(path):
    return {'path': path.relative_to(receipts).as_posix(), 'sha256': digest(path)}


def ambient(path):
    rows = [json.loads(row) for row in path.read_bytes().splitlines()]
    samples = [row for row in rows if row.get('cpu_idle_pct') is not None]
    ticks = Counter()
    for row in samples:
        ticks.update(row['delta_ticks'])
    idle = [row['cpu_idle_pct'] for row in samples]
    return {'receipt': proof(path), 'samples': len(samples), 'command_exit': rows[-1]['code'],
            'start_utc': rows[0]['utc'], 'end_utc': rows[-2]['utc'],
            'weighted_cpu_idle_pct': 100 * ticks['idle'] / ticks.total(),
            'window_cpu_idle_pct_min_median_max': [min(idle), median(idle), max(idle)],
            'load_1_minimum_maximum': [min(row['load_average'][0] for row in samples),
                                      max(row['load_average'][0] for row in samples)]}


def milliseconds(ns):
    return ns / 1_000_000


def score(count, lineage):
    name = f'combined-ci{count}'
    path = receipts / f'{name}.json'
    result = {'status': int((receipts / f'{name}.exit').read_text()), 'driver': lineage['drivers'][f'ci{count}'],
              'host': ambient(receipts / f'{name}-host-load.jsonl')}
    if not path.is_file():
        result['failure_log'] = proof(receipts / f'{name}.log')
        return result
    raw = data(path)
    assert raw['driver_sha256'] == result['driver'] and raw['jobs_per_engine'] == count and len(raw['pairs']) == 4
    assert result['status'] == result['host']['command_exit'] == 0
    result.update(receipt=proof(path), fixture_commit=raw['fixture_git_commit'], source_sha256=raw['fixture_source_sha256'],
                  image=raw['image'], jobs=count, cpus=raw['cpus'], memory_mib=raw['memory_mib'],
                  go_parallelism=raw['go_parallelism'], timed_scope=raw['timing_scope'],
                  warm_binary_sha256=raw['warm_artifact_sha256'], cold={}, waves={}, cleanup={}, sample_order=[])
    for count_no, pair in enumerate(raw['pairs'], 1):
        assert pair['pair'] == count_no
        result['sample_order'].append(pair['order'])
    cleanup_receipt = receipts / f'{name}-cleanup.json'
    result['cleanup_receipt'] = proof(cleanup_receipt)
    cleanup = data(cleanup_receipt)
    for engine in raw['arms']:
        clean = cleanup[engine]
        assert len(clean['owned_ids']) == count and not clean['remaining']
        result['cleanup'][engine] = clean
        priming = raw['priming'][engine]
        groups = priming.get('groups', [priming])
        assert len(groups) == (1 if count == 8 else 2)
        assert all(len(group['jobs']) == 8 for group in groups)
        result['cold'][engine] = {'groups': len(groups), 'max_simultaneous_jobs': 8,
                                  'makespan_ms_by_group': [milliseconds(group['makespan_ns']) for group in groups],
                                  'measured_host_wall_ms': milliseconds(priming['host_wall_ns'])
                                  if 'host_wall_ns' in priming else None}
    for phase in ('warm', 'incremental'):
        rows = [pair[phase] for pair in raw['pairs']]
        engines = {}
        for engine in ('hvf', 'orbstack'):
            batches = [sample[engine] for sample in rows]
            assert all(batch['peak_scored_parallelism'] == count and len(batch['jobs']) == count
                       and batch['all_jobs_overlap_ns'] > 0 for batch in batches)
            engines[engine] = {'wave_median_ms': median(milliseconds(b['makespan_ns']) for b in batches),
                               'all_jobs_overlap_median_ms': median(milliseconds(b['all_jobs_overlap_ns']) for b in batches),
                               'all_jobs_overlap_minimum_ms': min(milliseconds(b['all_jobs_overlap_ns']) for b in batches),
                               'peak_overlap_by_wave': [b['peak_scored_parallelism'] for b in batches],
                               'job_phase_median_ms': {
                                   name: median(milliseconds(job['phase_timings'][name]['elapsed_ns'])
                                                for batch in batches for job in batch['jobs'])
                                   for name in ('git_status', 'go_build', 'go_test')},
                               'wave_all_jobs_phase_overlap_median_ms': {
                                   name: median(milliseconds(batch['all_jobs_overlap_by_phase_ns'][name])
                                                for batch in batches)
                                   for name in ('git_status', 'go_build', 'go_test')}}
        wins = sum(pair['hvf']['makespan_ns'] < pair['orbstack']['makespan_ns'] for pair in rows)
        result['waves'][phase] = {'engines': engines, 'hvf_wins': wins,
                                  'paired_hvf_over_orbstack': [
                                      pair['hvf']['makespan_ns'] / pair['orbstack']['makespan_ns'] for pair in rows]}
    return result


def main():
    lineage = data(receipts / 'integration-lineage.json')
    ready_path = receipts / 'combined-ready.json'
    worker = data(ready_path)
    installation = worker['owned_artifacts']
    assert all(installation[role]['sha256'] == meta['sha256'] for role, meta in lineage['artifacts'].items())
    profile = {'host': 'Gamma-128GB.local', 'date_melbourne': '2026-11-26',
               'worker': proof(ready_path), 'runtime': installation, 'lineage': lineage,
               'image': data(receipts / 'image.json'), 'kernel_args': worker['kernel_arguments_requested'],
               'async_release_sysfs': (receipts / 'combined-async-release-mode.txt').read_text().strip(),
               'fixture_public_trust': proof(receipts / 'tools-combined-lineage.json'),
               'ci': {str(count): score(count, lineage) for count in (8, 16)},
               'stock_filesystem': {},
               'wire_and_stock': {}}
    for pattern in ('combined-edits.json', 'combined-mmap-exact.json', 'combined-guest-splice.json',
                    'combined-stock-pid1.json', 'combined-correctness-exit.log'):
        path = receipts / pattern
        if path.is_file():
            profile['stock_filesystem'][pattern] = proof(path)
    final = receipts / 'docker-final01'
    if final.is_dir():
        registry = data(final / 'registry.json')
        retention = data(final / 'retention.json')
        live = data(final / 'live-combination.json')
        assert registry['passed'] and retention['passed'] and live['sysfs_async_release'] == 'Y'
        assert all(registry['cleanup'].values()) and all(retention['cleanup'].values())
        assert not registry['private_image_ids_until_worker_disposal']
        profile['live_registry'] = {
            'registry_receipt': proof(final / 'registry.json'), 'retention_receipt': proof(final / 'retention.json'),
            'live_combination_receipt': proof(final / 'live-combination.json'),
            'verified_registry_release': registry['release'], 'registry_api': registry['api'],
            'strict_tls_and_basic_auth': registry['tls_and_basic_auth'],
            'concurrent_push_overlap_ms': registry['eight_concurrent_publications']['all_streams_overlap_ms'],
            'push_request_to_last_eof_ms': registry['eight_concurrent_publications']['first_request_to_last_eof_ms'],
            'private_ids_removed': len(registry['private_image_id_removal']),
            'registry_objects_absent': registry['cleanup'], 'stock_retention_and_short_id_passed': retention['passed'],
        }
    for pattern in ('*wire*', '*registry*', '*retention*', '*image-id*', 'docker-final*'):
        for path in sorted(receipts.glob(pattern)):
            if path.is_file():
                profile['wire_and_stock'][path.name] = proof(path)
            elif path.is_dir():
                for file in sorted(path.rglob('*')):
                    if file.is_file() and not file.is_symlink():
                        profile['wire_and_stock'][file.relative_to(receipts).as_posix()] = proof(file)
    print(json.dumps(profile, indent=2))


if __name__ == '__main__':
    main()
