"""Freeze the exact Linux runner files relative to the previously tested registry guest."""
import argparse
import difflib
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, obj):
    path.write_text(json.dumps(obj, sort_keys=True, indent=2) + "\n")


parser = argparse.ArgumentParser()
parser.add_argument("--label", default="registry-id")
parser.add_argument("--stage", default="image-prune")
parser.add_argument("--new", nargs="+", required=True)
parser.add_argument("--change", nargs="+", required=True)
args = parser.parse_args()
e = Path(__file__).resolve().parent
hub = e.parent / "home"
report, stage = e / args.label, hub / args.stage
src = stage / "source/guest/runner"
src.mkdir(parents=True)
report.mkdir(exist_ok=True)
live = Path("/Users/benebsworth/projects/micropod/bench/phase0-host-scheduling/guest/runner")
before = hub / "image-push/source/guest/runner"
parent = json.loads((e / "registry/source.json").read_bytes())["source_files"]
parent_build = json.loads((e / "registry/build.json").read_bytes())
inputs = {}
patch = []
for name in sorted(set(parent) | set(args.new)):
    old = (before / name).read_bytes() if name in parent else b""
    data = (live / name).read_bytes()
    if name in parent:
        assert sha(old) == parent[name], name
    if data != old:
        assert name in args.change or name in args.new, name
        a = ("a/guest/runner/" + name) if name in parent else "/dev/null"
        b = "b/guest/runner/" + name
        patch.extend(difflib.unified_diff(old.decode().splitlines(True), data.decode().splitlines(True), a, b))
    elif name in args.new:
        raise ValueError(name)
    (src / name).write_bytes(data)
    inputs[name] = sha(data)
(report / "source.patch").write_text("".join(patch))
source_tar = report / "source.tar.gz"
with source_tar.open("xb") as stream, gzip.GzipFile(fileobj=stream, mode="wb", filename="", mtime=0) as compressed:
    with tarfile.open(mode="w", fileobj=compressed) as tar:
        for name in sorted(inputs):
            data = (src / name).read_bytes()
            f = tarfile.TarInfo("guest/runner/" + name)
            f.size = len(data)
            tar.addfile(f, io.BytesIO(data))
different = sorted(k for k, v in inputs.items() if parent.get(k) != v)
manifest = {"parent_job_sha256": parent_build["job_sha256"], "source_files": inputs, "changed": different,
            "source_archive_sha256": sha(source_tar.read_bytes()), "patch_sha256": sha((report / "source.patch").read_bytes())}
write_json(report / "source.json", manifest)
goroot = "/Users/benebsworth/.local/share/mise/installs/go/1.27.2"
go = str(Path(goroot) / "bin/go")
env = os.environ | {"GOROOT": goroot, "GOTOOLCHAIN": "local", "GOOS": "linux", "GOARCH": "arm64", "CGO_ENABLED": "0"}
flags = ["-mod=readonly", "-trimpath"]
out, test = stage / "job.id", stage / "runner.id.test"
for name, cmd in [("build", ["build", *flags, "-o", out, "."]),
                  ("test-build", ["test", *flags, "-c", "-o", test, "."]),
                  ("vet", ["vet", *flags, "./..."])]:
    with (report / (name + ".log")).open("xb") as log:
        subprocess.run([go, *cmd], env=env, cwd=src, stdout=log, stderr=subprocess.STDOUT, check=True)
go_env = json.loads(subprocess.check_output([go, "env", "-json", "GOCACHE", "GOFLAGS", "GOVERSION"], env=env, cwd=src))
assert go_env["GOCACHE"] == "/Users/benebsworth/Library/Caches/go-build" and "-trimpath" in go_env["GOFLAGS"].split()
assert inputs == {n: sha((live / n).read_bytes()) for n in inputs}
result = {"go_env": go_env, "job_sha256": sha(out.read_bytes()), "test_sha256": sha(test.read_bytes()),
          "job_size": out.stat().st_size, "test_size": test.stat().st_size, "changed": different,
          "source_manifest_sha256": sha((report / "source.json").read_bytes())}
write_json(report / "build.json", result)
print(json.dumps(result))
