# Stock Linux virtio-fs trace

Boot the dedicated managed HVF worker with the existing B5 kernel and shipping VMM. Select the staged tools bank `tools-trace-proof2` with `MICROPOD_CI_OCI_TOOLS` or the protected benchmark driver's `--tools` option. The cloned bank comes from `tools-release`. Its runner starts the one-shot observer from the read-only guest tools mount.

Use a fresh, dedicated `MICROPOD_CI_WORKSPACE` on the host, set below as `WORK`. After Docker readiness and fixture image import, start the capture, run one scan or edit benchmark and finish immediately.

```sh
D=/private/tmp/mp-wci-AWfKIVpK/home/artifacts/trace-proof
TOKEN=$(python3 -c 'import secrets; print(secrets.token_hex(8))')
python3 -B "$D/trace_proof.py" start --workspace "$WORK" --token "$TOKEN"

# Run the existing 512-file scan or bench_workspace_edits.py here.

python3 -B "$D/trace_proof.py" finish --workspace "$WORK" --token "$TOKEN"
python3 -B "$D/trace_proof.py" report --workspace "$WORK" --token "$TOKEN" > "$D/trace-receipt.json"
```

The guest answers `.trace-start.request` and `.trace-finished.request` with token-matched `.trace-started` and `.trace-done`. Save those files together with `.trace-events`, `.trace-stats`, `.trace-observer.log` and the benchmark receipt. The archive can be parsed by passing the raw files' directory as `--workspace`. The observer log records available clocks, tracers and options before and after configuration, along with setup stderr.

The observer waits at most five minutes for start. It uses a unique private tracefs instance, requests overwrite disabled, sets a 2 MiB buffer per vCPU and caps the active capture at 30 seconds. The observer verifies that the trace clock is `mono` or `global`, both usable across CPUs. FUSE send and end events are filtered by the workspace's kernel device number. The observer requests kernel workqueue filters for `virtio_fs_requests_done_work` and reports how many the kernel accepted. The parser matches that symbol in text when a filter is unavailable. It takes the stats and trace snapshot after stopping, removes its own instance and unmounts tracefs if it mounted it privately.

The report pairs FUSE send and end by unique request ID within the selected connection. It separately pairs work enqueue and execution by work object. A work sample belongs to the workspace subset when a matched workspace FUSE reply occurs inside that execution on the same guest worker PID. A single execution can complete several FUSE requests. The report records such linkage counts as well as a separate distribution of queue wait per execution. A work execution queued before some requests were submitted can still contain those requests. The report counts those cases separately.

Stock ftrace text exposes one-microsecond timestamps on this kernel. The parser converts the displayed fractions exactly to integer nanoseconds and reports their resolution. It records loss and incomplete or ambiguous pairings without guessing their durations. FUSE round-trip time and workqueue wait overlap where the work completes a request, and the two subtotals cannot be added together. The capture includes the start acknowledgement and occasional observer metadata checks around the scan.

To reproduce the private bank with a different baseline:

```sh
python3 -B "$D/trace_proof.py" install \
  --source "$D/../tools-release" --target "$D/../tools-trace-proof-other"
cd "$D"
python3 -B -m unittest -v test_trace_proof.py
```
