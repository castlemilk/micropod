import tempfile
import unittest
from pathlib import Path

import trace_proof as proof


TOKEN = "fefe10203040abcd"
WORKER = "kworker/1:2-37"
WORK_PTR = "12bda7916402abab"
WORK_FN = "virtio_fs_requests_done_work+0x0/0x288"
STARTED = {
    "schema": "1", "token": TOKEN, "device": "0:27", "connection": "27",
    "clock": "mono", "observer_pid": "42", "kernel_work_event_filters": "3",
}
DONE = {"schema": "1", "token": TOKEN, "status": "ok", "reason": "finished"}
STATS = """[cpu1]
entries: 19
overrun: 0
commit overrun: 0
dropped events: 0
"""


def row(when, event, body, task="probe-600"):
    return f" {task:>18} [001] d..1.  4295000.{when:06}: {event}: {body}"


def marker(when, edge):
    return row(when, "tracing_mark_write", f"mp-workspace-{edge} {TOKEN}", "sh-42")


def request(when, opcode, name, unique, end_task=WORKER, extra_enqueue=False):
    queue_line = row(when + 7, "workqueue_queue_work",
                     f"work struct={WORK_PTR} function={WORK_FN} workqueue=events req_cpu=8192 cpu=1")
    return [
        row(when, "fuse_request_send", f"connection 27 req {unique} opcode {opcode} (FUSE_{name}) len 48 "),
        queue_line,
        *([queue_line] if extra_enqueue else []),
        row(when + 10, "workqueue_execute_start", f"work struct {WORK_PTR}: function {WORK_FN}", WORKER),
        row(when + 13, "fuse_request_end", f"connection 27 req {unique} len 16 error 0", end_task),
        row(when + 14, "workqueue_execute_end", f"work struct {WORK_PTR}: function {WORK_FN}", WORKER),
    ]


def receipt(rows, stats=STATS, done=DONE):
    return proof.reconcile(STARTED, done, "\n".join(rows), stats)


BASE = [marker(1, "start"), *request(10, 14, "OPEN", 20), *request(30, 15, "READ", 22),
        *request(50, 18, "RELEASE", 24), marker(100, "finish")]


class TraceTests(unittest.TestCase):
    def test_latency_and_workqueue_delay_keep_microsecond_precision(self):
        result = receipt(BASE)
        self.assertTrue(result["complete"], result["problems"])
        self.assertEqual(result["timestamp_resolution_ns"], [1000])
        self.assertEqual(result["fuse_send_to_end"]["OPEN"]["p50_ns"], 13000)
        self.assertEqual(result["work_enqueue_to_start_workspace"]["sum_ns"], 9000)
        self.assertEqual(result["workspace_completions_with_paired_work_by_opcode"],
                         {"OPEN": 1, "READ": 1, "RELEASE": 1})

    def test_dropped_buffer_event_makes_receipt_incomplete(self):
        result = receipt(BASE, STATS.replace("dropped events: 0", "dropped events: 14"))
        self.assertFalse(result["complete"])
        self.assertEqual(result["trace_loss"]["per_cpu"]["cpu1"]["dropped events"], 14)
        self.assertIn("trace buffer reports loss", result["problems"])

    def test_ambiguous_and_nested_work_excluded_from_workspace_latency(self):
        result = receipt([*BASE[:-1], *request(70, 18, "RELEASE", 26, extra_enqueue=True),
                          *request(85, 15, "READ", 28, end_task="kworker/1:1-36"), marker(110, "finish")])
        self.assertEqual(result["work_pairing"]["ambiguous_work_starts"], 1)
        self.assertEqual(result["work_pairing"]["workspace_completions_without_queue_pair"], 1)
        self.assertEqual(result["fuse_send_to_end"]["READ"]["count"], 2)
        self.assertEqual(result["work_enqueue_to_start_all_virtiofs"]["count"], 4)
        self.assertEqual(result["work_enqueue_to_start_workspace"]["count"], 3)

    def test_duplicate_request_and_missing_barrier_are_attested(self):
        rows = [*BASE[:-1], BASE[1], BASE[-1]]
        result = receipt(rows)
        self.assertFalse(result["complete"])
        self.assertEqual(result["fuse_pairing"]["ambiguous_fuse_ids"], 1)
        incomplete = receipt(BASE[:-1])
        self.assertFalse(incomplete["complete"])
        self.assertIn("missing, duplicate or out-of-order markers", incomplete["problems"])

    def test_requests_are_complete_and_never_overwrite_prior_requests(self):
        with tempfile.TemporaryDirectory() as temp:
            work = Path(temp)
            proof.request(work, ".trace-start.request", TOKEN)
            self.assertEqual((work / ".trace-start.request").read_bytes(), (TOKEN + "\n").encode())
            with self.assertRaises(FileExistsError):
                proof.request(work, ".trace-start.request", "0" * 16)
            self.assertEqual(sorted(p.name for p in work.iterdir()), [".trace-start.request"])


if __name__ == "__main__":
    unittest.main()
