#!/usr/bin/env python3
"""Control and reconcile a single stock-kernel workspace trace."""

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import time
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path


TOKEN = re.compile(r"[0-9a-f]{16}")
LEAVES = (".trace-start.request", ".trace-finished.request", ".trace-started",
          ".trace-done", ".trace-events", ".trace-stats", ".trace-observer.log")
LINE = re.compile(
    r"^\s*.*?-(?P<pid>\d+)\s*(?:\(\s*(?:\d+|-+)\s*\)\s*)?\[(?P<cpu>\d+)\]\s+"
    r"(?:[^:\s]+\s+)?(?P<sec>\d+)\.(?P<frac>[0-9]{1,9}):\s+(?P<event>\w+):\s*(?P<body>.*)$"
)
SEND = re.compile(r"connection (\d+) req (\d+) opcode (\d+) \(([^)]+)\) len (\d+)")
END = re.compile(r"connection (\d+) req (\d+) len (\d+) error (-?\d+)")
WORK = re.compile(
    r"work struct[= ]([0-9a-fA-F]+)(?:\s+function=|:\s+function\s+)"
    r"virtio_fs_requests_done_work(?:[.+][^\s]+)?(?:\s|$)"
)
COUNTERS = ("overrun", "commit overrun", "dropped events")
CAPTURE_LIMIT = 32 * 1024 * 1024


@dataclass(frozen=True)
class Event:
    line: int
    ns: int
    pid: int
    cpu: int
    name: str
    body: str


def require(condition, message):
    if not condition:
        raise ValueError(message)


def info(path, token):
    fields = {}
    for line in path.read_text().splitlines():
        key, sep, value = line.partition("=")
        require(sep and key and key not in fields, f"invalid metadata in {path.name}")
        fields[key] = value
    require(fields.get("schema") == "1" and fields.get("token") == token,
            f"invalid schema or token in {path.name}")
    return fields


def wait_for(work, leaf, token, timeout):
    deadline = time.monotonic() + timeout
    path = work / leaf
    while not path.is_file():
        if leaf != ".trace-done" and (work / ".trace-done").is_file():
            raise ValueError(f"observer exited before starting: {info(work / '.trace-done', token)}")
        if time.monotonic() >= deadline:
            raise TimeoutError(f"timed out waiting for {leaf}")
        time.sleep(0.05)
    return info(path, token)


def request(work, leaf, token):
    # Link the complete, closed request into place without replacing a stale request.
    with tempfile.NamedTemporaryFile(mode="w", dir=work, prefix=".trace-host-", delete=False) as file:
        tmp = Path(file.name)
        file.write(token + "\n")
    try:
        os.link(tmp, work / leaf)
    finally:
        tmp.unlink()


def parse_events(trace):
    events, bad, lost, resolutions = [], [], [], set()
    for number, row in enumerate(trace.splitlines(), 1):
        stripped = row.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if "[LOST" in row:
            lost.append(number)
            continue
        m = LINE.fullmatch(row)
        if not m:
            bad.append(number)
            continue
        fraction = m["frac"]
        resolution = 10 ** (9 - len(fraction))
        timestamp = int(m["sec"]) * 1_000_000_000 + int(fraction) * resolution
        resolutions.add(resolution)
        events.append(Event(number, timestamp, int(m["pid"]), int(m["cpu"]), m["event"], m["body"].strip()))
    return events, bad, lost, sorted(resolutions)


def loss_stats(text):
    stats, cpu = {}, None
    for row in text.splitlines():
        if re.fullmatch(r"\[cpu\d+\]", row):
            cpu = row[1:-1]
            require(cpu not in stats, "duplicate CPU stats")
            stats[cpu] = {}
        else:
            key, _, value = row.partition(":")
            if key in COUNTERS and cpu is not None:
                require(key not in stats[cpu] and value.strip().isdigit(), f"invalid {cpu} loss counter")
                stats[cpu][key] = int(value)
    require(stats and all(set(rows) == set(COUNTERS) for rows in stats.values()), "incomplete per-CPU loss counters")
    return stats


def distribution(values):
    values = sorted(values)
    size = len(values)
    if not size:
        return {"count": 0}
    result = {"count": size, "sum_ns": sum(values), "min_ns": values[0], "max_ns": values[-1]}
    for percentile in (50, 95, 99):
        result[f"p{percentile}_ns"] = values[(percentile * size + 99) // 100 - 1]
    return result


def fuse_pairs(events, connection, observer):
    by_request = defaultdict(lambda: ([], []))
    counts, delays, errors, matches = Counter(), defaultdict(list), defaultdict(Counter), {}
    for event in events:
        if event.name == "fuse_request_send":
            match = SEND.fullmatch(event.body)
            index = 0
        elif event.name == "fuse_request_end":
            match = END.fullmatch(event.body)
            index = 1
        else:
            continue
        if not match:
            counts["malformed_fuse_events"] += 1
            continue
        if int(match[1]) != connection:
            counts["foreign_connection_events"] += 1
            continue
        by_request[int(match[2])][index].append((event, match))
    for sends, ends in by_request.values():
        if len(sends) > 1 or len(ends) > 1:
            counts["ambiguous_fuse_ids"] += 1
        elif not sends:
            counts["ends_without_send"] += len(ends)
        elif not ends:
            counts["sends_without_end"] += len(sends)
        else:
            (send, args), (end, reply) = sends[0], ends[0]
            if send.pid == observer:
                counts["observer_fuse_pairs_excluded"] += 1
            elif end.ns < send.ns or end.line < send.line:
                counts["out_of_order_fuse_pairs"] += 1
            else:
                op = args[4].removeprefix("FUSE_")
                delays[op].append(end.ns - send.ns)
                if int(reply[4]):
                    errors[op][reply[4]] += 1
                matches[end.line] = (send.ns, op)
    return counts, delays, errors, matches


def work_pairs(events, fuse):
    pending, running = defaultdict(list), {}
    counts, queue_delays, workspace_delays, linked_by_opcode = Counter(), [], [], Counter()
    for event in events:
        if event.name == "fuse_request_end":
            if event.line in fuse and event.pid in running:
                running[event.pid][3].append(fuse[event.line])
            continue
        if event.name not in ("workqueue_queue_work", "workqueue_execute_start", "workqueue_execute_end"):
            continue
        match = WORK.match(event.body)
        if not match:
            if "virtio_fs_requests_done_work" in event.body:
                counts["malformed_done_work_events"] += 1
            else:
                counts["other_work_events"] += 1
            continue
        ptr = match[1]
        if event.name == "workqueue_queue_work":
            pending[ptr].append(event)
        elif event.name == "workqueue_execute_start":
            enqueue = pending.pop(ptr, [])
            if not enqueue:
                counts["work_starts_without_enqueue"] += 1
            elif len(enqueue) > 1:
                counts["ambiguous_work_starts"] += 1
                counts["ambiguous_work_enqueues"] += len(enqueue)
            if event.pid in running:
                counts["overlapping_work_on_worker"] += 1
                enqueue = []
            running[event.pid] = (event, ptr, enqueue, [])
        else:
            active = running.pop(event.pid, None)
            if active is None:
                counts["work_ends_without_start"] += 1
                continue
            start, start_ptr, enqueue, completions = active
            if ptr != start_ptr or event.ns < start.ns:
                counts["mismatched_work_ends"] += 1
                continue
            if len(enqueue) != 1:
                counts["workspace_completions_without_queue_pair"] += len(completions)
                continue
            queued = enqueue[0]
            if queued.ns > start.ns:
                counts["out_of_order_work_pairs"] += 1
                continue
            delay = start.ns - queued.ns
            queue_delays.append(delay)
            if completions:
                workspace_delays.append(delay)
                linked_by_opcode.update(op for _, op in completions)
                counts["workspace_completions_submitted_after_enqueue"] += sum(
                    accepted > queued.ns for accepted, _ in completions
                )
            else:
                counts["work_pairs_without_workspace_completion"] += 1
    counts["work_enqueues_without_start"] += sum(map(len, pending.values()))
    counts["work_starts_without_end"] += len(running)
    return counts, queue_delays, workspace_delays, linked_by_opcode


def reconcile(started, done, trace, stats):
    observer = int(started["observer_pid"])
    connection = int(started["connection"])
    major, minor = map(int, started["device"].split(":"))
    require(started["clock"] in ("mono", "global") and (major << 20 | minor) == connection,
            "invalid trace clock or workspace device")
    events, unreadable, lost_lines, resolutions = parse_events(trace)
    cpus = loss_stats(stats)
    observed_cpus = {f"cpu{e.cpu}" for e in events}
    require(observed_cpus <= cpus.keys(), "missing stats for a CPU present in the trace")
    token = started["token"]
    boundaries = {
        edge: [e for e in events if e.name == "tracing_mark_write"
               and e.pid == observer and e.body == f"mp-workspace-{edge} {token}"]
        for edge in ("start", "finish")
    }
    start, finish = boundaries.values()
    window_ok = len(start) == len(finish) == 1 and start[0].line < finish[0].line and start[0].ns <= finish[0].ns
    window = [e for e in events if start[0].line < e.line < finish[0].line] if window_ok else []
    fuse_counts, fuse_delays, fuse_errors, matched = fuse_pairs(window, connection, observer)
    work_counts, queue_delays, workspace_delays, linked = work_pairs(window, matched)
    problems = []
    if done.get("status") != "ok":
        problems.append(f"observer {done.get('status')}: {done.get('reason')}")
    if not window_ok:
        problems.append("missing, duplicate or out-of-order markers")
    if lost_lines or any(any(counters.values()) for counters in cpus.values()):
        problems.append("trace buffer reports loss")
    if unreadable or fuse_counts["malformed_fuse_events"] or work_counts["malformed_done_work_events"]:
        problems.append("unparsed events")
    if not all(fuse_delays.get(op) and linked[op] for op in ("OPEN", "READ", "RELEASE")):
        problems.append("insufficient matched workspace OPEN/READ/RELEASE and done work")
    return {
        "schema": 1, "complete": not problems, "problems": problems,
        "capture": started,
        "window_ns": finish[0].ns - start[0].ns if window_ok else None,
        "timestamp_resolution_ns": resolutions,
        "trace_loss": {"per_cpu": cpus, "reported_loss_lines": lost_lines, "unparsed_lines": unreadable},
        "fuse_send_to_end": {op: distribution(values) for op, values in fuse_delays.items()},
        "fuse_reply_errors": {op: dict(values) for op, values in fuse_errors.items()},
        "fuse_pairing": dict(fuse_counts),
        "work_enqueue_to_start_all_virtiofs": distribution(queue_delays),
        "work_enqueue_to_start_workspace": distribution(workspace_delays),
        "workspace_completions_with_paired_work_by_opcode": dict(linked),
        "work_pairing": dict(work_counts),
    }


def report(work, token):
    done = info(work / ".trace-done", token)
    setup = work / ".trace-observer.log"
    trace, stats = (work / name for name in (".trace-events", ".trace-stats"))
    if done.get("status") != "ok" and not (trace.is_file() and stats.is_file()):
        return {"schema": 1, "complete": False, "observer": done,
                "setup_log_available": setup.is_file()}
    started = info(work / ".trace-started", token)
    require(trace.stat().st_size <= CAPTURE_LIMIT, "text trace exceeds the host analysis size bound")
    raw = [path.read_bytes() for path in (trace, stats)]
    result = reconcile(started, done, *(data.decode("utf-8", errors="replace") for data in raw))
    result["raw_files_sha256"] = {
        path.name: hashlib.sha256(data).hexdigest() for path, data in zip((trace, stats), raw, strict=True)
    }
    if setup.is_file():
        result["raw_files_sha256"][setup.name] = hashlib.sha256(setup.read_bytes()).hexdigest()
    return result


def install(source, target):
    source = source.resolve(strict=True)
    target = target.resolve()
    require(not target.exists() and source not in target.parents, "choose a new, separate tools bank")
    observer = Path(__file__).with_name("trace-observer.sh")
    with tempfile.TemporaryDirectory(prefix=".trace-tools-", dir=target.parent) as temporary:
        bank = Path(temporary) / "bank"
        subprocess.run(["/bin/cp", "-cRp", str(source), str(bank)], check=True)
        start_script = bank / "runner/start.sh"
        startup = start_script.read_text()
        needle = "\nconfigure_scheduler\n"
        require(startup.count(needle) == 1 and "trace-observer.sh" not in startup,
                "unexpected runner start.sh hook")
        guest = bank / "runner/trace-observer.sh"
        shutil.copy2(observer, guest)
        guest.chmod(0o755)
        start_script.write_text(startup.replace(needle, needle + "/opt/micropod-oci/runner/trace-observer.sh &\n"))
        for path in (guest, start_script):
            subprocess.run(["/bin/sh", "-n", str(path)], check=True)
        require(not target.exists(), "tools destination already exists")
        bank.rename(target)
    return {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in (target / "runner/start.sh", target / "runner/trace-observer.sh", target / "runner/bin/job")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_subparsers(dest="command", required=True)
    for command in ("start", "finish", "report"):
        mode = modes.add_parser(command)
        mode.add_argument("--workspace", type=Path, required=True)
        mode.add_argument("--token", required=True)
        if command != "report":
            mode.add_argument("--timeout", type=float, default=20)
    mode = modes.add_parser("install")
    mode.add_argument("--source", type=Path, required=True)
    mode.add_argument("--target", type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.command == "install":
            result = install(args.source, args.target)
        else:
            require(TOKEN.fullmatch(args.token) is not None, "use 16 lowercase hexadecimal digits")
            work = args.workspace.resolve(strict=True)
            require(work.is_dir(), "workspace must be a directory")
            if args.command == "start":
                require(not any(os.path.lexists(work / leaf) for leaf in LEAVES),
                        "use a fresh dedicated workspace")
                request(work, ".trace-start.request", args.token)
                result = wait_for(work, ".trace-started", args.token, args.timeout)
            elif args.command == "finish":
                info(work / ".trace-started", args.token)
                if not (work / ".trace-done").exists():
                    request(work, ".trace-finished.request", args.token)
                result = wait_for(work, ".trace-done", args.token, args.timeout)
            else:
                result = report(work, args.token)
    except (KeyError, OSError, ValueError, subprocess.CalledProcessError) as error:
        result = {"complete": False, "error": str(error)}
    print(json.dumps(result, indent=2, sort_keys=True))
    return int(result.get("complete") is False or result.get("status") in ("error", "timeout"))


if __name__ == "__main__":
    raise SystemExit(main())
