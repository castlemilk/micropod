module github.com/castlemilk/micropod/guest/runner

go 1.25.0

require (
	github.com/containerd/containerd/api v1.11.1
	github.com/distribution/reference v0.6.0
	github.com/moby/term v0.5.2
	github.com/opencontainers/image-spec v1.1.1
	golang.org/x/sys v0.39.0
	google.golang.org/grpc v1.79.3
	k8s.io/cri-api v0.35.3
)

require (
	github.com/Azure/go-ansiterm v0.0.0-20250102033503-faa5f7b0171c // indirect
	github.com/containerd/log v0.1.0 // indirect
	github.com/containerd/ttrpc v1.2.5 // indirect
	github.com/opencontainers/go-digest v1.0.0 // indirect
	github.com/sirupsen/logrus v1.9.3 // indirect
)

require (
	github.com/vishvananda/netlink v1.3.1
	github.com/vishvananda/netns v0.0.5
	golang.org/x/net v0.48.0
	golang.org/x/text v0.32.0 // indirect
	google.golang.org/genproto/googleapis/rpc v0.0.0-20251202230838-ff82c1b0f217 // indirect
	google.golang.org/protobuf v1.36.10
)
