#!/bin/sh
set -eu

endpoint=${MICROPOD_KERNEL_DOCKER_HOST:?explicit Docker Unix socket}
workspace=$(dirname "$(dirname "$(realpath "$0")")")
name=${1:?unique container name}
image=sha256:469c9ea410b9215eaee7976ba6c0639039b444be8e5d638f7abbada189971eb2
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_API_VERSION DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH

docker --host "$endpoint" run --rm --pull never --name "$name" \
    --label "org.micropod.experiment=$name" \
    --cpus=4 --memory=6g --platform linux/arm64 --env JOBS=4 \
    --mount "type=bind,src=$workspace,dst=/artifacts" "$image" sh -eu -c '
    apk add --no-cache build-base gcc=15.2.0-r2 binutils=2.45.1-r0 make=4.4.1-r3 \
        bc bison flex perl openssl-dev elfutils-dev linux-headers xz zstd bash \
        coreutils pahole gmp-dev mpc1-dev mpfr-dev cpio python3 gawk perl-utils \
        diffutils findutils file rsync
    { uname -a; gcc --version; ld --version; make --version; apk info -vv; } \
        > /artifacts/workspace-release-toolchain.txt
    sh /artifacts/controls/build-virtiofs-workspace-release-kernel.sh /artifacts/inputs /artifacts/workspace-release
    '
