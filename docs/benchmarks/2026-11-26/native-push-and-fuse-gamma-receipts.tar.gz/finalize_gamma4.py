"""Retire only this Gamma round's private APFS and Docker scopes and archive their receipts."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import plistlib
import shutil
import subprocess
import sys
import tarfile
import time

import worker_apfs_drive as apfs

receipts = Path(__file__).resolve().parent
scope = receipts.parent
hub = scope / 'home'
assert scope.parent == Path('/private/tmp') and scope.name.startswith('mp-gamma4.')
suffix = scope.name.removeprefix('mp-gamma4.').lower()
worktree = Path(sys.argv[1]).resolve(strict=True)
results = worktree / 'docs/benchmarks/2026-11-26'
scorecard = results / 'native-push-and-fuse-gamma.json'
archive = results / 'native-push-and-fuse-gamma-receipts.tar.gz'
assert not scorecard.exists() and not archive.exists()


def read(path):
    return json.loads(path.read_bytes())


def write(path, data):
    pending = path.with_name(path.name + '.writing')
    pending.write_text(json.dumps(data, indent=2) + '\n')
    pending.replace(path)


def sha(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()


def run(argv, *, check=True, timeout=55):
    return subprocess.run(argv, text=True, capture_output=True, timeout=timeout, check=check)


def mounted_images():
    payload = subprocess.check_output(['/usr/bin/hdiutil', 'info', '-plist'], timeout=40)
    return {image['image-path'] for image in plistlib.loads(payload)['images'] if image.get('image-path')}


def prior_products():
    expected = read(receipts / 'prior-pinned-products.json')
    lineage = read(receipts / 'baseline-lineage.json')
    for item in (*lineage['archives'].values(), *lineage['artifacts'].values()):
        path = item.get('source', item.get('path'))
        expected[path] = item['sha256']
    for path, digest in expected.items():
        assert sha(Path(path)) == digest, path
    return expected


def archive_receipts():
    items = {path.relative_to(receipts).as_posix(): path for path in sorted(receipts.rglob('*'))
             if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts}
    assert all('registry-fixture' not in path.parts and not path.name.endswith('.key')
               and 'workspace-irq-token' not in path.name for path in items.values())
    manifest = {name: sha(path) for name, path in items.items()}
    payload = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    pending = archive.with_suffix(archive.suffix + '.pending')
    with pending.open('xb') as file, gzip.GzipFile(filename='', fileobj=file, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w|') as raw:
            for name, path in items.items():
                row = raw.gettarinfo(path, arcname=name)
                row.uid = row.gid = row.mtime = 0
                row.uname = row.gname = ''
                with path.open('rb') as source:
                    raw.addfile(row, source)
            row = tarfile.TarInfo('MANIFEST.sha256.json')
            row.size = len(payload)
            row.mode = 0o644
            raw.addfile(row, io.BytesIO(payload))
    with tarfile.open(pending) as raw:
        assert read_manifest(raw) == manifest and set(raw.getnames()) == set(manifest) | {'MANIFEST.sha256.json'}
        for name, digest in manifest.items():
            with raw.extractfile(name) as content:
                assert hashlib.file_digest(content, 'sha256').hexdigest() == digest, name
    pending.replace(archive)
    return {'path': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size, 'entries': len(manifest)}


def read_manifest(raw):
    with raw.extractfile('MANIFEST.sha256.json') as data:
        return json.load(data)


def worker_audit():
    workers = {}
    attached = mounted_images()
    for path in sorted(receipts.glob('*-worker.json')):
        worker = read(path)
        retirement = worker['drive']['detached']
        policy = retirement['persisted_policy']
        machine = worker['machine']
        assert not worker['errors'] and worker['scope_absent'] and machine['clean_shutdown'], path
        assert not machine['scoped_processes_after_stop'] and machine['supervisor_lock_released'] and machine['defaults_unchanged'], path
        assert retirement['image_absent'] and retirement['mount_restored'] and worker['image'] not in attached, path
        assert not any(Path(worker[key]).exists() for key in ('socket', 'image', 'worker_directory')), path
        assert policy['mounted_read_only'] and policy['spotlight']['disabled'] and policy['raw_disk_unchanged'], path
        assert policy['markers_unchanged'] and policy['journal_unchanged'], path
        assert policy['fsevents']['journal_files'] == policy['fsevents']['journal_bytes'] == 0, path
        workers[worker['label']] = {'image': worker['image'], 'uuid': policy['volume']['uuid'], 'clean_shutdown': True,
                                    'read_only': True, 'spotlight_disabled': True, 'fsevents_files': 0, 'fsevents_bytes': 0,
                                    'raw_identity_preserved': True, 'defaults_unchanged': True, 'removed': True,
                                    'artifacts': worker['owned_artifacts']}
    assert workers and str(scope / 'hub.sparseimage') in attached
    return workers


def retained_artifacts(workers):
    proof = read(receipts / 'retained-runtime-manifest.json')
    manifest = Path(proof['path']).resolve(strict=True)
    assert read(manifest) == proof['manifest'] and sha(manifest) == proof['sha256']
    item_to_role = {'runner_with_native_registry_push_and_auth': 'job', 'registry_protocol_initial_job': 'job',
                    'registry_id_initial_job': 'job', 'matched_fuse_release_experiment_kernel': 'kernel'}
    for item, data in proof['manifest']['artifacts'].items():
        path = Path(data['path'])
        assert path.resolve(strict=True) == path and sha(path) == data['sha256'] and path.stat().st_size == data['bytes']
        assert path.parent == manifest.parent and workers[data['attested_worker']]['artifacts'][item_to_role[item]]['sha256'] == data['sha256']
    for role, data in proof['manifest']['production_lineage'].items():
        path = Path(data['path'])
        assert sha(path) == data['sha256']
        if role in ('vmm', 'cli'):
            run(['/usr/bin/codesign', '--verify', '--strict', '--verbose=4', str(path)])
    return proof


def copy_candidate_evidence():
    folders = ('kernel-release-base/inputs', 'kernel-release-base/controls', 'kernel-release-base/workspace-release',
               'image-push/provenance', 'image-push/qualification', 'image-prune/provenance',
               'image-prune/qualification', 'image-prune-final/provenance',
               'image-prune-final/qualification', 'evidence/prior/trace-proof')
    allowed = ('.json', '.jsonl', '.log', '.py', '.sh', '.patch', '.txt', '.tar.gz', '.md', '.go', '.config', '.diff', '.mod', '.sum')
    exact = {'config', 'release', 'SHA256SUMS', 'toolchain', 'toolchain.txt'}
    copied = {}
    for relative in folders:
        directory = hub / relative
        if not directory.is_dir():
            continue
        assert directory.resolve(strict=True) == directory
        for root, dirs, files in os.walk(directory, followlinks=False):
            dirs[:] = [name for name in dirs if name not in {'.git', 'source', 'target', '__pycache__'}
                       and not (Path(root) / name).is_symlink()]
            for name in sorted(files):
                file = Path(root) / name
                if (name not in exact and not name.endswith(allowed)) or file.is_symlink() or file.stat().st_size > 16 * 2**20:
                    continue
                target = receipts / 'candidate-inputs' / file.relative_to(hub)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(file, target)
                copied[target.relative_to(receipts).as_posix()] = sha(target)
    for subpath in ('artifacts/tools-release-trace/runner/start.sh', 'artifacts/tools-release-trace/runner/trace-observer.sh',
                    'artifacts/tools-release-trace/runner/release-lifecycle-observer.sh',
                    'artifacts/tools-release-lifecycle-v2/runner/start.sh',
                    'artifacts/tools-release-lifecycle-v2/runner/release-lifecycle-observer.sh',
                    'artifacts/tools-workspace-irq-owner/runner/start.sh', 'irq-owner/main_linux.go'):
        file = hub / subpath
        assert file.resolve(strict=True) == file
        target = receipts / 'candidate-inputs' / subpath
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(file, target)
        copied[target.relative_to(receipts).as_posix()] = sha(target)
    return copied


def hub_attachment_audit(workers):
    hold_command = ['/usr/sbin/lsof', '-nP', '+f', '--', str(hub)]
    try:
        holding = run(hold_command, check=False)
    except subprocess.TimeoutExpired as stalled:
        write(receipts / 'hub-holders-initial-timeout.json', {'command': hold_command, 'error': repr(stalled)})
        holding = run(hold_command, check=False)
    write(receipts / 'hub-holders-final.json', {'exit': holding.returncode, 'stdout': holding.stdout, 'stderr': holding.stderr})
    assert holding.returncode == 1 and not holding.stdout.strip() and not holding.stderr.strip(), holding
    created = read(receipts / 'hub-created.json')
    live = apfs.verify(created)
    write(receipts / 'hub-final-live.json', live)
    detached = apfs.detach(created, remove_image=True, inspect_history=True)
    write(receipts / 'hub-detached.json', detached)
    policy = detached['persisted_policy']
    assert detached['image_absent'] and detached['mount_restored'] and policy['mounted_read_only']
    assert policy['spotlight']['disabled'] and policy['markers_unchanged'] and policy['journal_unchanged']
    assert policy['fsevents']['journal_files'] == policy['fsevents']['journal_bytes'] == 0
    hub.rmdir()
    owned = {arm['image'] for arm in workers.values()} | {created['image']}
    assert not (mounted_images() & owned) and not any(Path(path).exists() for path in owned)
    return {'uuid': live['volume']['uuid'], 'read_only_remount': True, 'spotlight_disabled': True,
            'fsevents_files': 0, 'fsevents_bytes': 0, 'image_removed': True}


def audit_reference(docker, image):
    assert image['tag'] == f'micropod-qa/checkout:gamma4-{suffix}'
    assert run([*docker, 'image', 'inspect', '--format', '{{.Id}}', image['tag']]).stdout.strip() in (
        image['config_digest'], image['manifest_digest'])
    assert not run([*docker, 'ps', '-aq', '--filter', f'ancestor={image["tag"]}']).stdout.strip()
    assert not run([*docker, 'ps', '-aq', '--filter', f'label={image["label"]}']).stdout.strip()
    assert run([*docker, 'image', 'inspect', '--format', '{{.Id}}', image['base']]).stdout.strip() == image['source_config']


def main():
    workers = worker_audit()
    assert {'baseline', 'release-off', 'release-on'} <= workers.keys()
    preservation = prior_products()
    retained = retained_artifacts(workers)
    assert not (hub / 'registry-fixture').exists(), 'the registry owner has not released its private fixture'
    candidate_files = copy_candidate_evidence()
    summary = json.loads(run([sys.executable, '-B', str(receipts / 'summarize_gamma4.py')]).stdout)
    assert {'baseline', 'release-off', 'release-on'} <= summary['material'].keys()
    write(receipts / 'measurement-summary.json', summary)
    write(receipts / 'candidate-inputs-manifest.json', candidate_files)
    write(receipts / 'prior-artifacts-final.json', preservation)

    for key in ('DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH', 'DOCKER_API_VERSION'):
        os.environ.pop(key, None)
    docker = ['/opt/homebrew/bin/docker', '--host', 'unix:///Users/benebsworth/.orbstack/run/docker.sock']
    image = read(receipts / 'image.json')
    audit_reference(docker, image)
    hub_cleanup = hub_attachment_audit(workers)
    audit_reference(docker, image)
    run([*docker, 'image', 'rm', image['tag']])
    absent = run([*docker, 'image', 'inspect', image['tag']], check=False)
    assert absent.returncode and any(value in absent.stderr.lower() for value in ('no such', 'not found'))
    assert run([*docker, 'image', 'inspect', '--format', '{{.Id}}', image['base']]).stdout.strip() == image['source_config']

    cleanup = {'worker_volumes': workers, 'hub': hub_cleanup, 'owned_orbstack_tag_removed': True,
               'owned_orbstack_builder_removed': image['builder_removed'], 'preexisting_orbstack_base_preserved': True}
    write(receipts / 'final-cleanup.json', cleanup)
    proof = archive_receipts()
    assert list(scope.iterdir()) == [receipts] and not any(path.is_socket() for path in receipts.rglob('*'))
    assert not scope.is_mount() and not receipts.is_mount()
    shutil.rmtree(receipts)
    scope.rmdir()
    cleanup['private_stage_removed'] = not scope.exists()
    summary.update(cleanup=cleanup, receipts=proof, prior_preservation=preservation, retained_runtime=retained,
                   archived_candidate_files=candidate_files)
    write(scorecard, summary)
    print(scorecard, sha(scorecard), archive, proof['sha256'], flush=True)


if __name__ == '__main__':
    main()
