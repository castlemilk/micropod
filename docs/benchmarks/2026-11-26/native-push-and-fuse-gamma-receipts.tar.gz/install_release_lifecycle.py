"""Install the same approved terminal lifecycle observer in both matched workers."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

receipts = Path(__file__).resolve().parent
hub = receipts.parent / 'home'
tools = hub / 'artifacts/tools-release-trace/runner'
source = hub / 'kernel-release-base/controls/qualify_virtiofs_release_mounts.sh'
observer = tools / 'release-lifecycle-observer.sh'
startup = tools / 'start.sh'
trace = tools / 'trace-observer.sh'
expected = 'ddf2d9bede7c96b1632483a6fa7dca76da9346d5aec3fa664cbae695218cdd85'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert not observer.exists() and digest(source) == expected
old = startup.read_text()
original = '"$tools/runner/trace-observer.sh" &\nobserver=$!\n'
chain = '''(
    if ! "$tools/runner/trace-observer.sh"; then
        printf '%s\\n' 'The scoped workspace trace observer did not finish cleanly' >&2
    fi
    exec "$tools/runner/release-lifecycle-observer.sh"
) &
observer=$!
'''
assert old.count(original) == 1
shutil.copy2(source, observer)
observer.chmod(0o755)
startup.write_text(old.replace(original, chain))
assert digest(observer) == expected
for path in (startup, observer, trace):
    subprocess.run(['/bin/sh', '-n', str(path)], check=True)
attested = {str(path.relative_to(tools.parent)): digest(path) for path in (startup, trace, observer)}
(receipts / 'tools-release-lifecycle-lineage.json').write_text(json.dumps(attested, indent=2) + '\n')
