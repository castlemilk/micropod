"""Stage the revised terminal-only lifecycle operator on the baseline tool bank."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

receipts = Path(__file__).resolve().parent
hub = receipts.parent / 'home'
base = hub / 'artifacts/tools-baseline'
bank = hub / 'artifacts/tools-release-lifecycle-v2'
source = hub / 'kernel-release-base/controls/qualify_virtiofs_release_mounts-v2.sh'
expected = 'ca6f1b54efd2f4294e65b2363dcaec8b26f79e3c057b91a963d847e83d8d1501'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert not bank.exists() and digest(source) == expected
subprocess.run(['/bin/cp', '-cRp', str(base), str(bank)], check=True)
startup = bank / 'runner/start.sh'
old = startup.read_text()
trap = 'trap \'kill "$engine" ${service:+"$service"} ${api:+"$api"} 2>/dev/null || true\' EXIT'
armed_trap = trap.replace(' 2>/dev/null', ' ${observer:+"$observer"} 2>/dev/null')
start = '"$tools/runner/bin/job" recover\n'
instrument = '"$tools/runner/release-lifecycle-observer.sh" &\nobserver=$!\n'
assert old.count(trap) == 1 and old.count(start) == 1
startup.write_text(old.replace(trap, 'observer=\n' + armed_trap).replace(start, start + instrument))
observer = bank / 'runner/release-lifecycle-observer.sh'
shutil.copy2(source, observer)
observer.chmod(0o755)
assert digest(observer) == expected
for path in (startup, observer):
    subprocess.run(['/bin/sh', '-n', str(path)], check=True)
attested = {str(path.relative_to(bank)): digest(path) for path in (startup, observer)}
(receipts / 'tools-release-lifecycle-v2-lineage.json').write_text(json.dumps(attested, indent=2) + '\n')
