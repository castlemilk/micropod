"""Clone the private 5de tools bank and add the dormant IRQ measurement hook."""
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
from tempfile import TemporaryDirectory

receipts = Path(__file__).resolve().parent
home = receipts.parent / "home"
base = home / "artifacts" / "tools-baseline"
stage = home / "irq-owner"
target = home / "artifacts" / "tools-workspace-irq-owner"

assert home.is_mount() and not target.exists()
with TemporaryDirectory(dir=stage, prefix=".bank-") as scratch:
    clone = Path(scratch) / "bank"
    subprocess.run(["/bin/cp", "-cRp", str(base), str(clone)], check=True)
    runner = clone / "runner"
    line = '"$tools/runner/bin/job" recover\n'
    start = runner / "start.sh"
    before = start.read_text()
    assert before.count(line) == 1
    after = before.replace(line, line + '"$tools/runner/bin/workspace-irq" "$tools/runner/.workspace-irq-token" &\n')
    start.write_text(after)
    binary = runner / "bin" / "workspace-irq"
    shutil.copy2(stage / "workspace-irq", binary)
    token = runner / ".workspace-irq-token"
    with os.fdopen(os.open(token, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o400), "w") as handle:
        handle.write(secrets.token_hex(16) + "\n")
    subprocess.run(["/bin/sh", "-n", str(start)], check=True)
    clone.rename(target)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

files = ("runner/start.sh", "runner/bin/job", "runner/bin/workspace-irq")
result = {"base": str(base), "bank": str(target), "source_sha256": sha(stage / "main_linux.go"),
          "digests": {name: sha(target / name) for name in files}}
assert result["digests"]["runner/bin/job"] == "5de5611a7371bd542d92bd7c34a656431af9734f2c0e848a588fa692400248fd"
with (receipts / "tools-workspace-irq-owner-lineage.json").open("x") as handle:
    json.dump(result, handle, indent=2)
    handle.write("\n")
