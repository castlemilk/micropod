"""Add a one-time public CA to the cloned push fixture's Linux tool bank."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

receipts = Path(__file__).resolve().parent
hub = receipts.parent / 'home'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--base', type=Path, default=hub / 'artifacts/tools-baseline')
parser.add_argument('--name', default='tools-push-trust')
args = parser.parse_args()
base = args.base.resolve(strict=True)
assert base.parent == hub / 'artifacts' and base.is_dir()
assert '/' not in args.name and args.name.startswith('tools-') and len(args.name) < 60
dest = hub / 'artifacts' / args.name
assert not dest.exists()

public_cert = hub / 'registry-fixture/test-ca.crt'
assert public_cert.is_file() and not public_cert.is_symlink()
pem = public_cert.read_bytes()
assert pem.count(b'-----BEGIN CERTIFICATE-----') == 1 and b'PRIVATE KEY' not in pem
der = subprocess.check_output(['/usr/bin/openssl', 'x509', '-in', str(public_cert), '-outform', 'DER'])
digest = hashlib.sha256(der).hexdigest()
assert digest == 'e9c9ed4c87f5c3050230d097ca420d3af5f0bd10b0b64d18906b0bc3bd5a9b62'
subprocess.run(['/bin/cp', '-cRp', str(base), str(dest)], check=True)
target = dest / 'runner/fixture-certs/gamma-local-test-ca.crt'
target.parent.mkdir(mode=0o755)
target.write_bytes(pem)
target.chmod(0o644)
start = dest / 'runner/start.sh'
previous = start.read_text()
head, rest = previous.split('\n', 1)
assert head == '#!/bin/sh' and 'SSL_CERT_DIR=' not in previous
export = 'export SSL_CERT_DIR=/etc/ssl/certs:/opt/micropod-oci/runner/fixture-certs'
start.write_text('\n'.join((head, export, rest)))
subprocess.run(['/bin/sh', '-n', str(start)], check=True)
changes = {'base': str(base), 'cloned_tools': str(dest), 'public_certificate_der_sha256': digest,
           'start_sha256_before': hashlib.sha256(previous.encode()).hexdigest(),
           'start_sha256_after': hashlib.sha256(start.read_bytes()).hexdigest(),
           'guest_export': export}
(receipts / f'{args.name}-lineage.json').write_text(json.dumps(changes, indent=2) + '\n')
print(dest, flush=True)
