"""Clone the qualified tools and add the archived one-shot workspace ftrace observer."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

receipts = Path(__file__).resolve().parent
hub = receipts.parent / 'home'
base = hub / 'artifacts/tools-baseline'
bank = hub / 'artifacts/tools-release-trace'
observer = hub / 'evidence/prior/trace-proof/trace-observer.sh'
assert base.is_dir() and not bank.exists()
subprocess.run(['/bin/cp', '-cRp', str(base), str(bank)], check=True)
script = bank / 'runner/start.sh'
old = script.read_text()
trap = 'trap \'kill "$engine" ${service:+"$service"} ${api:+"$api"} 2>/dev/null || true\' EXIT'
armed_trap = trap.replace(' 2>/dev/null', ' ${observer:+"$observer"} 2>/dev/null')
start = '"$tools/runner/bin/job" recover\n'
instrument = '"$tools/runner/trace-observer.sh" &\nobserver=$!\n'
assert old.count(trap) == 1 and old.count(start) == 1 and 'trace-observer.sh' not in old
script.write_text(old.replace(trap, 'observer=\n' + armed_trap).replace(start, start + instrument))
installed = bank / 'runner/trace-observer.sh'
shutil.copy2(observer, installed)
probe = installed.read_text()
enable_close = r'''reason=configure_close_events
close_events_enabled=0
for event in sys_enter_close sys_exit_close; do
    point="$instance/events/syscalls/$event/enable"
    if [ -w "$point" ]; then
        printf '1\n' > "$point"
        close_events_enabled=$((close_events_enabled + 1))
    fi
done
release_parameter=/sys/module/virtiofs/parameters/workspace_async_release
if [ -r "$release_parameter" ]; then
    release_mode=$(cat "$release_parameter")
else
    release_mode=unavailable
fi

'''
started = 'reason=publish_started\n'
kernel = '    printf \'kernel_release=%s\\n\' "$(uname -r)"\n'
added_fields = r'''    printf 'close_syscall_events_enabled=%s\n' "$close_events_enabled"
    printf 'workspace_async_release=%s\n' "$release_mode"
'''
assert probe.count(started) == 1 and probe.count(kernel) == 1
installed.write_text(probe.replace(started, enable_close + started).replace(kernel, kernel + added_fields))
installed.chmod(0o755)
for path in (script, installed):
    subprocess.run(['/bin/sh', '-n', str(path)], check=True)
records = {'base': str(base), 'trace_tools': str(bank), 'retained_job_sha256': hashlib.sha256((bank/'runner/bin/job').read_bytes()).hexdigest(),
           'start_before_sha256': hashlib.sha256(old.encode()).hexdigest(), 'start_after_sha256': hashlib.sha256(script.read_bytes()).hexdigest(),
           'trace_observer_base_sha256': hashlib.sha256(observer.read_bytes()).hexdigest(),
           'trace_observer_sha256': hashlib.sha256(installed.read_bytes()).hexdigest()}
(receipts/'tools-release-trace-lineage.json').write_text(json.dumps(records, indent=2)+'\n')
print(bank, flush=True)
