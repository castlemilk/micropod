#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
arm=${1:?registry worker}
binary=${2:?staged Linux test executable}
sha=${3:?test SHA-256}
focus=${4:-'^TestDocker(ImagePush|RegistryLogin|RegistryPull)'}
test -S "$(jq -er .socket "$D/$arm-ready.json")"
set +e
bash "$D/qualify_guest_binary.sh" "$arm" "$binary" "$sha" "$focus" 50 registry-focused \
    > "$D/$arm-linux-registry-focused.log" 2>&1
focused=$?
bash "$D/qualify_guest_binary.sh" "$arm" "$binary" "$sha" '.' 100 registry-full \
    > "$D/$arm-linux-full.log" 2>&1
full=$?
bash "$D/run_gamma4_arm.sh" "$arm" correctness > "$D/$arm-correctness.log" 2>&1
ordinary=$?
set -e
printf 'linux_registry_focused=%s linux_full=%s filesystem_and_stock=%s\n' "$focused" "$full" "$ordinary" |
    tee "$D/$arm-registry-guest-exit.log"
(( focused == 0 && full == 0 && ordinary == 0 ))
