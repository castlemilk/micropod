#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
arm=${1:?release-off or release-on}
case "$arm" in
    release-off) mode=N ;;
    release-on) mode=Y ;;
    *) exit 2 ;;
esac
test -S "$(jq -er .socket "$D/$arm-ready.json")"
set +e
bash "$D/run_gamma4_arm.sh" "$arm" material
material=$?
python3 -B "$D/with_host_load.py" --out "$D/$arm-raw-git-host-load.jsonl" -- bash "$D/run_raw_git_release_trace.sh" \
    "$D/$arm-ready.json" "$mode" "$D/$arm-raw-git.json" > "$D/$arm-raw-git.log" 2>&1
trace=$?
bash "$D/run_gamma4_arm.sh" "$arm" correctness
correctness=$?
bash "$D/run_raw_git_release_untraced.sh" "$arm"
untraced=$?
lifecycle=125
if [[ $correctness == 0 && $trace == 0 && $untraced == 0 ]]; then
    python3 -B "$D/run_release_lifecycle.py" "$arm" > "$D/$arm-lifecycle.log" 2>&1
    lifecycle=$?
fi
set -e
printf 'material=%s trace=%s correctness=%s untraced=%s terminal_lifecycle=%s\n' "$material" "$trace" "$correctness" "$untraced" "$lifecycle" |
    tee "$D/$arm-qualification-exit.log"
(( material == 0 && trace == 0 && correctness == 0 && untraced == 0 && lifecycle == 0 ))
