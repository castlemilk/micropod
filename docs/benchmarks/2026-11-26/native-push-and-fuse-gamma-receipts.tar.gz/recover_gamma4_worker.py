"""Finish the already stopped push owner's protected APFS retirement after an lsof timeout."""
import fcntl
import json
from pathlib import Path
import shutil

import outer_machine_proof as proof
import worker_apfs_drive as apfs

receipts = Path(__file__).resolve().parent
result = receipts / 'push-worker.json'
record = json.loads(result.read_bytes())
assert record['label'] == 'push'
original_error = record['errors'].get('cleanup', '')
assert original_error.startswith("TimeoutExpired(['/usr/sbin/lsof', '-nP', '-t',") and not record['errors'].get('operation')
proof.record(receipts / 'push-worker-initial-attempt.json', record)
scan = json.loads((receipts / 'push-owned-scope-holders-recovery.json').read_bytes())
worker = Path(record['worker_directory']).resolve(strict=True)
mount = Path(record['worker_volume'])
image = Path(record['image'])
scope = Path(record['public_scope'])
assert worker.parent == Path('/private/tmp') and worker.name.startswith('mpg4-push-')
assert mount == worker / 'home' and mount.is_mount() and image == worker / 'worker.sparseimage'
assert scope.resolve(strict=True) == scope and scope.parent == mount and scope.name.startswith('outer-machine-')
assert scan['argv'][-1] == str(mount) and scan['exit'] == 1 and not scan['out'].strip() and not scan['err'].strip()
machine = record['machine']
assert machine['clean_shutdown'] and machine['supervisor_lock_released'] and machine['defaults_unchanged']
assert machine['status_stopped']['phase'] == 'stopped' and not machine['status_stopped']['supervisorAlive']
assert machine['status_stopped']['state']['lastExitCode'] == 0
table = proof.process_table()
assert not proof.scoped_processes(table, scope) and record['owner_pid'] not in table
socket = Path(record['socket'])
assert socket == scope / 'machine/run/docker.sock' and not socket.exists() and not socket.is_symlink()
with (scope / 'machine/run/supervisor.lock').open('r') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    fcntl.flock(lock, fcntl.LOCK_UN)
record['drive']['final_live'] = apfs.verify(record['drive']['created'])
raw = scope / 'machine/disk.ext4'
assert raw.resolve(strict=True) == raw
identity = proof.identity(raw)
assert identity['device'] == mount.stat().st_dev
for key in ('device', 'inode', 'logical_bytes'):
    assert identity[key] == record['raw_disk_live'][key], (key, identity)
raw_preserved = mount / 'worker.ext4'
assert not raw_preserved.exists() and not raw_preserved.is_symlink()
raw.rename(raw_preserved)
assert not proof.scoped_processes(proof.process_table(), scope)
shutil.rmtree(scope)
machine['scope_removed'] = not scope.exists()
record['drive']['detached'] = apfs.detach(record['drive']['created'], remove_image=True, inspect_history=True,
                                         expected_raw_identity=(identity['inode'], identity['logical_bytes']))
assert record['drive']['detached']['image_absent'] and record['drive']['detached']['mount_restored']
assert not any(mount.iterdir()) and not mount.is_mount() and not image.exists()
mount.rmdir()
worker.rmdir()
record['scope_absent'] = not worker.exists()
record['retirement_recovery'] = {'initial_cleanup_error': record['errors'].pop('cleanup'), 'worker_volume_holder_scan': scan}
proof.record(result, record)
print('Push worker read-only remount and full removal verified.', flush=True)
