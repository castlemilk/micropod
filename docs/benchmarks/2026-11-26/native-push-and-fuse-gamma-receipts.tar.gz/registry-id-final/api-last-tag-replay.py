"""Replay the scoped image identity regression and the pinned v1.47 Engine audit."""

import argparse
from collections import Counter
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from urllib.parse import urlencode

from qualify_engine_api import Engine, LABEL


def audited_scope(endpoint, scope):
    engine = Engine(endpoint, "alpine:3.23", None, None, api_version="1.47")
    name = scope["labels"][LABEL]
    assert re.fullmatch(r"mp-engine-[0-9a-f]{32}", name)
    filters = json.dumps({"label": [LABEL + "=" + name]})
    containers, _, data = engine.request("GET", "/containers/json?" + urlencode({"all": 1, "filters": filters}))
    container_count = len(json.loads(data)) if containers == 200 else None
    networks, _, data = engine.request("GET", "/networks?" + urlencode({"filters": filters}))
    network_count = len(json.loads(data)) if networks == 200 else None
    volume, _, _ = engine.request("GET", "/volumes/" + name)
    alias, _, _ = engine.request("GET", "/images/micropod-qa/" + name + ":qualification/json")
    alpine, _, data = engine.request("GET", "/images/alpine:3.23/json")
    base_image_id = json.loads(data).get("Id") if alpine == 200 else None
    return {
        "scope": name,
        "containers_http": containers,
        "scope_container_count": container_count,
        "networks_http": networks,
        "scope_network_count": network_count,
        "scope_volume_http": volume,
        "scope_alias_http": alias,
        "preloaded_alpine_http": alpine,
        "preloaded_alpine_id": base_image_id,
        "passed": (containers, container_count, networks, network_count, volume, alias, alpine) == (200, 0, 200, 0, 404, 404, 200),
    }


def read_json(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--prior-audit", type=Path, required=True)
    parser.add_argument("--results", type=Path, required=True)
    args = parser.parse_args()
    assert args.candidate.is_socket() and args.reference.is_socket() and not args.candidate.samefile(args.reference)
    sources = Path(__file__).resolve().parent
    fixture_hashes = read_json(sources / "replay-source-sha256.json")
    assert all(sha(sources / name) == digest for name, digest in fixture_hashes.items())
    build = read_json(args.build)
    job_sha = build["job_sha256"]
    assert re.fullmatch(r"[0-9a-f]{64}", job_sha)
    prior = json.loads(gzip.decompress(args.prior_audit.read_bytes()))
    results = args.results.resolve()
    results.mkdir(mode=0o700, exist_ok=False)
    identity = results / "stock-last-tag-identity.json"
    identity_cleanup = results / "stock-last-tag-cleanup.json"
    audit = results / "native-docker-api-v1.47-image-id-final.json.gz"

    def run(script, *script_args):
        with (results / (script.stem + ".log")).open("wb") as log:
            return subprocess.run([sys.executable, "-B", str(script), *map(str, script_args)], env=env,
                                  stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, timeout=180, check=False).returncode

    with tempfile.TemporaryDirectory(prefix="stock-cli-config-", dir=results) as config:
        env = dict(os.environ, DOCKER_CONFIG=config)
        (Path(config) / "config.json").write_text('{"auths":{"fixture.invalid":{}}}\n')
        identity_exit = run(sources / "qualify_tag_identity.py", "--scripts", sources, "--socket", args.candidate,
                            "--output", identity, "--disposable-native")
        cleanup_exit = None
        if identity_exit == 0:
            cleanup_exit = run(sources / "verify_last_tag_cleanup.py", "--socket", args.candidate,
                               "--identity", identity, "--output", identity_cleanup)
        audit_exit = run(sources / "qualify_engine_api.py", "--reference", args.reference, "--candidate", args.candidate,
                         "--reference-image", "alpine:3.23", "--candidate-image", "alpine:3.23", "--api-version", "1.47",
                         "--engine-only", "--spec", sources / "docker-engine-api-1.47-spec.yaml", "--output", audit,
                         "--database", results / "measurements.sqlite3")

    current = json.loads(gzip.decompress(audit.read_bytes()))
    assert current["spec_sha256"] == prior["spec_sha256"] == fixture_hashes["docker-engine-api-1.47-spec.yaml"]
    assert current["profile"] == "engine" and current["version"] == "1.47" and current["cli_api_version"] == "1.47"
    assert current["operations"] == prior["operations"] and current["candidate"].keys() == prior["candidate"].keys()
    current_cases, prior_cases = current["candidate"], prior["candidate"]
    classification_changes = {name: {"before": prior_cases[name]["comparison"], "after": value["comparison"]}
                              for name, value in current_cases.items() if value["comparison"] != prior_cases[name]["comparison"]}
    observations_changed = [name for name, value in current_cases.items() if value != prior_cases[name]]
    counts = Counter(value["comparison"] for value in current_cases.values())
    cleanup = {side: audited_scope(endpoint, current["scopes"][side])
               for side, endpoint in (("reference", args.reference), ("candidate", args.candidate))}
    summary = {
        "job_sha256": job_sha,
        "build_receipt_sha256": sha(args.build),
        "identity": {"exit": identity_exit, "receipt": identity.name, "sha256": sha(identity) if identity.exists() else None},
        "identity_cleanup": {"exit": cleanup_exit, "receipt": identity_cleanup.name,
                             "sha256": sha(identity_cleanup) if identity_cleanup.exists() else None},
        "audit": {"exit": audit_exit, "receipt": audit.name, "sha256": sha(audit), "previous_receipt_sha256": sha(args.prior_audit),
                  "api_version": "1.47", "profile": "engine", "spec_sha256": current["spec_sha256"],
                  "observed_groups": len(current_cases), "group_counts": dict(counts),
                  "spec_operations": len(current["operations"]), "probed_operations": sum("cases" in op for op in current["operations"].values()),
                  "comparison_state_changes": classification_changes, "candidate_observations_changed": observations_changed,
                  "scope_cleanup": cleanup},
    }
    summary["passed"] = (identity_exit == cleanup_exit == 0 and audit_exit in (0, 1) and not counts["reference-failed"] and
                         not classification_changes and all(row["passed"] for row in cleanup.values()))
    (results / "acceptance.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, indent=2, sort_keys=True))
    return int(not summary["passed"])


if __name__ == "__main__":
    raise SystemExit(main())
