"""Keep the exact native push guest and matched release kernel in the qualified binary store."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

receipts = Path(__file__).resolve().parent
scope = receipts.parent
hub = scope / 'home'
repository = Path('/Users/benebsworth/projects/micropod')
store = repository / '.build/qualified' / ('micropod-hvf-gamma4-' + scope.name.removeprefix('mp-gamma4.').lower())


def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def staged(arm, role):
    data = read(receipts / f'{arm}-ready.json')['owned_artifacts'][role]
    path = Path(data['path'])
    assert path.resolve(strict=True) == path and path.is_relative_to(hub) and sha(path) == data['sha256'], data
    return path, data['sha256']


def retain(arm, role, name):
    path, digest = staged(arm, role)
    target = store / f'{name}-{digest[:12]}'
    if not target.exists():
        temporary = target.with_name(target.name + '.writing')
        with path.open('rb') as source, temporary.open('xb') as output:
            shutil.copyfileobj(source, output)
        shutil.copystat(path, temporary)
        assert sha(temporary) == digest
        temporary.rename(target)
    assert target.resolve(strict=True) == target and sha(target) == digest
    return {'attested_worker': arm, 'path': str(target), 'sha256': digest, 'bytes': target.stat().st_size}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--push-label', required=True)
    args = parser.parse_args()
    assert hub.is_mount() and not (store / 'manifest.json').exists()
    assert staged('release-off', 'kernel') == staged('release-on', 'kernel')
    store.mkdir(mode=0o755, exist_ok=True)
    manifest = {'bench_scope': scope.name, 'production_lineage': read(receipts / 'baseline-lineage.json')['artifacts']}
    manifest['artifacts'] = {
        'runner_with_native_registry_push_and_auth': retain(args.push_label, 'job', 'runner-job'),
        'matched_fuse_release_experiment_kernel': retain('release-on', 'kernel', 'Image-release-ab'),
    }
    if args.push_label != 'push':
        manifest['artifacts']['registry_protocol_initial_job'] = retain('push', 'job', 'runner-job')
    if args.push_label != 'push-id' and (receipts / 'push-id-ready.json').is_file():
        manifest['artifacts']['registry_id_initial_job'] = retain('push-id', 'job', 'runner-job')
    for role in ('cli', 'vmm', 'initrd', 'kernel', 'job'):
        item = manifest['production_lineage'][role]
        original = Path(item.pop('source'))
        item.pop('staged')
        assert sha(original) == item['sha256']
        item['path'] = str(original)
        if role in ('cli', 'vmm'):
            check = subprocess.run(['/usr/bin/codesign', '--verify', '--strict', '--verbose=4', str(original)],
                                   capture_output=True, text=True, check=True, timeout=20)
            item['signature'] = check.stderr
    product = store / 'manifest.json'
    payload = json.dumps(manifest, indent=2) + '\n'
    with product.open('x') as file:
        file.write(payload)
    proof = {'path': str(product), 'sha256': sha(product), 'manifest': manifest}
    (receipts / 'retained-runtime-manifest.json').write_text(json.dumps(proof, indent=2) + '\n')
    print(json.dumps(proof, indent=2))


if __name__ == '__main__':
    main()
