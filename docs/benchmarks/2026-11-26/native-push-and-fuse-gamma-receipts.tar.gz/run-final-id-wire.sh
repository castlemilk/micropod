#!/bin/bash
set -euo pipefail
e=$(cd "$(dirname "$0")" && pwd -P)
a=$(dirname "$e")/home/registry-fixture
w=/Users/benebsworth/projects/micropod/bench/phase0-host-scheduling/scripts
label=${1:?private worker label}
run=${2:?fresh run identifier}
ready="$e/$label-ready.json"
dest="$e/registry-id-final"
mkdir -p "$dest"
s=$(jq -er .socket "$ready")
img=$(jq -er .benchmark_image "$ready")
test -S "$s"
test ! -e "$dest/$run-registry.json" && test ! -e "$dest/$run-retention.json"
for file in qualify_docker_push.py qualify_docker_image_id.py qualify_docker_image_history.py qualify_engine_api.py; do
    cp "$w/$file" "$dest/$run-$file"
done
set +e
python3 -B "$w/qualify_docker_image_id.py" --socket "$s" --output "$dest/$run-retention.json" --native >"$dest/$run-retention.log" 2>&1
retention=$?
python3 -B "$w/qualify_docker_push.py" --socket "$s" --worker-image "$img" --ca-cert "$a/test-ca.crt" \
    --ca-key "$a/test-ca.key" --registry-archive "$a/registry-release.tar.gz" --output "$dest/$run-registry.json" --active-removal \
    >"$dest/$run-registry.log" 2>&1
registry=$?
set -e
printf 'retention %d registry %d\n' "$retention" "$registry"
test "$retention" -eq 0 && test "$registry" -eq 0
