#!/bin/bash
set -euo pipefail
receipts=$(cd "$(dirname "$0")" && pwd -P)
hub=$(dirname "$receipts")/home
ready="$receipts/irq-route-ready.json"
repo=/Users/benebsworth/projects/micropod
driver="$repo/bench/phase0-host-scheduling/scripts/bench_git_cpu_placement.py"
sock=$(jq -er .socket "$ready")
workspace=$(jq -er .workspace "$ready")
image=$(jq -er .benchmark_image "$ready")
trigger() {
    python3 -B "$receipts/workspace_irq_trigger.py" "$1" --ready "$ready" --out "$receipts/irq-control-$1.json"
}
placement() {
    python3 -B "$receipts/with_host_load.py" --out "$receipts/irq-git-$1-load.jsonl" -- python3 -B "$driver" \
        --hvf-socket "$sock" --orbstack-socket /Users/benebsworth/.orbstack/run/docker.sock --workspace "$workspace" \
        --source "$hub/evidence/prior/runner-vendored" --helpers "$hub/evidence/prior/final-harness/scripts" \
        --image-manifest "$receipts/image-manifest.json" --image "$image" --out "$receipts/irq-git-$1.json"
}
trigger begin
placement default
trigger route
trap 'test -f "$receipts/irq-control-restore.json" || trigger restore' EXIT
placement moved
trigger restore
trap - EXIT
