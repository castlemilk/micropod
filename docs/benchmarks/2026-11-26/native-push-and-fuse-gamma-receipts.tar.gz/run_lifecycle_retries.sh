#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
H="$(dirname "$D")/home"
kernel="$H/kernel-release-base/workspace-release/Image"
bank="$H/artifacts/tools-release-lifecycle-v2"
sha=61b4e143b26039e4642f48b3819e0233f22b44f5c3e88e109cbc9c17508cc85f
test "$(shasum -a 256 "$kernel" | cut -d' ' -f1)" = "$sha"
overall=0
for mode in off on; do
    arm="release-$mode-life"
    flag=0
    if [[ $mode == on ]]; then flag=1; fi
    python3 -B "$D/public_machine.py" "$arm" --live-read 1 --kernel "$kernel" --tools "$bank" \
        --kernel-arg "virtiofs.workspace_async_release=$flag" > "$D/$arm-owner.log" 2>&1 &
    owner=$!
    for x in {1..60}; do
        [[ -s "$D/$arm-ready.json" ]] && break
        kill -0 "$owner" 2>/dev/null || break
        sleep 1
    done
    if [[ ! -s "$D/$arm-ready.json" ]]; then
        kill -TERM "$owner" 2>/dev/null || true
        wait "$owner" || true
        printf '%s failed in protected boot\n' "$arm" >&2
        exit 1
    fi
    set +e
    bash "$D/run_gamma4_arm.sh" "$arm" correctness > "$D/$arm-correctness.log" 2>&1
    ordinary=$?
    python3 -B "$D/run_release_lifecycle.py" "$arm" > "$D/$arm-lifecycle.log" 2>&1
    terminal=$?
    set -e
    printf 'ordinary_and_held=%s terminal_lifecycle=%s\n' "$ordinary" "$terminal" | tee "$D/$arm-qualification-exit.log"
    python3 -B "$D/retire_gamma4_worker.py" "$arm"
    wait "$owner"
    jq -e '.errors == {} and .scope_absent and .machine.clean_shutdown and .drive.detached.persisted_policy.mounted_read_only' \
        "$D/$arm-worker.json" >/dev/null
    if (( ordinary != 0 || terminal != 0 )); then overall=1; fi
done
exit "$overall"
