#!/bin/bash
set -euo pipefail

r=$(cd "$(dirname "$0")" && pwd -P)
hub=$(dirname "$r")
archive="$hub/home/evidence/prior"
driver="$hub/home/kernel-release-base/controls/trace_raw_git_release.py"
ready=$1
mode=$2
out=$3
test "$out" = "$r/$(basename "$out")"
test ! -e "$out"
socket=$(jq -er .socket "$ready")
workspace=$(jq -er .workspace "$ready")
image=$(jq -er .benchmark_image "$ready")
python3 -B "$driver" --socket "$socket" --workspace "$workspace" --image "$image" --out "$out" \
    --source "$archive/runner-vendored" --helpers "$archive/final-harness/scripts" --observer "$archive/trace-proof" \
    --image-manifest "$r/image-manifest.json" --expected-mode "$mode" --trace --samples 6
