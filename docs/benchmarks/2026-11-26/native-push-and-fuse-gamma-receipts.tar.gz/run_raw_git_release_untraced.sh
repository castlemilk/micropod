#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
arm=${1:?release arm}
case "$arm" in
    release-off) mode=N ;;
    release-on) mode=Y ;;
    *) exit 2 ;;
esac
R="$D/$arm-ready.json"
H="$(dirname "$D")/home"
P="$H/evidence/prior"
exec python3 -B "$D/with_host_load.py" --out "$D/$arm-raw-git-untraced-host-load.jsonl" -- \
    python3 -B "$H/kernel-release-base/controls/trace_raw_git_release.py" \
    --socket "$(jq -er .socket "$R")" --workspace "$(jq -er .workspace "$R")" --image "$(jq -er .benchmark_image "$R")" \
    --out "$D/$arm-raw-git-untraced.json" --source "$P/runner-vendored" --helpers "$P/final-harness/scripts" \
    --observer "$P/trace-proof" --image-manifest "$D/image-manifest.json" --expected-mode "$mode" --samples 6 \
    > "$D/$arm-raw-git-untraced.log" 2>&1
