"""Exercise exact owned virtiofs connection recovery after a matched kernel arm."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
from secrets import token_hex
import subprocess
import tempfile
import time

receipts = Path(__file__).resolve().parent
hub = receipts.parent / 'home'
container_label = 'io.micropod.gamma4.release-lifecycle'


def read_line_fields(path, token, mode):
    assert path.is_file() and not path.is_symlink()
    pairs = [row.split('=', 1) for row in path.read_text().splitlines()]
    assert all(len(pair) == 2 for pair in pairs)
    result = dict(pairs)
    assert len(result) == len(pairs) and result['token'] == token and result['mode'] == mode
    return result


def command(argv, *, check=True, timeout=15):
    return subprocess.run(argv, capture_output=True, text=True, check=check, timeout=timeout)


def fs_connection(device):
    assert re.fullmatch(r'[0-9]+:[0-9]+', device), device
    major, minor = map(int, device.split(':'))
    return (major << 20) | minor


def run(args, report):
    assert re.fullmatch(r'release-(on|off)(-life)?', args.arm)
    label = args.arm
    ready = json.loads((receipts / f'{label}-ready.json').read_text())
    mode = 'Y' if label.startswith('release-on') else 'N'
    assert f'virtiofs.workspace_async_release={int(mode == "Y")}' in ready['kernel_arguments_requested']
    workspace = Path(ready['workspace'])
    socket = Path(ready['socket'])
    assert workspace.resolve(strict=True) == workspace and workspace == hub / 'share' / label
    assert socket.is_socket() and socket.resolve(strict=True).is_relative_to(Path(ready['worker_directory']))
    docker = ['/opt/homebrew/bin/docker', '--host', 'unix://' + str(socket)]
    report['containers_before'] = command([*docker, 'ps', '-aq']).stdout.splitlines()
    assert not report['containers_before']
    receipt = workspace / '.release-lifecycle.done'
    request = workspace / '.release-lifecycle.request'
    assert not any(os.path.lexists(path) for path in (receipt, request))
    assert not any(workspace.glob('.trace-*'))
    token = token_hex(8)
    report['request'] = {'token': token, 'mode': mode, 'utc': datetime.now(timezone.utc).isoformat()}
    with tempfile.NamedTemporaryFile(mode='w', dir=workspace, prefix='.terminal-', delete=False) as staged:
        staged.write(token + '\n')
        tmp = Path(staged.name)
    try:
        os.link(tmp, request)
    finally:
        tmp.unlink()
    started = time.monotonic()
    try:
        deadline = started + 55
        while not receipt.is_file():
            if time.monotonic() > deadline:
                raise TimeoutError('The terminal fixture did not publish a receipt. Read the owned console.')
            time.sleep(0.05)
        data = read_line_fields(receipt, token, mode)
        report.update(observer=data, observer_seconds=time.monotonic() - started)
        assert data['exit'] == '0' and data['step'] == 'pass', data
        assert data['held_read_failed_after_abort'] == '1', data
        assert int(data['aborted_connection']) == fs_connection(data['workspace_device_remounted']) > 0, data
        assert fs_connection(data['workspace_device_initial']) > 0 and fs_connection(data['workspace_device_final']) > 0, data
        assert data['concurrent_readers'] == data['fsynced_writers'] == '8' and data['reads_per_job'] == '64', data
        assert not (workspace / f'release-lifecycle-{token}').exists(), 'guest fixture still exists'

        # A new stock Docker container verifies bytes through the recovered bind endpoint.
        name = f'mpg4-release-{token}'
        key = f'{container_label}={name}'
        cleanup = [*docker, 'ps', '--no-trunc', '-aq', '--filter', f'label={key}']
        assert not command(cleanup).stdout.strip()
        with tempfile.TemporaryDirectory(prefix='mpg4-remount-check-', dir=workspace) as own:
            path = Path(own)
            (path / 'value').write_text(token + '\n')
            try:
                value = command([*docker, 'run', '--rm', '--pull=never', '--network=none', '--label', key,
                                 '--name', name, '--mount', f'type=bind,src={path},dst=/check,readonly',
                                 '--entrypoint', '/bin/cat', ready['benchmark_image'], '/check/value'])
                report['post_recovery_docker_read'] = value.stdout.rstrip('\n')
                assert value.stdout == token + '\n'
            finally:
                ids = command(cleanup).stdout.splitlines()
                if ids:
                    assert ids == [command([*docker, 'inspect', '--format', '{{.Id}}', name]).stdout.strip()]
                    command([*docker, 'container', 'rm', '--force', ids[0]])
                report['containers_after'] = command([*docker, 'ps', '-aq']).stdout.splitlines()
                assert not report['containers_after']
    finally:
        if receipt.is_file() and not receipt.is_symlink():
            record = receipts / f'{label}-lifecycle-guest.txt'
            with record.open('x') as file:
                file.write(receipt.read_text())
            receipt.unlink()
        if request.is_file() and not request.is_symlink():
            assert request.read_text() == token + '\n'
            request.unlink()


def main():
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument('arm')
    values = args.parse_args()
    assert re.fullmatch(r'release-(on|off)(-life)?', values.arm)
    result = receipts / f'{values.arm}-lifecycle.json'
    assert not result.exists()
    for key in ('DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH', 'DOCKER_API_VERSION'):
        os.environ.pop(key, None)
    report = {'pass': False, 'arm': values.arm}
    try:
        run(values, report)
        report['pass'] = True
    except Exception as error:
        report['failure'] = repr(error)
        raise
    finally:
        with result.open('x') as file:
            json.dump(report, file, indent=2)
            file.write('\n')


if __name__ == '__main__':
    main()
