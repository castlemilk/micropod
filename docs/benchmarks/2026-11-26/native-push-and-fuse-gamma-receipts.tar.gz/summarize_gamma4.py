"""Summarize Gamma native Docker push and stock mounted CI with matched kernel controls."""
from collections import Counter
import hashlib
import json
from pathlib import Path
from statistics import median

receipts = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_bytes())


def receipt(path):
    with path.open('rb') as content:
        digest = hashlib.file_digest(content, 'sha256').hexdigest()
    return {'path': path.relative_to(receipts).as_posix(), 'sha256': digest}


def load(path):
    rows = [json.loads(line) for line in path.read_bytes().splitlines()]
    samples = [row for row in rows if row.get('cpu_idle_pct') is not None]
    ticks = Counter()
    for sample in samples:
        ticks.update(sample['delta_ticks'])
    idle = [sample['cpu_idle_pct'] for sample in samples]
    result = {'receipt': receipt(path), 'samples': len(samples), 'command_exit': rows[-1]['code'],
              'first_utc': rows[0]['utc'], 'last_utc': rows[-2]['utc']}
    if samples:
        result.update(weighted_cpu_idle_pct=100 * ticks['idle'] / ticks.total(),
                      idle_pct_min_median_max=[min(idle), median(idle), max(idle)],
                      load_avg_1m_min_max=[min(row['load_average'][0] for row in samples),
                                          max(row['load_average'][0] for row in samples)])
    return result


def milliseconds(ns):
    return ns / 1e6 if ns is not None else None


def material(path, result):
    records = {'receipt': receipt(path), 'source': result['source'], 'git_commit': result['git_commit'], 'image': result['image'],
               'pairs': len(result['pairs']), 'cpus': result['cpus'], 'memory_mib': result['memory_mib'],
               'timing_scopes': result['timing_scopes'], 'load': load(path.with_name(path.stem + '-host-load.jsonl')),
               'cold_prime': {engine: {'guest_sum_ms': milliseconds(row['sum_ns']),
                                      'phase_ms': {key: milliseconds(value) for key, value in row['phase_ns'].items()},
                                      'stock_docker_transport': row['stock_docker_transport']}
                              for engine, row in result['prime'].items()}, 'rounds': {}}
    for phase in ('warm', 'incremental'):
        paired = [pair[phase] for pair in result['pairs']]
        by_engine = {}
        for engine in ('hvf', 'orbstack'):
            rows = [pair[engine] for pair in paired]
            by_engine[engine] = {'guest_sum_median_ms': result['median_ms'][phase][engine],
                               'guest_phase_medians_ms': {key: milliseconds(median(row['phase_ns'][key] for row in rows))
                                                         for key in rows[0]['phase_ns']},
                               'edit_return_to_matching_ms': result['edit_return_to_correct_median_ms'][phase][engine],
                               'edit_through_verified_build_ms': result['edit_to_completed_build_median_ms'][phase][engine],
                               'all_first_byte_reads_match': all(row['visibility']['observations'][0]['sha256'] ==
                                                                 row['visibility']['expected_sha256'] for row in rows)}
        records['rounds'][phase] = {'engines': by_engine,
                                    'hvf_wins': sum(row['hvf']['sum_ns'] < row['orbstack']['sum_ns'] for row in paired),
                                    'median_hvf_to_orbstack_ratio': median(row['hvf']['sum_ns'] / row['orbstack']['sum_ns'] for row in paired)}
    return records


def receipts_for(*patterns):
    entries = {}
    for pattern in patterns:
        for path in sorted(receipts.glob(pattern)):
            if path.is_file() and path.stat().st_size:
                entries[path.relative_to(receipts).as_posix()] = receipt(path)
    return entries


def git_trace(path):
    data = read(path)
    passed = data.get('trace_complete', data.get('passed', False))
    summary = {'receipt': receipt(path), 'pass': passed}
    if not passed:
        return {**summary, 'failure': data.get('failure')}
    if samples := data.get('untraced_samples'):
        summary.update(mode=samples[0]['mode'], kernel=samples[0]['kernel'], samples_ms=[row['status_ms'] for row in samples],
                       git_ms_median=median(row['status_ms'] for row in samples), remaining=data['remaining'])
    if 'traced_sample' in data:
        main = data['git_fuse']['main_thread']
        git_ns = data['traced_sample']['finish_ns'] - data['traced_sample']['clock']['now_ns']
        close = data['git_fuse']['close']
        summary.update(traced_git_ms=data['traced_sample']['status_ms'],
                       all_scoped_wire_timings=data['git_fuse']['all_threads_and_scoped_activity'],
                       main_thread_wire_timings=main,
                       main_thread_close=close,
                       close_with_release_pct_of_traced_git=100 * close['calls_with_release'].get('sum_ns', 0) / git_ns,
                       open_read_wire_sum_pct_of_traced_git=100 * (main['OPEN']['sum_ns'] + main['READ']['sum_ns']) / git_ns,
                       main_request_overlap=data['git_fuse']['main_next_send_before_this_reply'],
                       guest_work_enqueue_to_start=data['capture']['work_enqueue_to_start_workspace'],
                       capture=data['capture']['capture'])
    return summary


def main():
    materials = {}
    for path in sorted(receipts.glob('*-material.json')):
        if path.stat().st_size and (data := read(path)).get('workspace_mode') == 'independent byte-identical raw host checkouts':
            materials[path.stem.removesuffix('-material')] = material(path, data)
    workers = {}
    for path in sorted(receipts.glob('*-ready.json')):
        data = read(path)
        workers[data['label']] = {'receipt': receipt(path), 'artifacts': data['owned_artifacts'],
                                  'tools': data.get('tool_bank_lineage', {}), 'arguments': data.get('kernel_arguments_requested', []),
                                  'kernel_reported': data['guest_tool_probe'][0]}
    traces = {}
    for path in sorted(receipts.glob('*.json')):
        if 'raw-git' in path.stem and path.stat().st_size and any(k in read(path) for k in ('diagnostic_trace', 'trace_complete')):
            traces[path.stem] = git_trace(path)
    material_delta = {}
    if {'release-off', 'release-on'} <= materials.keys():
        before, after = (materials[name] for name in ('release-off', 'release-on'))
        for phase, old in before['rounds'].items():
            new = after['rounds'][phase]
            material_delta[phase] = {
                'guest_phase_median_ms_off': old['engines']['hvf']['guest_phase_medians_ms'],
                'guest_phase_median_ms_on': new['engines']['hvf']['guest_phase_medians_ms'],
                'hvf_guest_sum_ms_off': old['engines']['hvf']['guest_sum_median_ms'],
                'hvf_guest_sum_ms_on': new['engines']['hvf']['guest_sum_median_ms'],
                'hvf_to_orbstack_paired_ratio_off': old['median_hvf_to_orbstack_ratio'],
                'hvf_to_orbstack_paired_ratio_on': new['median_hvf_to_orbstack_ratio'],
            }
    ambient = {path.stem: load(path) for path in sorted(receipts.glob('*-load.jsonl'))
               if path.stat().st_size and json.loads(path.read_bytes().splitlines()[-1]).get('code') is not None}
    diagnostics = {}
    for name, keys in {
        'git-affinity.json': ('passed', 'medians', 'source', 'remaining'),
        'irq-git-default.json': ('passed', 'medians', 'source', 'remaining'),
        'irq-git-moved.json': ('passed', 'medians', 'source', 'remaining'),
        'irq-control-begin.json': ('pass', 'status', 'cleanup'),
        'irq-control-route.json': ('pass', 'status', 'cleanup'),
        'irq-control-restore.json': ('pass', 'status', 'cleanup', 'control_removed'),
        'release-density-git-jobs.json': ('passed', 'comparison', 'cpus', 'memory_mib', 'medians_ms', 'cleanup'),
        'release-density-git-wave.json': ('passed', 'comparison', 'jobs_per_wave', 'cpus_per_job', 'memory_mib',
                                          'summary', 'cleanup', 'workspace_removed'),
        'lifecycle-matched-summary.json': ('source_scope', 'arms'),
        'final-runtime-audit.json': ('baseline_checkout_unchanged', 'source', 'final_linux'),
        'registry/combined-engine-coverage.json': ('api', 'covered', 'total', 'job_sha256',
                                                   'pinned_operations', 'registry_operations', 'combined_operations'),
    }.items():
        path = receipts / name
        if path.is_file():
            data = read(path)
            diagnostics[path.stem] = {'receipt': receipt(path), **{key: data[key] for key in keys}}
    result = {'host': 'Gamma-128GB.local', 'date_melbourne': '2026-11-26',
              'lineage': read(receipts / 'baseline-lineage.json'), 'image': read(receipts / 'image.json'),
              'workers': workers, 'material': materials, 'material_toggle_comparison': material_delta,
              'standalone_stock_git': traces, 'ambient_load': ambient, 'supplemental_results': diagnostics,
              'lifecycle': {path.stem: {'receipt': receipt(path), **read(path)}
                            for path in sorted(receipts.glob('release-*-lifecycle.json'))},
              'git_cpu_placement_evidence': receipts_for('*affinity*', '*density*', 'git-cpu*/**/*',
                                                        'git-affinity*/**/*', 'bench_git_cpu_placement.py', 'irq-*.json'),
              'kernel_evidence': receipts_for('workspace-release-*', 'release-*', 'baseline-raw-git*', 'lifecycle-*', '*irq-route*'),
              'filesystem_and_stock_control_evidence': receipts_for('*-edits.json', '*-mmap-exact.json',
                                                                      '*-guest-splice.json', '*-stock-pid1.json'),
              'push_evidence': receipts_for('*registry*.json', 'push-*.json', 'docker-image-push*',
                                            'image-push*/**/*', 'docker-image-auth*', 'native-push*', 'docker-engine-api-*.json', 'native-docker-api-*.json.gz', 'registry/**/*', 'registry-id/**/*', 'registry-id-final/**/*')}
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
