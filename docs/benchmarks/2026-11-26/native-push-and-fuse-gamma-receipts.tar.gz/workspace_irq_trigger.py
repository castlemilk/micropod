"""Deliver one authenticated demand event through a private stock Docker job."""
import argparse
import json
import os
from pathlib import Path
import re
from secrets import token_hex
import subprocess
import time

receipts = Path(__file__).resolve().parent
home = receipts.parent / "home"
label = "io.micropod.gamma4.irq-command"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("begin", "route", "restore"))
    parser.add_argument("--ready", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    assert args.out.parent.resolve(strict=True) == receipts and not args.out.exists()
    ready = json.loads(args.ready.read_bytes())
    workspace = Path(ready["workspace"])
    socket = Path(ready["socket"])
    assert ready["label"] == "irq-route" and workspace.resolve(strict=True) == home / "share" / "irq-route"
    assert socket.is_socket() and socket.resolve(strict=True).is_relative_to(Path(ready["worker_directory"]))
    assert "tools-workspace-irq-owner/" in ready["owned_artifacts"]["job"]["path"]
    control = workspace / ".workspace-irq-owner"
    inbox = control / "inbox"
    marker = control / "ready.json"
    passed = control / (args.action + ".json")
    assert control.resolve(strict=True) == control and inbox.resolve(strict=True) == inbox
    assert not marker.is_symlink() and json.loads(marker.read_bytes()) == {"ready": True}
    assert not os.path.lexists(inbox / "next") and not os.path.lexists(passed)
    token = (home / "artifacts/tools-workspace-irq-owner/runner/.workspace-irq-token").read_text().strip()
    assert re.fullmatch(r"[0-9a-f]{32}", token)
    payload = f"{token} {args.action}\n".encode()

    for key in ("DOCKER_HOST", "DOCKER_CONTEXT", "DOCKER_TLS", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH", "DOCKER_API_VERSION"):
        os.environ.pop(key, None)
    docker = ["/opt/homebrew/bin/docker", "--host", "unix://" + str(socket)]
    name = "mpg4-irq-" + token_hex(8)
    scope = f"{label}={name}"
    query = [*docker, "ps", "-aq", "--filter", "label=" + scope]
    code = ('umask 077; p=$(mktemp /command/.request.XXXXXX); trap \'rm -f "$p"\' EXIT; '
            'cat > "$p"; mv "$p" /command/next')
    report = {"pass": False, "action": args.action, "worker": str(args.ready), "cleanup": None}
    try:
        wrote = subprocess.run([*docker, "run", "--rm", "-i", "--pull=never", "--network=none", "--label", scope,
                                "--name", name, "--mount", f"type=bind,src={inbox},dst=/command",
                                "--entrypoint", "/bin/sh", ready["benchmark_image"], "-ec", code],
                               input=payload, capture_output=True, timeout=15, check=False)
        report["docker_exit"] = wrote.returncode
        if wrote.returncode != 0:
            raise RuntimeError(wrote.stderr.decode(errors="replace"))
        deadline = time.monotonic() + 8
        while not passed.is_file():
            if time.monotonic() > deadline:
                raise TimeoutError("owner hook did not acknowledge the command; inspect the private worker console")
            time.sleep(0.025)
        status = json.loads(passed.read_bytes())
        assert not passed.is_symlink() and status["action"] == args.action
        report["status"] = status
        if args.action == "restore":
            expected = {"ready.json", "begin.json", "route.json", "restore.json", "inbox"}
            deadline = time.monotonic() + 2
            while list(control.glob(".report-*")) and time.monotonic() < deadline:
                time.sleep(0.01)
            assert {path.name for path in control.iterdir()} == expected and not list(inbox.iterdir())
            inbox.rmdir()
            for name in expected - {"inbox"}:
                path = control / name
                assert path.is_file() and not path.is_symlink()
                path.unlink()
            control.rmdir()
            report["control_removed"] = not control.exists()
        report["pass"] = True
    except Exception as error:
        report["failure"] = repr(error)
        raise
    finally:
        try:
            ids = subprocess.run(query, capture_output=True, timeout=10, check=True).stdout.decode().splitlines()
            if ids:
                subprocess.run([*docker, "rm", "-f", *ids], capture_output=True, timeout=10, check=True)
            report["cleanup"] = subprocess.run(query, capture_output=True, timeout=10, check=True).stdout.decode().splitlines()
        finally:
            with args.out.open("x") as handle:
                json.dump(report, handle, indent=2)
                handle.write("\n")
    assert report["cleanup"] == []
    print(json.dumps(report["status"], indent=2))


if __name__ == "__main__":
    main()
