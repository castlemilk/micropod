"""Attribute completed FUSE requests to Git's issuing thread in the archived raw-index trace."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re

here = Path(__file__).resolve().parent / 'historical'
trace = here / 'base-host-gitstudy.trace-events.log'
report = json.loads((here / 'base-host-ftrace.json').read_bytes())
connection = int(report['capture']['connection'])
observer = int(report['capture']['observer_pid'])
event_prefix = r'^\s*(\S+)-(\d+)\s+\[\d+\]\s+\S+\s+(\d+\.\d{6}): '
prefix = re.compile(event_prefix + r'(fuse_request_(?:send|end)): connection (\d+) req (\d+) (.*)$')
opcode = re.compile(r'opcode \d+ \(FUSE_([A-Z0-9_]+)\)')
token = report['capture']['token']
marker = re.compile(event_prefix + rf'tracing_mark_write: mp-workspace-(start|finish) {token}$')
lines = trace.read_text().splitlines()
timing = {m[4]: int(m[3].replace('.', '')) for line in lines if (m := marker.match(line)) and int(m[2]) == observer}
assert (timing['finish'] - timing['start']) * 1000 == report['window_ns']
pending = {}
paired = []
for line in lines:
    event = prefix.match(line)
    if event is None:
        continue
    comm, tid, stamp, operation, conn, req, rest = event.groups()
    if int(conn) != connection:
        continue
    at = int(stamp.replace('.', ''))
    if not timing['start'] <= at <= timing['finish']:
        continue
    if operation.endswith('send'):
        pending[req] = (comm, int(tid), at, opcode.search(rest)[1])
    elif req in pending:
        sender, origin, start, kind = pending.pop(req)
        if origin != observer:
            paired.append((sender, origin, kind, start, at))
by_kind = Counter(row[2] for row in paired)
assert by_kind == Counter({key: row['count'] for key, row in report['fuse_send_to_end'].items()})
open_by_thread = Counter(row[1] for row in paired if row[0] == 'git' and row[2] == 'OPEN')
main, count = open_by_thread.most_common(1)[0]
mine = [row for row in paired if row[0] == 'git' and row[1] == main]
read_path = {'OPEN', 'READ', 'RELEASE'}
read_intervals = sorted((row[3], row[4]) for row in mine if row[2] in read_path)
intervals = []
for start, finish in read_intervals:
    if intervals and start <= intervals[-1][1]:
        intervals[-1][1] = max(intervals[-1][1], finish)
    else:
        intervals.append([start, finish])
by_operation = defaultdict(lambda: {'count': 0, 'sum_us': 0, 'max_us': 0})
for _, _, kind, start, finish in mine:
    row = by_operation[kind]
    row['count'] += 1
    row['sum_us'] += finish - start
    row['max_us'] = max(row['max_us'], finish - start)
result = {'trace_sha256': hashlib.sha256(trace.read_bytes()).hexdigest(), 'capture': report['capture'],
          'complete_requests': len(paired), 'complete_requests_ge_5ms': sum(row[4] - row[3] >= 5000 for row in paired),
          'max_guest_fuse_roundtrip_us': max(row[4] - row[3] for row in paired),
          'main_git_tid_by_open_count': main, 'git_main_open_count': count, 'main_git_by_operation': dict(by_operation),
          'main_git_open_read_release_union_us': sum(finish - start for start, finish in intervals),
          'main_git_observed_fuse_span_us': max(row[4] for row in mine) - min(row[3] for row in mine),
          'scope': 'Archived raw-index trace. FUSE wire events do not carry a pathname for these operations.'}
(here / 'base-host-dispatch-detail.json').write_text(json.dumps(result, indent=2) + '\n')
