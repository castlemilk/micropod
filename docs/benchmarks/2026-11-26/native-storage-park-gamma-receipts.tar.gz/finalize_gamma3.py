"""Retire only this Gamma round's private APFS and Docker scopes and archive their receipts."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import plistlib
import shutil
import subprocess
import sys
import tarfile
import time

import worker_apfs_drive as apfs

receipts = Path(__file__).resolve().parent
scope = receipts.parent
hub = scope / 'home'
assert scope.parent == Path('/private/tmp') and scope.name.startswith('mp-gamma3.')
suffix = scope.name.removeprefix('mp-gamma3.').lower()
worktree = Path(sys.argv[1]).resolve(strict=True)
results = worktree / 'docs/benchmarks/2026-11-26'
scorecard = results / 'native-storage-park-gamma.json'
archive = results / 'native-storage-park-gamma-receipts.tar.gz'
assert not scorecard.exists() and not archive.exists()


def read(path):
    return json.loads(path.read_bytes())


def write(path, data):
    pending = path.with_name(path.name + '.writing')
    pending.write_text(json.dumps(data, indent=2) + '\n')
    pending.replace(path)


def sha(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()


def run(argv, *, check=True, timeout=55):
    return subprocess.run(argv, text=True, capture_output=True, timeout=timeout, check=check)


def mounted_images():
    payload = subprocess.check_output(['/usr/bin/hdiutil', 'info', '-plist'], timeout=40)
    return {image['image-path'] for image in plistlib.loads(payload)['images'] if image.get('image-path')}


def prior_products():
    expected = read(receipts / 'prior-pinned-products.json')
    lineage = read(receipts / 'baseline-lineage.json')
    for item in (*lineage['archives'].values(), *lineage['artifacts'].values()):
        path = item.get('source', item.get('path'))
        expected[path] = item['sha256']
    for path, digest in expected.items():
        assert sha(Path(path)) == digest, path
    return expected


def qualified_build_receipt(arms):
    folder = worktree.parent.parent / '.build/qualified' / f'micropod-hvf-gamma3-{suffix}'
    manifest = folder / 'manifest.json'
    data = read(manifest)['artifacts']
    prior_data = read(receipts / 'retained-b7d78-manifest.json')['artifacts']
    roles = {'vmm': 'micropod-vmm', 'job': 'runner-job'}
    candidates = {role: data[name]['sha256'] for role, name in roles.items()}
    products = {}
    for item in (*prior_data.values(), *data.values()):
        file = folder / item['filename']
        assert file.parent == folder and file.resolve(strict=True) == file and sha(file) == item['sha256'], file
        assert file.stat().st_size == item['size_bytes'], file
        products[file.name] = item['sha256']
    density_digest = arms['image-identity']['artifacts']['job']['sha256']
    density_binary = folder / f'runner-job-{density_digest[:12]}'
    assert density_binary.resolve(strict=True) == density_binary and sha(density_binary) == density_digest
    products[density_binary.name] = density_digest
    attested = [label for label, arm in arms.items() if all(arm['artifacts'][role]['sha256'] == digest for role, digest in candidates.items())]
    assert attested, candidates
    originals = read(receipts / 'baseline-lineage.json')['artifacts']
    signed = [Path(originals[role]['source']) for role in ('cli', 'vmm')]
    signed.append(folder / data['micropod-vmm']['filename'])
    signatures = {}
    for path in signed:
        check = run(['/usr/bin/codesign', '--verify', '--strict', '--verbose=4', str(path)])
        signatures[str(path)] = {'sha256': sha(path), 'codesign_stderr': check.stderr, 'exit': check.returncode}
    shutil.copy2(manifest, receipts / 'retained-runtime-manifest.json')
    return {'manifest': str(manifest), 'sha256': sha(manifest), 'verified_file_sha256': products,
            'installed_candidates': candidates, 'attested_workers': attested, 'strict_codesign': signatures}


def copy_candidate_evidence():
    allowed = ('.json', '.jsonl', '.log', '.py', '.sh', '.patch', '.txt', '.tar.gz', '.md', '.go')
    copied = {}
    for candidate in sorted(hub.iterdir()):
        if not candidate.is_dir() or not candidate.name.startswith(('storage-park', 'git-', 'image-', 'tag-')):
            continue
        for root, dirs, files in os.walk(candidate):
            dirs[:] = [name for name in dirs if name not in {'.git', 'source', 'target', '__pycache__'}]
            for name in sorted(files):
                file = Path(root) / name
                if not name.endswith(allowed) or file.is_symlink() or file.stat().st_size > 8 * 2**20:
                    continue
                target = receipts / 'candidate-inputs' / file.relative_to(hub)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(file, target)
                copied[target.relative_to(receipts).as_posix()] = sha(target)
    return copied


def archive_receipts():
    items = {path.relative_to(receipts).as_posix(): path for path in sorted(receipts.rglob('*'))
             if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts}
    manifest = {name: sha(path) for name, path in items.items()}
    payload = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    pending = archive.with_suffix(archive.suffix + '.pending')
    with pending.open('xb') as file, gzip.GzipFile(filename='', fileobj=file, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w|') as raw:
            for name, path in items.items():
                row = raw.gettarinfo(path, arcname=name)
                row.uid = row.gid = row.mtime = 0
                row.uname = row.gname = ''
                with path.open('rb') as source:
                    raw.addfile(row, source)
            row = tarfile.TarInfo('MANIFEST.sha256.json')
            row.size = len(payload)
            row.mode = 0o644
            raw.addfile(row, io.BytesIO(payload))
    with tarfile.open(pending) as raw:
        assert read_manifest(raw) == manifest and set(raw.getnames()) == set(manifest) | {'MANIFEST.sha256.json'}
        for name, digest in manifest.items():
            with raw.extractfile(name) as content:
                assert hashlib.file_digest(content, 'sha256').hexdigest() == digest, name
    pending.replace(archive)
    return {'path': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size, 'entries': len(manifest)}


def read_manifest(raw):
    with raw.extractfile('MANIFEST.sha256.json') as data:
        return json.load(data)


def worker_audit():
    workers = {}
    attached = mounted_images()
    for path in sorted(receipts.glob('*-worker.json')):
        worker = read(path)
        retirement = worker['drive']['detached']
        policy = retirement['persisted_policy']
        machine = worker['machine']
        assert not worker['errors'] and worker['scope_absent'] and machine['clean_shutdown'], path
        assert not machine['scoped_processes_after_stop'] and machine['supervisor_lock_released'] and machine['defaults_unchanged'], path
        assert retirement['image_absent'] and retirement['mount_restored'] and worker['image'] not in attached, path
        assert not any(Path(worker[key]).exists() for key in ('socket', 'image', 'worker_directory')), path
        assert policy['mounted_read_only'] and policy['spotlight']['disabled'] and policy['raw_disk_unchanged'], path
        assert policy['markers_unchanged'] and policy['journal_unchanged'], path
        assert policy['fsevents']['journal_files'] == policy['fsevents']['journal_bytes'] == 0, path
        workers[worker['label']] = {'image': worker['image'], 'uuid': policy['volume']['uuid'], 'clean_shutdown': True,
                                    'read_only': True, 'spotlight_disabled': True, 'fsevents_files': 0, 'fsevents_bytes': 0,
                                    'raw_identity_preserved': True, 'defaults_unchanged': True, 'removed': True,
                                    'artifacts': worker['owned_artifacts']}
    assert workers and str(scope / 'hub.sparseimage') in attached
    return workers


workers = worker_audit()
preservation = prior_products()
retained = qualified_build_receipt(workers)
candidate_files = copy_candidate_evidence()
summary = json.loads(run([sys.executable, '-B', str(receipts / 'summarize_gamma3.py')]).stdout)
write(receipts / 'measurement-summary.json', summary)
write(receipts / 'candidate-inputs-manifest.json', candidate_files)
write(receipts / 'prior-artifacts-final.json', preservation)

for key in ('DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH', 'DOCKER_API_VERSION'):
    os.environ.pop(key, None)
docker = ['/opt/homebrew/bin/docker', '--host', 'unix:///Users/benebsworth/.orbstack/run/docker.sock']
image = read(receipts / 'image.json')
assert image['tag'] == f'micropod-qa/checkout:gamma3-{suffix}'
assert run([*docker, 'image', 'inspect', '--format', '{{.Id}}', image['tag']]).stdout.strip() in (image['config_digest'], image['manifest_digest'])
assert not run([*docker, 'ps', '-aq', '--filter', f'ancestor={image["tag"]}']).stdout.strip()
assert not run([*docker, 'ps', '-aq', '--filter', f'label={image["label"]}']).stdout.strip()

started = time.monotonic()
holding = run(['/usr/sbin/lsof', '-nP', '+f', '--', str(hub)], check=False)
write(receipts / 'hub-holders-final.json', {'exit': holding.returncode, 'stdout': holding.stdout, 'stderr': holding.stderr,
                                         'seconds': time.monotonic() - started})
assert holding.returncode == 1 and not holding.stdout.strip() and not holding.stderr.strip(), holding
created = read(receipts / 'hub-created.json')
live = apfs.verify(created)
write(receipts / 'hub-final-live.json', live)
detached = apfs.detach(created, remove_image=True, inspect_history=True)
write(receipts / 'hub-detached.json', detached)
policy = detached['persisted_policy']
assert detached['image_absent'] and detached['mount_restored'] and policy['mounted_read_only']
assert policy['spotlight']['disabled'] and policy['markers_unchanged'] and policy['journal_unchanged']
assert policy['fsevents']['journal_files'] == policy['fsevents']['journal_bytes'] == 0
hub.rmdir()
owned = {arm['image'] for arm in workers.values()} | {created['image']}
assert not (mounted_images() & owned) and not any(Path(path).exists() for path in owned)

assert not run([*docker, 'ps', '-aq', '--filter', f'ancestor={image["tag"]}']).stdout.strip()
run([*docker, 'image', 'rm', image['tag']])
absent = run([*docker, 'image', 'inspect', image['tag']], check=False)
assert absent.returncode and any(value in absent.stderr.lower() for value in ('no such', 'not found'))

cleanup = {'worker_volumes': workers, 'hub_uuid': live['volume']['uuid'], 'hub_read_only_remount': True,
           'hub_spotlight_disabled': True, 'hub_fsevents_files': 0, 'hub_fsevents_bytes': 0, 'owned_images_removed': True,
           'owned_orbstack_tag_removed': True, 'owned_orbstack_builder_removed': image['builder_removed']}
write(receipts / 'final-cleanup.json', cleanup)
proof = archive_receipts()
assert list(scope.iterdir()) == [receipts] and not any(path.is_socket() for path in receipts.rglob('*'))
assert not scope.is_mount() and not receipts.is_mount()
shutil.rmtree(receipts)
scope.rmdir()
cleanup['private_stage_removed'] = not scope.exists()
summary.update(cleanup=cleanup, receipts=proof, prior_preservation=preservation, retained_runtime=retained,
               archived_candidate_files=candidate_files)
write(scorecard, summary)
print(scorecard, sha(scorecard), archive, proof['sha256'], flush=True)
