#!/usr/bin/env python3
"""Qualify Linux direct splice and sendfile with ordinary and edited files."""

import argparse
from contextlib import ExitStack
import errno
import hashlib
import json
import mmap
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time
from uuid import uuid4


ORIGINAL = b"warm0000old00001old00002"
MAPPED = b"mmap0000fresh001fresh002"
REPLACEMENT = b"repl0000repl0001repl0002"
INITIAL = b"aaaa0000bbbb0000cccc0000"
GUEST_MAPPED = b"aaaa0000mapped01mapped02"
UNTOUCHED = bytes(range(127))
MTIME_NS = 1_765_443_210_123_456_789
LABEL = "io.micropod.guest-splice-contract"


def check(actual, expected, description):
    if actual != expected:
        raise RuntimeError(f"{description}: {actual!r} != {expected!r}")


def wait(directory, name):
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        if (directory / name).exists():
            return
        time.sleep(0.01)
    raise RuntimeError(f"timed out waiting for {name}")


def file_observation(contents):
    for description, payload in (
        ("before_host_edit", ORIGINAL),
        ("after_host_edit", MAPPED),
        ("new_inode", REPLACEMENT),
    ):
        if contents == payload:
            return description
    raise RuntimeError(f"unexpected file bytes {contents!r}")


def copy_to_pipe(source, copy):
    reader, writer = os.pipe()
    try:
        n = copy(source, writer)
        return os.read(reader, n)
    finally:
        os.close(reader)
        os.close(writer)


def guest(directory, require_live_splice):
    payload = directory / "payload"
    output = {}
    with ExitStack() as opened:
        def file(path, flags):
            fd = os.open(path, flags, 0o600)
            opened.callback(os.close, fd)
            return fd

        sample = file(directory / "splice-control", os.O_RDONLY)
        os.lseek(sample, 9, os.SEEK_SET)
        methods = {
            "sendfile": lambda src, dst, off, n: os.sendfile(dst, src, off, n),
            "splice": lambda src, dst, off, n: os.splice(src, dst, n, offset_src=off),
        }
        for name, copy in methods.items():
            for offset, length in ((17, 31), (121, 14), (127, 10)):
                received = copy_to_pipe(sample, lambda src, dst: copy(src, dst, offset, length))
                check(received, UNTOUCHED[offset:offset + length], f"{name} control bytes")
                check(os.lseek(sample, 0, os.SEEK_CUR), 9, f"{name} explicit offset preserves fd")
        output["untouched_file_splice_and_sendfile"] = "range_short_read_eof_and_offset_passed"

        old_ro = file(payload, os.O_RDONLY)
        old_rw = file(payload, os.O_RDWR)
        prefaulted = opened.enter_context(
            mmap.mmap(old_ro, len(ORIGINAL), flags=mmap.MAP_SHARED, prot=mmap.PROT_READ)
        )
        check(prefaulted[:], ORIGINAL, "prefault shared read-only mmap")
        check(os.pread(old_ro, len(ORIGINAL), 0), ORIGINAL, "initial pread")
        check(os.read(old_rw, len(ORIGINAL)), ORIGINAL, "initial read")
        check(os.fstat(old_ro).st_mtime_ns, MTIME_NS, "guest initial exact mtime")
        (directory / "guest-ready").touch()

        wait(directory, "host-mapped")
        check(os.pread(old_ro, len(MAPPED), 0), MAPPED, "old O_RDONLY pread after host mmap")
        os.lseek(old_rw, 0, os.SEEK_SET)
        check(os.read(old_rw, len(MAPPED)), MAPPED, "old O_RDWR read after host mmap")
        check(os.fstat(old_ro).st_mtime_ns, MTIME_NS, "guest held exact mtime after mmap")
        output["ordinary_read_after_host_mmap"] = "after_host_edit"
        output["prefaulted_guest_shared_map_after_host_mmap"] = file_observation(prefaulted[:])
        for name, copy in methods.items():
            received = copy_to_pipe(old_ro, lambda src, dst: copy(src, dst, 0, len(MAPPED)))
            if require_live_splice:
                check(received, MAPPED, f"held {name} after host mmap")
            output[f"held_{name}_after_host_mmap"] = file_observation(received)
        with mmap.mmap(old_ro, len(MAPPED), flags=mmap.MAP_SHARED, prot=mmap.PROT_READ) as fresh:
            check(fresh[:], MAPPED, "new mapping of live old fd after host mmap")
        output["newly_faulted_shared_map_after_host_mmap"] = "after_host_edit"
        (directory / "guest-mapped").touch()

        wait(directory, "host-renamed")
        check(os.pread(old_ro, len(MAPPED), 0), MAPPED, "old O_RDONLY fd after replacement")
        check(os.pread(old_rw, len(MAPPED), 0), MAPPED, "old O_RDWR fd after replacement")
        new_ro = file(payload, os.O_RDONLY)
        check(os.fstat(new_ro).st_mtime_ns, MTIME_NS, "guest replacement same exact mtime")
        check(os.pread(new_ro, len(REPLACEMENT), 0), REPLACEMENT, "new pathname after replacement")
        with mmap.mmap(
            new_ro, len(REPLACEMENT), flags=mmap.MAP_PRIVATE, prot=mmap.PROT_READ | mmap.PROT_WRITE,
        ) as private:
            check(private[:], REPLACEMENT, "private mmap of replacement")
            private[:8] = b"private!"
            check(os.pread(new_ro, len(REPLACEMENT), 0), REPLACEMENT, "private write stays private")
        try:
            with mmap.mmap(
                new_ro, len(REPLACEMENT), flags=mmap.MAP_SHARED, prot=mmap.PROT_WRITE,
            ):
                raise RuntimeError("O_RDONLY fd accepted writable shared mmap")
        except OSError as error:
            check(error.errno, errno.EACCES, "writable shared mmap on O_RDONLY")
        output["atomic_rename"] = "old_fds_and_new_inode_correct"
        output["private_map_and_readonly_access"] = "passed"

        created = directory / "guest-mapped-payload"
        writer = file(created, os.O_CREAT | os.O_EXCL | os.O_RDWR)
        check(os.write(writer, INITIAL), len(INITIAL), "initial regular FUSE_CREATE write")
        observer = file(created, os.O_RDONLY)
        with mmap.mmap(
            writer, len(INITIAL), flags=mmap.MAP_SHARED, prot=mmap.PROT_READ | mmap.PROT_WRITE,
        ) as shared_writer, mmap.mmap(
            observer, len(INITIAL), flags=mmap.MAP_SHARED, prot=mmap.PROT_READ,
        ) as shared_reader:
            check(shared_reader[:], INITIAL, "same-inode guest read-only mapping")
            shared_writer[8:16] = b"mapped01"
            check(shared_reader[8:16], b"mapped01", "guest shared-writable map is coherent")
            check(os.pread(observer, 8, 8), b"mapped01", "pread sees dirty guest mapping")
            shared_writer[16:24] = b"mapped02"
            shared_writer.flush()
            os.fsync(writer)
            check(os.pread(observer, len(INITIAL), 0), GUEST_MAPPED, "guest mmap write after fsync")
        output["shared_write_and_readonly_map"] = "passed"

    (directory / "guest.json").write_text(json.dumps(output))
    (directory / "guest-done").touch()


def host(args):
    name = "mp-mmap-contract-" + uuid4().hex
    receipt = {
        "container": name,
        "image": args.image,
        "require_live_splice": args.require_live_splice,
        "success": False,
    }

    def docker(*arguments, check=True):
        return subprocess.run(
            ["docker", "--host", args.docker_host, *arguments],
            check=check, text=True, capture_output=True, timeout=12,
        )

    def stamp_and_stat(path):
        os.utime(path, ns=(MTIME_NS, MTIME_NS))
        info = path.stat()
        check(info.st_mtime_ns, MTIME_NS, "host exact nanosecond timestamp")
        return info.st_dev, info.st_ino, info.st_size

    with tempfile.TemporaryDirectory(prefix=".mp-map-contract-", dir=args.workspace.resolve()) as tmp:
        directory = Path(tmp)
        container = None
        control = directory / "splice-control"
        control.write_bytes(UNTOUCHED)
        payload = directory / "payload"
        payload.write_bytes(ORIGINAL)
        initial = stamp_and_stat(payload)
        shutil.copyfile(Path(__file__).resolve(), directory / "check.py")
        try:
            container = docker(
                "run", "--detach", "--pull", "never", "--network", "none",
                "--name", name, "--label", f"{LABEL}={name}",
                "--mount", f"type=bind,src={directory},dst=/probe",
                "--entrypoint", "python3", args.image, "/probe/check.py", "--guest", "/probe",
                *(["--require-live-splice"] if args.require_live_splice else []),
            ).stdout.strip()
            if not re.fullmatch(r"[0-9a-f]{64}", container):
                raise RuntimeError("Docker returned an invalid container ID")
            with payload.open("r+b", buffering=0) as fd:
                with mmap.mmap(fd.fileno(), 0, access=mmap.ACCESS_WRITE) as view:
                    wait(directory, "guest-ready")
                    view[:] = MAPPED
                    check(stamp_and_stat(payload), initial, "same inode after host mmap")
                    check(os.pread(fd.fileno(), len(MAPPED), 0), MAPPED, "host held bytes")
                    (directory / "host-mapped").touch()
                    wait(directory, "guest-mapped")
                    next_path = directory / "replacement"
                    next_path.write_bytes(REPLACEMENT)
                    after = stamp_and_stat(next_path)
                    next_path.replace(payload)
                    if after[1] == initial[1]:
                        raise RuntimeError("atomic rename failed to create a new inode")
                    (directory / "host-renamed").touch()
                    wait(directory, "guest-done")
            check(docker("wait", container).stdout.strip(), "0", "guest exit status")
            stored = (directory / "guest-mapped-payload").read_bytes()
            check(stored, GUEST_MAPPED, "guest-mapped bytes reached host")
            check(control.read_bytes(), UNTOUCHED, "splice control stayed untouched")
            receipt.update(
                success=True, mtime_ns=MTIME_NS, original_inode=initial[1], replacement_inode=after[1],
                guest=json.loads((directory / "guest.json").read_text()),
                host_guest_mapped_sha256=hashlib.sha256(stored).hexdigest(),
            )
        except (OSError, RuntimeError, subprocess.SubprocessError) as error:
            receipt["failure"] = str(error)
            if container and re.fullmatch(r"[0-9a-f]{64}", container):
                try:
                    logs = docker("logs", container, check=False)
                    receipt["guest_log"] = logs.stdout + logs.stderr
                except (OSError, subprocess.SubprocessError) as log_error:
                    receipt["guest_log_error"] = str(log_error)
        finally:
            try:
                ids = docker(
                    "ps", "-a", "-q", "--no-trunc", "--filter", f"label={LABEL}={name}"
                ).stdout.splitlines()
                for owned_id in ids:
                    if not re.fullmatch(r"[0-9a-f]{64}", owned_id):
                        raise RuntimeError("Docker returned an invalid cleanup ID")
                    docker("rm", "-f", owned_id)
            except (OSError, RuntimeError, subprocess.SubprocessError) as cleanup_error:
                receipt["success"] = False
                receipt["cleanup_error"] = str(cleanup_error)
    print(json.dumps(receipt, indent=2, sort_keys=True))
    return 0 if receipt["success"] else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--guest", type=Path)
    parser.add_argument("--docker-host")
    parser.add_argument("--workspace", type=Path)
    parser.add_argument("--image", default="micropod-qa/checkout:gamma2-fmdkh0")
    parser.add_argument("--require-live-splice", action="store_true")
    args = parser.parse_args()
    if args.guest:
        guest(args.guest, args.require_live_splice)
    elif args.docker_host and args.workspace:
        raise SystemExit(host(args))
    else:
        parser.error("supply --docker-host and --workspace")
