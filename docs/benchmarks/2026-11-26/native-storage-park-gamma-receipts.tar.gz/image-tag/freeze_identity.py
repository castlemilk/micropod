"""Freeze the final source review delta against the b7 checkout used for CI scoring."""
import difflib
import hashlib
import io
import json
from pathlib import Path
import shutil
import sys
import tarfile

workspace, run = (Path(x).resolve() for x in sys.argv[1:])
prior = run/"home/image-reviewed/source/guest/runner"
overlay = run/"home/image-tag/source/guest/runner"
evidence = run/"receipts/image-tag/identity"
target = run/"home/image-identity/source/guest/runner"
evidence.mkdir()
shutil.copytree(prior,target)
for name in ("docker_image_tag_linux.go","docker_image_tag_linux_test.go"):
    shutil.copyfile(overlay/name,target/name)
for name in ("docker_image_delete_linux.go","docker_image_delete_linux_test.go"):
    shutil.copyfile(workspace/name,target/name)
def files(folder):
    return {p.relative_to(folder).as_posix():p.read_bytes() for p in sorted(folder.rglob("*")) if p.is_file()}
def sha(v):
    return hashlib.sha256(v).hexdigest()
base, final = files(prior), files(target)
assert base.keys()==final.keys()
delta = [name for name in base if base[name]!=final[name]]
assert set(delta) == {"docker_image_tag_linux.go","docker_image_tag_linux_test.go","docker_image_delete_linux.go","docker_image_delete_linux_test.go"}, delta
patch=[]
for name in delta:
    patch.extend(difflib.unified_diff(base[name].decode().splitlines(True),final[name].decode().splitlines(True),fromfile="a/"+name,tofile="b/"+name))
(evidence/"b7-to-identity.patch").write_text("".join(patch))
ap=evidence/"source.tar.gz"
with tarfile.open(ap,"x:gz",compresslevel=6) as archive:
    for name,data in final.items():
        entry=tarfile.TarInfo("guest/runner/"+name)
        entry.size=len(data)
        archive.addfile(entry,io.BytesIO(data))
doc={"base":"b7d78d2bac1f3138325c469bcbb473ba89b39bde5e453a070a708142bfa05391","source_files":{k:sha(v) for k,v in final.items()},"changed":delta,"source_archive_sha256":sha(ap.read_bytes()),"patch_sha256":sha((evidence/"b7-to-identity.patch").read_bytes())}
(evidence/"source.json").write_text(json.dumps(doc,indent=2)+"\n")
print(len(final), delta)
