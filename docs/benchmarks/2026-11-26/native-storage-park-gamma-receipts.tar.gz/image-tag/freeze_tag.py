"""Apply the tag-only delta to a qualified history checkout and freeze the guest module."""
from argparse import ArgumentParser
import difflib
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def replace(path, before, after):
    source = path.read_text()
    if source.count(before) != 1:
        raise ValueError(f"{path.name} does not match the history baseline")
    path.write_text(source.replace(before, after))


def tree(root):
    return {p.relative_to(root).as_posix(): p.read_bytes() for p in sorted(root.rglob("*")) if p.is_file()}


def main():
    parser = ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("overlay", type=Path)
    parser.add_argument("stage", type=Path)
    parser.add_argument("evidence", type=Path)
    a = parser.parse_args()
    a.stage.mkdir()
    module = a.stage / "source/guest/runner"
    shutil.copytree(a.base, module)
    for filename in ("docker_image_tag_linux.go", "docker_image_tag_linux_test.go"):
        shutil.copyfile(a.overlay / filename, module / filename)
    route = '\tcase path == "create" && r.Method == "POST":\n\t\tref := q.Get("fromImage")'
    replace(module/"docker_http_linux.go", route,
            '\tcase strings.HasSuffix(path, "/tag") && r.Method == "POST":\n'
            '\t\treturn s.tagImage(w, r, strings.TrimSuffix(path, "/tag"))\n' + route)
    iface = 'type imageMetadataClient interface {\n'
    replace(module/"docker_image_delete_linux.go", iface, iface +
            '\tCreate(context.Context, *images.CreateImageRequest, ...grpc.CallOption) (*images.CreateImageResponse, error)\n'
            '\tUpdate(context.Context, *images.UpdateImageRequest, ...grpc.CallOption) (*images.UpdateImageResponse, error)\n')
    eventmatch = '''			matched = slices.Contains(values, event.From) || slices.Contains(values, event.Actor.ID)
			if !matched {
				if image, err := reference.ParseNormalizedNamed(event.From); err == nil {'''
    replace(module/"docker_events_linux.go", eventmatch, '''			name := event.From
			if event.Type == "image" {
				name = event.Actor.Attributes["name"]
			}
			matched = slices.Contains(values, name) || slices.Contains(values, event.Actor.ID)
			if !matched {
				if image, err := reference.ParseNormalizedNamed(name); err == nil {''')
    base, final = tree(a.base), tree(module)
    delta = sorted(k for k in base.keys() | final.keys() if base.get(k) != final.get(k))
    assert len(delta) == 5, delta
    patch = []
    for name in delta:
        old, new = base.get(name, b""), final[name]
        patch.extend(difflib.unified_diff(old.decode().splitlines(True), new.decode().splitlines(True),
                                         fromfile="a/"+name if name in base else "/dev/null", tofile="b/"+name))
    (a.evidence/"history-to-tag.patch").write_text("".join(patch))
    archive_path = a.evidence/"combined-engine-source.tar.gz"
    with tarfile.open(archive_path, "x:gz", compresslevel=6) as archive:
        for name, data in final.items():
            entry = tarfile.TarInfo("guest/runner/" + name)
            entry.size = len(data)
            archive.addfile(entry, io.BytesIO(data))
    result = {"changed_from_history":delta, "base_files":{k:digest(v) for k,v in base.items()},
              "final_files":{k:digest(v) for k,v in final.items()}, "archive_sha256":digest(archive_path.read_bytes())}
    (a.evidence/"sources.json").write_text(json.dumps(result,indent=2)+"\n")
    print(len(base), len(final), delta)


if __name__ == "__main__":
    main()
