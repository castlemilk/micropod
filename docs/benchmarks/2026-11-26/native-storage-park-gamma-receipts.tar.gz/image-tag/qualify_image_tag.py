"""Exercise local Docker tag and retag on API 1.47, including a retained container."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import stat
import sys
import time
from urllib.parse import quote, urlencode
import uuid


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scripts", type=Path, required=True)
    parser.add_argument("--socket", type=Path, required=True)
    parser.add_argument("--second-image", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--require-serialized-writes", action="store_true")
    args = parser.parse_args()
    sys.path.insert(0, str(args.scripts.resolve()))
    from qualify_engine_api import Engine

    if not stat.S_ISSOCK(args.socket.stat().st_mode) or args.output.exists():
        raise RuntimeError("a local engine socket and a fresh output path are required")
    run = uuid.uuid4().hex
    repo = "micropod-qa/tag-" + run
    alias, default = repo + ":ci", repo + ":latest"
    held = "mp-tag-" + run
    api = Engine(args.socket, "alpine:3.23", None, None, api_version="1.47")
    receipt = {"socket": str(args.socket), "run": run, "api_version": "1.47", "steps": [],
               "cleanup": {}, "passed": False}

    def require(cond, detail):
        if not cond:
            raise RuntimeError(detail)

    def request(method, path):
        status, _, payload = api.request(method, path)
        return status, payload

    def cli(*argv):
        p = api.cli(*argv, timeout=25)
        if p.returncode:
            raise RuntimeError(f"docker {' '.join(argv)}: {p.stderr.decode(errors='replace')}")
        return p.stdout

    def image_endpoint(ref, suffix):
        return "/images/" + quote(ref, safe="/:") + suffix

    def inspect(ref):
        code, body = request("GET", image_endpoint(ref, "/json"))
        require(code == 200, f"inspect {ref}: {code} {body[:300]!r}")
        return json.loads(body)

    def tag(source, values):
        return request("POST", image_endpoint(source, "/tag?") + urlencode(values))

    def check(ref, expected):
        got = inspect(ref)
        require(got["Id"] == expected["Id"] and got["RootFS"] == expected["RootFS"], f"retagged content: {ref}")
        stock = json.loads(cli("image", "inspect", ref))[0]
        require(stock["Id"] == expected["Id"], f"stock inspect resolved a different image: {ref}")
        return got["Id"]

    alpine = "alpine:3.23"
    sources = {ref: inspect(ref) for ref in (alpine, args.second_image)}
    require(sources[alpine]["Id"] != sources[args.second_image]["Id"], "fixtures must identify different images")
    for ref in [alias, default]:
        code, _ = request("GET", image_endpoint(ref, "/json"))
        require(code == 404, f"owned tag {ref} already exists")
    code, _ = request("GET", "/containers/" + held + "/json")
    require(code == 404, "owned container already exists")
    start = int(time.time()) - 1
    try:
        code, body = tag(alpine, {"repo": repo, "tag": "ci"})
        require((code, body) == (201, b""), f"tag create HTTP {code} {body!r}")
        receipt["steps"].append(["tag-by-name", check(alias, sources[alpine])])
        cli("create", "--pull=never", "--name", held, "--label", "io.micropod.tag-probe="+run,
            "--network=none", alias, "/bin/sh", "-c", "printf retained-tag")
        cli("tag", sources[alpine]["Id"], alias)
        receipt["steps"].append(["idempotent-tag-by-full-id", check(alias, sources[alpine])])
        code, body = tag(alpine, {"repo": repo})
        require((code, body) == (201, b""), f"default tag HTTP {code} {body!r}")
        receipt["steps"].append(["default-tag", check(default, sources[alpine])])
        cli("tag", sources[args.second_image]["Id"].removeprefix("sha256:")[:12], alias)
        receipt["steps"].append(["replace-by-short-id", check(alias, sources[args.second_image])])
        check(default, sources[alpine])
        old = json.loads(cli("inspect", held))[0]
        require(old["Image"] == sources[alpine]["Id"], "retained container lost its original image identity")
        require(cli("start", "-a", held).strip() == b"retained-tag", "retained container no longer starts")
        receipt["steps"].append(["retained-container", old["Image"]])
        code, body = tag("micropod-qa/no-such-"+run, {"repo": repo, "tag": "ci"})
        require(code == 404 and json.loads(body).get("message"), "missing source was not reported")
        code, body = tag(alpine, {"repo": "INVALID NAME", "tag": "bad tag"})
        require(code == 400 and json.loads(body).get("message"), "invalid destination was not reported")
        receipt["steps"].append(["errors", [404, 400]])
        src_digest = (sources[alpine].get("RepoDigests") or [None])[0]
        if src_digest:
            code, body = tag(src_digest, {"repo": repo,"tag":"ci"})
            require((code, body) == (201,b""), f"tag by manifest digest {code} {body!r}")
            receipt["steps"].append(["tag-by-repo-digest", check(alias, sources[alpine])])
            digest = src_digest.rsplit("@", 1)[1]
            wrong = "micropod-qa/missing-" + run + "@" + digest
            for suffix in ["/json", "/history"]:
                code, body = request("GET", image_endpoint(wrong, suffix))
                require(code == 404 and json.loads(body).get("message"), "wrong repository digest was accepted")
            code, body = tag(wrong, {"repo": repo, "tag": "ci"})
            require(code == 404 and json.loads(body).get("message"), "tag accepted a wrong repository digest")
            receipt["steps"].append(["absent-repository-digest", [404,404,404]])
        names = (alpine, args.second_image) * 2
        with ThreadPoolExecutor(max_workers=4) as pool:
            replies = list(pool.map(lambda src: tag(src, {"repo": repo, "tag": "ci"}), names))
        outcomes = [{"status": code, "message": json.loads(body).get("message") if body else None}
                    for code, body in replies]
        receipt["concurrent_writers"] = outcomes
        strict = all(reply == (201, b"") for reply in replies)
        require(any(reply == (201, b"") for reply in replies), "no concurrent tag completed")
        if args.require_serialized_writes:
            require(strict, f"concurrent tag responses: {outcomes!r}")
        final = inspect(alias)["Id"]
        require(final in {i["Id"] for i in sources.values()}, "concurrent tag resolved to foreign content")
        check(alias, next(v for v in sources.values() if v["Id"] == final))
        receipt["steps"].append(["four-concurrent-tag-writes", final])
        query = urlencode({"since": start, "until": int(time.time())+1,
                           "filters": json.dumps({"type":["image"],"event":["tag"],"image":[alias]})})
        code, body = request("GET", "/events?"+query)
        events = [json.loads(l) for l in body.splitlines() if l.strip()]
        require(code == 200 and len(events) >= 3, f"filtered tag events = {code}, {events}")
        require(all(e["Actor"]["Attributes"].get("name") == alias for e in events), "foreign image event")
        receipt["events"] = events
        receipt["passed"] = True
    except Exception as exc:
        receipt["error"] = str(exc)
    finally:
        try:
            code, body = request("GET", "/containers/"+held+"/json")
            if code == 200:
                labels = json.loads(body)["Config"].get("Labels") or {}
                if labels.get("io.micropod.tag-probe") != run:
                    raise RuntimeError("retained container ownership changed")
                cli("rm", "-f", held)
            receipt["cleanup"]["container_absent"] = request("GET", "/containers/"+held+"/json")[0] == 404
            source_ids = {v["Id"] for v in sources.values()}
            for ref in [alias, default]:
                code, body = request("GET", image_endpoint(ref, "/json"))
                if code == 200:
                    if json.loads(body)["Id"] not in source_ids:
                        raise RuntimeError("owned tag now addresses an unrelated image")
                    cli("image", "rm", ref)
                receipt["cleanup"][ref] = request("GET", image_endpoint(ref, "/json"))[0] == 404
            receipt["cleanup"]["source_ids_preserved"] = all(check(ref, image) == image["Id"] for ref,image in sources.items())
            receipt["passed"] &= all(receipt["cleanup"].values())
        except Exception as exc:
            receipt["passed"] = False
            receipt["cleanup_error"] = str(exc)
        args.output.write_text(json.dumps(receipt,indent=2)+"\n")
    if not receipt["passed"]:
        raise SystemExit(receipt.get("error","cleanup failed"))


if __name__ == "__main__":
    main()
