"""Qualify a hexadecimal repository and replacement of its last tagged reference."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile
import time
from urllib.parse import quote
import uuid


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scripts", required=True, type=Path)
    parser.add_argument("--socket", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--disposable-native", action="store_true")
    a = parser.parse_args()
    sys.path.insert(0, str(a.scripts.resolve()))
    from qualify_engine_api import Engine
    from qualify_docker_image_history import tar_bytes
    api = Engine(a.socket, "alpine:3.23", None, None, api_version="1.47")
    run = uuid.uuid4().hex
    repo, other = "ab"+run[:12], "micropod-qa/hex-"+run+":alias"
    ref, held = repo+":latest", "mp-hex-"+run
    label = "io.micropod.hex-identity"
    data = {"passed": False,"run": run,"repository": repo,"steps":{},"cleanup":{}}
    assert not a.output.exists()

    def cli(*args, input_data=None):
        result = api.cli(*args, data=input_data,timeout=40)
        if result.returncode:
            raise RuntimeError(f"{args}: {result.stderr.decode(errors='replace')}")
        return result.stdout

    def get(ref):
        code, _, body = api.request("GET","/images/"+quote(ref,safe=":/")+"/json")
        return code,json.loads(body)

    def check(ok, message):
        if not ok:
            raise RuntimeError(message)

    def wait(ref):
        until=time.monotonic()+4
        while True:
            code, v = get(ref)
            if code==200:
                return v
            if code!=404 or time.monotonic()>until:
                raise RuntimeError(f"lookup of {ref}: {code} {v}")
            time.sleep(.03)

    check(get(ref)[0]==404 and get(other)[0]==404, "fresh tag already exists")
    original = wait("alpine:3.23")
    original_id = original["Id"]
    source = cli("image","save","alpine:3.23")
    with tarfile.open(fileobj=io.BytesIO(source)) as infile:
        entry, = json.load(infile.extractfile("manifest.json"))
        cfg = json.load(infile.extractfile(entry["Config"]))
        labels = cfg.setdefault("config",{}).get("Labels") or {}
        cfg["config"]["Labels"] = {**labels,label: run}
        payload = json.dumps(cfg,separators=(",",":")).encode()
        digest = hashlib.sha256(payload).hexdigest()
        config_name = digest+".json"
        layers = [(n,infile.extractfile(n).read()) for n in entry["Layers"]]
    archive = tar_bytes([*layers, (config_name,payload),("manifest.json",json.dumps([
        {"Config":config_name,"RepoTags":[ref],"Layers":[n for n,_ in layers]}]).encode())])
    old_id=None
    try:
        cli("load","-q",input_data=archive)
        old = wait(ref)
        old_id = old["Id"]
        check(old_id!=original_id and old["Config"]["Labels"].get(label)==run, "fixture image identity")
        tags = sorted(x.removeprefix("docker.io/").removeprefix("library/") for x in old["RepoTags"])
        check(tags==[ref], f"fixture starts with additional tags: {tags}")
        check(wait(repo)["Id"]==old_id,"bare-hex inspect")
        cli("image","tag",repo,other)
        check(wait(other)["Id"]==old_id,"bare-hex tag selected wrong image")
        cli("image","rm",other)
        data["steps"]["bare_hex_tag_and_inspect"] = True
        cli("create","--pull=never","--name",held,"--label",label+"="+run,"--network=none",ref,
            "/bin/sh","-c","printf last-tag-retained")
        tags = [x.removeprefix("docker.io/").removeprefix("library/") for x in wait(ref)["RepoTags"]]
        check(tags==[ref],f"original has other named references at replacement: {tags}")
        cli("image","tag","alpine:3.23",ref)
        check(wait(ref)["Id"]==original_id and wait(old_id)["Id"]==old_id,"retag failed to retain original ID")
        c = json.loads(cli("container","inspect",held))[0]
        check(c["Image"]==old_id and cli("start","-a",held).strip()==b"last-tag-retained","retained last-tag container could not start")
        data["steps"]["last_named_tag_preserves_container_and_id"]=True
        cli("image","rm",repo)
        check(get(repo)[0]==404 and get(ref)[0]==404,"bare-hex untag or stale inspection")
        cli("image","tag","alpine:3.23",ref)
        status, _, removed = api.request("DELETE","/images/"+repo)
        check(status==200 and any("Untagged" in row for row in json.loads(removed)), "raw unqualified hex untag")
        check(get(repo)[0]==404, "raw untag remained visible")
        check(wait(original_id.removeprefix("sha256:")[:12])["Id"]==original_id,"short ID lookup regressed")
        data["steps"]["bare_hex_untag_and_short_id"]=True
        data["old_id"] = old_id
        data["passed"]=True
    except Exception as exc:
        data["error"]=str(exc)
    finally:
        try:
            code,_,body=api.request("GET","/containers/"+held+"/json")
            if code==200:
                check(json.loads(body)["Config"]["Labels"].get(label)==run,"container ownership changed")
                cli("rm","-f",held)
            data["cleanup"]["no_container"] = api.request("GET","/containers/"+held+"/json")[0]==404
            for name in (other,ref):
                code,row=get(name)
                if code==200:
                    check(row["Id"] in (old_id,original_id) or (row["Config"].get("Labels") or {}).get(label)==run,"tag ownership changed")
                    cli("image","rm",name)
                data["cleanup"][name]=get(name)[0]==404
            if old_id and not a.disposable_native:
                code,row=get(old_id)
                if code==200:
                    check((row["Config"].get("Labels") or {}).get(label)==run and not row.get("RepoTags"),"old image unexpectedly retained by another tag")
                    cli("image","rm",old_id)
                data["cleanup"]["unique_image_removed"]=get(old_id)[0]==404
            elif old_id:
                data["private_config_record_until_worker_disposal"] = get(old_id)[0]==200
            data["cleanup"]["original_preserved"]=get("alpine:3.23")[1]["Id"]==original_id
            data["passed"] &= all(data["cleanup"].values())
        except Exception as exc:
            data["passed"]=False
            data["cleanup_error"]=str(exc)
        a.output.write_text(json.dumps(data,indent=2)+"\n")
    if not data["passed"]:
        raise SystemExit(str(data))


if __name__=="__main__":
    main()
