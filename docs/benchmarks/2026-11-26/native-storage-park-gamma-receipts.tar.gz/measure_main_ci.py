"""Run the archived guest workload with bounded attached or detached stock Docker control."""
from contextlib import ExitStack
import json
import os
from pathlib import Path
import statistics
import subprocess
import time
from uuid import uuid4

import bench_workspace_checkout as bench
import bench_workspace_runner as runner

transport = os.environ.get('MP_GAMMA2_TRANSPORT', 'attached')
assert transport in ('attached', 'detached')
original_guest = bench.Arm.guest
original_start = bench.Arm.start
result_root = Path('/mp-gamma2-results')


def start(arm, stack, name, stage, args, accepted_ids, *, extra_mounts=()):
    if transport == 'detached':
        bench.require(stage is not None, 'detached proof requires a scoped host results bind')
        arm.result_dir = stage / f'.mpg2-results-{arm.name}'
        arm.result_dir.mkdir(mode=0o700)
        extra_mounts = (*extra_mounts, bench.bind_mount(arm.result_dir, result_root, read_only=False))
    return original_start(arm, stack, name, stage, args, accepted_ids, extra_mounts=extra_mounts)


def snapshot(arm, mode, started, error):
    path = os.environ.get('MP_GAMMA2_FAILURE_PREFIX')
    if not path:
        return
    failure = {'workload': list(mode), 'backend': arm.name, 'container': arm.id, 'error': repr(error),
               'started_host_realtime': started, 'failure_host_realtime': time.time(), 'checks': {}, 'snapshot_errors': {}}

    def getter(label, action):
        try:
            failure['checks'][label] = action()
        except Exception as snapshot_error:
            failure['snapshot_errors'][label] = repr(snapshot_error)

    def query(route):
        return subprocess.check_output(['/usr/bin/curl', '-fsS', '--max-time', '6', '--unix-socket', str(arm.socket),
                                        'http://localhost' + route], text=True, timeout=8)

    def events():
        payload = query(f'/events?since={int(started)-1}&until={int(time.time())+2}')
        return [row for line in payload.splitlines() if (row := json.loads(line))['Actor']['ID'] == arm.id]

    getter('engine_events', events)
    rows = failure['checks'].get('engine_events', [])
    exits = [row for row in rows if row['Action'] == 'exec_die' and row['Actor']['Attributes'].get('exitCode') == '137']
    if exits:
        ident = exits[-1]['Actor']['Attributes']['execID']
        failure['exec_id'] = ident
        getter('exec_inspect', lambda: json.loads(query(f'/exec/{ident}/json')))
        begin = next((row for row in rows if row['Action'].startswith('exec_start:') and row['Actor']['Attributes']['execID'] == ident), None)
        if begin is not None:
            failure['elapsed_guest_event_ms'] = (exits[-1]['timeNano'] - begin['timeNano']) / 1e6
    getter('container_inspect_before_cleanup', arm.read_container)
    getter('guest_cgroup_memory_before_cleanup', lambda: bench.call([*arm.docker, 'exec', arm.id, 'sh', '-ec',
        'for p in memory.events memory.peak memory.current memory.max; do printf "%s\\n" "-- $p --"; '
        'cat "/sys/fs/cgroup/$p"; done; cat /proc/meminfo'], timeout=6).stdout.decode())
    Path(path + '-' + uuid4().hex[:8] + '.json').write_text(json.dumps(failure, indent=2) + '\n')


def detached_guest(arm, mode, timeout):
    token = uuid4().hex
    base = arm.result_dir / token
    code = Path(str(base) + '.exit')
    stdout = Path(str(base) + '.out')
    stderr = Path(str(base) + '.err')
    payload = ('out=$1; shift; '
               'if python3 /checkout-ci/driver.py --guest "$@" >"$out.out" 2>"$out.err"; then rc=0; else rc=$?; fi; '
               'printf "%s\\n" "$rc" >"$out.pending"; mv "$out.pending" "$out.exit"; exit "$rc"')
    bench.call([*arm.docker, 'exec', '-d', arm.id, 'sh', '-ec', payload, 'mp-gamma2-build',
                str(result_root / token), *map(str, mode)], timeout=10)
    deadline = time.monotonic() + timeout
    while not code.is_file():
        if time.monotonic() >= deadline:
            raise TimeoutError(f'{arm.name}: detached {mode[0]} did not publish a result in {timeout}s')
        time.sleep(0.01)
    outcome = int(code.read_text().strip())
    if outcome != 0:
        raise RuntimeError(f'{arm.name}: detached {mode[0]} exited {outcome}: {stderr.read_text(errors="replace")[-3500:]}')
    result = json.loads(stdout.read_bytes())
    for member in (code, stdout, stderr):
        member.unlink()
    return result


def timed(arm, *mode, timeout=120):
    started = time.monotonic_ns()
    realtime = time.time()
    try:
        if transport == 'attached':
            result = original_guest(arm, *mode, timeout=timeout)
        else:
            result = detached_guest(arm, mode, timeout)
    except Exception as error:
        snapshot(arm, mode, realtime, error)
        raise
    result['host_call_monotonic_ns'] = [started, time.monotonic_ns()]
    result['stock_docker_transport'] = transport
    return result


def verify_current_bytes(arm, expected, publication):
    started = time.monotonic_ns()
    statuses = []
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        row = subprocess.run([*arm.docker, 'exec', arm.id, '/usr/bin/sha256sum', str(bench.GUEST_SOURCE / 'main_linux.go')],
                             capture_output=True, timeout=5)
        actual = row.stdout.decode(errors='replace').split(maxsplit=1)
        seen = actual[0] if row.returncode == 0 and actual else None
        now = time.monotonic_ns()
        statuses.append({'at_ns': now, 'sha256': seen, 'exit': row.returncode,
                         'error': row.stderr.decode(errors='replace')[-900:] if row.returncode else None})
        if seen == expected:
            return {'started_host_ns': started, 'first_correct_host_ns': now,
                    'pre_run_wait_ns': now - started, 'observations': statuses, 'expected_sha256': expected,
                    'edit_return_to_correct_ns': now - publication if publication is not None else None}
        time.sleep(0.03)
    raise RuntimeError(f'{arm.name} did not see expected checkout {expected}: {statuses}')


def fixture_sample(arm, source, base, variant, cpus):
    main = source / 'main_linux.go'
    content = base.replace(runner.MESSAGE.encode(), f'{runner.MESSAGE} {variant}'.encode()) if variant else base
    expected = bench.sha(content)
    started = time.monotonic_ns()
    edit_started = None
    published = None
    if main.read_bytes() != content:
        edit_started = time.monotonic_ns()
        pending = source.parent / 'edited-main.go'
        pending.write_bytes(content)
        pending.chmod(main.stat().st_mode & 0o777)
        pending.replace(main)
        published = time.monotonic_ns()
    try:
        visibility = verify_current_bytes(arm, expected, published)
        result = arm.guest('build', cpus, variant, timeout=240)
    except Exception as error:
        prefix = os.environ.get('MP_GAMMA2_FAILURE_PREFIX')
        if prefix:
            detail = {'engine': arm.name, 'name': arm.container['Name'], 'expected_sha256': expected,
                      'revision': variant, 'source_sha256': bench.file_sha(main), 'error': repr(error)}
            snapshot_cmd = ('cd /checkout-ci/source; sha256sum main_linux.go; '
                            'git -c safe.directory=/checkout-ci/source status --porcelain=v1 --untracked-files=all')
            try:
                row = subprocess.run([*arm.docker, 'exec', arm.id, 'sh', '-ec', snapshot_cmd], capture_output=True,
                                     text=True, timeout=5)
                detail.update(guest_readback=row.stdout, guest_readback_error=row.stderr, guest_readback_exit=row.returncode)
            except Exception as readback_error:
                detail['readback_failure'] = repr(readback_error)
            Path(prefix + '-generation-' + uuid4().hex[:8] + '.json').write_text(json.dumps(detail, indent=2) + '\n')
        raise
    bench.require(result['main_sha256'] == expected, 'timed build observed different bytes from the admitted generation')
    complete = time.monotonic_ns()
    return {**result, 'host_update_wall_ns': complete - started, 'host_edit_begin_ns': edit_started,
            'host_edit_return_ns': published, 'verified_build_complete_host_ns': complete, 'visibility': visibility,
            'edit_to_completed_build_ns': complete - edit_started if edit_started is not None else None}


def measure_isolated(args, stage):
    names = ('orbstack', 'hvf')
    arms = {name: bench.Arm(name, sock, args.image)
            for name, sock in zip(names, (args.orbstack_socket, args.hvf_socket))}
    identity = bench.image_identity(args.image_manifest, [arm.image_id for arm in arms.values()])
    checkouts, heads, staging = {}, {}, {}
    for name in names:
        directory = stage / name
        directory.mkdir()
        staging[name] = directory
        checkouts[name], heads[name] = runner.prepare_checkout(directory, args.source)
    expected = runner.inventory(checkouts[names[0]])
    bench.require(len(set(heads.values())) == 1 and all(runner.inventory(checkouts[name]) == expected for name in names),
                  'independently mounted checkouts did not match')
    original = (checkouts[names[0]] / 'main_linux.go').read_bytes()
    bench.require(original.count(runner.MESSAGE.encode()) == 1, 'runner validation string changed')
    receipt = {'image': identity, 'image_reference': args.image, 'source': expected, 'git_commit': heads[names[0]],
               'cpus': args.cpus, 'memory_mib': args.memory_mib, 'pairs': [], 'preparation': {}, 'prime': {},
               'workspace_mode': 'independent byte-identical raw host checkouts',
               'timing_scopes': {'sum_ns': 'guest Git status, Go build, and three uncached Go test subprocesses',
                                 'edit_return_to_correct_ns': 'host atomic edit returned through first matching guest SHA256',
                                 'edit_to_completed_build_ns': 'host started its own atomic edit through observed verified completed build',
                                 'host_update_wall_ns': 'before own edit or unchanged sample through observed completed build'}}
    scope = 'mpg2-raw-' + uuid4().hex[:16]
    revision_hashes = set()
    with ExitStack() as cleanup:
        baseline_hashes = set()
        for name in names:
            arm = arms[name]
            arm.start(cleanup, f'{scope}-{name}', staging[name], args, set(identity.values()))
            prep = arm.guest('prepare', args.cpus, args.memory_mib)
            bench.require(prep['tree'] == expected and prep['head'] == heads[name] and not any(prep['cache_initial_entries'].values()),
                          f'{name} initial fixture or job cache differs')
            bench.require(prep['runner_driver_sha256'] == bench.file_sha(staging[name] / 'driver.py'), 'unexpected guest build driver')
            receipt['preparation'][name] = prep
            prime = fixture_sample(arm, checkouts[name], original, '', args.cpus)
            receipt['prime'][name] = prime
            baseline_hashes.add(prime['binary_sha256'])
        left, right = (receipt['preparation'][n] for n in names)
        bench.require(len(baseline_hashes) == 1 and left['boot_id'] != right['boot_id']
                      and all(left[key] == right[key] for key in ('limits', 'versions', 'tools_sha256', 'go_env')), 'unequal CI environments')
        for pair in range(args.pairs):
            order = names if pair % 2 == 0 else names[::-1]
            block = {'pair': pair + 1, 'order': {'warm': order, 'incremental': order[::-1]}}
            for phase, sequence in block['order'].items():
                variant = str(pair + 1).zfill(4) if phase == 'incremental' else ''
                block[phase] = {name: fixture_sample(arms[name], checkouts[name], original, variant, args.cpus) for name in sequence}
                observed = {result['binary_sha256'] for result in block[phase].values()}
                bench.require(len(observed) == 1, 'different product binary from identical selected fixture')
                if variant:
                    bench.require(observed.isdisjoint(baseline_hashes | revision_hashes), 'expected fresh edited product binary')
                    revision_hashes.update(observed)
                else:
                    bench.require(observed == baseline_hashes, 'reset build did not match its prime')
            receipt['pairs'].append(block)
        for arm in arms.values():
            arm.check_generation()
    for field, getter in (
        ('median_ms', lambda row: row['sum_ns']),
        ('host_update_wall_median_ms', lambda row: row['host_update_wall_ns']),
        ('edit_return_to_correct_median_ms', lambda row: row['visibility']['edit_return_to_correct_ns']),
        ('edit_to_completed_build_median_ms', lambda row: row['edit_to_completed_build_ns']),
    ):
        receipt[field] = {}
        for phase in ('warm', 'incremental'):
            receipt[field][phase] = {}
            for name in names:
                times = [elapsed for pair in receipt['pairs'] if (elapsed := getter(pair[phase][name])) is not None]
                receipt[field][phase][name] = statistics.median(times) / 1e6 if times else None
    return receipt


bench.Arm.start = start
bench.Arm.guest = timed
if os.environ.get('MP_GAMMA2_VISIBILITY') == '1':
    runner.measure = measure_isolated
runner.main()
