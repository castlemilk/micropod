#!/usr/bin/env python3
"""Check a live VirtioFS mmap edit and atomic replacement with exact host mtime."""

import argparse
import hashlib
import json
import mmap
import os
from pathlib import Path
import re
import subprocess
import tempfile
import time
import uuid


ORIGINAL = b"warm0000old00001old00002"
MAPPED = b"mmap0000fresh001fresh002"
REPLACEMENT = b"repl0000repl0001repl0002"
MTIME_NS = 1_765_443_210_123_456_789
LABEL = "io.micropod.exact-mtime-probe"

GUEST = r"""
set -eu
cd "$1"
equals() {
    if [ "$2" != "$3" ]; then
        printf '%s observed=%s expected=%s\n' "$1" "$2" "$3" >&2
        exit 1
    fi
}
wait_for() {
    n=0
    while [ ! -f "$1" ]; do
        n=$((n + 1))
        [ "$n" -lt 500 ] || return 1
        sleep 0.02
    done
}
exec 3<payload
equals held-initial "$(dd bs=8 count=1 <&3 2>/dev/null)" warm0000
stamp="$(stat -c %y payload)"
case "$stamp" in
    *.123456789*) ;;
    *) printf 'unexpected guest mtime %s\n' "$stamp" >&2; exit 1 ;;
esac
printf '%s\n' "$stamp" > guest-mtime-before
touch guest-ready
wait_for host-mapped
equals held-after-mmap "$(dd bs=8 count=1 <&3 2>/dev/null)" fresh001
equals new-after-mmap "$(cat payload)" mmap0000fresh001fresh002
equals stamp-after-mmap "$(stat -c %y payload)" "$stamp"
touch guest-mapped
wait_for host-replaced
equals held-after-replacement "$(dd bs=8 count=1 <&3 2>/dev/null)" fresh002
equals new-after-replacement "$(cat payload)" repl0000repl0001repl0002
equals stamp-after-replacement "$(stat -c %y payload)" "$stamp"
touch guest-replaced
"""


def put_exact_times(path):
    os.utime(path, ns=(MTIME_NS, MTIME_NS))


def evidence(info, contents):
    return {
        "device": info.st_dev,
        "inode": info.st_ino,
        "size": info.st_size,
        "mtime_ns": info.st_mtime_ns,
        "ctime_ns": info.st_ctime_ns,
        "sha256": hashlib.sha256(contents).hexdigest(),
    }


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def check_edits(directory, wait, receipt):
    payload = directory / "payload"
    original = payload.stat()
    require(original.st_mtime_ns == MTIME_NS, "APFS did not store the requested nanoseconds")
    receipt["original"] = evidence(original, ORIGINAL)

    with payload.open("r+b", buffering=0) as held:
        with mmap.mmap(held.fileno(), 0, access=mmap.ACCESS_WRITE) as mapping:
            wait("guest-ready")
            mapping[:] = MAPPED
            put_exact_times(payload)
            mapped = payload.stat()
            observed = os.pread(held.fileno(), len(MAPPED), 0)
            require(observed == MAPPED, "host cannot see the mmap write")
            require(
                (mapped.st_dev, mapped.st_ino, mapped.st_size, mapped.st_mtime_ns)
                == (original.st_dev, original.st_ino, original.st_size, MTIME_NS),
                "mmap edit changed identity, size or exact mtime",
            )
            receipt["mapped"] = evidence(mapped, observed)
            (directory / "host-mapped").touch()
            wait("guest-mapped")

            replacement = directory / "replacement"
            replacement.write_bytes(REPLACEMENT)
            put_exact_times(replacement)
            replacement.replace(payload)
            replaced = payload.stat()
            require(
                (replaced.st_dev, replaced.st_size, replaced.st_mtime_ns)
                == (original.st_dev, original.st_size, MTIME_NS)
                and replaced.st_ino != original.st_ino,
                "replacement did not retain size and exact mtime on a new inode",
            )
            receipt["replaced"] = evidence(replaced, payload.read_bytes())
            (directory / "host-replaced").touch()
            wait("guest-replaced")
            require(os.pread(held.fileno(), len(MAPPED), 0) == MAPPED, "host hold lost the old inode")
    receipt["guest_mtime"] = (directory / "guest-mtime-before").read_text().strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--docker-host", required=True)
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--image", default="alpine:3.23")
    args = parser.parse_args()
    base = ["docker", "--host", args.docker_host]
    name = "mp-mmap-" + uuid.uuid4().hex
    receipt = {"container": name, "image": args.image, "success": False}

    def docker(*argv, check=True):
        return subprocess.run(
            [*base, *argv], timeout=10, check=check, capture_output=True, text=True
        )

    with tempfile.TemporaryDirectory(prefix=".mp-mmap-", dir=args.workspace.resolve()) as temp:
        directory = Path(temp)
        container = None

        def wait(marker):
            deadline = time.monotonic() + 12
            while time.monotonic() < deadline:
                if (directory / marker).is_file():
                    return
                time.sleep(0.01)
            raise RuntimeError(f"guest never acknowledged {marker}")

        try:
            payload = directory / "payload"
            payload.write_bytes(ORIGINAL)
            put_exact_times(payload)
            container = docker(
                "run", "--detach", "--pull", "never", "--network", "none",
                "--name", name, "--label", f"{LABEL}={name}",
                "--mount", f"type=bind,src={directory},dst=/probe",
                "--entrypoint", "/bin/sh", args.image, "-c", GUEST, "probe", "/probe",
            ).stdout.strip()
            require(re.fullmatch(r"[0-9a-f]{64}", container), "invalid Docker container ID")
            check_edits(directory, wait, receipt)
            exit_status = docker("wait", container).stdout.strip()
            require(exit_status == "0", f"guest exit status {exit_status}")
            receipt["success"] = True
        except (OSError, RuntimeError, subprocess.SubprocessError) as error:
            receipt["error"] = str(error)
            if isinstance(error, subprocess.CalledProcessError):
                receipt["docker_stderr"] = error.stderr
            if container and re.fullmatch(r"[0-9a-f]{64}", container):
                try:
                    logs = docker("logs", container, check=False)
                    receipt["guest_log"] = logs.stdout + logs.stderr
                except (OSError, subprocess.SubprocessError) as log_error:
                    receipt["guest_log_error"] = str(log_error)
        finally:
            # The generated label also covers a detached create whose response was lost.
            try:
                ids = docker(
                    "ps", "-a", "-q", "--no-trunc", "--filter", f"label={LABEL}={name}"
                ).stdout.splitlines()
                for owned_id in ids:
                    require(re.fullmatch(r"[0-9a-f]{64}", owned_id), "invalid Docker cleanup ID")
                    docker("rm", "-f", owned_id)
            except (OSError, RuntimeError, subprocess.SubprocessError) as cleanup_error:
                receipt["success"] = False
                receipt["cleanup_error"] = str(cleanup_error)
    print(json.dumps(receipt, indent=2, sort_keys=True))
    return 0 if receipt["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
