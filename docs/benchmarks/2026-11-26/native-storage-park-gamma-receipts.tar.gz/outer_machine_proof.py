#!/usr/bin/env python3
"""Qualify a root-built Micropod machine using only an owned APFS scope."""

import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import plistlib
import re
import shutil
import signal
import stat
import subprocess
import sys
import tarfile
import tempfile
import time


OUTER_HEAD = '1db09e63a621a82520169d20613761da83ade14f'
FROZEN_CLI_SHA = 'c9d54a9a157e38b2fbab32026bcf610f608c7a404e8dee064998013a9c04bf90'
IMAGE = 'alpine:3.23'
DOCKER = '/opt/homebrew/bin/docker'
OWNERS = re.compile(r'^\s*(\d+)\s+(\d+)\s+(\S+\s+\S+\s+\d+\s+\S+\s+\d+)\s+(.*)$')


def record(path, contents):
    staging = path.with_name(path.name + '.writing')
    staging.write_text(json.dumps(contents, indent=2, sort_keys=True) + '\n')
    os.replace(staging, path)


def hash_file(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    current = path.lstat()
    return {
        'device': current.st_dev, 'inode': current.st_ino, 'logical_bytes': current.st_size,
        'allocated_bytes': current.st_blocks * 512, 'mode': oct(stat.S_IMODE(current.st_mode)),
        'mtime_ns': current.st_mtime_ns,
    }


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def process_table():
    listing = subprocess.check_output(['/bin/ps', '-ww', '-axo', 'pid=,ppid=,lstart=,command='], text=True)
    table = {}
    for line in listing.splitlines():
        match = OWNERS.match(line)
        if match:
            pid, parent, start, command = match.groups()
            table[int(pid)] = {'parent': int(parent), 'start': start, 'command': command}
    return table


def outside_processes(table):
    def stable_service(command):
        executable = command.split(' ', 1)[0]
        return (executable.startswith(('/Applications/Micropod.app/', '/Applications/OrbStack.app/'))
                or executable.endswith(('/MicropodAPI', '/micropod-docker-shim', '/micropod-sharedfs', '/cf-runner-machine')))
    return {pid: row for pid, row in table.items()
            if stable_service(row['command']) or row['command'].startswith('/Applications/OrbStack.app/')}


def scoped_processes(table, scope):
    prefix = str(scope) + '/'
    spellings = (prefix, prefix.removeprefix('/private')) if prefix.startswith('/private/tmp/') else (prefix,)
    return {pid: row for pid, row in table.items() if row['command'].startswith(spellings)}


def default_state(home):
    paths = [home / '.micropod' / name for name in ('hvf', 'runtimes.json', 'docker.sock')]
    result = {}
    for path in paths:
        if not path.exists():
            result[str(path)] = None
        else:
            result[str(path)] = identity(path)
            if path.is_file():
                result[str(path)]['sha256'] = hash_file(path)
    return result


def volume_identity(mount):
    info = plistlib.loads(subprocess.check_output(['/usr/sbin/diskutil', 'info', '-plist', str(mount)]))
    require(mount.is_mount() and info['MountPoint'] == str(mount) and info['FilesystemType'] == 'apfs',
            f'{mount} is not the expected dedicated APFS mount')
    keys = ('DeviceIdentifier', 'APFSContainerReference', 'APFSPhysicalStores', 'FilesystemType', 'MountPoint',
            'RemovableMediaOrExternalDevice', 'WritableVolume', 'DiskUUID', 'VolumeUUID', 'Size')
    return {key: info[key] for key in keys if key in info}


class Proof:
    def __init__(self, args):
        self.assets = args.mount / 'artifacts'
        self.scope = Path(tempfile.mkdtemp(prefix='outer-machine-', dir=args.mount))
        self.mount = args.mount
        self.scope_identity = identity(self.scope)
        self.machine = self.scope / 'machine'
        self.binary = self.scope / 'micropod'
        self.workspace = self.scope / 'workspace'
        self.socket = self.machine / 'run' / 'docker.sock'
        self.release = self.scope / 'release'
        self.logs = args.output
        self.repo = args.repo
        self.disk_input = args.disk_base
        self.hold = args.hold
        for directory in ('home', 'workspace', 'tmp', 'docker-config'):
            (self.scope / directory).mkdir(mode=0o700)
        self.env = {
            'HOME': str(self.scope / 'home'), 'CFFIXED_USER_HOME': str(self.scope / 'home'),
            'TMPDIR': str(self.scope / 'tmp'), 'PATH': '/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
            'MICROPOD_HVF_ROOT': str(self.machine), 'MICROPOD_RUNTIMES_CONFIG': str(self.scope / 'runtimes.json'),
            'MICROPOD_CLI': str(self.binary), 'MICROPOD_NO_UPDATE_NOTIFIER': '1', 'MICROPOD_RUNTIME': 'cli',
            'MICROPOD_CONTAINER_CLI_PATH': str(self.scope / 'unused-apple-container'),
            'DOCKER_HOST': 'unix://' + str(self.socket), 'DOCKER_CONFIG': str(self.scope / 'docker-config'),
            'DOCKER_CLI_HINTS': 'false', 'NO_COLOR': '1',
        }
        self.result = {'scope': str(self.scope), 'checks': {}, 'errors': {}}
        self.name = 'outer-proof-' + self.scope.name.removeprefix('outer-machine-')
        self.start_attempted = False

    def event(self, message):
        print(message, flush=True)
        with self.logs.with_suffix('.log').open('a') as handle:
            handle.write(message + '\n')

    def run(self, *args, timeout=30, require_success=True, label=None):
        name = label or ' '.join(map(str, args))
        started = time.monotonic()
        command = [str(arg) for arg in args]
        with subprocess.Popen(command, env=self.env, cwd=self.scope, stdin=subprocess.DEVNULL,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True) as proc:
            try:
                out, err = proc.communicate(timeout=timeout)
            except BaseException:
                proc.send_signal(signal.SIGTERM)
                try:
                    proc.communicate(timeout=10)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.communicate(timeout=5)
                raise
        result = {'command': command, 'exit': proc.returncode, 'stdout': out, 'stderr': err,
                  'seconds': round(time.monotonic() - started, 3)}
        self.result['checks'][name] = result
        with self.logs.with_suffix('.log').open('a') as handle:
            handle.write(f'{name} ({proc.returncode}) [{result["seconds"]}s]\n{out}')
        if err:
            with self.logs.with_suffix('.stderr').open('a') as handle:
                handle.write(f'{name} ({proc.returncode})\n{err}')
        require(not require_success or proc.returncode == 0, f'{name} failed (status {proc.returncode}): {err.strip()}')
        return result

    def signature(self, binary, label):
        self.run('/usr/bin/codesign', '--verify', '--strict', binary, label=f'{label} valid signature')
        details = self.run('/usr/bin/codesign', '-d', '--entitlements', '-', '--xml', binary,
                           label=f'{label} entitlements')
        return plistlib.loads(details['stdout'].encode())

    def status(self, label):
        return json.loads(self.run(self.binary, '--json', 'machine', 'status', label=label)['stdout'])

    def prepare(self):
        self.result['volume'] = volume_identity(self.mount)
        before = process_table()
        self.result['outside_processes_before'] = outside_processes(before)
        self.result['defaults_before'] = default_state(Path.home())
        self.result['root_head_before'] = subprocess.check_output(['git', '-C', str(self.repo), 'rev-parse', 'HEAD'], text=True).strip()
        require(self.result['root_head_before'] == OUTER_HEAD, 'Outer source commit differs from the frozen qualification revision')
        source = self.repo / '.build' / 'debug' / 'micropod'
        self.run('/bin/cp', '-p', source, self.binary, label='freeze root-built CLI')
        root_cli_hash = hash_file(self.binary)
        require(root_cli_hash == FROZEN_CLI_SHA, 'Expected exact preflight root CLI bytes')
        self.event(f'Froze outer CLI SHA-256 {root_cli_hash}')
        self.result['source_changes_since_head'] = subprocess.check_output(
            ['git', '-C', str(self.repo), 'diff', '--name-only', OUTER_HEAD, '--',
             'Package.swift', 'Package.resolved', 'Sources', 'vmm'], text=True).splitlines()
        installed = Path('/Applications/Micropod.app/Contents/MacOS/micropod-cli')
        root_vmm = self.repo / 'vmm' / 'target' / 'release' / 'micropod-vmm'
        root_init = self.repo / 'vmm' / 'target' / 'mp-hvf-init.cpio'
        tools = self.assets / 'guard-standalone' / 'micropod-oci-tools'
        kernel = self.assets / 'Image'
        min_seed = self.assets / 'minimal.tar'
        harness = self.assets / 'exec-prospective-harness'
        self.result['provenance'] = {
            'root_cli': {'path': str(source), 'sha256': root_cli_hash,
                         'build_artifact': identity(source), 'entitlements': self.signature(self.binary, 'root-built CLI')},
            'installed_cli': {'path': str(installed), 'sha256': hash_file(installed),
                              'entitlements': self.signature(installed, 'installed CLI')},
            'root_vmm': {'path': str(root_vmm), 'sha256': hash_file(root_vmm), 'build_artifact': identity(root_vmm)},
            'root_initrd': {'path': str(root_init), 'sha256': hash_file(root_init), 'build_artifact': identity(root_init)},
            'kernel': {'path': str(kernel), 'sha256': hash_file(kernel)},
            'tools': {'path': str(tools), 'files': {str(path.relative_to(tools)): hash_file(path)
                       for path in sorted(tools.rglob('*')) if path.is_file()}},
            'seed': {'path': str(min_seed), 'sha256': hash_file(min_seed)},
            'harness': {'path': str(harness), 'files': {path.name: hash_file(path) for path in sorted(harness.glob('*.py'))}},
            'docker': {'path': DOCKER, 'resolved': str(Path(DOCKER).resolve()), 'sha256': hash_file(Path(DOCKER))},
        }
        with tarfile.open(min_seed) as seed:
            tags = [tag for image in json.load(seed.extractfile('manifest.json')) for tag in image.get('RepoTags', [])]
        require(IMAGE in tags, f'Expected to preload {IMAGE}')
        self.result['provenance']['seed']['tags'] = tags
        info = plistlib.loads((installed.parent.parent / 'Info.plist').read_bytes())
        self.result['provenance']['installed_cli']['app_version'] = info.get('CFBundleShortVersionString')
        self.run(installed, 'machine', 'help', label='installed CLI machine help', require_success=False)
        help_text = self.run(self.binary, 'machine', 'help', label='frozen root CLI machine help')['stdout']
        require('machine docker-endpoint' in help_text, 'Root CLI lacks the machine front door')
        self.result['base_input_before'] = identity(self.disk_input)
        require(self.disk_input.is_file() and not self.disk_input.is_symlink(), 'Expected a regular cached Alpine disk')
        require(not any(f'--disk {self.disk_input} ' in row['command'] for row in before.values()),
                'An observed process is running with the staged disk path')
        clone_base = self.scope / 'base.ext4'
        self.run('/bin/cp', '-p', self.disk_input, clone_base, timeout=60, label='sparse copy of cached Alpine base')
        clone_base.chmod(0o400)
        self.result['private_clone_base'] = identity(clone_base)
        require(clone_base.stat().st_dev == self.scope.stat().st_dev, 'Base copy is outside the APFS volume')
        require(clone_base.stat().st_ino != self.disk_input.stat().st_ino or clone_base.stat().st_dev != self.disk_input.stat().st_dev,
                'Disk input and private base have the same identity')
        self.result['private_clone_base']['sha256'] = hash_file(clone_base)
        require(self.result['private_clone_base']['sha256'] == hash_file(self.disk_input), 'Cached Alpine base copy differs')
        self.run(self.binary, 'machine', 'install', '--vmm', root_vmm, '--kernel', kernel, '--initrd', root_init,
                 '--tools', tools, '--disk-from', clone_base, '--cpus', '4', '--memory-mib', '4096',
                 '--workspace', self.workspace, label='install private outer machine')
        raw = self.machine / 'disk.ext4'
        self.result['installed_disk'] = identity(raw)
        require(raw.stat().st_dev == self.scope.stat().st_dev and raw.stat().st_ino != clone_base.stat().st_ino,
                'Machine disk must be an independent APFS clone in the owned scope')
        require(self.result['installed_disk']['mode'] == '0o600', 'Expected private machine disk mode 0600')
        verify = self.result['provenance']
        for name, path in [('root_vmm', self.machine / 'micropod-vmm'), ('root_initrd', self.machine / 'mp-hvf-init.cpio'),
                           ('kernel', self.machine / 'Image')]:
            require(verify[name]['sha256'] == hash_file(path), f'Installed {name} bytes differ')
        verify['root_vmm']['entitlements'] = self.signature(self.machine / 'micropod-vmm', 'installed VMM')
        require(verify['root_vmm']['entitlements'].get('com.apple.security.hypervisor') is True, 'VMM entitlement is missing')
        tools_copy = self.machine / 'tools'
        require(verify['tools']['files'] == {str(path.relative_to(tools_copy)): hash_file(path)
                for path in sorted(tools_copy.rglob('*')) if path.is_file()}, 'Installed guest tool bytes differ')
        self.diskbase = clone_base
        self.seed = min_seed
        self.harness = harness / 'qualify_docker_exec.py'

    def start(self):
        self.result['status_installed'] = self.status('installed machine status')
        require(self.result['status_installed']['phase'] == 'stopped', 'Installed machine was not stopped')
        self.start_attempted = True
        self.run(self.binary, 'machine', 'start', '--timeout', '65', timeout=75, label='start private outer machine')
        details = self.status('running machine status')
        self.result['status_running'] = details
        state = details['state']
        require(details['phase'] == 'running' and details['supervisorAlive'] and state['restartCount'] == 0,
                f'Unexpected running state: {details}')
        table = process_table()
        sup, vmm = state['supervisorPID'], state['vmmPID']
        owned = scoped_processes(table, self.scope)
        supervisor_args = owned[sup]['command'].split()
        require(Path(supervisor_args[0]).resolve() == self.binary and supervisor_args[1:] == ['machine', 'serve'],
                'Running supervisor is from another scope')
        vmm_args = owned[vmm]['command'].split()
        require(Path(vmm_args[0]).resolve() == self.machine / 'micropod-vmm' and
                Path(vmm_args[vmm_args.index('--disk') + 1]).resolve() == self.machine / 'disk.ext4' and
                owned[vmm]['parent'] == sup, 'Running VMM is from another scope')
        self.result['running_processes'] = owned
        self.result['running_disk'] = identity(self.machine / 'disk.ext4')
        endpoint = self.run(self.binary, 'machine', 'docker-endpoint', label='explicit Docker endpoint')['stdout'].strip()
        require(endpoint.startswith('unix:///') and Path(endpoint.removeprefix('unix://')).resolve() == self.socket and
                self.socket.is_socket(), f'Machine endpoint is mismatched: {endpoint}')
        self.env['DOCKER_HOST'] = endpoint
        self.run(DOCKER, 'version', '--format', '{{json .}}', label='stock Docker client and server versions')
        self.run(DOCKER, 'load', '-i', self.seed, timeout=60, label='load offline Alpine seed')
        self.run(DOCKER, 'image', 'inspect', IMAGE, '--format', '{{.Id}} {{.Os}}/{{.Architecture}}', label='preloaded Alpine image id')
        self.event(f'Private outer machine is ready at {endpoint}')

    def probes(self):
        harness_result = self.run(sys.executable, '-B', self.harness, '--host', self.env['DOCKER_HOST'], '--image', IMAGE,
                                  timeout=260, label='stock Docker exec qualification', require_success=False)
        self.logs.with_name(self.logs.name + '-exec.json').write_text(harness_result['stdout'])
        self.logs.with_name(self.logs.name + '-exec.stderr').write_text(harness_result['stderr'])
        if harness_result['exit'] != 0:
            self.result['errors']['stock Docker exec qualification'] = f'Exit {harness_result["exit"]}'
        self.run(self.binary, 'runtime', 'enable', 'hvf', label='enable HVF in private runtime config')
        run = self.run(self.binary, 'run', '--runtime', 'hvf', '--name', self.name, IMAGE, '--', '/bin/sh', '-ec',
                       'printf "micropod machine canary\\n"; exec sleep 900', label='native CLI noninteractive run')
        require(run['stdout'].strip() == self.name, f'Unexpected native CLI container id {run["stdout"]!r}')
        version = self.run(self.binary, 'exec', self.name, '--', 'cat', '/etc/alpine-release',
                           label='native CLI noninteractive exec')['stdout'].strip()
        require(version.startswith('3.23.'), f'Unexpected Alpine guest release {version!r}')
        self.run(self.binary, 'logs', '-n', '5', self.name, label='native CLI container logs')
        self.run(self.binary, 'exec', self.name, '--', '/bin/sh', '-c', 'printf "native-command-out\\n"; printf "native-command-err\\n" >&2; exit 23',
                 label='native CLI exec exit status boundary', require_success=False)
        self.run(self.binary, 'exec', '-i', '-t', self.name, '--', 'true', label='native CLI interactive exec boundary', require_success=False)
        self.run(self.binary, 'exec', '-d', self.name, '--', 'true', label='native CLI detached exec boundary', require_success=False)
        self.run(self.binary, 'cp', self.name + ':/etc/alpine-release', self.scope / 'native-copy',
                 label='native CLI copy boundary', require_success=False)
        self.run(self.binary, 'export', self.name, '-o', self.scope / 'export.tar',
                 label='native CLI export boundary', require_success=False)
        data = b'outer archive proof\x00binary\xff\n'
        source = self.scope / 'docker-source'
        source.write_bytes(data)
        docker_copy = self.run(DOCKER, 'cp', source, self.name + ':/tmp/protected-scope-file',
                               label='stock Docker copy into running container', require_success=False)
        if docker_copy['exit'] == 0:
            target = self.scope / 'docker-copyback'
            docker_out = self.run(DOCKER, 'cp', self.name + ':/tmp/protected-scope-file', target,
                                  label='stock Docker copy out of running container', require_success=False)
            self.result['stock_docker_archive_roundtrip'] = docker_out['exit'] == 0 and target.read_bytes() == data
        else:
            self.result['stock_docker_archive_roundtrip'] = False
        self.run(DOCKER, 'container', 'inspect', self.name, '--format', '{{.Id}} {{.State.Status}}', label='Docker can see native CLI container')

    def wait_for_release(self):
        if not self.hold:
            return
        receipt = {'scope': str(self.scope), 'canary': self.name, 'release_file': str(self.release), 'environment': self.env}
        record(self.logs.with_name(self.logs.name + '-hold.json'), receipt)
        self.event(f'Holding owned machine. Write the release file at {self.release} to retire it.')
        while not self.release.is_file():
            time.sleep(1)

    def stop_and_remove(self):
        if self.start_attempted:
            self.run(DOCKER, 'rm', '-f', self.name, require_success=False, label='remove private canary')
            self.run(self.binary, 'machine', 'stop', '--timeout', '22', timeout=28, label='graceful stop of private outer machine')
            self.result['status_stopped'] = self.status('final machine status')
            for log in ('supervisor', 'console'):
                source = self.machine / 'logs' / (log + '.log')
                if source.is_file():
                    shutil.copyfile(source, self.logs.with_name(self.logs.name + '-' + log + '.log'))
            deadline = time.monotonic() + 10
            while scoped_processes(process_table(), self.scope) and time.monotonic() < deadline:
                time.sleep(0.2)
            outside_after = process_table()
            alive = scoped_processes(outside_after, self.scope)
            self.result['scoped_processes_after_stop'] = alive
            require(not alive, f'Scoped processes remain: {alive}')
            for pid, row in self.result.get('running_processes', {}).items():
                require(outside_after.get(pid, {}).get('start') != row['start'], f'Initial owned process {pid} did not exit')
            self.result['socket_removed'] = not self.socket.exists() and not self.socket.is_symlink()
            require(self.result['socket_removed'], 'Owned Docker socket still exists after stopping the machine')
            lock_path = self.machine / 'run' / 'supervisor.lock'
            if lock_path.is_file():
                with lock_path.open('r') as lock:
                    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    fcntl.flock(lock, fcntl.LOCK_UN)
                self.result['supervisor_lock_released'] = True
            final = self.result['status_stopped']
            self.result['clean_shutdown'] = (final['phase'] == 'stopped' and not final['supervisorAlive'] and
                final.get('state', {}).get('lastExitCode') == 0 and 'exit_reason=poweroff' in final['state'].get('lastExitReason', ''))
        self.result['defaults_after'] = default_state(Path.home())
        self.result['outside_processes_after'] = outside_processes(process_table())
        self.result['defaults_unchanged'] = self.result.get('defaults_before') == self.result['defaults_after']
        self.result['outside_processes_unchanged'] = self.result.get('outside_processes_before') == self.result['outside_processes_after']
        if self.disk_input.exists():
            self.result['base_input_after'] = identity(self.disk_input)
            self.result['base_input_unchanged'] = self.result.get('base_input_before') == self.result['base_input_after']
        self.result['volume_after'] = volume_identity(self.mount)
        current = identity(self.scope)
        require(self.scope.parent == self.mount and self.scope.name.startswith('outer-machine-') and not self.scope.is_symlink()
                and all(current[key] == self.scope_identity[key] for key in ('device', 'inode'))
                and current['device'] == self.mount.stat().st_dev and not self.scope.is_mount(),
                'Owned scope identity changed')
        require(not scoped_processes(process_table(), self.scope), 'Cannot remove a scope with a running process')
        shutil.rmtree(self.scope)
        self.result['scope_removed'] = not self.scope.exists()
        self.event(f'Retired private scope {self.scope}')


def interrupted(signum, _frame):
    raise KeyboardInterrupt(f'Received signal {signum}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mount', required=True, type=Path)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--disk-base', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path, help='unique receipt basename outside the mounted scope')
    parser.add_argument('--hold', action='store_true')
    args = parser.parse_args()
    signal.signal(signal.SIGTERM, interrupted)
    os.umask(0o077)
    for attr in ('mount', 'repo', 'disk_base'):
        setattr(args, attr, getattr(args, attr).resolve(strict=True))
    args.output = args.output.resolve()
    require(args.output.parent == args.mount.parent and not args.output.suffix, 'Output must be a receipt basename beside the mount')
    require(not list(args.output.parent.glob(args.output.name + '*')), 'Receipt basename is already used')
    volume_identity(args.mount)
    proof = Proof(args)
    proof.event(f'Allocated protected APFS scope {proof.scope}')
    try:
        proof.prepare()
        proof.start()
        proof.probes()
        record(args.output.with_name(args.output.name + '-running.json'), proof.result)
        proof.wait_for_release()
    except (Exception, KeyboardInterrupt) as error:
        proof.result['errors']['operation'] = f'{type(error).__name__}: {error}'
        print(proof.result['errors']['operation'], file=sys.stderr, flush=True)
    finally:
        try:
            proof.stop_and_remove()
        except (Exception, KeyboardInterrupt) as error:
            proof.result['errors']['cleanup'] = f'{type(error).__name__}: {error}'
            print(proof.result['errors']['cleanup'], file=sys.stderr, flush=True)
        proof.result['passed'] = not proof.result['errors'] and all(proof.result.get(key, False) for key in
                                ('clean_shutdown', 'scope_removed', 'defaults_unchanged', 'base_input_unchanged'))
        record(args.output.with_suffix('.json'), proof.result)
    return 0 if proof.result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
