"""Restore the archived workload and exact qualified native artifacts on the new hub."""
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tarfile

receipt = Path(__file__).resolve().parent
hub = receipt.parent / 'home'
assert hub.is_mount() and receipt.parent.name.startswith('mp-gamma3.')
worktree = Path(sys.argv[1]).resolve(strict=True)
repo = worktree.parent.parent
production = repo / '.build/qualified/micropod-hvf-gamma2-fmdkh0'
prepared = hub / 'artifacts'
source = hub / 'evidence/prior'
prepared.mkdir()
source.mkdir(parents=True)
(hub / 'share').mkdir(mode=0o700)


def sha(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def verified_archive(path, expected, selects):
    assert sha(path) == expected, path
    wanted = set(selects)
    with tarfile.open(path) as archive:
        manifest = json.load(archive.extractfile('MANIFEST.sha256.json'))
        count = 0
        for entry in archive:
            if entry.name not in manifest:
                continue
            assert entry.isfile(), entry.name
            with archive.extractfile(entry) as data:
                content = data.read()
            assert hashlib.sha256(content).hexdigest() == manifest[entry.name], entry.name
            count += 1
            if entry.name in wanted:
                target = selects[entry.name]
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
                target.chmod(entry.mode & 0o777)
                os.utime(target, (entry.mtime, entry.mtime))
                wanted.remove(entry.name)
        assert not wanted and count == len(manifest), (wanted, count, len(manifest))
    return {'path': str(path), 'sha256': expected, 'verified_entries': count, 'selected_entries': len(selects)}


reports = worktree / 'docs/benchmarks'
prior_archive = reports / '2026-11-26/core-pid1-and-mutable-gamma-receipts.tar.gz'
prior_summary = json.loads((reports / '2026-11-26/core-pid1-and-mutable-gamma.json').read_bytes())
operators = ('prepare_image.py', 'public_machine.py', 'outer_machine_proof.py', 'measure_main_ci.py',
             'with_host_load.py', 'run_public_arm.sh', 'stock_pid1_probe.py')
selections = {name: receipt / name for name in operators}
selections.update({'candidate-inputs/mutable-candidate/mmap_exact_timestamp.py': receipt / 'mmap_exact_timestamp.py',
                   'candidate-inputs/kernel-splice/guest_splice_contract.py': receipt / 'guest_splice_contract.py'})
verified = {'previous_current_receipts': verified_archive(prior_archive, prior_summary['receipts']['sha256'], selections)}
older = reports / '2026-11-26/mounted-ci-gamma-receipts.tar.gz'
verified['previous_mounted_receipts'] = verified_archive(older, '774763ef36286b0d1c747c81a6c24354654e190d29a69b1f041cdcd7565f6eb0', {})
older = reports / '2026-11-25/managed-ci-git-and-exec-receipts.tar.gz'
older_hashes = prior_summary['historical_preservation']['archived_products_sha256']
historic_trace = ('raw/metadata-repeat-gitstudy-samples.json', 'raw/baseline-repeat-gitstudy-samples.json',
                  'raw/metadata-repeat-gitstudy.trace-events.log', 'raw/metadata-repeat-gitstudy.trace-stats.log')
verified['historical_receipts'] = verified_archive(older, older_hashes[older.name],
                                                  {name: receipt / 'historical' / PurePosixPath(name).name for name in historic_trace})
source_archive = reports / '2026-11-25/managed-ci-git-and-exec-sources.tar.gz'
with tarfile.open(source_archive) as archive:
    files = [member.name for member in archive if member.isfile() and
             member.name.startswith(('runner-vendored/', 'final-harness/scripts/'))]
assert all('..' not in PurePosixPath(name).parts for name in files)
verified['historical_sources'] = verified_archive(source_archive, older_hashes[source_archive.name], {name: source / name for name in files})

role_names = {'vmm': 'micropod-vmm', 'initrd': 'mp-hvf-init.cpio', 'kernel': 'Image'}
originals = json.loads((production / 'manifest.json').read_bytes())['combined-image']
roles = {role: {'source': row['retained_path'], 'sha256': row['sha256'],
                'staged': str(prepared / role_names.get(role, 'tools-baseline/runner/bin/job'))}
         for role, row in originals.items()}
cli_source = repo / '.build/qualified/micropod-tty-31c78102d9a1'
cli_dest = prepared / 'cli-baseline'
shutil.copytree(cli_source, cli_dest, symlinks=True)
roles['cli'] = {'source': str(cli_source / 'micropod'), 'staged': str(cli_dest / 'micropod'),
                'sha256': '31c78102d9a1ab7a07912cbbd89f2e3dd265889eae62663336d0fb1e595f0259'}

with gzip.open(reports / '2026-11-21/gamma-vcpu-priority.json.gz', 'rt') as data:
    installation = json.load(data)['installation']
original_tools = Path(installation['path']) / 'micropod-oci-tools'
staged_tools = prepared / 'tools-baseline'
shutil.copytree(original_tools, staged_tools, symlinks=True)
for name, digest in installation['tools'].items():
    assert sha(staged_tools / name) == sha(original_tools / name) == digest, name
for role, row in roles.items():
    assert sha(Path(row['source'])) == row['sha256'], row
    if role != 'cli':
        shutil.copy2(row['source'], row['staged'])
    assert sha(Path(row['staged'])) == row['sha256'], row
for role in ('cli', 'vmm'):
    subprocess.run(['/usr/bin/codesign', '--verify', '--strict', roles[role]['staged']], check=True)

probe = source / 'final-harness/scripts/workspacebench/main.go'
environment = dict(os.environ, GOOS='linux', GOARCH='arm64', CGO_ENABLED='0')
subprocess.run(['go', 'build', '-trimpath', '-o', str(prepared / 'fsprobe'), str(probe)], env=environment, check=True)
write(receipt / 'baseline-lineage.json', {'artifacts': roles, 'archives': verified,
      'tool_bank_entries': len(installation['tools']), 'tool_bank_source': str(original_tools),
      'fsprobe': {'source_sha256': sha(probe), 'binary_sha256': sha(prepared / 'fsprobe')}})
