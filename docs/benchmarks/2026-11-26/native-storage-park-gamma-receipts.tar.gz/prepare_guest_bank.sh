#!/bin/bash
set -euo pipefail

receipts=$(cd "$(dirname "$0")" && pwd -P)
hub=$(dirname "$receipts")/home
job=${1:?protected guest binary}
expected=${2:?guest SHA-256}
arm=${3:?owned prospective worker label}
[[ $arm =~ ^[a-z0-9-]{1,22}$ && $expected =~ ^[0-9a-f]{64}$ ]]
base="$hub/artifacts/tools-baseline"
dest="$hub/artifacts/tools-$arm"
test -d "$base" && test -f "$job" && test ! -L "$job" && test ! -e "$dest"
resolved=$(python3 -B -c 'from pathlib import Path; import sys; print(Path(sys.argv[1]).resolve(strict=True))' "$job")
[[ $resolved == "$hub/"* ]]

digest() { /usr/bin/shasum -a 256 "$1" | /usr/bin/cut -d' ' -f1; }
test "$(digest "$job")" = "$expected"
/bin/cp -Rc "$base" "$dest"
/bin/cp -p "$job" "$dest/runner/bin/job"
test "$(digest "$dest/runner/bin/job")" = "$expected"
/usr/bin/diff -qr -x job "$base" "$dest"
/usr/bin/shasum -a 256 "$dest/runner/bin/job" > "$receipts/$arm-job-sha256.txt"
