#!/bin/bash
set -euo pipefail

r=$(cd "$(dirname "$0")" && pwd -P)
hub=$(dirname "$r")
stage="$hub/home/git-preload-check/density"
ready=$1
prefix=$2
test "$prefix" = "$r/$(basename "$prefix")"
test ! -e "$prefix.json"
socket=$(jq -er .socket "$ready")
workspace=$(jq -er .workspace "$ready")
image=$(jq -er .benchmark_image "$ready")
orb_socket=/Users/benebsworth/.orbstack/run/docker.sock
monitor="$r/with_host_load.py"

python3 -B "$monitor" --out "$prefix-pre-idle.jsonl" -- python3 -B -c 'import time; time.sleep(2.25)'
set +e
python3 -B "$monitor" --out "$prefix-host-load.jsonl" -- python3 -B "$stage/bench_git_gate_density.py" \
    --hvf-socket "$socket" --orbstack-socket "$orb_socket" --workspace "$workspace" \
    --source "$hub/home/evidence/prior/runner-vendored" --helpers "$hub/home/evidence/prior/final-harness/scripts" \
    --helper "$stage/git_parallel_clean.py" --image-manifest "$r/image-manifest.json" \
    --image "$image" --out "$prefix.json" > "$prefix.log" 2>&1
result=$?
set -e
python3 -B "$monitor" --out "$prefix-post-idle.jsonl" -- python3 -B -c 'import time; time.sleep(2.25)'
printf '%s\n' "$result" > "$prefix.exit"
exit "$result"
