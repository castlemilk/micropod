#!/bin/bash
set -euo pipefail

receipts=$(cd "$(dirname "$0")" && pwd -P)
hub=$(dirname "$receipts")
stage="$hub/home/git-preload-check/full"
ready=$1
prefix=$2
name=$(basename "$prefix")
test "$prefix" = "$receipts/$name"
test ! -e "$prefix-material.json"
test ! -e "$prefix-dirty.json"
test ! -e "$prefix-exits.log"
source_checkout="$hub/home/evidence/prior/runner-vendored"
helpers="$hub/home/evidence/prior/final-harness/scripts"
socket=$(jq -er .socket "$ready")
workspace=$(jq -er .workspace "$ready")
image=$(jq -er .benchmark_image "$ready")
orb_socket=/Users/benebsworth/.orbstack/run/docker.sock
stats="$receipts/with_host_load.py"
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH DOCKER_API_VERSION

python3 -B "$stage/test_git_parallel_clean.py" -v > "$prefix-units.log" 2>&1
python3 -B "$stats" --out "$prefix-pre-idle.jsonl" -- python3 -B -c 'import time; time.sleep(2.25)'
set +e
python3 -B "$stats" --out "$prefix-material-host-load.jsonl" -- python3 -B "$stage/bench_workspace_git_gate.py" \
    --hvf-socket "$socket" --orbstack-socket "$orb_socket" --workspace "$workspace" --source "$source_checkout" \
    --helpers "$helpers" --helper "$stage/git_parallel_clean.py" --image-manifest "$receipts/image-manifest.json" \
    --out "$prefix-material.json" --image "$image" --pairs 4 > "$prefix-material.log" 2>&1
material=$?
python3 -B "$stats" --out "$prefix-dirty-host-load.jsonl" -- python3 -B "$stage/bench_git_preload.py" \
    --hvf-host "unix://$socket" --orb-host "unix://$orb_socket" --workspace "$workspace" --source "$source_checkout" \
    --helpers "$helpers" --image "$image" --parallel-helper "$stage/git_parallel_clean.py" \
    --dirty-parallel --rounds 4 --out "$prefix-dirty.json" > "$prefix-dirty.log" 2>&1
dirty=$?
set -e
python3 -B "$stats" --out "$prefix-post-idle.jsonl" -- python3 -B -c 'import time; time.sleep(2.25)'
printf 'material=%s dirty=%s\n' "$material" "$dirty" > "$prefix-exits.log"
(( material == 0 && dirty == 0 ))
