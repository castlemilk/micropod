"""Capture the same quiescent VMM windows with eight owned guest sleepers on each arm."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from uuid import uuid4

receipts = Path(__file__).resolve().parent
idle = receipts / 'storage-park'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('arm')
args = parser.parse_args()
ready = json.loads((receipts / f'{args.arm}-ready.json').read_bytes())
socket = Path(ready['socket'])
assert socket.is_socket()
vmm, = [(int(pid), row) for pid, row in ready['machine']['running_processes'].items()
        if '/machine/micropod-vmm ' in row['command']]
pid, process = vmm
scope = 'mpg3-idle-' + uuid4().hex[:12]
label = f'io.micropod.gamma3.idle={scope}'
environment = {key: value for key, value in os.environ.items() if not key.startswith('DOCKER_')}
docker = ['/opt/homebrew/bin/docker', '--host', f'unix://{socket}']


def call(*options, check=True):
    return subprocess.run([*docker, *options], text=True, capture_output=True, timeout=15, check=check, env=environment)


report = {'arm': args.arm, 'vmm_pid': pid, 'vmm_process': process, 'scope': scope, 'label': label, 'sleepers': [],
          'artifacts': ready['owned_artifacts'], 'memory_mib': 64, 'cpu_quota': '0.25', 'passed': False}
try:
    assert not call('ps', '-aq', '--filter', f'label={label}').stdout.strip()
    for ordinal in range(8):
        child = call('run', '--detach', '--pull=never', '--network=none', '--name', f'{scope}-{ordinal}', '--label', label,
                     '--memory', '64m', '--cpus', '0.25', 'alpine:3.23', 'sleep', '180').stdout.strip()
        report['sleepers'].append(child)
    assert len(set(report['sleepers'])) == 8
    for edge in ('before', 'after'):
        if edge == 'after':
            time.sleep(1)
            command = [sys.executable, '-B', str(receipts / 'with_host_load.py'), '--out', str(idle / f'{args.arm}-idle-host-load.jsonl'),
                       '--', sys.executable, '-B', str(idle / 'sample_idle.py'), str(pid), str(idle / f'{args.arm}-idle.json')]
            with (idle / f'{args.arm}-idle-sampler.log').open('x') as log:
                subprocess.run(command, env=environment, check=True, timeout=42, stdout=log, stderr=subprocess.STDOUT)
        live = call('ps', '--no-trunc', '-q', '--filter', f'label={label}').stdout.splitlines()
        report[f'running_{edge}'] = live
        assert set(live) == set(report['sleepers'])
    report['passed'] = True
finally:
    if report['sleepers']:
        removal = call('container', 'rm', '--force', *report['sleepers'], check=False)
        report['removal'] = {'exit': removal.returncode, 'stdout': removal.stdout, 'stderr': removal.stderr}
    report['remaining'] = call('ps', '--no-trunc', '-aq', '--filter', f'label={label}').stdout.splitlines()
    (idle / f'{args.arm}-idle-scope.json').write_text(json.dumps(report, indent=2) + '\n')
assert not report['remaining'] and report['removal']['exit'] == 0
