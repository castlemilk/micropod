"""Select exact earlier raw-index FUSE dispatch evidence without replaying the older suite."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

receipts = Path(__file__).resolve().parent
lineage = json.loads((receipts / 'baseline-lineage.json').read_bytes())['archives']['historical_receipts']
archive_path = Path(lineage['path'])
with archive_path.open('rb') as data:
    assert hashlib.file_digest(data, 'sha256').hexdigest() == lineage['sha256']
names = ('raw/base-host-ftrace.json', 'raw/base-host-gitstudy.trace-events.log', 'raw/base-host-gitstudy.trace-stats.log')
with tarfile.open(archive_path) as archive:
    records = json.load(archive.extractfile('MANIFEST.sha256.json'))
    for name in names:
        payload = archive.extractfile(name).read()
        assert hashlib.sha256(payload).hexdigest() == records[name], name
        target = receipts / 'historical' / PurePosixPath(name).name
        with target.open('xb') as out:
            out.write(payload)
