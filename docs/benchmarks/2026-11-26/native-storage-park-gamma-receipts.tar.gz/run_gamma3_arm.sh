#!/bin/bash
set -euo pipefail

receipts=$(cd "$(dirname "$0")" && pwd -P)
arm=${1:?private public arm}
phase=${2:?correctness or material}
out=${3:-$arm}
ready="$receipts/$arm-ready.json"
socket=$(jq -er .socket "$ready")
workspace=$(jq -er .workspace "$ready")
image=$(jq -er .benchmark_image "$ready")
test -S "$socket"
unset DOCKER_CONTEXT DOCKER_HOST DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH DOCKER_API_VERSION

if [[ $phase == material ]]; then
    export MP_GAMMA2_TRANSPORT=attached MP_GAMMA2_VISIBILITY=1
    exec /bin/bash "$receipts/run_public_arm.sh" "$arm" material "$out"
fi
test "$phase" = correctness

set +e
/bin/bash "$receipts/run_public_arm.sh" "$arm" edits "$out"
edits=$?
python3 -B "$receipts/mmap_exact_timestamp.py" --docker-host "unix://$socket" --workspace "$workspace" \
    > "$receipts/$out-mmap-exact.json" 2> "$receipts/$out-mmap-exact.log"
held=$?
python3 -B "$receipts/guest_splice_contract.py" --require-live-splice --docker-host "unix://$socket" --workspace "$workspace" --image "$image" \
    > "$receipts/$out-guest-splice.json" 2> "$receipts/$out-guest-splice.log"
splice=$?
python3 -B "$receipts/stock_pid1_probe.py" --socket "$socket" --out "$receipts/$out-stock-pid1.json" \
    > "$receipts/$out-stock-pid1.log" 2>&1
stock=$?
if [[ $stock == 0 ]]; then
    jq -e '.errors == {} and (.cases | length == 4 and all(.[]; .pass)) and (.remaining_owned|length == 0)' \
        "$receipts/$out-stock-pid1.json" >> "$receipts/$out-stock-pid1.log" 2>&1
    stock=$?
fi
set -e
/opt/homebrew/bin/docker --host "unix://$socket" ps -aq > "$receipts/$out-correctness-cleanup.log"
test ! -s "$receipts/$out-correctness-cleanup.log"
printf 'ordinary_edits=%s held_read=%s splice=%s stock_pid1=%s\n' "$edits" "$held" "$splice" "$stock" |
    tee "$receipts/$out-correctness-exit.log"
(( edits == 0 && held == 0 && splice == 0 && stock == 0 ))
