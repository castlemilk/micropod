#!/bin/bash
set -euo pipefail
r=$(cd "$(dirname "$0")" && pwd -P)
s=$(dirname "$r")
e="$s/home/evidence/prior"
name=${1:?private arm}
workload=${2:?edits or material}
label=${3:-$name}
sock=$(jq -er .socket "$r/$name-ready.json")
work=$(jq -er .workspace "$r/$name-ready.json")
image=$(jq -er .benchmark_image "$r/$name-ready.json")
orb=/Users/benebsworth/.orbstack/run/docker.sock
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH DOCKER_API_VERSION
sampler=(python3 -B "$r/with_host_load.py" --out "$r/$label-$workload-host-load.jsonl" --)
case "$workload" in
  material)
    MP_GAMMA2_FAILURE_PREFIX="$r/$label-material-fail" PYTHONPATH="$e/final-harness/scripts" "${sampler[@]}" python3 -B "$r/measure_main_ci.py" --hvf-socket "$sock" \
      --orbstack-socket "$orb" --workspace "$work" --source "$e/runner-vendored" --image "$image" \
      --image-manifest "$r/image-manifest.json" --pairs "${PAIRS:-4}" --cpus 2 --memory-mib 1536 \
      --out "$r/$label-material.json" > "$r/$label-material.log" 2>&1
    ;;
  edits)
    "${sampler[@]}" python3 -B "$e/final-harness/scripts/bench_workspace_edits.py" --host "unix://$sock" --workspace "$work" \
      --probe "$s/home/artifacts/fsprobe" --rounds "${ROUNDS:-4}" > "$r/$label-edits.json" 2> "$r/$label-edits.log"
    ;;
  orb-edits)
    "${sampler[@]}" python3 -B "$e/final-harness/scripts/bench_workspace_edits.py" --host "unix://$orb" --workspace "$work" \
      --probe "$s/home/artifacts/fsprobe" --rounds "${ROUNDS:-4}" > "$r/$label-orb-edits.json" 2> "$r/$label-orb-edits.log"
    ;;
  *) exit 2 ;;
esac
