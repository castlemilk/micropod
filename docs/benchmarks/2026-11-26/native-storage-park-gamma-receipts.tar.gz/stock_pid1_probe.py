"""Independent stock Docker PID 1 and ordinary lifecycle checks."""
import argparse
import errno
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pty
import select
import signal
import struct
import subprocess
import tempfile
import termios
import time
from uuid import uuid4

DOCKER = '/opt/homebrew/bin/docker'
IMAGE = 'alpine:3.23'
LABEL = 'org.micropod.gamma2.stock-pid1'


def output(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'display': data[:4096].decode('utf-8', errors='backslashreplace')}


class Engine:
    def __init__(self, socket, docker_config):
        self.command = [DOCKER, '--host', 'unix://' + str(socket)]
        self.env = {k: v for k, v in os.environ.items() if not k.startswith('DOCKER_')}
        self.env.update(DOCKER_CONFIG=str(docker_config), DOCKER_CLI_HINTS='false', TERM='xterm')
        self.scope = 'mp-gamma2-pid1-' + uuid4().hex[:10]

    def run(self, *args, input_data=None, timeout=12):
        popen_args = dict(env=self.env, start_new_session=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          stdin=subprocess.PIPE if input_data is not None else subprocess.DEVNULL)
        started = time.monotonic_ns()
        with subprocess.Popen([*self.command, *args], **popen_args) as child:
            try:
                stdout, stderr = child.communicate(input_data, timeout=timeout)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                stdout, stderr = child.communicate(timeout=4)
                return {'exit': child.returncode, 'stdout': stdout, 'stderr': stderr, 'timeout': True,
                        'elapsed_ms': (time.monotonic_ns() - started) / 1e6}
        return {'exit': child.returncode, 'stdout': stdout, 'stderr': stderr, 'timeout': False,
                'elapsed_ms': (time.monotonic_ns() - started) / 1e6}

    def flags(self, name):
        return ['--name', name, '--pull=never', '--network=none', '--label', f'{LABEL}={self.scope}']

    def owned(self):
        result = self.run('ps', '-aq', '--filter', f'label={LABEL}={self.scope}')
        assert result['exit'] == 0, result
        return result['stdout'].decode().split()

    def cleanup(self):
        owned = self.owned()
        for ident in owned:
            result = self.run('rm', '-f', ident)
            assert result['exit'] == 0, result
        assert not self.owned()
        return owned


def printable(row):
    return {**row, 'stdout': output(row['stdout']), 'stderr': output(row['stderr'])}


def resize(fd, rows, cols):
    fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack('HHHH', rows, cols, 0, 0))


def terminal(engine):
    name = engine.scope + '-tty'
    guest = ('printf "pid1-early>"; printf "initial "; stty size; '
             'IFS= read -r reply; printf "pid1-saw=%s\\n" "$reply"; printf "resized "; stty size; exit 23')
    command = [*engine.command, 'run', '-it', *engine.flags(name), IMAGE, 'sh', '-ec', guest]
    started = time.monotonic_ns()
    pid, fd = pty.fork()
    if pid == 0:
        resize(0, 31, 97)
        os.execve(DOCKER, command, engine.env)
    seen = b''
    exit_code = None
    eof = False
    sent = False
    first_prompt_ms = None
    deadline = time.monotonic() + 10
    try:
        while time.monotonic() < deadline:
            if not eof and select.select([fd], [], [], 0.08)[0]:
                try:
                    data = os.read(fd, 8192)
                except OSError as error:
                    if error.errno != errno.EIO:
                        raise
                    data = b''
                if data:
                    seen += data
                else:
                    eof = True
            if not sent and b'pid1-early>' in seen and b'initial ' in seen and b'\n' in seen:
                first_prompt_ms = (time.monotonic_ns() - started) / 1e6
                resize(fd, 42, 113)
                # Let the host CLI deliver its SIGWINCH resize before PID 1 resumes.
                time.sleep(0.2)
                os.write(fd, b'gamma-input\n')
                sent = True
            if exit_code is None:
                waited, status = os.waitpid(pid, os.WNOHANG)
                if waited:
                    exit_code = os.waitstatus_to_exitcode(status)
            if eof and exit_code is not None:
                break
    finally:
        if exit_code is None:
            try:
                os.killpg(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            _, status = os.waitpid(pid, 0)
            exit_code = os.waitstatus_to_exitcode(status)
        os.close(fd)
    normalized = seen.replace(b'\r\n', b'\n')
    return {'exit': exit_code, 'early_prompt_seen_before_input': sent, 'prompt_ms': first_prompt_ms,
            'transcript': output(seen), 'initial_size_read': b'initial 31 97' in normalized,
            'resized_size_read': b'resized 42 113' in normalized,
            'pass': sent and exit_code == 23 and b'pid1-saw=gamma-input\n' in normalized and b'resized 42 113' in normalized}


def pipes(engine):
    name = engine.scope + '-pipes'
    sample = (bytes([0, 255, 254, 10, 13, 43]) * 1031) + b'tail'
    command = 'cat; printf "pid1-stderr\\000\\377" >&2; exit 29'
    row = engine.run('run', '-i', *engine.flags(name), IMAGE, 'sh', '-ec', command, input_data=sample, timeout=15)
    return {**printable(row), 'expected_input_sha256': hashlib.sha256(sample).hexdigest(),
            'pass': row['exit'] == 29 and row['stdout'] == sample and row['stderr'] == b'pid1-stderr\0\xff'}


def attachment(engine):
    name = engine.scope + '-attach'
    command = ('printf "previous-out\\n"; printf "previous-err\\n" >&2; touch /tmp/ready; '
               'while ! test -f /tmp/release; do sleep .05; done; '
               'printf "live-out\\n"; printf "live-err\\n" >&2; exit 47')
    base = engine.run('run', '-d', *engine.flags(name), IMAGE, 'sh', '-ec', command)
    assert base['exit'] == 0, base
    deadline = time.monotonic() + 5
    while engine.run('exec', name, 'test', '-f', '/tmp/ready')['exit'] and time.monotonic() < deadline:
        time.sleep(0.05)
    child = subprocess.Popen([*engine.command, 'attach', '--no-stdin', name], env=engine.env, start_new_session=True,
                             stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    exited_before_release = False
    try:
        time.sleep(0.3)
        exited_before_release = child.poll() is not None
        released = engine.run('exec', name, 'touch', '/tmp/release')
        assert released['exit'] == 0, released
        stdout, stderr = child.communicate(timeout=8)
    except BaseException:
        if child.poll() is None:
            os.killpg(child.pid, signal.SIGKILL)
        child.communicate(timeout=4)
        raise
    waited = engine.run('wait', name)
    logs = engine.run('logs', name)
    expected = child.returncode == 47 and stdout == b'live-out\n' and stderr == b'live-err\n' and not exited_before_release
    return {'attach': {'exit': child.returncode, 'early_exit': exited_before_release, 'stdout': output(stdout), 'stderr': output(stderr)},
            'wait': printable(waited), 'logs': printable(logs),
            'pass': expected and waited['exit'] == 0 and waited['stdout'].strip() == b'47'}


def ordinary(engine):
    name = engine.scope + '-ordinary'
    code = 'printf "ordinary-log\\n"; exec sleep 90'
    results = {}
    for action, argv in (
        ('create', ['create', *engine.flags(name), IMAGE, 'sh', '-ec', code]),
        ('start', ['start', name]),
        ('inspect', ['inspect', '--format', '{{.State.Running}}', name]),
        ('exec', ['exec', name, '/bin/sh', '-ec', 'printf "ordinary-exec\\n"']),
        ('logs', ['logs', name]),
        ('stop', ['stop', '--time', '1', name]),
        ('wait', ['wait', name]),
        ('remove', ['rm', name]),
    ):
        row = engine.run(*argv)
        results[action] = printable(row)
        assert row['exit'] == 0, (action, row)
    return {'results': results, 'pass': (results['inspect']['stdout']['display'] == 'true\n'
                                        and results['exec']['stdout']['display'] == 'ordinary-exec\n'
                                        and results['logs']['stdout']['display'] == 'ordinary-log\n')}


def measure(socket):
    with tempfile.TemporaryDirectory(prefix='mpg2-config-') as config:
        engine = Engine(socket, config)
        result = {'socket': str(socket), 'scope': engine.scope, 'cases': {}, 'errors': {}}
        try:
            result['version'] = json.loads(engine.run('version', '--format', '{{json .}}')['stdout'])
            result['image'] = engine.run('image', 'inspect', '--format', '{{.Id}}', IMAGE)['stdout'].decode().strip()
            assert result['image'].startswith('sha256:')
            for case in (terminal, pipes, attachment, ordinary):
                try:
                    result['cases'][case.__name__] = case(engine)
                except Exception as error:
                    result['errors'][case.__name__] = repr(error)
        finally:
            result['owned_survivors_removed'] = engine.cleanup()
            result['remaining_owned'] = engine.owned()
    return result


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--socket', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
assert args.socket.is_absolute() and args.socket.is_socket() and not args.out.exists()
args.out.write_text(json.dumps(measure(args.socket), indent=2) + '\n')
