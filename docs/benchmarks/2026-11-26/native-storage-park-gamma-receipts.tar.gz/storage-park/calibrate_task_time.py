import ctypes as C
import json
import os
from pathlib import Path
import runpy
import time

here = Path(__file__).resolve().parent
snapshot = runpy.run_path(str(here / "sample_idle.py"))["snapshot"]

class Timebase(C.Structure):
    _fields_ = [("numer", C.c_uint32), ("denom", C.c_uint32)]

base = Timebase()
lib = C.CDLL("/usr/lib/libSystem.B.dylib")
assert lib.mach_timebase_info(C.byref(base)) == 0 and base.denom
start = snapshot(os.getpid())["cpu_ns"]
p0 = time.process_time_ns()
while time.process_time_ns() - p0 < 75_000_000:
    pass
p1 = time.process_time_ns()
end = snapshot(os.getpid())["cpu_ns"]
task_ns = (end - start) * base.numer // base.denom
assert abs(task_ns - (p1 - p0)) < 3_000_000
out = {"mach_timebase_numer": base.numer, "mach_timebase_denom": base.denom,
       "task_ticks": end - start, "calibrated_ns": task_ns, "process_time_ns": p1 - p0,
       "units": "The legacy snapshot field cpu_ns at task level stores absolute ticks. Per-thread cpu_ns stores nanoseconds."}
print(json.dumps(out, indent=2))
