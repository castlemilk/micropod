"""Read macOS libproc counters around successive quiet VMM intervals."""
import argparse
import ctypes as C
import json
import os
from pathlib import Path
import time

u64 = C.c_uint64
i32 = C.c_int32


class Task(C.Structure):
    _fields_ = [(name, u64) for name in (
        "virtual", "rss", "user_ns", "system_ns", "threads_user_ns", "threads_system_ns"
    )] + [(name, i32) for name in (
        "policy", "faults", "pageins", "cow_faults", "messages_sent", "messages_received",
        "mach_syscalls", "unix_syscalls", "context_switches", "threads", "running", "priority"
    )]


class Thread(C.Structure):
    _fields_ = [("user_ns", u64), ("system_ns", u64)] + [(name, i32) for name in (
        "usage", "policy", "run_state", "flags", "sleep_time", "curpri", "priority", "maxpriority"
    )] + [("name", C.c_char * 64)]


class RUsage(C.Structure):
    _fields_ = [("uuid", C.c_uint8 * 16)] + [(name, u64) for name in (
        "user_time", "system_time", "package_idle_wakeups", "interrupt_wakeups", "pageins",
        "wired_size", "resident_size", "footprint", "start_time", "exit_time"
    )]


lib = C.CDLL("/usr/lib/libproc.dylib", use_errno=True)
lib.proc_pidinfo.argtypes = [C.c_int, C.c_int, u64, C.c_void_p, C.c_int]
lib.proc_pid_rusage.argtypes = [C.c_int, C.c_int, C.c_void_p]


def info(pid, flavor, arg, buf):
    size = C.sizeof(buf)
    count = lib.proc_pidinfo(pid, flavor, arg, C.byref(buf), size)
    if count <= 0:
        raise OSError(C.get_errno(), "proc_pidinfo")
    return count


def snapshot(pid):
    task, ru = Task(), RUsage()
    if info(pid, 4, 0, task) != C.sizeof(task):
        raise RuntimeError("short proc_taskinfo")
    if lib.proc_pid_rusage(pid, 0, C.byref(ru)) != 0:
        raise OSError(C.get_errno(), "proc_pid_rusage")
    ids = (u64 * (task.threads + 64))()
    count = info(pid, 6, 0, ids)
    if count % 8 or count == C.sizeof(ids):
        raise RuntimeError("unusable thread enumeration")
    workers = []
    for tid in ids[:count // 8]:
        named = Thread()
        try:
            n = info(pid, 5, tid, named)
        except OSError as exc:
            if exc.errno == 3:  # thread exited during enumeration
                continue
            raise
        if n != C.sizeof(named):
            raise RuntimeError("short proc_threadinfo")
        name = named.name.decode("utf-8", "replace")
        if name.startswith(("vmm-fs-", "vmm-blk")):
            workers.append({"thread": tid, "name": name, "cpu_ns": named.user_ns + named.system_ns})
    return {"monotonic_ns": time.monotonic_ns(), "process_start": ru.start_time,
            "context_switches": task.context_switches, "mach_syscalls": task.mach_syscalls,
            "unix_syscalls": task.unix_syscalls, "cpu_ns": task.user_ns + task.system_ns,
            "interrupt_wakeups": ru.interrupt_wakeups, "package_idle_wakeups": ru.package_idle_wakeups,
            "storage_threads": workers}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("pid", type=int)
    parser.add_argument("output", type=Path)
    parser.add_argument("--seconds", type=float, default=8)
    parser.add_argument("--windows", type=int, default=3)
    args = parser.parse_args()
    records = [snapshot(args.pid)]
    for _ in range(args.windows):
        time.sleep(args.seconds)
        records.append(snapshot(args.pid))
    if len({s["process_start"] for s in records}) != 1:
        raise RuntimeError("VMM restarted")
    if any(not s["storage_threads"] for s in records):
        raise RuntimeError("no named storage workers")
    with args.output.open("x") as out:
        json.dump({"pid": args.pid, "host": os.uname().nodename, "snapshots": records}, out, indent=2)
        out.write("\n")


if __name__ == "__main__":
    main()
