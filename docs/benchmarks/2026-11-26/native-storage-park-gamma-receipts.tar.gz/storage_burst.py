"""Check first real VirtioFS and block I/O after idle without mutating shared engines."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
from uuid import uuid4

RECEIPTS = Path(__file__).resolve().parent
MOUNT = Path('/pulse')
INPUT_BYTES = 32768
BLOCK_BYTES = 2 * 1024 * 1024


def sha(data):
    return hashlib.sha256(data).hexdigest()


def payload(ordinal, length):
    block = hashlib.sha256(f'Gamma storage pulse {ordinal}'.encode()).digest()
    return (block * (length // len(block) + 1))[:length]


def block_stats():
    for row in Path('/proc/diskstats').read_text().splitlines():
        _, _, device, *fields = row.split()
        if device == 'vda':
            values = list(map(int, fields))
            result = {'reads': values[0], 'read_sectors': values[2], 'writes': values[4], 'written_sectors': values[6]}
            if len(values) >= 16:
                result['flushes'] = values[15]
            return result
    raise RuntimeError('virtio block vda is absent')


def guest(ordinal):
    indexed = MOUNT / 'input.bin'
    got = sha(indexed.read_bytes())
    assert got == sha(payload(ordinal, INPUT_BYTES))
    started = time.monotonic_ns()
    before = block_stats()
    data = payload(ordinal, BLOCK_BYTES)
    with tempfile.TemporaryDirectory(prefix='gamma-block-pulse-') as directory:
        target = Path(directory) / 'guest-overlay.bin'
        with target.open('w+b') as file:
            file.write(data)
            file.flush()
            os.fdatasync(file.fileno())
            if hasattr(os, 'posix_fadvise'):
                os.posix_fadvise(file.fileno(), 0, len(data), os.POSIX_FADV_DONTNEED)
            file.seek(0)
            observed = sha(file.read())
            assert observed == sha(data)
        after = block_stats()
    guest_file = MOUNT / 'guest-out.pending'
    expected_guest_output = payload(ordinal + 100, INPUT_BYTES)
    with guest_file.open('wb') as file:
        file.write(expected_guest_output)
        file.flush()
        os.fsync(file.fileno())
    guest_file.replace(MOUNT / 'guest-out.bin')
    delta = {key: after[key] - before[key] for key in before}
    assert delta['written_sectors'] >= BLOCK_BYTES // 512, delta
    return {'input_sha256': got, 'guest_output_sha256': sha(expected_guest_output), 'block_sha256': observed,
            'guest_elapsed_ns': time.monotonic_ns() - started, 'block_stat_delta': delta}


def qualify(arm):
    ready = json.loads((RECEIPTS / f'{arm}-ready.json').read_bytes())
    socket, workspace = Path(ready['socket']), Path(ready['workspace'])
    assert socket.is_socket() and workspace.is_dir()
    environment = {key: value for key, value in os.environ.items() if not key.startswith('DOCKER_')}
    docker = ['/opt/homebrew/bin/docker', '--host', f'unix://{socket}']
    scope = 'mpg3-storage-' + uuid4().hex[:12]
    label = f'io.micropod.gamma3.storage={scope}'
    report = {'arm': arm, 'scope': scope, 'artifacts': ready['owned_artifacts'], 'pulses': [], 'passed': False}

    def call(*argv, check=True):
        return subprocess.run([*docker, *argv], text=True, capture_output=True, check=check, timeout=18, env=environment)

    assert not call('ps', '-aq', '--filter', f'label={label}').stdout.strip()
    with tempfile.TemporaryDirectory(prefix='storage-pulse-', dir=workspace) as scratch:
        directory = Path(scratch)
        shutil.copy2(__file__, directory / 'driver.py')
        result = call('run', '-d', '--pull=never', '--network=none', '--name', scope, '--label', label,
                      '--memory', '128m', '--cpus', '0.5', '--mount', f'type=bind,src={directory},dst={MOUNT}',
                      '--entrypoint', '/bin/sh', ready['benchmark_image'], '-ec', 'exec sleep 180')
        container = result.stdout.strip()
        report['container'] = container
        try:
            for ordinal, wait in enumerate((5, 0.075, 0.100, 0.200, 0.350, 0.050, 0.125, 0.250)):
                pending = directory / 'input.pending'
                pending.write_bytes(payload(ordinal, INPUT_BYTES))
                pending.replace(directory / 'input.bin')
                time.sleep(wait)
                started = time.monotonic_ns()
                result = call('exec', container, 'python3', str(MOUNT / 'driver.py'), '--guest', str(ordinal), check=False)
                elapsed = time.monotonic_ns() - started
                assert result.returncode == 0, (result.returncode, result.stdout, result.stderr)
                row = json.loads(result.stdout)
                assert row['input_sha256'] == sha(payload(ordinal, INPUT_BYTES))
                assert row['guest_output_sha256'] == sha((directory / 'guest-out.bin').read_bytes())
                assert row['block_sha256'] == sha(payload(ordinal, BLOCK_BYTES))
                report['pulses'].append({'ordinal': ordinal, 'nominal_quiet_s': wait, 'host_exec_elapsed_ns': elapsed, **row})
            call('stop', '--time', '2', container)
            report['wait'] = call('wait', container).stdout.strip()
            report['state'] = json.loads(call('inspect', '--format', '{{json .State}}', container).stdout)
            assert report['state']['Status'] == 'exited' and not report['state']['OOMKilled']
            report['passed'] = True
        except Exception as error:
            report['error'] = repr(error)
            raise
        finally:
            removal = call('container', 'rm', '--force', container, check=False)
            report['removal'] = {'exit': removal.returncode, 'stdout': removal.stdout, 'stderr': removal.stderr}
            report['remaining'] = call('ps', '-aq', '--filter', f'label={label}').stdout.splitlines()
            path = RECEIPTS / 'storage-park' / f'{arm}-bursts.json'
            path.write_text(json.dumps(report, indent=2) + '\n')
    assert not report['remaining'] and report['removal']['exit'] == 0


if __name__ == '__main__':
    if sys.argv[1:2] == ['--guest']:
        print(json.dumps(guest(int(sys.argv[2]))))
    else:
        parser = argparse.ArgumentParser(description=__doc__)
        parser.add_argument('arm')
        qualify(parser.parse_args().arm)
