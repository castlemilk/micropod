"""Reduce matched native checkout and idle process measurements while preserving each raw arm."""
from collections import Counter
import hashlib
import json
from pathlib import Path
from statistics import median

receipts = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_bytes())


def receipt(path):
    with path.open('rb') as content:
        digest = hashlib.file_digest(content, 'sha256').hexdigest()
    return {'path': path.relative_to(receipts).as_posix(), 'sha256': digest}


def load(path):
    rows = [json.loads(line) for line in path.read_bytes().splitlines()]
    samples = [row for row in rows if row.get('cpu_idle_pct') is not None]
    ticks = Counter()
    for sample in samples:
        ticks.update(sample['delta_ticks'])
    idle = [sample['cpu_idle_pct'] for sample in samples]
    result = {'receipt': receipt(path), 'samples': len(samples), 'command_exit': rows[-1]['code'],
              'first_utc': rows[0]['utc'], 'last_utc': rows[-2]['utc']}
    if samples:
        result.update(weighted_cpu_idle_pct=100 * ticks['idle'] / ticks.total(),
                      idle_pct_min_median_max=[min(idle), median(idle), max(idle)],
                      load_avg_1m_min_max=[min(row['load_average'][0] for row in samples),
                                          max(row['load_average'][0] for row in samples)])
    return result


def milliseconds(ns):
    return ns / 1e6 if ns is not None else None


def material(path, result):
    records = {'receipt': receipt(path), 'source': result['source'], 'git_commit': result['git_commit'], 'image': result['image'],
               'pairs': len(result['pairs']), 'cpus': result['cpus'], 'memory_mib': result['memory_mib'],
               'timing_scopes': result['timing_scopes'], 'load': load(path.with_name(path.stem + '-host-load.jsonl')),
               'cold_prime': {engine: {'guest_sum_ms': milliseconds(row['sum_ns']),
                                      'phase_ms': {key: milliseconds(value) for key, value in row['phase_ns'].items()},
                                      'stock_docker_transport': row['stock_docker_transport']}
                              for engine, row in result['prime'].items()}, 'rounds': {}}
    for phase in ('warm', 'incremental'):
        paired = [pair[phase] for pair in result['pairs']]
        by_engine = {}
        for engine in ('hvf', 'orbstack'):
            rows = [pair[engine] for pair in paired]
            by_engine[engine] = {'guest_sum_median_ms': result['median_ms'][phase][engine],
                               'guest_phase_medians_ms': {key: milliseconds(median(row['phase_ns'][key] for row in rows))
                                                         for key in rows[0]['phase_ns']},
                               'edit_return_to_matching_ms': result['edit_return_to_correct_median_ms'][phase][engine],
                               'edit_through_verified_build_ms': result['edit_to_completed_build_median_ms'][phase][engine],
                               'all_first_byte_reads_match': all(row['visibility']['observations'][0]['sha256'] ==
                                                                 row['visibility']['expected_sha256'] for row in rows)}
        records['rounds'][phase] = {'engines': by_engine,
                                    'hvf_wins': sum(row['hvf']['sum_ns'] < row['orbstack']['sum_ns'] for row in paired),
                                    'median_hvf_to_orbstack_ratio': median(row['hvf']['sum_ns'] / row['orbstack']['sum_ns'] for row in paired)}
    return records


def idle(path):
    rows = read(path)['snapshots']
    fields = ('context_switches', 'mach_syscalls', 'unix_syscalls', 'cpu_ns', 'interrupt_wakeups', 'package_idle_wakeups')
    calibration = read(receipts / 'storage-park/mach-timebase.json')
    task_ticks_to_ns = calibration['mach_timebase_numer'] / calibration['mach_timebase_denom']
    windows = []
    for first, second in zip(rows, rows[1:]):
        dt = (second['monotonic_ns'] - first['monotonic_ns']) / 1e9
        starts = {(row['thread'], row['name']): row['cpu_ns'] for row in first['storage_threads']}
        finishes = {(row['thread'], row['name']): row['cpu_ns'] for row in second['storage_threads']}
        assert starts.keys() == finishes.keys(), path
        thread_rates = {name: (finishes[tid, name] - cpu) / dt for (tid, name), cpu in starts.items()}
        window = {field: (second[field] - first[field]) / dt for field in fields}
        window['cpu_ns'] *= task_ticks_to_ns
        windows.append({'seconds': dt, 'process_per_second': window, 'thread_cpu_ns_per_second': thread_rates})
    tag = path.stem
    return {'receipt': receipt(path), 'scope': read(path.with_name(tag + '-scope.json')),
            'task_cpu_unit_calibration': receipt(receipts / 'storage-park/mach-timebase.json'),
            'xnu_task_and_thread_counter_source': 'https://github.com/apple-oss-distributions/xnu/blob/main/osfmk/kern/bsd_kern.c#L1055-L1099',
            'load': load(path.with_name(tag + '-host-load.jsonl')), 'windows': windows,
            'process_rate_medians': {field: median(row['process_per_second'][field] for row in windows) for field in fields},
            'total_storage_worker_cpu_ns_per_second_median': median(sum(row['thread_cpu_ns_per_second'].values()) for row in windows)}


def outcomes(glob_pattern, *, include_path=False):
    return {(path.relative_to(receipts).as_posix() if include_path else path.stem): {'receipt': receipt(path), 'data': read(path)}
            for path in sorted(receipts.glob(glob_pattern)) if path.stat().st_size}


def main():
    idle_measurements = {path.stem.removesuffix('-idle'): idle(path) for path in sorted(receipts.glob('storage-park/*-idle.json'))}
    materials = {}
    for path in sorted(receipts.glob('*-material.json')):
        if path.stat().st_size and (data := read(path)).get('workspace_mode') == 'independent byte-identical raw host checkouts':
            materials[path.stem.removesuffix('-material')] = material(path, data)
    workers = {path.stem.removesuffix('-ready'): {'receipt': receipt(path), 'artifacts': read(path)['owned_artifacts']}
               for path in sorted(receipts.glob('*-ready.json')) if path.stat().st_size}
    image_evidence = {}
    for pattern in ('image-history*.json', 'docker-image-*.json', 'image-tag*.json', 'image-*/**/*.json',
                    'docker-engine-api-*.json'):
        image_evidence.update(outcomes(pattern, include_path=True))
    result = {'host': 'Gamma-128GB.local', 'date_melbourne': '2026-11-26', 'lineage': read(receipts / 'baseline-lineage.json'),
              'november24_preservation': outcomes('november24-baseline-rechecked.json'),
              'image': read(receipts / 'image.json'), 'workers': workers, 'material': materials, 'idle': idle_measurements,
              'ordinary_edit_checks': outcomes('*-edits.json'),
              'storage_bursts': outcomes('storage-park/*-bursts.json'), 'strict_held_and_splice': outcomes('*-guest-splice.json'),
              'git_diagnostics': outcomes('git-*.json'),
              'git_diagnostic_load': {path.stem: load(path) for path in sorted(receipts.glob('git-*-host-load.jsonl')) if path.stat().st_size},
              'historical_dispatch': {**outcomes('historical/*ftrace.json'), **outcomes('historical/*dispatch-detail.json')},
              'stock_pid1': outcomes('*-stock-pid1.json'),
              'image_compatibility': image_evidence}
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
