#!/usr/bin/env python3
"""Report paired Git+Go and dirty-only results from the isolated opt-in run."""

import argparse
import json
from pathlib import Path
import statistics


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("prefix")
prefix = parser.parse_args().prefix


def receipt(kind, suffix=".json"):
    return Path(prefix + "-" + kind + suffix)


def load_monitor(kind):
    return [json.loads(line) for line in receipt(kind, ".jsonl").read_text().splitlines()]


def collect_ticks(events):
    intervals = [event["delta_ticks"] for event in events if "delta_ticks" in event]
    return 100 * sum(row["idle"] for row in intervals) / sum(sum(row.values()) for row in intervals)


def pair_deltas(material, phase, engine, key):
    return [(block["results"][phase][engine + "/stock"][key] - block["results"][phase][engine + "/helper"][key]) / 1e6
            for block in material["pairs"]]


def interval_values(events):
    return [row["cpu_idle_pct"] for row in events if row["edge"] == "running"]


material = json.loads(receipt("material").read_text())
dirty = json.loads(receipt("dirty").read_text())
assert material["passed"] and dirty["passed"] and len(material["pairs"]) == 4
pre = interval_values(load_monitor("pre-idle"))
post = interval_values(load_monitor("post-idle"))
idle_gate = any(a >= 90 and b >= 90 for a, b in zip(pre, pre[1:]))
summary = {
    "passed": True,
    "load_class": "quiet" if idle_gate else "ambient",
    "pre_idle_pct": pre,
    "post_idle_pct": post,
    "material_host_idle_pct": collect_ticks(load_monitor("material-host-load")),
    "dirty_host_idle_pct": collect_ticks(load_monitor("dirty-host-load")),
    "medians_ms": material["medians_ms"],
    "cold_first_jobs_ms": {name: row["first_total_with_staging_ns"] / 1e6 for name, row in material["primes"].items()},
    "pairs": {},
    "dirty_git": {},
}
for phase in ("warm", "incremental"):
    summary["pairs"][phase] = {}
    for engine in ("hvf", "orbstack"):
        summary["pairs"][phase][engine] = {
            key: {"count": len(deltas), "helper_wins": sum(value > 0 for value in deltas), "median_saving_ms": statistics.median(deltas)}
            for key in ("sum_ns", "host_total_ns") if (deltas := pair_deltas(material, phase, engine, key))
        }
for engine, side in dirty["engines"].items():
    data = side["dirty"]
    gain = -data["clean"]["paired_penalty_ms"]
    summary["dirty_git"][engine] = {}
    for label, row in data.items():
        penalty = row["paired_penalty_ms"]
        summary["dirty_git"][engine][label] = {
            "pair_count": len(row["pairs"]), "median_ms": row["median_ms"], "paired_penalty_ms": penalty,
            "illustrative_clean_share_break_even_pct": (100 * penalty / (gain + penalty)
                                                          if gain > 0 and penalty > 0 else None),
        }
with receipt("summary").open("x") as out:
    json.dump(summary, out, indent=2)
    out.write("\n")
