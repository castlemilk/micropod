"""Record native macOS aggregate CPU deltas while a scoped workload runs."""
import argparse
import ctypes
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import threading
import time

lib = ctypes.CDLL('/usr/lib/libSystem.B.dylib')
tick_type = ctypes.c_uint32 * 4
lib.mach_host_self.restype = ctypes.c_uint32
lib.host_statistics.argtypes = (ctypes.c_uint32, ctypes.c_int, ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_uint32))
lib.host_statistics.restype = ctypes.c_int
host = lib.mach_host_self()


def ticks():
    values, count = tick_type(), ctypes.c_uint32(4)
    assert lib.host_statistics(host, 3, values, ctypes.byref(count)) == 0 and count.value == 4
    return tuple(values)


def read_sample(edge, before=None):
    now = ticks()
    sample = dict(edge=edge, utc=datetime.now(timezone.utc).isoformat(), monotonic_ns=time.monotonic_ns(),
                  ticks=dict(zip(('user', 'system', 'idle', 'nice'), now)), load_average=os.getloadavg())
    if before is not None:
        delta = [(current - previous) & 0xffffffff for previous, current in zip(before, now)]
        sample['cpu_idle_pct'] = delta[2] * 100 / sum(delta) if sum(delta) else None
        sample['delta_ticks'] = dict(zip(('user', 'system', 'idle', 'nice'), delta))
    return now, sample


def interrupted(sig, _frame):
    raise InterruptedError(f'sample owner received signal {sig}')


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--interval', type=float, default=1.0)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
assert args.command[0] == '--' and args.interval > 0.0
signal.signal(signal.SIGTERM, interrupted)
stop = threading.Event()
with args.out.open('x', buffering=1) as sink:
    def emit(sample):
        sink.write(json.dumps(sample) + '\n')
    start, event = read_sample('before_work')
    emit(event)
    def sample_while_running():
        before = start
        while not stop.wait(args.interval):
            before, next_event = read_sample('running', before)
            emit(next_event)
        _, done_event = read_sample('after_work', before)
        emit(done_event)
    monitor = threading.Thread(target=sample_while_running, name='Gamma host load')
    monitor.start()
    try:
        with subprocess.Popen(args.command[1:], start_new_session=True) as child:
            try:
                code = child.wait()
            except BaseException:
                try:
                    os.killpg(child.pid, signal.SIGTERM)
                    child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait(timeout=5)
                raise
    finally:
        stop.set()
        monitor.join(timeout=5)
    assert not monitor.is_alive()
    emit({'edge': 'command_exit', 'code': code, 'monotonic_ns': time.monotonic_ns()})
raise SystemExit(code)
