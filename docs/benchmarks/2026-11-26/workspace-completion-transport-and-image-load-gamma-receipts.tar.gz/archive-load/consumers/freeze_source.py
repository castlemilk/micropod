#!/usr/bin/env python3
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import tempfile


BASE_RUNNER = '5004945fa3eae40fc5be5a81c96b44097427191b260368e14601f1f8f09ad1dd'
FILES = (
    'docker_http_linux.go',
    'docker_image_delete_linux.go',
    'docker_image_digest_delete_linux.go',
    'docker_image_digest_delete_linux_test.go',
    'docker_image_export_linux.go',
    'docker_image_export_linux_test.go',
    'docker_image_history_linux_test.go',
    'docker_image_id_delete_linux.go',
    'docker_image_transfer_linux.go',
    'go.mod',
    'go.sum',
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_archive(archive):
    sources = {}
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
        for entry in tar:
            path = PurePosixPath(entry.name)
            if (not entry.isfile() or path.parts[:-1] != ('guest', 'runner')
                    or entry.name in sources):
                raise RuntimeError(f'unexpected source entry: {entry.name}')
            sources[entry.name] = tar.extractfile(entry).read()
    return sources


def populate(directory, sources):
    directory.mkdir()
    (directory / 'guest' / 'runner').mkdir(parents=True)
    for name, data in sources.items():
        (directory / name).write_bytes(data)


def main():
    parser = argparse.ArgumentParser()
    for field in ('worktree', 'base_receipts', 'stage', 'receipts'):
        parser.add_argument(field, type=Path)
    opt = parser.parse_args()
    previous = json.loads((opt.base_receipts / 'build.json').read_bytes())
    payload = (opt.base_receipts / 'source.tar.gz').read_bytes()
    assert previous['job_sha256'] == BASE_RUNNER
    assert sha(payload) == previous['source_archive_sha256']
    baseline = read_archive(payload)
    assert {name: sha(data) for name, data in baseline.items()} == previous['source_files']
    delta = {f'guest/runner/{name}': (opt.worktree / 'guest' / 'runner' / name).read_bytes() for name in FILES}
    # Healthcheck work can edit other HTTP branches in parallel. Take only
    # these two owned export dispatch lines from the shared worktree.
    http = 'guest/runner/docker_http_linux.go'
    for call in (b'q["names"]', b'[]string{strings.TrimSuffix(path, "/get")}'):
        original = b'return exportImages(w, r, ' + call + b')'
        replacement = b'return s.exportImages(w, r, ' + call + b')'
        assert baseline[http].count(original) == 1 and replacement in delta[http]
    delta[http] = baseline[http].replace(b'return exportImages(w, r, ', b'return s.exportImages(w, r, ')
    assert all(baseline.get(name) != data for name, data in delta.items())
    expected = baseline | delta
    with tempfile.TemporaryDirectory(dir=opt.stage, prefix='source-compare-') as scratch:
        root = Path(scratch)
        populate(root / 'previous', baseline)
        populate(root / 'current', expected)
        diff = subprocess.run(['git', 'diff', '--no-index', '--binary', 'previous/guest', 'current/guest'],
                              cwd=root, capture_output=True, check=False)
        if diff.returncode != 1:
            raise RuntimeError(diff.stderr.decode())
        patch = diff.stdout.replace(b'a/previous/guest/', b'a/guest/').replace(b'a/current/guest/', b'a/guest/').replace(b'b/current/guest/', b'b/guest/')
        (opt.receipts / 'source.patch').write_bytes(patch)
        source = opt.stage / 'source'
        populate(source, baseline)
        cmd = ['git', 'apply', '--whitespace=error-all']
        subprocess.run(cmd + ['--check'], cwd=source, input=patch, check=True)
        subprocess.run(cmd, cwd=source, input=patch, check=True)
        assert all((source / name).read_bytes() == data for name, data in expected.items())
    result = opt.receipts / 'source.tar.gz'
    with tarfile.open(result, 'w:gz') as tar:
        for name in sorted(expected):
            item = tarfile.TarInfo(name)
            item.size = len(expected[name])
            tar.addfile(item, io.BytesIO(expected[name]))
    assert read_archive(result.read_bytes()) == expected
    manifest = {
        'base_runner_sha256': BASE_RUNNER,
        'base_source_archive_sha256': sha(payload),
        'source_files': {name: sha(data) for name, data in sorted(expected.items())},
        'changed': {name: {'base_sha256': sha(baseline[name]) if name in baseline else None, 'sha256': sha(data)} for name, data in sorted(delta.items())},
        'source_archive_sha256': sha(result.read_bytes()),
        'patch_sha256': sha(patch),
        'patch_replay_all_sources_verified': True,
        'toolchain': 'go1.27.2', 'GOOS': 'linux', 'GOARCH': 'arm64', 'CGO_ENABLED': 0,
        'flags': ['-mod=readonly', '-trimpath', '-p=2'],
    }
    (opt.receipts / 'source.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(f'{len(expected)} inputs; {len(delta)} changed; source {manifest["source_archive_sha256"]}; patch {manifest["patch_sha256"]}')


if __name__ == '__main__':
    main()
