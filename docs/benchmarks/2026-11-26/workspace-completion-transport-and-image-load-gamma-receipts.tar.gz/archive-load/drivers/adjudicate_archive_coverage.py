#!/usr/bin/env python3
"""Confirm raw Docker archive coverage, retained bytes and pinned group counts."""
import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path

from qualify_docker_image_history import familiar


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def data(path):
    return json.loads(path.read_bytes())


def scope_ok(row):
    return (row['passed'] and set(row['cleanup'].values()) == {404} and row['remaining_scoped_list_rows'] == []
            and row['baseline_ids_preserved'] and row['owned_ids_absent_from_inventory'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ('ready', 'coverage_directory', 'retention_native', 'retention_stock', 'consumers_native', 'consumers_stock', 'output'):
        parser.add_argument(option, type=Path)
    opt = parser.parse_args()
    runner = data(opt.ready)['owned_artifacts']['job']['sha256']
    api = opt.coverage_directory / 'docker-api-v1.47.json.gz'
    result = json.loads(gzip.decompress(api.read_bytes()))
    coverage_summary = data(opt.coverage_directory / 'summary.json')
    assert coverage_summary['job_sha256'] == runner and coverage_summary['exits']['cleanup'] == 0
    assert result['candidate']['image-list-labels']['comparison'] == 'matched'
    covered = {key for key, value in result['operations'].items() if value.get('cases')}
    prior = {'ImageCreate', 'ImagePush', 'SystemAuth', 'Session'}
    routes = {'images-digest-get': 'ImageGet', 'images-get': 'ImageGetAll', 'images-load': 'ImageLoad'}
    assert len(covered) == 39 and len(result['operations']) == 107
    assert not covered.intersection(prior | set(routes.values())) and not prior.intersection(routes.values())
    exercised = covered | prior | set(routes.values())
    assert exercised <= result['operations'].keys()
    retention = {'native': opt.retention_native, 'stock': opt.retention_stock}
    checks = {side: data(path) for side, path in retention.items()}
    proofs = {}
    for side, trace in checks.items():
        assert scope_ok(trace) and trace['identical_marker_twice'] == checks['stock']['identical_marker_twice']
        assert [trace['wire'][key]['status'] for key in ('running-plain', 'running-force', 'stopped-plain', 'stopped-force')] == [409, 409, 409, 200]
        for key, operation in routes.items():
            row = trace['wire'][key]
            assert row['status'] == 200
            assert row['method'] == result['operations'][operation]['method']
            if key != 'images-load':
                body = retention[side].with_name(row['body_file'])
                assert row['sha256'] == 'sha256:' + sha(body) and body.stat().st_size == row['bytes']
                assert all(row['archive'][k] for k in ('target_matches', 'config_matches', 'diff_ids_match')) and not row['archive']['repo_tags']
                assert row['archive'] == checks['stock']['wire'][key]['archive']
            proofs.setdefault(operation, {})[side] = {k: row[k] for k in ('method', 'path', 'status', 'headers', 'body_file', 'bytes', 'sha256', 'request_sha256') if k in row}
    stock, native = data(opt.consumers_stock), data(opt.consumers_native)
    assert scope_ok(stock) and scope_ok(native)
    assert stock['save']['archive'] == native['save']['archive'] and stock['save']['exit'] == native['save']['exit'] == 0
    left, right = stock['same_repo_rmi'], native['same_repo_rmi']
    assert {familiar(ref): status for ref, status in left['after'].items()} == {familiar(ref): status for ref, status in right['after'].items()}
    assert left['exit'] == right['exit'] == 0 and left['stdout'].splitlines() == right['stdout'].splitlines()
    assert stock['last_repo_rmi']['exit'] == native['last_repo_rmi']['exit'] == 0
    assert set(stock['last_repo_rmi']['after'].values()) == set(native['last_repo_rmi']['after'].values()) == {404}
    assert stock['wrong_rmi']['status'] == native['wrong_rmi']['status'] == 404
    assert stock['wrong_save']['exit'] == native['wrong_save']['exit'] == 1
    files = [api, opt.coverage_directory/'summary.json', opt.coverage_directory/'cleanup.json', *retention.values(), opt.consumers_stock, opt.consumers_native]
    relative = Path(__file__).resolve().parent.parent
    report = {'job_sha256': runner, 'ready_sha256': sha(opt.ready), 'strict': dict(Counter(case['comparison'] for case in result['candidate'].values())),
              'groups': len(result['candidate']), 'operation_denominator': len(result['operations']), 'pinned_operations': sorted(covered),
              'prior_outside_pinned_profile': sorted(prior), 'new_operation_successes': proofs, 'union_operations_exercised': sorted(exercised),
              'count_operations_exercised': len(exercised), 'same_repository_untag_scope_matches_stock': True,
              'stopped_force_retained_config_native_status': checks['native']['wire']['config-after-forced-stopped-untag']['status'],
              'stopped_force_retained_config_orb_status': checks['stock']['wire']['config-after-forced-stopped-untag']['status'],
              'both_restart_exact_bytes': True, 'active_save_survived_retag_and_confirmed_old_id_absent': True, 'all_scopes_cleanup_verified': True,
              'receipts_sha256': {str(path.relative_to(relative)): sha(path) for path in files}}
    opt.output.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')


if __name__ == '__main__':
    main()
