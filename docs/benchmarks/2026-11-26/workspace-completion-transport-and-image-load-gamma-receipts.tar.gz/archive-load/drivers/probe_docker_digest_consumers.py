#!/usr/bin/env python3
"""Observe stock Docker save/rmi for owned named repository digests."""
import argparse
import gzip
import json
from pathlib import Path
import tarfile
from tempfile import TemporaryDirectory
from urllib.parse import quote

from qualify_docker_archive_load import Probe, ROLES, require
from qualify_docker_image_history import digest
from qualify_engine_api import Engine


def command(engine, *args):
    result = engine.cli(*args, timeout=40)
    return {'exit': result.returncode, 'stdout': result.stdout.decode(errors='replace'),
            'stderr': result.stderr.decode(errors='replace')}


def check_save(path, fixture, target):
    with tarfile.open(path) as archive:
        rows = json.load(archive.extractfile('manifest.json'))
        row, = rows
        config_id = digest(archive.extractfile(row['Config']).read())
        diff_ids = []
        for filename in row['Layers']:
            data = archive.extractfile(filename).read()
            diff_ids.append(digest(gzip.decompress(data) if data.startswith(b'\x1f\x8b') else data))
        index = json.load(archive.extractfile('index.json'))
        root, = index['manifests']
        blob = archive.extractfile('blobs/sha256/' + target.removeprefix('sha256:')).read()
        return {'config': config_id, 'config_matches': config_id == fixture['config_id'], 'diff_ids': diff_ids,
                'diff_ids_match': diff_ids == fixture['diff_ids'], 'repo_tags': row.get('RepoTags'),
                'target_matches': root['digest'] == target == digest(blob), 'root_annotations': root.get('annotations')}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--socket', type=Path, required=True)
    p.add_argument('--fixture', type=Path, required=True)
    p.add_argument('--image', required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--native', action='store_true')
    opt = p.parse_args()
    require(opt.socket.is_socket() and not opt.output.exists(), 'Use an explicit socket with fresh output path')
    fixture = json.loads((opt.fixture / 'manifest.json').read_bytes())
    named = (opt.fixture / 'named.tar').read_bytes()
    require(digest(named) == fixture['archives']['named'], 'Fixture archive hash mismatch')
    report = {'schema': 'micropod-digest-consumers-v1', 'run': fixture['run'], 'endpoint': str(opt.socket),
              'native': opt.native, 'cli': [], 'wire': {}, 'owned_ids': {}, 'named_digests': {}, 'cleanup': {}, 'passed': False}
    with TemporaryDirectory(prefix='digest-consumers-', dir=opt.output.parent) as temporary:
        directory = Path(temporary)
        (directory / 'config.json').write_text('{"auths":{"fixture.invalid":{}}}')
        engine = Engine(opt.socket, opt.image, None, None, api_version='1.47')
        engine.env['DOCKER_CONFIG'] = str(directory)
        engine.env.pop('DOCKER_CUSTOM_HEADERS', None)
        probe = Probe(engine, fixture, opt.image, opt.native, report)
        orig, next_ref = (fixture['images'][role]['tag'] for role in ROLES[:2])
        extra = (fixture['repository'] + ':same-target', fixture['repository'] + '-other:keep')
        try:
            report['before_ids'] = sorted({row['Id'] for row in probe.inventory()})
            report['baselines_before'] = probe.bases()
            require(not probe.inventory(scoped=True), 'Fixture label already in use')
            require(all(probe.inspect(ref)[0] == 404 for ref in (orig, next_ref, *extra)), 'Fixture tags already in use')
            report['started'] = True
            probe.cli('image', 'load', '--quiet', data=named)
            for role, ref in zip(ROLES, (orig, next_ref)):
                _, row = probe.inspect(ref, record='tag-' + role)
                probe.check(role, row)
                report['named_digests'][role] = probe.named_digest(row)
            original = report['named_digests']['original']
            target = original.partition('@')[2]
            out = directory / 'digest-export.tar'
            report['save'] = command(engine, 'image', 'save', '--output', str(out), original)
            if report['save']['exit'] == 0:
                report['save']['archive'] = check_save(out, fixture['images']['original'], target)
            wrong = fixture['repository'] + '-missing@' + target
            report['wrong_save'] = command(engine, 'image', 'save', '--output', str(directory / 'wrong.tar'), wrong)
            http, _, data = engine.request('DELETE', '/images/' + quote(wrong, safe=':/') + '?noprune=1')
            report['wrong_rmi'] = {'status': http, 'body': json.loads(data)}
            for ref in extra:
                probe.cli('image', 'tag', orig, ref)
                require(probe.inspect(ref)[1]['Id'] == report['owned_ids']['original'], 'Stock tag did not preserve source ID')
            report['same_repo_rmi'] = command(engine, 'image', 'rm', '--no-prune', original)
            report['same_repo_rmi']['after'] = {ref: probe.inspect(ref)[0] for ref in (orig, *extra, original, next_ref)}
            other_digest = report['named_digests']['replacement']
            report['last_repo_rmi'] = command(engine, 'image', 'rm', '--no-prune', other_digest)
            report['last_repo_rmi']['after'] = {ref: probe.inspect(ref)[0] for ref in (next_ref, other_digest, report['owned_ids']['replacement'])}
            report['passed'] = True
        except Exception as exc:
            report['error'] = str(exc)
        finally:
            try:
                if report.get('started'):
                    for ref in extra:
                        code, row = probe.inspect(ref)
                        if code == 200:
                            probe.check('original', row)
                            probe.cli('image', 'rm', '--no-prune', ref)
                        report['cleanup'][ref] = probe.inspect(ref)[0]
                    probe.cleanup()
            except Exception as exc:
                report.update(passed=False, cleanup_error=str(exc))
            opt.output.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    return int(not report['passed'])


if __name__ == '__main__':
    raise SystemExit(main())
