#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from qualify_engine_api import Engine


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--socket', type=Path, required=True)
    parser.add_argument('--image', required=True)
    parser.add_argument('--out', type=Path, required=True)
    opt = parser.parse_args()
    assert opt.socket.is_socket() and not opt.out.exists()
    engine = Engine(opt.socket, opt.image, None, None, api_version='1.47')
    history = {}
    for name in (opt.image, 'alpine:3.23', 'registry.k8s.io/pause:3.10'):
        code, row = engine.inspect_image(name)
        history[name] = {'status': code, 'id': row.get('Id'), 'repo_tags': row.get('RepoTags'), 'repo_digests': row.get('RepoDigests')}
        for digest in row.get('RepoDigests') or []:
            status, digest_row = engine.inspect_image(digest)
            history[name].setdefault('lookup', {})[digest] = {'status': status, 'id': digest_row.get('Id')}
    with TemporaryDirectory(prefix='label-filter-config-', dir=opt.out.parent) as scratch:
        (Path(scratch) / 'config.json').write_text('{"auths":{"fixture.invalid":{}}}')
        engine.env['DOCKER_CONFIG'] = scratch
        engine.env.pop('DOCKER_CUSTOM_HEADERS', None)
        result = engine.image_list_labels()
    opt.out.write_text(json.dumps({'fixture': engine.name, 'version': '1.47', 'history': history, 'labels': result}, indent=2, sort_keys=True) + '\n')


if __name__ == '__main__':
    main()
