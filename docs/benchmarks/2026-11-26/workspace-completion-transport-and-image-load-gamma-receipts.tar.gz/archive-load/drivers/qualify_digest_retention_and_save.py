#!/usr/bin/env python3
"""Qualify concurrent image save and running/stopped Docker digest removal."""
import argparse
import gzip
import json
from pathlib import Path
import tarfile
from tempfile import TemporaryDirectory
import time
from urllib.parse import quote, urlencode

from probe_docker_digest_consumers import check_save, command
from qualify_docker_archive_load import MARKER, Probe, ROLES, require
from qualify_docker_image_history import digest, familiar
from qualify_engine_api import Engine, UnixHTTP


def remove_digest(probe, ref, force, key):
    query = urlencode({'noprune': 1, 'force': int(force)})
    code, _, data = probe.engine.request('DELETE', '/images/' + quote(ref, safe=':/') + '?' + query)
    probe.report['wire'][key] = {'status': code, 'body': json.loads(data)}
    return code


def archive_receipt(probe, output, name, path, headers, status, payload, role, target):
    receipt = {'method': 'GET', 'path': probe.engine.prefix + path, 'status': status, 'headers': headers,
               'bytes': len(payload), 'sha256': digest(payload)}
    probe.report['wire'][name] = receipt
    if status != 200:
        receipt['body'] = payload.decode(errors='replace')
    require(status == 200, 'Image save returned ' + str(status))
    archive_path = output.with_name(output.stem + '-' + name + '.tar')
    require(not archive_path.exists(), 'Image save receipt would overwrite earlier evidence')
    archive_path.write_bytes(payload)
    archive = check_save(archive_path, role, target)
    receipt.update(body_file=archive_path.name, archive=archive)
    require(all(archive[k] for k in ('config_matches', 'diff_ids_match', 'target_matches'))
            and not archive['repo_tags'], 'Digest export changed the selected immutable bytes or added a tag')


def verify_mixed_save(probe, directory, digest_ref, next_ref):
    path = directory / 'mixed-save.tar'
    outcome = command(probe.engine, 'image', 'save', '--output', str(path), digest_ref, next_ref)
    probe.report['mixed_save'] = outcome
    require(outcome['exit'] == 0, 'Stock mixed image save failed: ' + outcome['stderr'])
    by_id = {probe.images[role]['config_id']: (role, [next_ref] if role == 'replacement' else [])
             for role in ROLES[:2]}
    found = {}
    with tarfile.open(path) as archive:
        mounts = json.load(archive.extractfile('index.json'))['manifests']
        for row in json.load(archive.extractfile('manifest.json')):
            config_id = digest(archive.extractfile(row['Config']).read())
            role, tags = by_id[config_id]
            got_tags = [familiar(name) for name in row.get('RepoTags') or []]
            layers = [archive.extractfile(member).read() for member in row['Layers']]
            diff_ids = [digest(gzip.decompress(data) if data.startswith(b'\x1f\x8b') else data) for data in layers]
            require(role not in found and got_tags == tags and diff_ids == probe.images[role]['diff_ids'],
                    'Mixed save changed the selected descriptor content or tags')
            target = probe.report['named_digests'][role].partition('@')[2]
            actual = archive.extractfile('blobs/sha256/' + target.removeprefix('sha256:')).read()
            require(any(desc['digest'] == target for desc in mounts) and digest(actual) == target,
                    'Mixed save omitted a selected manifest')
            found[role] = {'config_id': config_id, 'target': target, 'diff_ids': diff_ids, 'repo_tags': got_tags}
    require(set(found) == set(ROLES[:2]), 'Mixed save omitted a selected image')
    outcome['images'] = found


def tagged_and_concurrent_save(probe, directory, output, original, next_ref):
    role = probe.images['original']
    iid = probe.report['owned_ids']['original']
    ref = probe.report['named_digests']['original']
    target = ref.partition('@')[2]
    named_path = directory / 'tag-save.tar'
    outcome = command(probe.engine, 'image', 'save', '--output', str(named_path), original)
    probe.report['named_save'] = outcome
    require(outcome['exit'] == 0, 'Stock named image save failed: ' + outcome['stderr'])
    archive = check_save(named_path, role, target)
    outcome['archive'] = archive
    require(all(archive[k] for k in ('config_matches', 'diff_ids_match', 'target_matches'))
            and [familiar(name) for name in archive['repo_tags']] == [original], 'Named save changed the image or tag')
    verify_mixed_save(probe, directory, ref, next_ref)

    by_name = '/images/' + quote(ref, safe=':/') + '/get'
    code, headers, body = probe.engine.request('GET', by_name)
    archive_receipt(probe, output, 'images-digest-get', by_name, headers, code, body, role, target)

    query = '/images/get?' + urlencode({'names': ref})
    socket = UnixHTTP(probe.engine.endpoint)
    try:
        socket.request('GET', probe.engine.prefix + query)
        response = socket.getresponse()
        code = response.status
        headers = {key.lower(): value for key, value in response.getheaders()}
        if code != 200:
            archive_receipt(probe, output, 'images-get', query, headers, code, response.read(8192), role, target)
        head = response.read(512)
        require(len(head) == 512, 'The archive never started streaming')
        probe.cli('image', 'tag', next_ref, original)
        code, row = probe.inspect(original, record='moved-during-export')
        require(code == 200 and probe.check('replacement', row) != iid, 'Retag did not win during the held export')
        code, row = probe.inspect(iid, record='original-config-during-export')
        if code == 200:
            require(probe.check('original', row) == iid, 'Wrong original image during export')
            probe.engine.remove_owned_image_id(iid, role['labels'])
        require(probe.inspect(iid, record='original-config-after-delete-during-export')[0] == 404,
                'Original image ID remained after removal during save')
        payload = head + response.read(12 << 20)
        require(not response.read(1), 'Fixture unexpectedly exceeded the bounded receipt size')
    finally:
        socket.close()
    archive_receipt(probe, output, 'images-get', query, headers, code, payload, role, target)


def wait_logs(probe, container, expected):
    until = time.monotonic() + 6
    while time.monotonic() < until:
        result = probe.engine.cli('logs', container, timeout=10)
        if result.returncode == 0 and result.stdout.decode() == expected:
            return
        time.sleep(0.04)
    raise ValueError('Retained container did not publish the exact image marker')


def retention(probe, next_ref):
    name = probe.names[1]
    selection = probe.report['named_digests']['replacement']
    iid = probe.report['owned_ids']['replacement']
    marker = probe.images['replacement']['bytes']
    probe.cli('create', '--pull=never', '--network=none', '--name', name, '--label', probe.label,
              next_ref, '/bin/sh', '-c', 'cat /' + MARKER + '; while :; do sleep 1; done')
    probe.cli('start', name)
    wait_logs(probe, name, marker)
    check_path = '/containers/' + name + '/json'
    code, row = probe.get(check_path, record='running-container-before-delete')
    require(code == 200 and row['Image'] == iid and row['State']['Running'], 'Image not in use by running test container')
    # The held save replaced original with next_ref. Remove that extra owned
    # association first so this is a real last-reference control.
    original = probe.images['original']['tag']
    require(probe.inspect(original)[1]['Id'] == iid, 'Expected extra replacement tag after held save')
    probe.cli('image', 'rm', '--no-prune', original)
    for force, key in ((False, 'running-plain'), (True, 'running-force')):
        require(remove_digest(probe, selection, force, key) == 409,
                'Running image digest removal should conflict: ' + key)
        require(probe.inspect(next_ref)[0] == 200 and probe.get(check_path)[1]['State']['Running'],
                'Running image or its tag was disturbed')
    probe.cli('stop', '--time=0', name)
    code, row = probe.get(check_path, record='stopped-container-before-untag')
    require(code == 200 and row['State']['Status'] == 'exited' and row['Image'] == iid, 'Container is not stopped')
    require(remove_digest(probe, selection, False, 'stopped-plain') == 409, 'Stopped image removal without force should conflict')
    require(remove_digest(probe, selection, True, 'stopped-force') == 200, 'Forced removal of stopped repository reference failed')
    code, _ = probe.inspect(iid, record='config-after-forced-stopped-untag')
    require(code == (200 if probe.native else 404), 'Unexpected retained image availability after forced untag')
    require(probe.inspect(next_ref, record='tag-after-force')[0] == 404
            and probe.inspect(selection, record='digest-after-force')[0] == 404, 'Forced untag left old repository references')
    probe.cli('start', name)
    wait_logs(probe, name, marker + marker)
    code, row = probe.get(check_path, record='retained-container-after-untag')
    require(code == 200 and row['State']['Running'] and row['Image'] == iid, 'Retained container did not restart with original identity')
    probe.report['identical_marker_twice'] = marker


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--socket', type=Path, required=True)
    p.add_argument('--fixture', type=Path, required=True)
    p.add_argument('--image', required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--native', action='store_true')
    opt = p.parse_args()
    require(opt.socket.is_socket() and not opt.output.exists(), 'Use an explicit socket with fresh output path')
    fixture = json.loads((opt.fixture / 'manifest.json').read_bytes())
    loaded = (opt.fixture / 'named.tar').read_bytes()
    require(digest(loaded) == fixture['archives']['named'], 'Fixture archive hash mismatch')
    report = {'schema': 'micropod-digest-retention-and-save-v1', 'run': fixture['run'], 'endpoint': str(opt.socket),
              'native': opt.native, 'cli': [], 'wire': {}, 'owned_ids': {}, 'named_digests': {}, 'cleanup': {}, 'passed': False}
    with TemporaryDirectory(prefix='digest-race-', dir=opt.output.parent) as temporary:
        directory = Path(temporary)
        (directory / 'config.json').write_text('{"auths":{"fixture.invalid":{}}}')
        engine = Engine(opt.socket, opt.image, None, None, api_version='1.47')
        engine.env['DOCKER_CONFIG'] = str(directory)
        engine.env.pop('DOCKER_CUSTOM_HEADERS', None)
        probe = Probe(engine, fixture, opt.image, opt.native, report)
        orig, next_ref = (fixture['images'][role]['tag'] for role in ROLES[:2])
        try:
            report['before_ids'] = sorted({row['Id'] for row in probe.inventory()})
            report['baselines_before'] = probe.bases()
            require(not probe.inventory(scoped=True), 'Fixture label already in use')
            require(all(probe.inspect(ref)[0] == 404 for ref in (orig, next_ref)), 'Fixture tags already in use')
            require(all(probe.get('/containers/' + name + '/json')[0] == 404 for name in probe.names), 'Fixture container already in use')
            report['started'] = True
            load_path = '/images/load?quiet=1'
            code, headers, body = engine.request('POST', load_path, body=loaded, headers={'Content-Type': 'application/x-tar'})
            report['wire']['images-load'] = {'method': 'POST', 'path': engine.prefix + load_path, 'status': code,
                                             'headers': headers, 'request_sha256': digest(loaded), 'body': body.decode()}
            require(code == 200, 'Docker API load failed')
            for role, ref in zip(ROLES, (orig, next_ref)):
                _, row = probe.inspect(ref, record='loaded-' + role)
                probe.check(role, row)
                report['named_digests'][role] = probe.named_digest(row)
            tagged_and_concurrent_save(probe, directory, opt.output, orig, next_ref)
            retention(probe, next_ref)
            report['passed'] = True
        except Exception as exc:
            report['error'] = str(exc)
        finally:
            try:
                probe.cleanup()
            except Exception as exc:
                report.update(passed=False, cleanup_error=str(exc))
            opt.output.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    return int(not report['passed'])


if __name__ == '__main__':
    raise SystemExit(main())
