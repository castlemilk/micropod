#!/usr/bin/env python3
"""Qualify named and unnamed Docker archives and a retained stopped container."""

import argparse
import copy
import gzip
import json
from pathlib import Path
import re
import tarfile
from tempfile import TemporaryDirectory
import time
from urllib.parse import urlencode
from uuid import uuid4

from qualify_docker_image_history import digest, familiar, tar_bytes
from qualify_engine_api import Engine

OWNER = 'io.micropod.qualification.archive-load'
MARKER = 'micropod-archive-load-payload'
ROLES = ('original', 'replacement', 'unnamed')
FULL_ID = re.compile(r'sha256:[0-9a-f]{64}')


def encode(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()


def require(condition, detail):
    if not condition:
        raise RuntimeError(detail)


def prepare(base_archive, directory):
    run = uuid4().hex
    repo = 'micropod-qa/archive-load-' + run
    tags = {'original': repo + ':latest', 'replacement': repo + ':next', 'unnamed': None}
    with tarfile.open(base_archive) as archive:
        base, = (row for row in json.load(archive.extractfile('manifest.json'))
                 if 'alpine:3.23' in {familiar(name) for name in row['RepoTags'] or []})
        original = json.load(archive.extractfile(base['Config']))
        base_layers = [archive.extractfile(name).read() for name in base['Layers']]
    base_diff_ids = [digest(gzip.decompress(data) if data.startswith(b'\x1f\x8b') else data) for data in base_layers]
    require(original['rootfs']['diff_ids'] == base_diff_ids, 'Alpine fixture source layers disagree with config')
    require((original['os'], original['architecture']) == ('linux', 'arm64'), 'Expected Linux ARM64 Alpine')
    sources = [(f'base-{index}.tar', data) for index, data in enumerate(base_layers)]
    layers = [path for path, _ in sources]
    metadata = {}
    members = {}
    entries = {}
    for role in ROLES:
        marker = f'{run} {role}\n'
        layer = tar_bytes([(MARKER, marker.encode())])
        config = copy.deepcopy(original)
        labels = {**(config['config'].get('Labels') or {}), OWNER: run, OWNER + '.role': role}
        config['config'].update(Labels=labels, Cmd=['/bin/cat', '/' + MARKER], Entrypoint=None)
        config['rootfs']['diff_ids'].append(digest(layer))
        config.setdefault('history', []).append({'created_by': 'COPY ' + MARKER})
        payload = encode(config)
        config_id = digest(payload)
        filename = config_id.removeprefix('sha256:') + '.json'
        layerfile = role + '.tar'
        members[role] = [(filename, payload), (layerfile, layer)]
        entries[role] = {'Config': filename, 'RepoTags': [tags[role]] if tags[role] else None, 'Layers': layers + [layerfile]}
        metadata[role] = {'config_id': config_id, 'tag': tags[role], 'labels': labels, 'bytes': marker,
                          'diff_ids': config['rootfs']['diff_ids']}
    directories = {'named': ROLES[:2], 'unnamed': ROLES[2:]}
    directory.mkdir(mode=0o700)
    archives = {}
    for name, roles in directories.items():
        tar = tar_bytes([('manifest.json', encode([entries[role] for role in roles])),
                         *sources, *(item for role in roles for item in members[role])])
        (directory / (name + '.tar')).write_bytes(tar)
        archives[name] = digest(tar)
    fixture = {'run': run, 'repository': repo, 'images': metadata, 'archives': archives}
    (directory / 'manifest.json').write_text(json.dumps(fixture, indent=2, sort_keys=True) + '\n')


class Probe:
    def __init__(self, engine, fixture, base_image, native, report):
        self.engine = engine
        self.fixture = fixture
        self.images = fixture['images']
        self.run = fixture['run']
        self.repo = fixture['repository']
        require(re.fullmatch(r'[0-9a-f]{32}', self.run) and self.repo == 'micropod-qa/archive-load-' + self.run,
                'Invalid fixture identity')
        require(set(self.images) == set(ROLES), 'Invalid fixture image roles')
        require([self.images[role]['tag'] for role in ROLES] == [self.repo + ':latest', self.repo + ':next', None],
                'Invalid fixture tag scope')
        for role, image in self.images.items():
            require(FULL_ID.fullmatch(image['config_id']) and image['labels'].get(OWNER) == self.run
                    and image['labels'].get(OWNER + '.role') == role, 'Invalid fixture image ownership')
        self.label = OWNER + '=' + self.run
        self.base_images = (base_image, 'alpine:3.23')
        self.names = ['mp-load-' + self.run + '-' + purpose for purpose in ('digest', 'retained')]
        self.native = native
        self.report = report

    def cli(self, *args, data=None):
        result = self.engine.cli(*args, data=data, timeout=45)
        reply = {'args': list(args), 'exit': result.returncode, 'stdout': result.stdout.decode(errors='replace'),
                 'stderr': result.stderr.decode(errors='replace')}
        self.report['cli'].append(reply)
        require(result.returncode == 0, f'docker {args} failed: {reply["stderr"][-2000:]}')
        return reply['stdout']

    def get(self, path, *, record=None):
        code, _, data = self.engine.request('GET', path)
        result = (code, json.loads(data))
        if record is not None:
            self.report['wire'][record] = {'status': code, 'body': result[1]}
        return result

    def inspect(self, ref, *, record=None):
        code, row = self.engine.inspect_image(ref)
        if record is not None:
            self.report['wire'][record] = {'status': code, 'body': row}
        return code, row

    def inventory(self, scoped=False):
        fields = {'all': 1}
        if scoped:
            fields['filters'] = json.dumps({'label': [self.label]})
        code, rows = self.get('/images/json?' + urlencode(fields))
        require(code == 200 and isinstance(rows, list), 'Could not read image inventory')
        return rows

    def bases(self):
        result = {}
        for image in self.base_images:
            code, row = self.inspect(image)
            require(code == 200, f'Could not resolve preloaded image {image}')
            aliases = {ref: self.inspect(ref)[0] for ref in row.get('RepoDigests') or []
                       if familiar(ref).startswith('import-')}
            require(all(status == 200 for status in aliases.values()), f'Historical alias lookup failed for {image}')
            result[image] = {'id': row['Id'], 'rootfs': row['RootFS'], 'historical_aliases': aliases}
        return result

    def owned(self, role, row):
        return (row.get('Config') or {}).get('Labels') == self.images[role]['labels']

    def check(self, role, row):
        iid = row.get('Id')
        require(iid and FULL_ID.fullmatch(iid) and iid not in self.report['before_ids'] and self.owned(role, row),
                f'Unverified ownership for {role}')
        require(not self.native or iid == self.images[role]['config_id'], f'Wrong native config ID for {role}')
        require(row['RootFS']['Layers'] == self.images[role]['diff_ids'], f'DiffIDs changed for {role}')
        prior = self.report['owned_ids'].setdefault(role, iid)
        require(prior == iid, f'Image ID changed for {role}')
        return iid

    def named_digest(self, row):
        refs = row.get('RepoDigests') or []
        matches = [ref for ref in refs if familiar(ref).partition('@')[0] == self.repo]
        require(len(matches) == 1 and FULL_ID.fullmatch(matches[0].partition('@')[2]), 'Missing or ambiguous named repository digest')
        require(not self.native or refs == matches, 'Named load created an extra immutable repository alias')
        return matches[0]

    def inspect_unnamed(self):
        until = time.monotonic() + 3
        while True:
            for entry in self.inventory(scoped=True):
                code, row = self.inspect(entry['Id'])
                if code == 200 and self.owned('unnamed', row):
                    return self.inspect(entry['Id'], record='unnamed-image')
            require(time.monotonic() < until, 'Unnamed archive image missing from owned inventory')
            time.sleep(0.05)

    def exercise(self, named, unnamed):
        original_ref, replacement_ref = (self.images[role]['tag'] for role in ROLES[:2])
        require(not self.inventory(scoped=True), 'An image already uses the unique fixture label')
        require(all(self.inspect(ref)[0] == 404 for ref in (original_ref, replacement_ref)), 'Owned tags already exist')
        require(all(self.get('/containers/' + name + '/json')[0] == 404 for name in self.names), 'Owned containers already exist')
        self.report['started'] = True
        self.cli('image', 'load', '--quiet', data=named)
        for role, ref in zip(ROLES, (original_ref, replacement_ref)):
            code, row = self.inspect(ref, record='named-' + role)
            require(code == 200 and row.get('RepoTags'), f'Named image {role} did not load')
            self.check(role, row)
            self.report['named_digests'][role] = self.named_digest(row)
        repo_digest = self.report['named_digests']['original']
        target = repo_digest.partition('@')[2]
        iid = self.report['owned_ids']['original']
        for key, ref in (('named-repository-digest', repo_digest), ('named-full-target', target)):
            code, row = self.inspect(ref, record=key)
            require(code == 200 and self.check('original', row) == iid, f'Cannot resolve {key}')
            require(self.cli('image', 'inspect', '--format', '{{.Id}}', ref).strip() == iid, f'Stock inspect disagrees for {key}')
        for key, ref in (('wrong-repository', self.repo + '-other@' + target), ('config-id-as-repository', 'sha256@' + target)):
            code, _ = self.inspect(ref, record=key)
            require(not self.native or code == 404, f'Unverified repository resolved for {key}')
        common = ('--pull=never', '--label', self.label, '--network=none')
        original_bytes = self.images['original']['bytes']
        actual = self.cli('run', '--rm', '--name', self.names[0], *common, repo_digest)
        require(actual == original_bytes, 'Stock run by advertised repository digest had wrong bytes')
        retained = self.names[1]
        self.cli('create', '--name', retained, *common, original_ref)
        require(self.cli('start', '--attach', retained) == original_bytes, 'Original container did not produce expected bytes')
        code, row = self.get('/containers/' + retained + '/json', record='stopped-before-retag')
        require(code == 200 and row['Image'] == iid and row['State']['Status'] == 'exited' and row['State']['ExitCode'] == 0,
                'Original container did not stop cleanly')
        self.cli('image', 'tag', replacement_ref, original_ref)
        code, row = self.inspect(original_ref, record='named-tag-after-replacement')
        require(code == 200 and self.check('replacement', row) != iid, 'Overwriting the last original tag did not move it')
        code, row = self.inspect(iid, record='original-id-after-replacement')
        require(code == 200 and self.check('original', row) == iid, 'Retained original image ID vanished before restart')
        code, _ = self.inspect(repo_digest, record='old-repository-digest-after-tag-move')
        require(not self.native or code == 404, 'Moved tag still claims its previous descriptor')
        require(self.cli('start', '--attach', retained) == original_bytes, 'Retained stopped container restarted with wrong bytes')
        code, row = self.get('/containers/' + retained + '/json', record='stopped-after-restart')
        require(code == 200 and row['Image'] == iid and row['State']['Status'] == 'exited' and row['State']['ExitCode'] == 0,
                'Retained container did not restart with original identity')
        fresh = self.cli('run', '--rm', '--name', self.names[0], *common, original_ref)
        require(fresh == self.images['replacement']['bytes'], 'Fresh replacement container produced wrong bytes')
        self.cli('image', 'load', '--quiet', data=unnamed)
        code, row = self.inspect_unnamed()
        require(code == 200 and not row.get('RepoTags'), 'Unnamed image unexpectedly has a named tag')
        unnamed_id = self.check('unnamed', row)
        if self.native:
            aliases = row.get('RepoDigests') or []
            require(len(aliases) == 1 and re.fullmatch(r'import-\d{4}-\d{2}-\d{2}', familiar(aliases[0]).partition('@')[0]),
                    'Unnamed native archive lost its generated immutable reference')
            for key, ref in (('unnamed-repository-digest', aliases[0]), ('unnamed-full-target', aliases[0].partition('@')[2])):
                code, image = self.inspect(ref, record=key)
                require(code == 200 and self.check('unnamed', image) == unnamed_id, f'Cannot resolve {key}')
        self.report['passed'] = True

    def cleanup(self):
        if not self.report.get('started'):
            return
        cleanup = self.report['cleanup']
        for name in self.names:
            code, row = self.get('/containers/' + name + '/json')
            if code == 200:
                require(row['Config']['Labels'].get(OWNER) == self.run, 'Refusing to remove unowned container ' + name)
                self.cli('rm', '--force', name)
            cleanup[name] = self.get('/containers/' + name + '/json')[0]
        for role in ROLES[:2]:
            tag = self.images[role]['tag']
            code, row = self.inspect(tag)
            if code == 200:
                owners = [name for name in ROLES[:2] if self.owned(name, row)]
                require(len(owners) == 1, 'Refusing to remove unowned tag ' + tag)
                self.check(owners[0], row)
                self.cli('image', 'rm', '--force', '--no-prune', tag)
            cleanup[tag] = self.inspect(tag)[0]
        # Recover IDs even if the run stopped during load or before inspection.
        for entry in self.inventory(scoped=True):
            code, row = self.inspect(entry['Id'])
            if code == 200:
                roles = [role for role in ROLES if self.owned(role, row)]
                require(len(roles) == 1, 'Unexpected result in owned image inventory')
                self.check(roles[0], row)
        for role in ROLES:
            iid = self.report['owned_ids'].get(role, self.images[role]['config_id'] if self.native else None)
            if iid:
                self.engine.remove_owned_image_id(iid, self.images[role]['labels'])
                cleanup[iid] = self.inspect(iid)[0]
        for key in ('unnamed-repository-digest', 'unnamed-full-target'):
            if key in self.report['wire']:
                row = self.report['wire'][key]['body']
                aliases = row.get('RepoDigests') or []
                if aliases:
                    ref = aliases[0] if key == 'unnamed-repository-digest' else aliases[0].partition('@')[2]
                    cleanup[ref] = self.inspect(ref)[0]
        for ref in self.report['named_digests'].values():
            cleanup[ref] = self.inspect(ref)[0]
        until = time.monotonic() + 3
        rows = self.inventory(scoped=True)
        while rows and time.monotonic() < until:
            time.sleep(0.05)
            rows = self.inventory(scoped=True)
        self.report['remaining_scoped_list_rows'] = rows
        after = {row['Id'] for row in self.inventory()}
        self.report['baseline_ids_preserved'] = set(self.report['before_ids']) <= after
        self.report['owned_ids_absent_from_inventory'] = not (set(self.report['owned_ids'].values()) & after)
        self.report['baselines_after'] = self.bases()
        require(all(code == 404 for code in cleanup.values()) and not rows and self.report['baseline_ids_preserved']
                and self.report['owned_ids_absent_from_inventory'] and self.report['baselines_before'] == self.report['baselines_after'],
                'Scoped cleanup or preservation check failed')


def replay(opt):
    require(opt.socket.is_socket() and not opt.output.exists(), 'Use an explicit socket and fresh output path')
    fixture = json.loads((opt.directory / 'manifest.json').read_bytes())
    archives = {name: (opt.directory / (name + '.tar')).read_bytes() for name in ('named', 'unnamed')}
    require({name: digest(data) for name, data in archives.items()} == fixture['archives'], 'Fixture archive hash mismatch')
    report = {'schema': 'micropod-archive-load-v1', 'run': fixture['run'], 'endpoint': str(opt.socket),
              'native': opt.native, 'cli': [], 'wire': {}, 'owned_ids': {}, 'named_digests': {}, 'cleanup': {}, 'passed': False}
    with TemporaryDirectory(prefix='archive-load-docker-config-', dir=opt.output.parent) as config:
        (Path(config) / 'config.json').write_text('{"auths":{"fixture.invalid":{}}}')
        engine = Engine(opt.socket, opt.image, None, None, api_version='1.47')
        engine.env['DOCKER_CONFIG'] = config
        engine.env.pop('DOCKER_CUSTOM_HEADERS', None)
        probe = Probe(engine, fixture, opt.image, opt.native, report)
        if opt.command == 'recover':
            prior = json.loads(opt.previous.read_bytes())
            require(prior['run'] == report['run'] and prior['native'] == opt.native and prior['endpoint'] == report['endpoint'],
                    'Recovery scope differs from recorded run')
            report.update({key: prior[key] for key in ('before_ids', 'baselines_before', 'owned_ids', 'named_digests', 'wire', 'started')})
        try:
            if opt.command == 'probe':
                report['before_ids'] = sorted({row['Id'] for row in probe.inventory()})
                report['baselines_before'] = probe.bases()
                probe.exercise(archives['named'], archives['unnamed'])
            else:
                report['passed'] = True
        except Exception as exc:
            report.update(passed=False, error=str(exc))
        finally:
            try:
                probe.cleanup()
            except Exception as exc:
                report.update(passed=False, cleanup_error=str(exc))
            opt.output.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    return int(not report['passed'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    p = commands.add_parser('prepare')
    p.add_argument('--base-archive', type=Path, required=True)
    p.add_argument('--directory', type=Path, required=True)
    for command in ('probe', 'recover'):
        p = commands.add_parser(command)
        p.add_argument('--directory', type=Path, required=True)
        p.add_argument('--socket', type=Path, required=True)
        p.add_argument('--image', required=True)
        p.add_argument('--output', type=Path, required=True)
        p.add_argument('--native', action='store_true')
        if command == 'recover':
            p.add_argument('--previous', type=Path, required=True)
    opt = parser.parse_args()
    if opt.command == 'prepare':
        prepare(opt.base_archive, opt.directory)
        return 0
    return replay(opt)


if __name__ == '__main__':
    raise SystemExit(main())
