#!/usr/bin/env python3
"""Run the same owned archive contracts on the final combined Docker guest."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from urllib.parse import urlencode

from qualify_docker_ancestor import OWNER
from qualify_engine_api import Engine


def inspect_graph_cleanup(sockets, wire, fixture, output):
    trace = json.loads(wire.read_bytes())
    meta = json.loads((fixture/'manifest.json').read_bytes())
    assert trace['passed'] and trace['mode'] == {'linked': True, 'native': True}
    assert trace['run'] == meta['run'] and len(trace['cases']) == 28
    inventories = {}
    cleanup = {}
    digest_refs = {ref for image in trace['images'].values() for ref in image['digests']}
    ids = {item['config_id'] for item in meta['images'].values()}
    tag_refs = {item['ref'] for item in meta['images'].values()}
    for side, sock in sockets.items():
        engine = Engine(sock, 'alpine:3.23', None, None, api_version='1.47')
        query = urlencode({'all': 1, 'filters': json.dumps({'label': {OWNER + '=' + meta['run']: True}})})
        for endpoint in ('images', 'containers'):
            code, _, body = engine.request('GET', '/' + endpoint + '/json?' + query)
            inventories.setdefault(side, {})[endpoint] = {'status': code, 'rows': json.loads(body)}
        cleanup[side] = {ref: engine.inspect_image(ref)[0] for ref in sorted(digest_refs | ids | tag_refs)}
    result = {'run': meta['run'], 'wire_sha256': hashlib.sha256(wire.read_bytes()).hexdigest(),
              'scoped_inventories': inventories, 'image_references': cleanup, 'probe_cleanup': trace['cleanup']}
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    assert all(v['status'] == 200 and v['rows'] == [] for endpoints in inventories.values() for v in endpoints.values())
    assert set(trace['cleanup'].values()) == {404} and all(set(values.values()) == {404} for values in cleanup.values())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ready', type=Path, required=True)
    parser.add_argument('--reference', type=Path, required=True)
    parser.add_argument('--job-sha', required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent.parent
    hub = root.parents[1] / 'home'
    drivers = root / 'drivers'
    out = root / 'consumers'
    profile = root / 'final-api-55f2ae'
    ready = json.loads(args.ready.read_bytes())
    assert ready['owned_artifacts']['job']['sha256'] == args.job_sha and len(args.job_sha) == 64
    assert args.job_sha.startswith('55f2ae')
    native = Path(ready['socket'])
    assert native.is_socket() and args.reference.is_socket() and not native.samefile(args.reference)
    sockets = {'native': native, 'stock': args.reference}
    image = ready['benchmark_image']
    prefix = args.job_sha[:6]
    digest_fixture = hub/'archive-load-candidate'/'digest-fixture'
    retirement_fixture = hub/'archive-digest-consumers'/'retention-fixture'
    archive_fixture = hub/'archive-load-candidate'/'archive-fixture'
    linked_fixture = hub/'archive-load-candidate'/'linked-fixture'
    evidence = root/'final-replay-55f2ae'
    evidence.mkdir(mode=0o700)
    steps = {}
    for side, sock in sockets.items():
        family = ('--native',) if side == 'native' else ()
        common = (*family, '--socket', str(sock), '--image', image)
        steps[side + '-digest-consumers'] = ('probe_docker_digest_consumers.py', *common, '--fixture', digest_fixture,
                                            '--output', out/f'{prefix}-{side}-digest-consumers.json')
        steps[side + '-retention-save'] = ('qualify_digest_retention_and_save.py', *common, '--fixture', retirement_fixture,
                                          '--output', out/f'{prefix}-{side}-retention-and-save.json')
    steps['native-archive'] = ('qualify_docker_archive_load.py', 'probe', '--native', '--socket', str(native), '--image', image,
                               '--directory', archive_fixture, '--output', out/f'{prefix}-native-archive.json')
    graph = out/f'{prefix}-linked-ancestry.json'
    steps['native-linked-graph'] = ('qualify_docker_ancestor.py', 'probe', '--native', '--linked', '--socket', str(native),
                                    '--directory', linked_fixture, '--output', graph)
    steps['pinned-api'] = ('run_final_api_audit.py', '--ready', args.ready, '--reference', args.reference,
                           '--job-sha', args.job_sha, '--client', hub/'archive-load-api-55f2ae', '--output-directory', profile)
    scripts = {case: [sys.executable, '-B', str(drivers/script), *(str(value) for value in opts)] for case,(script,*opts) in steps.items()}
    (evidence/'commands.json').write_text(json.dumps(scripts, indent=2, sort_keys=True) + '\n')
    results = {}
    for name, cmd in scripts.items():
        with (evidence/(name + '.log')).open('xb') as log:
            results[name] = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=False).returncode
        print(name, results[name], flush=True)
    (evidence/'exits.json').write_text(json.dumps(results, indent=2, sort_keys=True) + '\n')
    inspect_graph_cleanup(sockets, graph, linked_fixture, evidence/'linked-graph-cleanup.json')
    if any(results.values()):
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
