#!/usr/bin/env python3
"""Replay the unchanged Gamma6 Docker API v1.47 comparator and strict cleanup."""
import argparse
from collections import Counter
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ready', type=Path, required=True)
    parser.add_argument('--reference', type=Path, required=True)
    parser.add_argument('--job-sha', required=True)
    parser.add_argument('--client', type=Path, required=True)
    parser.add_argument('--output-directory', type=Path, required=True)
    args = parser.parse_args()
    driver = Path(__file__).resolve().parent
    qualifier = driver / 'qualify_engine_api.py'
    cleanup_driver = driver / 'verify_api_cleanup.py'
    spec = args.client / 'docker-v1.47.yaml'
    assert sha(spec) == 'f44c4514b5893e043cbe3e1675b67b9eed86fc26b6c15144bddcb02c46d2ca7e'
    assert sha(qualifier) == '5d6de4a3bf77de50be4e9db997866679782e33d83f2e5a4ff7aebd83ffeccdee'
    assert sha(cleanup_driver) == '2eaab6cb763c16a7c3d0ba355ec641ca7251614706d0089058edc7ccb0f29b12'
    ready = json.loads(args.ready.read_bytes())
    assert ready['owned_artifacts']['job']['sha256'] == args.job_sha
    candidate = Path(ready['socket'])
    assert candidate.is_socket() and args.reference.is_socket() and not candidate.samefile(args.reference)
    builder = args.client / 'buildx'
    output = args.output_directory
    audit = output / 'docker-api-v1.47.json.gz'
    cleanup = output / 'cleanup.json'
    database = args.client / 'api.sqlite'
    assert builder.is_dir() and not database.exists() and not audit.exists() and not cleanup.exists()
    env = {**os.environ, 'DOCKER_CONFIG': str(args.client/'docker'), 'BUILDX_CONFIG': str(builder), 'TMPDIR': str(args.client)}
    for remove in ('DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH',
                   'DOCKER_API_VERSION', 'DOCKER_CUSTOM_HEADERS', 'BUILDX_BUILDER'):
        env.pop(remove, None)
    subjects = ['--reference', str(args.reference), '--candidate', str(candidate)]
    commands = {
        'audit': [sys.executable, '-B', str(qualifier), *subjects, '--reference-image', 'alpine:3.23',
                  '--candidate-image', 'alpine:3.23', '--api-version', '1.47', '--spec', str(spec),
                  '--output', str(audit), '--database', str(database)],
        'cleanup': [sys.executable, '-B', str(cleanup_driver), *subjects, '--audit', str(audit), '--out', str(cleanup)],
    }
    provenance = {'job_sha256': args.job_sha, 'ready_sha256': sha(args.ready), 'qualifier_sha256': sha(qualifier),
                  'cleanup_sha256': sha(cleanup_driver), 'spec_sha256': sha(spec), 'argv': commands}
    (output/'commands.json').write_text(json.dumps(provenance, indent=2, sort_keys=True) + '\n')
    exits = {}
    for name, command in commands.items():
        if name == 'cleanup' and not audit.exists():
            break
        with (output/(name + '.log')).open('xb') as log:
            exits[name] = subprocess.run(command, env=env, check=False, stdout=log, stderr=subprocess.STDOUT).returncode
    (output/'exit.json').write_text(json.dumps(exits, indent=2, sort_keys=True) + '\n')
    if 'cleanup' not in exits or not audit.exists():
        return 2
    result = json.loads(gzip.decompress(audit.read_bytes()))
    previous = json.loads(gzip.decompress((driver.parent/'control-gamma6-api-v1.47.json.gz').read_bytes()))
    current = {key: case['comparison'] for key, case in result['candidate'].items()}
    control = {key: case['comparison'] for key, case in previous['candidate'].items()}
    operations = {key: item.get('cases') for key, item in result['operations'].items() if item.get('cases')}
    label = result['candidate']['image-list-labels']
    summary = {'audit_sha256': sha(audit), 'cleanup_sha256': sha(cleanup), 'job_sha256': args.job_sha,
               'groups': len(current), 'strict': dict(Counter(current.values())), 'control': dict(Counter(control.values())),
               'changed_groups': {key: {'control': control.get(key), 'current': state} for key, state in current.items()
                                  if state != control.get(key)}, 'operation_count': len(result['operations']),
               'operations_exercised': len(operations), 'image_list_label_check': label, 'exits': exits}
    (output/'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(summary['strict'], str(summary['operations_exercised']) + '/' + str(summary['operation_count']), exits, flush=True)
    return int(exits['cleanup'] != 0 or exits['audit'] not in (0, 1) or label['comparison'] != 'matched')


if __name__ == '__main__':
    raise SystemExit(main())
