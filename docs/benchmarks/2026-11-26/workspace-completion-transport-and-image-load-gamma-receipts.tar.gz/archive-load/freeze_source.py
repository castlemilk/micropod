#!/usr/bin/env python3
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import tempfile


BASE_RUNNER = 'eb363bff62ac2349f37a71d6a7db3a6ec2b813b0c470adf44b60ef19f41d4ed4'
FILES = (
    'docker_http_linux.go',
    'docker_image_id_delete_linux.go',
    'docker_image_list_linux.go',
    'docker_image_list_linux_test.go',
    'docker_image_resolve_linux.go',
    'docker_image_resolve_linux_test.go',
    'docker_image_transfer_linux.go',
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_archive(archive):
    sources = {}
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
        for entry in tar:
            path = PurePosixPath(entry.name)
            if (not entry.isfile() or path.parts[:-1] != ('guest', 'runner')
                    or entry.name in sources):
                raise RuntimeError(f'unexpected source entry: {entry.name}')
            sources[entry.name] = tar.extractfile(entry).read()
    return sources


def populate(directory, sources):
    directory.mkdir()
    (directory / 'guest' / 'runner').mkdir(parents=True)
    for name, data in sources.items():
        (directory / name).write_bytes(data)


def main():
    parser = argparse.ArgumentParser()
    for field in ('worktree', 'base_archive', 'stage', 'receipts'):
        parser.add_argument(field, type=Path)
    opt = parser.parse_args()
    with tarfile.open(opt.base_archive) as archive:
        previous = json.load(archive.extractfile('buildx/inventory/source.json'))
        payload = archive.extractfile('buildx/inventory/source.tar.gz').read()
    assert previous['runner_sha256'] == BASE_RUNNER
    assert sha(payload) == previous['source_archive_sha256']
    baseline = read_archive(payload)
    assert {PurePosixPath(name).name: sha(data) for name, data in baseline.items()} == previous['source_files']
    delta = {f'guest/runner/{name}': (opt.worktree / 'guest' / 'runner' / name).read_bytes() for name in FILES}
    assert delta.keys() <= baseline.keys()
    assert all(baseline[name] != data for name, data in delta.items())
    expected = baseline | delta
    with tempfile.TemporaryDirectory(dir=opt.stage, prefix='source-compare-') as scratch:
        root = Path(scratch)
        populate(root / 'previous', baseline)
        populate(root / 'current', expected)
        diff = subprocess.run(['git', 'diff', '--no-index', '--binary', 'previous/guest', 'current/guest'],
                              cwd=root, capture_output=True, check=False)
        if diff.returncode != 1:
            raise RuntimeError(diff.stderr.decode())
        patch = diff.stdout.replace(b'a/previous/guest/', b'a/guest/').replace(b'b/current/guest/', b'b/guest/')
        (opt.receipts / 'source.patch').write_bytes(patch)
        source = opt.stage / 'source'
        populate(source, baseline)
        cmd = ['git', 'apply', '--whitespace=error-all']
        subprocess.run(cmd + ['--check'], cwd=source, input=patch, check=True)
        subprocess.run(cmd, cwd=source, input=patch, check=True)
        assert all((source / name).read_bytes() == data for name, data in expected.items())
    result = opt.receipts / 'source.tar.gz'
    with tarfile.open(result, 'w:gz') as tar:
        for name in sorted(expected):
            item = tarfile.TarInfo(name)
            item.size = len(expected[name])
            tar.addfile(item, io.BytesIO(expected[name]))
    assert read_archive(result.read_bytes()) == expected
    manifest = {
        'base_runner_sha256': BASE_RUNNER,
        'base_source_archive_sha256': sha(payload),
        'source_files': {name: sha(data) for name, data in sorted(expected.items())},
        'changed': {name: {'base_sha256': sha(baseline[name]), 'sha256': sha(data)} for name, data in sorted(delta.items())},
        'source_archive_sha256': sha(result.read_bytes()),
        'patch_sha256': sha(patch),
        'patch_replay_all_sources_verified': True,
        'toolchain': 'go1.27.2', 'GOOS': 'linux', 'GOARCH': 'arm64', 'CGO_ENABLED': 0,
        'flags': ['-mod=readonly', '-trimpath', '-p=2'],
    }
    (opt.receipts / 'source.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(f'{len(expected)} inputs; {len(delta)} changed; source {manifest["source_archive_sha256"]}; patch {manifest["patch_sha256"]}')


if __name__ == '__main__':
    main()
