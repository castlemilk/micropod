#!/bin/sh
set -eu
fixture=$1
ctr=/opt/micropod-oci/runner/bin/ctr
label=org.mobyproject.image.parent
"$ctr" --namespace k8s.io images import --local --digests --platform linux/arm64 "$fixture/images.tar" >&2
target_for_id() {
    printf '%s\n' "$rows" | awk -v name="$1" '$1 == name { print $3 }'
}
wait_for_ids() {
    for image_id in "$@"; do
        target=$(target_for_id "$image_id")
        case "$target" in
            sha256:*) [ "${#target}" -eq 71 ] || return 1 ;;
            *) return 1 ;;
        esac
    done
}
parent_id='sha256:be42b442b172b16f5ad3dc304abbb40e65b4d9a2dd9a806164720f52a6435ab3'
child_id='sha256:a764fe8e3a3a20729ceb9660292281fe20126a2c1a01ff07f4d0d5bfeefd611f'
grandchild_id='sha256:2f7383b08a297458014ec59719d2d6202f79ed670237c6232b9c6a85364bf75f'
sibling_id='sha256:95cad0b82ab02ea7cb5d02a91ef7c01fe531a23a4ae5bb9261934cb52905cb2d'
lookalike_id='sha256:df79b0c35faf97e81e33c3690b87877eef68c8e7c4a1111900af619c395ba96b'
attempts=100
while :; do
    rows=$("$ctr" --namespace k8s.io images list)
    if wait_for_ids "$parent_id" "$child_id" "$grandchild_id" "$sibling_id" "$lookalike_id"; then
        break
    fi
    attempts=$((attempts-1))
    [ "$attempts" -gt 0 ] || exit 1
    sleep .05
done
parent_target=$(target_for_id "$parent_id")
child_target=$(target_for_id "$child_id")
[ "$parent_target" != "$child_target" ] && [ "$child_target" != "$(target_for_id "$grandchild_id")" ]
"$ctr" --namespace k8s.io images label "$child_id" "$label=$parent_target" >&2
"$ctr" --namespace k8s.io images label "$grandchild_id" "$label=$child_target" >&2
rows=$("$ctr" --namespace k8s.io images list)
printf '%s\n' "$rows" | awk -v id="$child_id" -v v="$label=$parent_target" '$1 == id && index($0,v) { found=1 } END { exit !found }'
printf '%s\n' "$rows" | awk -v id="$grandchild_id" -v v="$label=$child_target" '$1 == id && index($0,v) { found=1 } END { exit !found }'
printf 'ancestor fixture verified %s <- %s <- %s\n' "$parent_target" "$child_target" "$(target_for_id "$grandchild_id")" >&2
