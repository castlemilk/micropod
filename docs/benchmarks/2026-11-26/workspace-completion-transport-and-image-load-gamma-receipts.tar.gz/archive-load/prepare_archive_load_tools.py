"""Clone the candidate's tools and attach verified authoritative parent labels at boot."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

hub, receipts = map(Path, sys.argv[1:])
base = hub/"artifacts/tools-baseline"
target = hub/"artifacts/tools-archive-load"
fixture = hub/"archive-load-candidate/linked-fixture"
build = json.loads((receipts/"build.json").read_bytes())
job = hub/"archive-load-candidate/job.archive-load"
test = hub/"archive-load-candidate/runner.archive-load.test"
def sha(path):
    return hashlib.file_digest(path.open("rb"), "sha256").hexdigest()
assert sha(job) == build["job_sha256"] and sha(test) == build["test_sha256"]
base_job = "eb363bff62ac2349f37a71d6a7db3a6ec2b813b0c470adf44b60ef19f41d4ed4"
assert sha(base/"runner/bin/job") == base_job
assert not target.exists()
subprocess.run(["/bin/cp","-cRp",str(base),str(target)], check=True)
shutil.copy2(job,target/"runner/bin/job")
assert sha(target/"runner/bin/job") == build["job_sha256"]
assert sha(fixture/"images.tar") == json.loads((fixture/"manifest.json").read_bytes())["archive_digest"].removeprefix("sha256:")
fixture_bank = target/"runner/ancestor-fixture"
subprocess.run(["/bin/cp","-cRp",str(fixture),str(fixture_bank)], check=True)

manifest = json.loads((fixture_bank/"manifest.json").read_bytes())
known_roles = {"parent","child","grandchild","sibling","lookalike"}
assert re.fullmatch(r"[0-9a-f]{32}", manifest["run"])
assert set(manifest["images"]) == known_roles
ids = {role:entry["config_id"] for role,entry in manifest["images"].items()}
assert all(re.fullmatch(r"sha256:[0-9a-f]{64}",v) for v in ids.values()) and len(set(ids.values())) == len(ids)
seed = fixture_bank/"apply.sh"
seed.write_text('''#!/bin/sh
set -eu
fixture=$1
ctr=/opt/micropod-oci/runner/bin/ctr
label=org.mobyproject.image.parent
"$ctr" --namespace k8s.io images import --local --digests --platform linux/arm64 "$fixture/images.tar" >&2
target_for_id() {
    printf '%s\\n' "$rows" | awk -v name="$1" '$1 == name { print $3 }'
}
wait_for_ids() {
    for image_id in "$@"; do
        target=$(target_for_id "$image_id")
        case "$target" in
            sha256:*) [ "${#target}" -eq 71 ] || return 1 ;;
            *) return 1 ;;
        esac
    done
}
''' + "\n".join(f"{role}_id='{ids[role]}'" for role in ("parent","child","grandchild","sibling","lookalike")) + '''
attempts=100
while :; do
    rows=$("$ctr" --namespace k8s.io images list)
    if wait_for_ids "$parent_id" "$child_id" "$grandchild_id" "$sibling_id" "$lookalike_id"; then
        break
    fi
    attempts=$((attempts-1))
    [ "$attempts" -gt 0 ] || exit 1
    sleep .05
done
parent_target=$(target_for_id "$parent_id")
child_target=$(target_for_id "$child_id")
[ "$parent_target" != "$child_target" ] && [ "$child_target" != "$(target_for_id "$grandchild_id")" ]
"$ctr" --namespace k8s.io images label "$child_id" "$label=$parent_target" >&2
"$ctr" --namespace k8s.io images label "$grandchild_id" "$label=$child_target" >&2
rows=$("$ctr" --namespace k8s.io images list)
printf '%s\\n' "$rows" | awk -v id="$child_id" -v v="$label=$parent_target" '$1 == id && index($0,v) { found=1 } END { exit !found }'
printf '%s\\n' "$rows" | awk -v id="$grandchild_id" -v v="$label=$child_target" '$1 == id && index($0,v) { found=1 } END { exit !found }'
printf 'ancestor fixture verified %s <- %s <- %s\\n' "$parent_target" "$child_target" "$(target_for_id "$grandchild_id")" >&2
''')
seed.chmod(0o500)
subprocess.run(["/bin/sh","-n",str(seed)],check=True)
start = target/"runner/start.sh"
content = start.read_text()
needle = '"$tools/runner/bin/job" recover\n'
assert content.count(needle) == 1
start.write_text(content.replace(needle, '"$tools/runner/ancestor-fixture/apply.sh" "$tools/runner/ancestor-fixture"\n'+needle))
subprocess.run(["/bin/sh","-n",str(start)],check=True)
changed = ["runner/bin/job","runner/start.sh","runner/ancestor-fixture/apply.sh",
           "runner/ancestor-fixture/images.tar","runner/ancestor-fixture/manifest.json"]
def tree_files(directory):
    return {str(path.relative_to(directory)):sha(path) for path in directory.rglob("*") if path.is_file()}
before, after = tree_files(base), tree_files(target)
assert {name for name,value in after.items() if before.get(name) != value} == set(changed)
assert set(before) <= set(after)
report = {"source_job_sha256":base_job,"job_sha256":build["job_sha256"],"test_sha256":build["test_sha256"],
          "base_start_sha256":before["runner/start.sh"],"changed_files":{name:after[name] for name in changed},
          "fixture_import_labels":{"child":"parent","grandchild":"child"}}
(receipts/"tools-archive-load-lineage.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
for name in ("manifest.json","apply.sh"):
    shutil.copy2(fixture_bank/name,receipts/("linked-fixture-"+name))
print(json.dumps(report))
