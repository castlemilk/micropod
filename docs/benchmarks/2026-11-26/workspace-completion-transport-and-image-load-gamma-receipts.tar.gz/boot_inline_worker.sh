#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
H=$(dirname "$D")/home
arm=${1:?owned arm label}
case "$arm" in inline-off|inline-off-diag) enabled=0 ;; inline-on|inline-on-diag) enabled=1 ;; *) exit 2 ;; esac
toolbank="$H/artifacts/tools-baseline"
if [[ $arm == *-diag ]]; then toolbank="$H/artifacts/tools-inline-diagnostic"; fi
kernel="$H/kernel-base/workspace-inline-completion/Image"
test "$(/usr/bin/shasum -a 256 "$kernel" | cut -d ' ' -f 1)" = 1cb0c4b4920dec191080746256c15952e6cedd147baa03c096deacd2691f457b
exec python3 -B "$D/public_machine.py" "$arm" --kernel "$kernel" --workspace-queues 1 --live-read 1 \
    --kernel-arg virtiofs.workspace_async_release=1 --kernel-arg "virtiofs.workspace_inline_completion=$enabled" \
    --tools "$toolbank" > "$D/$arm-owner.log" 2>&1
