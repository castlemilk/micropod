"""Verify the isolated final worker is empty of functional fixtures before stock timing."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

receipts=Path(__file__).resolve().parent
ready_path=receipts/'stopped-health-ready.json'
ready=json.loads(ready_path.read_bytes())
socket=Path(ready['socket'])
assert socket.is_socket() and ready['label']=='stopped-health'
assert ready['owned_artifacts']['job']['sha256']=='55f2ae080a601a84fd10123f6a717e880a0da6f1f2d9f827f7bf249fa79ca4d0'
assert ready['virtiofs_sysfs']['parameters']=={'workspace_async_release':'Y'}
assert ready['workspace_request_queues_requested']==1 and not ready['virtiofs_sysfs']['devices']['workspace']['event_idx']
manifest_path=receipts/'archive-load/linked-fixture-manifest.json'
manifest=json.loads(manifest_path.read_bytes())
assert len(manifest['images'])==5 and manifest['repository'].startswith('micropod-qa/ancestor-')
reference='/Users/benebsworth/.orbstack/run/docker.sock'
env={name:value for name,value in os.environ.items() if name not in
     ('DOCKER_CONTEXT','DOCKER_HOST','DOCKER_API_VERSION','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH')}
env['DOCKER_CLI_HINTS']='false'

def query(endpoint,*args):
    argv=['/opt/homebrew/bin/docker','--host','unix://'+str(endpoint),*args]
    output=subprocess.run(argv,timeout=8,env=env,text=True,capture_output=True)
    return {'exit':output.returncode,'stdout':output.stdout.strip(),'stderr':output.stderr.strip()}

result={'operation':'read-only scope verification before integrated scores',
        'utc':datetime.now(timezone.utc).isoformat(),'ready_sha256':hashlib.sha256(ready_path.read_bytes()).hexdigest(),
        'startup_fixture_manifest_sha256':hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        'passed':False,'native':{},'reference':{}}
try:
    for noun,args in (('containers',('ps','-aq','--no-trunc')),('volumes',('volume','ls','-q')),
                      ('networks',('network','ls','--format','{{json .}}')),('images',('image','ls','--all','--no-trunc','--format','{{json .}}'))):
        row=query(socket,*args)
        result['native'][noun]=row
        assert row['exit']==0,row
        if noun in ('containers','volumes'):
            assert not row['stdout'],(noun,row)
    refs=[item[key] for item in manifest['images'].values() for key in ('ref','config_id')]
    for side,endpoint in (('native',socket),('reference',reference)):
        result[side]['startup_fixture_absence']={}
        for ref in refs:
            row=query(endpoint,'image','inspect',ref)
            result[side]['startup_fixture_absence'][ref]=row
            assert row['exit'] and ('no such' in row['stderr'].lower() or 'not found' in row['stderr'].lower()),(side,ref,row)
    image=json.loads((receipts/'image.json').read_bytes())
    recorded={}
    for side,endpoint in (('native',socket),('reference',reference)):
        row=query(endpoint,'image','inspect','--format','{{.Id}}',image['tag'])
        assert row['exit']==0 and row['stdout'] in (image['config_digest'],image['manifest_digest']),row
        recorded[side]=row['stdout']
    result['retained_matched_image']=recorded
    result['passed']=True
finally:
    with (receipts/'stopped-health-pre-score-cleanup.json').open('x') as out:
        json.dump(result,out,indent=2)
        out.write('\n')
