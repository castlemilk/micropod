"""Freeze the exact combined source and relative replay patch."""
from difflib import unified_diff
import gzip
from hashlib import sha256
import io
import json
from pathlib import Path
import tarfile

dest = Path(__file__).resolve().parent
root = dest.parent.parent
base = root / "home" / "archive-digest-consumers" / "source"
new = root / "home" / "archive-verified-health-candidate" / "source"
runner = Path("guest/runner")
legacy = {"docker_image_resolve_linux.go", "docker_image_resolve_linux_test.go"}
owned = {"docker_config_linux.go", "docker_engine_linux.go", "docker_exec_stream_linux.go",
         "docker_health_linux.go", "docker_health_image_linux.go", "docker_health_linux_test.go",
         "docker_http_linux.go", "docker_image_inspect_linux_test.go"}
patch = []
files = []
for path in sorted((new / runner).glob("*")):
    if not path.is_file():
        continue
    name = str(path.relative_to(new))
    data = path.read_bytes()
    files.append((name, data))
    previous = base / name
    if path.name in legacy:
        revision = root / "home" / "archive-legacy-tag" / "source"
        # The legacy patch is a separate baseline delta; replay verifies it.
        continue
    if path.name not in owned:
        assert previous.read_bytes() == data, name
        continue
    patch.append(f"diff --git a/{name} b/{name}\n")
    if not previous.exists():
        patch.append("new file mode 100644\n")
    patch.extend(unified_diff(previous.read_text().splitlines(keepends=True) if previous.exists() else [],
                              data.decode().splitlines(keepends=True),
                              "a/" + name if previous.exists() else "/dev/null", "b/" + name))
assert len(files) == 107
patch = "".join(patch).encode()
(diffpath := dest / "health-verified-source.patch").write_bytes(patch)
(bundlepath := dest / "health-verified-source.tar.gz").unlink(missing_ok=True)
with bundlepath.open("xb") as raw:
    with gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode="w") as archive:
            for name, data in files:
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(data))
with tarfile.open(bundlepath) as archive:
    assert [(path.name, archive.extractfile(path).read()) for path in archive.getmembers()] == files
manifest = {
    "base_patch": "b50cce4d440feb7d24c9802ee166b020c73c53135ceecb1eaa070e430535f3c2",
    "base_source_archive": "8feadebe889743a4db45f21426dfd70f5d872282faf6f8a75c7b0d86babb98b1",
    "additional_legacy_base_patch": "d6ff521f5b492733037cd31089daf4844ff0e8c8f8ff6efab87fd7679b326fbc",
    "patch_sha256": sha256(diffpath.read_bytes()).hexdigest(),
    "source_sha256": sha256(bundlepath.read_bytes()).hexdigest(),
    "sources": {name: sha256(data).hexdigest() for name, data in files},
    "health_paths": [str(runner / name) for name in sorted(owned)],
}
(dest / "health-verified-source.json").write_text(json.dumps(manifest, indent=2) + "\n")
