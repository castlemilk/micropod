#!/usr/bin/env python3
"""Exercise a stock Compose service_healthy dependency using a preloaded image."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import json
from pathlib import Path
import signal
import sys
from tempfile import TemporaryDirectory
import time

from qualify_docker_restart import LABEL, Qualification, interrupted, require


def await_health(fixture, cid, description, predicate):
    deadline = time.monotonic() + 12
    while True:
        state = fixture.inspect(cid)["State"]
        health = state.get("Health") or {}
        if predicate(health):
            return health
        require(state["Running"], f"Dependency exited while waiting for {description}")
        require(time.monotonic() < deadline, f"Timeout waiting for {description}. Last state {health!r}")
        time.sleep(0.1)


def timestamp(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def qualify(fixture, result):
    common = {
        "image": fixture.image, "pull_policy": "never", "network_mode": "none",
        "labels": {LABEL: fixture.key}, "entrypoint": ["/bin/sh", "-c"], "command": ["exec sleep 120"],
    }
    services = {
        "dependency": {**common, "healthcheck": {
            "test": ["CMD", "test", "-f", "/tmp/ready"], "interval": "300ms", "timeout": "2s",
            "retries": 2, "start_period": "15s", "start_interval": "300ms",
        }},
        "job": {**common, "depends_on": {"dependency": {"condition": "service_healthy"}}},
    }
    fixture.compose_file.write_text(json.dumps({"services": services}))
    result["image_id"] = json.loads(fixture.docker("image", "inspect", fixture.image).stdout)[0]["Id"]
    result["compose_version"] = fixture.docker("compose", "version", "--short").stdout.strip()
    fixture.compose_touched = True
    fixture.compose("create", "--pull", "never")
    ids = {name: fixture.inspect(fixture.compose("ps", "-aq", name).stdout.strip())["Id"] for name in services}
    result["containers"] = ids
    with ThreadPoolExecutor(max_workers=1) as executor:
        up = executor.submit(fixture.compose, "up", "--detach", "--wait", "--wait-timeout", "18",
                             "--pull", "never", check=False, timeout=23)
        deadline = time.monotonic() + 8
        while not fixture.inspect(ids["dependency"])["State"]["Running"]:
            require(not up.done(), "Compose returned before the dependency started")
            require(time.monotonic() < deadline, "Dependency never started")
            time.sleep(0.1)
        first = await_health(fixture, ids["dependency"], "a failed readiness probe",
                             lambda h: any(p["ExitCode"] == 1 for p in h.get("Log", [])))
        result["before_ready"] = {"dependency": first, "job": fixture.inspect(ids["job"])["State"]["Status"]}
        require(result["before_ready"]["job"] == "created", "Dependent job started before the readiness probe passed")
        fixture.docker("exec", ids["dependency"], "touch", "/tmp/ready")
        ready = await_health(fixture, ids["dependency"], "healthy", lambda h: h.get("Status") == "healthy")
        completed = up.result()
        require(completed.returncode == 0, completed.stderr[-1600:] or "Compose wait failed")

    job = fixture.inspect(ids["job"])["State"]
    first_success = next(probe for probe in ready["Log"] if probe["ExitCode"] == 0)
    require(ready["Status"] == "healthy" and job["Running"], "Compose returned before both services were ready")
    require(timestamp(job["StartedAt"]) >= timestamp(first_success["End"]),
            "Job start preceded the dependency's successful probe")
    result["after_ready"] = {"dependency": ready, "job_started": job["StartedAt"]}
    fixture.docker("exec", ids["dependency"], "rm", "/tmp/ready")
    result["unhealthy"] = await_health(fixture, ids["dependency"], "unhealthy", lambda h: h.get("Status") == "unhealthy")
    require(result["unhealthy"]["FailingStreak"] >= 2, "Health changed before two consecutive failures")
    fixture.docker("exec", ids["dependency"], "touch", "/tmp/ready")
    result["recovered"] = await_health(fixture, ids["dependency"], "recovery", lambda h: h.get("Status") == "healthy")
    require(result["recovered"]["FailingStreak"] == 0, "Successful probe did not reset failure streak")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument("--host")
    target.add_argument("--context")
    parser.add_argument("--image", required=True, help="Already loaded image with sh, sleep, test, touch and rm")
    args = parser.parse_args()
    with TemporaryDirectory(prefix="micropod-health-") as directory:
        fixture = Qualification(Path(directory), args, prefix="mp-health-")
        result = {"schema": 1, "project": fixture.key, "image": fixture.image, "passed": False}
        try:
            qualify(fixture, result)
            result["passed"] = True
        except Exception as exc:
            result["error"] = str(exc)
        finally:
            try:
                result["cleanup"] = fixture.cleanup()
                candidates = fixture.docker("network", "ls", "-q", "--filter",
                                            "label=com.docker.compose.project=" + fixture.key).stdout.splitlines()
                networks = json.loads(fixture.docker("network", "inspect", *candidates).stdout) if candidates else []
                remaining = [row["Id"] for row in networks
                             if (row.get("Labels") or {}).get("com.docker.compose.project") == fixture.key]
                result["cleanup"]["remaining_network_ids"] = remaining
                require(not remaining, "Compose project networks remain")
            except Exception as exc:
                result["cleanup_error"] = str(exc)
                result["passed"] = False
    print(json.dumps(result, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, interrupted)
    sys.exit(main())
