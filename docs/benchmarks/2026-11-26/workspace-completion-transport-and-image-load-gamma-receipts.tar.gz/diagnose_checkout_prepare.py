"""Record the exact first stock checkout preparation state on both owned endpoints."""
from contextlib import ExitStack
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from uuid import uuid4
import hashlib
import json
import os
import sys
import time

receipts = Path(__file__).resolve().parent
home = receipts.parent / 'home'
source = home / 'evidence/prior/runner-vendored'
sys.path.insert(0, str(home/'evidence/prior/final-harness/scripts'))
import bench_workspace_checkout as bench
import bench_workspace_runner as runner

ready = json.loads((receipts/'control-ready.json').read_text())
socket = Path(ready['socket'])
orbstack = Path('/Users/benebsworth/.orbstack/run/docker.sock')
assert socket.is_socket() and orbstack.is_socket()
probe = SimpleNamespace(image=ready['benchmark_image'], cpus=2, memory_mib=1536)
arms = {name:bench.Arm(name, endpoint, probe.image) for name, endpoint in [('orbstack',orbstack),('hvf',socket)]}
identity = bench.image_identity(receipts/'image-manifest.json', [arm.image_id for arm in arms.values()])
names = 'mpg7-prep-' + uuid4().hex[:12]
shared = Path(ready['workspace'])
assert shared.resolve(strict=True).parent == home/'share'

def files(tree):
    return {file.relative_to(tree).as_posix():[file.stat().st_size, bench.file_sha(file)]
            for file in tree.rglob('*') if file.is_file() and file.relative_to(tree).parts[0] != '.git'}

guest = '''
from pathlib import Path
import hashlib, json, os, subprocess, sys, time
tree=Path('/checkout-ci/source')
os.chdir(tree)
started=time.monotonic_ns()
status=subprocess.run(['git','-c','safe.directory=/checkout-ci/source','--no-optional-locks',
                       'status','--porcelain=v1','-z','--untracked-files=all'],capture_output=True)
rows={file.relative_to(tree).as_posix():(file.stat().st_size, hashlib.sha256(file.read_bytes()).hexdigest())
      for file in tree.rglob('*') if file.is_file() and file.relative_to(tree).parts[0] != '.git'}
print(json.dumps({'status':status.returncode,'stdout_hex':status.stdout.hex(),'stderr':status.stderr.decode(),
                  'files':rows,'elapsed_ns':time.monotonic_ns()-started}))
'''
with TemporaryDirectory(dir=shared,prefix='prep-discrepancy-') as temporary:
    scopes={}
    for engine in arms:
        stage=Path(temporary)/engine
        stage.mkdir()
        tree,head=runner.prepare_checkout(stage,source)
        scopes[engine]=(stage,tree,head)
    data={}
    with ExitStack() as cleanup:
        for name, arm in arms.items():
            stage,tree,head=scopes[name]
            clock=time.monotonic_ns()
            arm.start(cleanup,names+'-'+name,stage,probe,set(identity.values()))
            initial=arm.guest('prepare',2,1536)
            after_prepare=time.monotonic_ns()
            local=files(tree)
            observations=[]
            for index in range(3):
                row=arm.json('exec',arm.id,'python3','-B','-c',guest,timeout=15)
                viewed=row.pop('files')
                observations.append({**row,
                                     'extra': sorted(set(viewed)-set(local)),
                                     'missing': sorted(set(local)-set(viewed)),
                                     'changed':{key:{'host':local[key], 'guest':viewed[key]}
                                                for key in sorted(viewed.keys()&local.keys())
                                                if viewed[key]!=local[key]}})
                if index<2:
                    time.sleep(.05)
            data[name]={'host':runner.inventory(tree),'head':head,'prepared':initial,
                        'first_prepare_host_ns':after_prepare-clock,'observations':observations}
    for name,arm in arms.items():
        left=bench.call([*arm.docker,'ps','-aq','--filter','name='+names]).stdout.decode().strip()
        assert not left,left
    with (receipts/'control-prepare-discrepancy.json').open('x') as output:
        json.dump(data,output,indent=2)
        output.write('\n')
