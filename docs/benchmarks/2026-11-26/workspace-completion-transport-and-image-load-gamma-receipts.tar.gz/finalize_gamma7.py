"""Retire only this Gamma round's private APFS and Docker scopes and archive their receipts."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import plistlib
import shutil
import subprocess
import sys
import tarfile
import time

import worker_apfs_drive as apfs

receipts = Path(__file__).resolve().parent
scope = receipts.parent
hub = scope / 'home'
assert scope.parent == Path('/private/tmp') and scope.name.startswith('mp-gamma7.')
suffix = scope.name.removeprefix('mp-gamma7.').lower()
worktree = Path(sys.argv[1]).resolve(strict=True)
results = worktree / 'docs/benchmarks/2026-11-26'
scorecard = results / 'workspace-completion-transport-and-image-load-gamma.json'
archive = results / 'workspace-completion-transport-and-image-load-gamma-receipts.tar.gz'
assert not scorecard.exists() and not archive.exists()


def read(path):
    return json.loads(path.read_bytes())


def write(path, data):
    pending = path.with_name(path.name + '.writing')
    pending.write_text(json.dumps(data, indent=2) + '\n')
    pending.replace(path)


def sha(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()


def run(argv, *, check=True, timeout=55):
    return subprocess.run(argv, text=True, capture_output=True, timeout=timeout, check=check)


def mounted_images():
    payload = subprocess.check_output(['/usr/bin/hdiutil', 'info', '-plist'], timeout=40)
    return {image['image-path'] for image in plistlib.loads(payload)['images'] if image.get('image-path')}


def archive_receipts():
    items = {path.relative_to(receipts).as_posix(): path for path in sorted(receipts.rglob('*'))
             if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts}
    assert all('registry-fixture' not in path.parts and not path.name.endswith('.key')
               and 'workspace-irq-token' not in path.name and not path.name.endswith('.owner')
               for path in items.values())
    manifest = {name: sha(path) for name, path in items.items()}
    payload = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    pending = archive.with_suffix(archive.suffix + '.pending')
    with pending.open('xb') as file, gzip.GzipFile(filename='', fileobj=file, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w|') as raw:
            for name, path in items.items():
                row = raw.gettarinfo(path, arcname=name)
                row.uid = row.gid = row.mtime = 0
                row.uname = row.gname = ''
                with path.open('rb') as source:
                    raw.addfile(row, source)
            row = tarfile.TarInfo('MANIFEST.sha256.json')
            row.size = len(payload)
            row.mode = 0o644
            raw.addfile(row, io.BytesIO(payload))
    with tarfile.open(pending) as raw:
        assert read_manifest(raw) == manifest and set(raw.getnames()) == set(manifest) | {'MANIFEST.sha256.json'}
        for name, digest in manifest.items():
            with raw.extractfile(name) as content:
                assert hashlib.file_digest(content, 'sha256').hexdigest() == digest, name
    pending.replace(archive)
    return {'path': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size, 'entries': len(manifest)}


def read_manifest(raw):
    with raw.extractfile('MANIFEST.sha256.json') as data:
        return json.load(data)


def worker_audit():
    workers = {}
    attached = mounted_images()
    for path in sorted(receipts.glob('*-worker.json')):
        worker = read(path)
        retirement = worker['drive']['detached']
        policy = retirement['persisted_policy']
        machine = worker['machine']
        assert 'cleanup' not in worker['errors']
        operation_error = worker['errors'].get('operation')
        assert worker['scope_absent'] and machine['clean_shutdown'], path
        assert not machine['scoped_processes_after_stop'] and machine['supervisor_lock_released'] and machine['defaults_unchanged'], path
        assert retirement['image_absent'] and retirement['mount_restored'] and worker['image'] not in attached, path
        socket = Path(worker['socket']) if 'socket' in worker else Path(worker['public_scope']) / 'machine/run/docker.sock'
        assert not socket.exists() and not socket.is_symlink()
        assert not any(Path(worker[key]).exists() for key in ('image', 'worker_directory')), path
        assert policy['mounted_read_only'] and policy['spotlight']['disabled'] and policy['raw_disk_unchanged'], path
        assert policy['markers_unchanged'] and policy['journal_unchanged'], path
        assert policy['fsevents']['journal_files'] == policy['fsevents']['journal_bytes'] == 0, path
        workers[worker['label']] = {'image': worker['image'], 'uuid': policy['volume']['uuid'], 'clean_shutdown': True,
                                    'read_only': True, 'spotlight_disabled': True, 'fsevents_files': 0, 'fsevents_bytes': 0,
                                    'raw_identity_preserved': True, 'defaults_unchanged': True, 'removed': True,
                                    'artifacts': worker['owned_artifacts'], 'operation_error': operation_error}
    assert workers and str(scope / 'hub.sparseimage') in attached
    return workers


def hub_attachment_audit(workers):
    created = read(receipts / 'hub-created.json')
    live = apfs.verify(created)
    write(receipts / 'hub-final-live.json', live)
    detached = apfs.detach(created, remove_image=True, inspect_history=True)
    write(receipts / 'hub-detached.json', detached)
    policy = detached['persisted_policy']
    assert detached['image_absent'] and detached['mount_restored'] and policy['mounted_read_only']
    assert policy['spotlight']['disabled'] and policy['markers_unchanged'] and policy['journal_unchanged']
    assert policy['fsevents']['journal_files'] == policy['fsevents']['journal_bytes'] == 0
    hub.rmdir()
    owned = {arm['image'] for arm in workers.values()} | {created['image']}
    assert not (mounted_images() & owned) and not any(Path(path).exists() for path in owned)
    return {'uuid': live['volume']['uuid'], 'read_only_remount': True, 'spotlight_disabled': True,
            'fsevents_files': 0, 'fsevents_bytes': 0, 'image_removed': True}


def fixture_reference_digests(image):
    return {
        image['base']: image['source_config'],
        'alpine:3.23': 'sha256:469c9ea410b9215eaee7976ba6c0639039b444be8e5d638f7abbada189971eb2',
        'registry.k8s.io/pause:3.10.2': 'sha256:f548e0e8e3dc1896ca956272154dde3314e8cc4fde0a57577ee9fa1c63f5baf4',
    }


def audit_reference(docker, image):
    assert image['tag'] == f'micropod-qa/checkout:gamma7-{suffix}'
    assert run([*docker, 'image', 'inspect', '--format', '{{.Id}}', image['tag']]).stdout.strip() in (
        image['config_digest'], image['manifest_digest'])
    assert not run([*docker, 'ps', '-aq', '--filter', f'ancestor={image["tag"]}']).stdout.strip()
    assert not run([*docker, 'ps', '-aq', '--filter', f'label={image["label"]}']).stdout.strip()
    for ref, digest in fixture_reference_digests(image).items():
        assert run([*docker, 'image', 'inspect', '--format', '{{.Id}}', ref]).stdout.strip() == digest, ref


def verify_saved_products(workers):
    lineage = read(receipts / 'baseline-lineage.json')
    prior = dict(lineage['prior_products'])
    for role, item in lineage['artifacts'].items():
        path = Path(item['source'])
        prior[str(path)] = item['sha256']
        if role in ('cli', 'vmm'):
            run(['/usr/bin/codesign', '--verify', '--strict', '--verbose=4', str(path)])
    for category in ('retained_manifest', 'gamma6_manifest', 'workload_archive', 'prior_gamma4_archive'):
        item = lineage[category]
        prior[item['path']] = item['sha256']
    for name in ('native-push-and-fuse-gamma.json', 'native-combined-integration-gamma.json',
                 'workspace-queues-and-native-buildx-gamma.json'):
        prior.update(read(results / name)['prior_preservation'])
    for name, digest in prior.items():
        assert sha(Path(name)) == digest, name

    proof = read(receipts / 'retained-runtime-manifest.json')
    retained = Path(proof['path']).resolve(strict=True)
    assert read(retained) == proof['manifest'] and sha(retained) == proof['sha256']
    previous = proof['manifest'].get('previous_manifest')
    manifests = {retained}
    while previous:
        previous_path = Path(previous['path'])
        assert previous_path.resolve(strict=True) == previous_path and previous_path.parent == retained.parent
        assert previous_path not in manifests
        manifests.add(previous_path)
        assert sha(previous_path) == previous['sha256']
        earlier = read(receipts / f"retained-runtime-manifest-{previous['sha256'][:12]}.json")
        assert earlier['path'] == previous['path'] and earlier['sha256'] == previous['sha256']
        assert earlier['manifest'] == read(previous_path)
        previous = earlier['manifest'].get('previous_manifest')
    for role, value in proof['manifest']['retained'].items():
        label, artifact_kind = role.split('/')
        path = Path(value['path'])
        assert path.resolve(strict=True) == path and path.parent == retained.parent
        assert sha(path) == value['sha256'] == workers[label]['artifacts'][artifact_kind]['sha256']
        assert path.stat().st_size == value['bytes']
        if artifact_kind == 'vmm':
            run(['/usr/bin/codesign', '--verify', '--strict', '--verbose=4', str(path)])
    for role, row in proof['manifest']['verified_test_executables'].items():
        path = Path(row['path']).resolve(strict=True)
        log = receipts / row['successful_exit_receipt']
        assert role in workers and path.parent == retained.parent
        assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
        assert sha(log) == row['successful_exit_receipt_sha256']
        assert log.read_text().strip() == 'linux_focused=0 linux_full=0'
    preview = receipts / 'retained-unbooted-health-preview.json'
    if preview.is_file():
        preview_rows = read(preview)
        assert preview_rows['live_qualified'] is False
        for row in preview_rows['build_only'].values():
            path = Path(row['path']).resolve(strict=True)
            assert path.parent == retained.parent / 'unbooted-health-preview'
            assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
    return prior, proof


def candidate_inputs():
    prefixes = ('kernel-base/inputs', 'kernel-base/controls', 'kernel-base/build-attempt1',
                'kernel-base/workspace-inline-completion')
    allowed = ('.json', '.jsonl', '.log', '.py', '.sh', '.patch', '.txt', '.tar.gz', '.md', '.c', '.config')
    copied = {}

    def keep(file):
        assert file.resolve(strict=True) == file and file.is_relative_to(hub)
        assert not file.name.endswith(('.owner', '.key'))
        target = receipts / 'candidate-inputs' / file.relative_to(hub)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(file, target)
        copied[target.relative_to(receipts).as_posix()] = sha(target)

    for prefix in prefixes:
        folder = hub / prefix
        for file in sorted(folder.rglob('*')):
            if (file.is_file() and not file.is_symlink() and file.stat().st_size <= 8 * 2**20
                and (file.name.endswith(allowed) or file.name in ('SHA256SUMS', 'config', 'release'))):
                keep(file)
    for pattern in ('artifacts/tools-event-terminal/runner/*.sh',
                    'artifacts/tools-inline-diagnostic/runner/*.sh',
                    'artifacts/tools-archive-load*/runner/*fixture*/*'):
        for file in sorted(hub.glob(pattern)):
            if file.is_file() and not file.is_symlink() and not file.name.endswith(('.owner', '.key')):
                keep(file)
    return copied


def main():
    workers = worker_audit()
    assert {'control', 'event-off', 'event-on', 'inline-off', 'inline-on'} <= workers.keys()
    assert not (hub / 'registry-fixture').exists()
    prior, retained = verify_saved_products(workers)
    if not (receipts / 'baseline-final-rehash.json').exists():
        run([sys.executable, '-B', str(receipts / 'rehash_baseline_gamma7.py'), str(worktree)])
    sources = candidate_inputs()
    summary = json.loads(run([sys.executable, '-B', str(receipts / 'summarize_gamma7.py')]).stdout)
    write(receipts / 'measurement-summary.json', summary)
    write(receipts / 'candidate-inputs-manifest.json', sources)
    write(receipts / 'prior-artifacts-final.json', prior)

    for key in ('DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH', 'DOCKER_API_VERSION'):
        os.environ.pop(key, None)
    docker = ['/opt/homebrew/bin/docker', '--host', 'unix:///Users/benebsworth/.orbstack/run/docker.sock']
    image = read(receipts / 'image.json')
    audit_reference(docker, image)
    hub_cleanup = hub_attachment_audit(workers)
    audit_reference(docker, image)
    run([*docker, 'image', 'rm', image['tag']])
    missing = run([*docker, 'image', 'inspect', image['tag']], check=False)
    assert missing.returncode and any(marker in missing.stderr.lower() for marker in ('no such', 'not found'))
    for ref, digest in fixture_reference_digests(image).items():
        assert run([*docker, 'image', 'inspect', '--format', '{{.Id}}', ref]).stdout.strip() == digest, ref
    cleanup = {'worker_volumes': workers, 'hub': hub_cleanup, 'owned_orbstack_tag_removed': True,
               'owned_orbstack_builder_removed': image['builder_removed'], 'preexisting_orbstack_base_preserved': True,
               'preexisting_reference_digests': fixture_reference_digests(image)}
    write(receipts / 'final-cleanup.json', cleanup)
    proof = archive_receipts()
    assert list(scope.iterdir()) == [receipts] and not any(path.is_socket() for path in receipts.rglob('*'))
    assert not scope.is_mount() and not receipts.is_mount()
    shutil.rmtree(receipts)
    scope.rmdir()
    cleanup['private_stage_removed'] = not scope.exists()
    summary.update(cleanup=cleanup, receipts=proof, prior_preservation=prior, retained_runtime=retained,
                   archived_candidate_files=sources)
    write(scorecard, summary)
    print(scorecard, sha(scorecard), archive, proof['sha256'], flush=True)


if __name__ == '__main__':
    main()
