"""Stage the previously integrated runtime, pinned kernel inputs and archived large checkout."""
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tarfile
import sys

receipts = Path(__file__).resolve().parent
hub = receipts.parent / 'home'
repo = Path('/Users/benebsworth/projects/micropod')
reports = repo / 'bench/phase0-host-scheduling/docs/benchmarks'
qualified = repo / '.build/qualified/micropod-hvf-gamma4-vuwhjq/manifest.json'
recent = repo / '.build/qualified/micropod-hvf-gamma6-x5vshe/manifest-buildkit-inventory.json'
artifacts = hub / 'artifacts'
history = hub / 'evidence/prior'
assert hub.is_mount()
artifacts.mkdir(exist_ok=True)
(hub / 'share').mkdir(mode=0o700)

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def extract(path, expected, choose):
    assert sha(path) == expected, path
    files = {}
    with tarfile.open(path) as archive:
        manifest = json.load(archive.extractfile('MANIFEST.sha256.json'))
        for row in archive:
            target = choose(row.name)
            if target is None or not row.isfile():
                continue
            assert '..' not in PurePosixPath(row.name).parts and row.name in manifest
            payload = archive.extractfile(row).read()
            assert hashlib.sha256(payload).hexdigest() == manifest[row.name], row.name
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as out:
                out.write(payload)
            target.chmod(row.mode & 0o777)
            os.utime(target, (row.mtime, row.mtime))
            files[row.name] = manifest[row.name]
    assert files
    return {'path': str(path), 'sha256': expected, 'file_sha256': files}

history_path = reports / '2026-11-25/managed-ci-git-and-exec-sources.tar.gz'
roots = ('runner-vendored/', 'final-harness/scripts/', 'trace-proof/')
workload = extract(history_path, '052718b726d6d494c64e772615107df563472151042d6862b991d3d6f623b9e7',
                   lambda name: history / name if name.startswith(roots) else None)
old_report = reports / '2026-11-26'
gamma4 = old_report / 'native-push-and-fuse-gamma-receipts.tar.gz'
kernel_prefix = 'candidate-inputs/kernel-release-base/'
control_names = {'bench-release-density-wave.py', 'bench-release-density-job.py', 'run_raw_git_release_trace.sh',
                 'workspace-release-build-verification.json', 'kernel-release-base-manifest.json',
                 'previous-image.json'}
def past(name):
    if name.startswith(kernel_prefix):
        return hub / 'kernel-base' / name.removeprefix(kernel_prefix)
    if name in control_names:
        return receipts / ('gamma4-' + name)
    return None
prior = extract(gamma4, '951a630fffc76a5ded5f13a9e8372effca3a645b69813c4e4ff4f6d53dd4c21a', past)
products = {}
for name, expected in (
    ('native-push-and-fuse-gamma.json', '4f25412cb1d7bf9f51537aafcaddf7498f7b4459a9f29dae5696f17c1894e60b'),
    ('native-push-and-fuse-gamma-receipts.tar.gz', '951a630fffc76a5ded5f13a9e8372effca3a645b69813c4e4ff4f6d53dd4c21a'),
    ('native-combined-integration-gamma.json', '106f37ce525caf1673a76449e6f89b869fc3b6f496a644aa64adc369b83f5cc3'),
    ('native-combined-integration-gamma-receipts.tar.gz', '526390f79c16d53a949104faeadef4512baab7b68b6e9a2fb80d0c20434ed1a6'),
    ('workspace-queues-and-native-buildx-gamma.json', '2c6ff9113a3d2b772ceb0efebbd636cb95ffb1422442cab744edd55e9597b8a0'),
    ('workspace-queues-and-native-buildx-gamma-receipts.tar.gz', 'c179d7ce2e0b6ee3e79e0b332bd45e793c650a1f8249779b51c34c6aea50eaef'),
):
    path = old_report / name
    assert sha(path) == expected
    products[str(path)] = expected
sys.path.insert(0, str(history / 'final-harness/scripts'))
from bench_workspace_runner import inventory
fixture = inventory(history / 'runner-vendored')
assert fixture == {'files': 1058, 'bytes': 19326482,
                   'tree_sha256': 'd963fc6e9f0a6a636fb0819065d7184a05ac9f6c2c3828b0f69afaf6b30980bd'}

assert sha(qualified) == '663498e4addca168e129e01703a660e2422b624a6819f40f759eb013d8352a8f'
index = json.loads(qualified.read_bytes())
assert sha(recent) == 'cbf78f81bdc531f25bb467e8a7c0a52e2d2d7fbf901301cccea4e59414449403'
latest = json.loads(recent.read_bytes())
refs = {role: index['production_lineage'][role] for role in ('initrd', 'cli')}
refs['kernel'] = index['artifacts']['matched_fuse_release_experiment_kernel']
refs['vmm'] = latest['retained']['vmm-q4-score/vmm']
refs['job'] = latest['retained']['buildkit-inventory/job']
assert refs['vmm']['sha256'] == 'f0747277714ef1520de32e7e5d398a0b88aded8a52c8f8076dc7daaafde1d3c4'
assert refs['job']['sha256'] == 'eb363bff62ac2349f37a71d6a7db3a6ec2b813b0c470adf44b60ef19f41d4ed4'
paths = {'vmm': 'micropod-vmm', 'initrd': 'mp-hvf-init.cpio', 'cli': 'cli-baseline/micropod',
         'kernel': 'Image', 'job': 'tools-baseline/runner/bin/job'}
with gzip.open(reports / '2026-11-21/gamma-vcpu-priority.json.gz', 'rt') as data:
    installation = json.load(data)['installation']
tools = Path(installation['path']) / 'micropod-oci-tools'
shutil.copytree(tools, artifacts / 'tools-baseline', symlinks=True)
for name, digest in installation['tools'].items():
    assert sha(artifacts / 'tools-baseline' / name) == sha(tools / name) == digest, name
shutil.copytree(Path(refs['cli']['path']).parent, artifacts / 'cli-baseline', symlinks=True)
roles = {}
for role, item in refs.items():
    source = Path(item['path'])
    target = artifacts / paths[role]
    assert sha(source) == item['sha256']
    if role != 'cli':
        shutil.copy2(source, target)
    assert sha(target) == item['sha256']
    roles[role] = {'source': str(source), 'staged': str(target), 'sha256': item['sha256']}
for role in ('cli', 'vmm'):
    subprocess.run(['/usr/bin/codesign', '--verify', '--strict', roles[role]['staged']], check=True)
probe = history / 'final-harness/scripts/workspacebench/main.go'
env = dict(os.environ, GOOS='linux', GOARCH='arm64', CGO_ENABLED='0')
subprocess.run(['go', 'build', '-trimpath', '-o', artifacts / 'fsprobe', probe], env=env, check=True)
lineage = {'retained_manifest': {'path': str(qualified), 'sha256': sha(qualified)}, 'gamma6_manifest': {'path': str(recent), 'sha256': sha(recent)}, 'artifacts': roles,
           'workload_archive': workload, 'fixture': fixture, 'prior_gamma4_archive': prior,
           'prior_products': products, 'tool_bank_entries': len(installation['tools']), 'tool_bank_source': str(tools),
           'fsprobe': {'source_sha256': sha(probe), 'binary_sha256': sha(artifacts / 'fsprobe')}}
(receipts / 'baseline-lineage.json').write_text(json.dumps(lineage, indent=2) + '\n')
