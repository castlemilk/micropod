"""Prepare an isolated workspace trace and lifecycle tools bank for owned diagnostic boots."""
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess

receipts=Path(__file__).resolve().parent
hub=receipts.parent/'home'
artifacts=hub/'artifacts'
source=artifacts/'tools-baseline'
target=artifacts/'tools-inline-diagnostic'
assert hub.is_mount() and not target.exists()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def copy_script(src, dst, expected):
    path=receipts/src
    assert sha(path)==expected
    staged=runner/dst
    staged.write_bytes(path.read_bytes())
    staged.chmod(0o755)
    assert sha(staged)==expected
    return staged

subprocess.run(['/bin/cp','-cRp',source,target],check=True)
runner=target/'runner'
start=runner/'start.sh'
data=start.read_text()
original='service=\napi=\n'
assert data.count(original)==1
data=data.replace(original,original+'observer=\n')
original='${api:+"$api"} 2>/dev/null || true\' EXIT'
assert data.count(original)==1
data=data.replace(original,'${api:+"$api"} ${observer:+"$observer"} 2>/dev/null || true\' EXIT')
original='"$tools/runner/bin/job" recover\n'
assert data.count(original)==1
chain='''(
    if ! "$tools/runner/trace-observer.sh"; then
        printf '%s\\n' 'The scoped virtiofs trace failed' >&2
    fi
    exec "$tools/runner/qualify_virtiofs_inline_completion.sh"
) &
observer=$!
'''
start.write_text(data.replace(original,original+chain))
observer=copy_script('inline-trace-observer.sh','trace-observer.sh',
                     'ffe11891d8526bee55e738c54abdfb1391d8158c81fe4b611c1eacdec5411663')
source_lifecycle='qualify_virtiofs_inline_completion.sh'
lifecycle=copy_script(source_lifecycle,source_lifecycle,
                      'b8064c6c44f0734ab113cf2d81724ba11f342754df1304719b38b3aa4fafb14c')
secret=runner/'.workspace-inline-completion.owner'
with os.fdopen(os.open(secret,os.O_WRONLY|os.O_EXCL|os.O_CREAT,0o400),'w') as file:
    file.write(secrets.token_hex(16)+'\n')
for script in (start,observer,lifecycle):
    subprocess.run(['/bin/sh','-n',script],check=True)
job=runner/'bin/job'
assert sha(job)=='eb363bff62ac2349f37a71d6a7db3a6ec2b813b0c470adf44b60ef19f41d4ed4'
lineage={str(file.relative_to(target)):sha(file) for file in (job,start,observer,lifecycle)}
with (receipts/'inline-diagnostic-bank-lineage.json').open('x') as output:
    json.dump(lineage,output,indent=2)
    output.write('\n')
