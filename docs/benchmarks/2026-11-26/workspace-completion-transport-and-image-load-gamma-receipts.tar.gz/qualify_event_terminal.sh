#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
H=$(dirname "$D")/home
arm=event-on-terminal
for n in $(jot 125); do
    if test -s "$D/$arm-ready.json"; then break; fi
    if jq -e '(.errors // {}) | length > 0' "$D/$arm-worker.json" >/dev/null 2>&1; then
        jq '{errors,phase:.machine.status_running.phase}' "$D/$arm-worker.json"
        exit 1
    fi
    sleep 0.6
done
test -s "$D/$arm-ready.json"
jq -e '.workspace_event_idx_requested and .virtiofs_sysfs.devices.workspace.event_idx' "$D/$arm-ready.json" >/dev/null
ordinary=0
bash "$D/run_gamma4_arm.sh" "$arm" correctness "$arm" || ordinary=$?
lifecycle=0
python3 -B "$D/trigger_local_completion_lifecycle.py" --ready "$D/$arm-ready.json" \
    --owner "$H/artifacts/tools-event-terminal/runner/.workspace-local-completion.owner" --expected unavailable \
    --out "$D/$arm-lifecycle.json" || lifecycle=$?
if (( lifecycle == 0 )); then
    socket=$(jq -er .socket "$D/$arm-ready.json")
    workspace=$(jq -er .workspace "$D/$arm-ready.json")
    unset DOCKER_HOST DOCKER_CONTEXT DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH DOCKER_API_VERSION
    probe=$(mktemp "$workspace/remount-proof.XXXXXX")
    trap '/bin/unlink "$probe"' EXIT
    printf 'gamma7-event-idx-last-unmount-remount\n' > "$probe"
    actual=$(/opt/homebrew/bin/docker --host "unix://$socket" run --rm --pull=never --network=none \
        --mount "type=bind,src=$probe,dst=/owned.remount,readonly" --entrypoint /bin/busybox alpine:3.23 sha256sum /owned.remount)
    expected=$(/usr/bin/shasum -a 256 "$probe" | cut -d ' ' -f1)
    test "${actual%% *}" = "$expected"
    printf '%s\n' "$actual" > "$D/$arm-post-remount-byte-receipt.txt"
fi
printf 'ordinary_held_and_stock=%s terminal_lifecycle=%s\n' "$ordinary" "$lifecycle" |
    tee "$D/$arm-qualification-exit.log"
(( ordinary == 0 && lifecycle == 0 ))
