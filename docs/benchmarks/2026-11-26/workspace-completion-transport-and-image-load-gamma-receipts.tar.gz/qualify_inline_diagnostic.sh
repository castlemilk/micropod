#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
H=$(dirname "$D")/home
arm=${1:?owned diagnostic label}
mode=${2:?expected kernel mode}
[[ $arm == inline-off-diag || $arm == inline-on-diag ]]
[[ $mode == N || $mode == Y ]]
ready="$D/$arm-ready.json"
socket=$(jq -er .socket "$ready")
workspace=$(jq -er .workspace "$ready")
image=$(jq -er .benchmark_image "$ready")
test "$(jq -er .virtiofs_sysfs.parameters.workspace_inline_completion "$ready")" = "$mode"
test "$(jq -er .virtiofs_sysfs.parameters.workspace_async_release "$ready")" = Y
optimizer="$H/evidence/trace-inline"
bench="$H/evidence/prior"
trace=0
python3 -B "$D/trace_stock_git_completion.py" --socket "$socket" --workspace "$workspace" \
    --source "$bench/runner-vendored" --helpers "$bench/final-harness/scripts" --observer "$optimizer" \
    --image "$image" --image-manifest "$D/image-manifest.json" --expected-mode Y --expected-local-mode unavailable \
    --samples 4 --trace --out "$D/$arm-git.json" > "$D/$arm-git.log" 2>&1 || trace=$?
reduce=0
python3 -B "$D/reduce_inline_trace.py" --run "$D/$arm-git.json" --raw "$D/$arm-git-raw" \
    --observer "$optimizer" --expected "$mode" --out "$D/$arm-dispatch.json" > "$D/$arm-dispatch.log" 2>&1 || reduce=$?
lifecycle=0
python3 -B "$D/trigger_inline_completion_lifecycle.py" --ready "$ready" --observer "$optimizer" --expected "$mode" \
    --owner "$H/artifacts/tools-inline-diagnostic/runner/.workspace-inline-completion.owner" \
    --out "$D/$arm-lifecycle.json" > "$D/$arm-lifecycle.log" 2>&1 || lifecycle=$?
printf 'raw_trace=%s trace_reduction=%s terminal_lifecycle=%s\n' "$trace" "$reduce" "$lifecycle" |
    tee "$D/$arm-qualification-exit.log"
(( trace == 0 && reduce == 0 && lifecycle == 0 ))
