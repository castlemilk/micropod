#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
arm=${1:?owned public ready arm}
mark=${2:-$arm}
[[ $arm =~ ^[a-z0-9-]{1,22}$ && $mark =~ ^[a-z0-9-]+$ ]]
capture_admission() {
    local key=$1 status=0
    bash "$D/probe_quiet_admission.sh" "$key" 3.2 || status=$?
    (( status <= 1 ))
    jq -e '(.quiet_prestart_observed | type == "boolean") and (.host_observed_idle_pct | length == 3)' \
        "$D/$key-preflight.json" > /dev/null
}
capture_admission "$mark"
material=0
PAIRS=4 bash "$D/run_scored_worker.sh" "$arm" "$mark" material || material=$?
capture_admission "$mark-density"
density=0
PAIRS=4 bash "$D/run_scored_worker.sh" "$arm" "$mark" density || density=$?
correctness=0
bash "$D/run_gamma4_arm.sh" "$arm" correctness "$mark" || correctness=$?
printf 'material=%s density=%s ordinary_held_and_stock=%s\n' "$material" "$density" "$correctness" |
    tee "$D/$mark-qualification-exit.log"
(( material == 0 && density == 0 && correctness == 0 ))
