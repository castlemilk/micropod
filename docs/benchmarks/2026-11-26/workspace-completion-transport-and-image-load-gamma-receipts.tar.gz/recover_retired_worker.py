"""Complete an owned Gamma7 APFS retirement after a stuck supplemental holder scan."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

import outer_machine_proof as proof
import worker_apfs_drive as apfs

receipts=Path(__file__).resolve().parent
label=sys.argv[1]
assert re.fullmatch('[a-z0-9-]{1,22}',label)
path=receipts/f'{label}-worker.json'
partial=path.read_bytes()
worker=json.loads(partial)
assert worker['label']==label and not worker.get('scope_absent')
reason=worker['errors']['cleanup']
assert reason.startswith('TimeoutExpired(') and '/usr/sbin/lsof' in reason
assert 'detached' not in worker['drive']
outer=Path(worker['worker_directory']).resolve(strict=True)
mount=Path(worker['worker_volume'])
scope=Path(worker['public_scope']).resolve(strict=True)
assert outer.parent==Path('/private/tmp') and outer.name.startswith('mpg7-'+label+'-')
assert mount==outer/'home' and mount.is_mount() and scope.parent==mount and scope.name.startswith('outer-machine-')
assert not scope.is_mount() and worker['image']==str(outer/'worker.sparseimage')
raw=scope/'machine/disk.ext4'
assert raw.resolve(strict=True)==raw
original=worker['raw_disk_live']
assert all(proof.identity(raw)[key]==original[key] for key in ('device','inode','logical_bytes'))

table=proof.process_table()
assert worker['owner_pid'] not in table, 'the original owner is still active'
assert not proof.scoped_processes(table,scope), 'scope still has live clients'
assert not [row for row in table.values() if '/usr/sbin/lsof' in row['command'] and str(mount) in row['command']], 'the prior scan remains active'
ready=json.loads((receipts/f'{label}-ready.json').read_bytes())
assert worker['owned_artifacts']==ready['owned_artifacts'] and worker['raw_disk_live']==ready['raw_disk_live']
status=subprocess.run([str(scope/'micropod'),'--json','machine','status'],env=ready['environment'],
                      capture_output=True,check=True,timeout=8)
stopped=json.loads(status.stdout)
assert stopped['phase']=='stopped' and not stopped['supervisorAlive']
assert stopped['state']['lastExitCode']==0 and 'exit_reason=poweroff' in stopped['state']['lastExitReason']
assert not os.path.lexists(worker['socket'])
with (scope/'machine/run/supervisor.lock').open('rb') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert worker['machine']['clean_shutdown'] and worker['machine']['supervisor_lock_released']
assert worker['machine']['defaults_unchanged'] and not worker['machine']['scoped_processes_after_stop']

earlier=receipts/f'{label}-pre-recovery-worker-state.json'
with earlier.open('xb') as file:
    file.write(partial)
worker['drive']['final_live']=apfs.verify(worker['drive']['created'])
worker['drive']['detached']=apfs.detach(worker['drive']['created'],remove_image=True,inspect_history=True,
                                     expected_raw_identity=(original['inode'],original['logical_bytes']),
                                     raw_relative_path=raw.relative_to(mount))
result=worker['drive']['detached']
assert result['image_absent'] and result['persisted_policy']['mounted_read_only']
assert not mount.is_mount() and not scope.exists() and not any(mount.iterdir())
worker['machine']['scope_removed']=True
mount.rmdir()
outer.rmdir()
worker['scope_absent']=not outer.exists()
worker['recovery']={'prior_worker_state':earlier.name,'prior_worker_state_sha256':hashlib.sha256(partial).hexdigest(),
                    'original_cleanup_error':worker['errors'].pop('cleanup'),'owned_scanners_exited':True,
                    'proved_stopped_status':stopped,'ordinary_unforced_detach':True,
                    'raw_disk_relative_location':str(raw.relative_to(mount))}
proof.record(path,worker)
print(json.dumps(worker['recovery'],indent=2))
