#!/usr/bin/env python3
"""Count hard-IRQ FUSE replies in a retained stock-Git trace."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
import sys

FLAGS = re.compile(
    r"^\s*.*?-\d+\s+(?:\(\s*(?:\d+|-+)\s*\)\s+)?\[\d+\]\s+"
    r"(?P<flags>[\.A-Za-z0-9]{5,})\s+\d+\.\d+:\s+"
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("run", "raw", "observer", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--expected", choices=("N", "Y"), required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.observer))
    import trace_proof as trace

    run = json.loads(args.run.read_bytes())
    sample = run["traced_sample"]
    capture = run["capture"]
    info = capture["capture"]
    connection = info["connection"]
    trace.require(run["passed"] and capture["complete"] and info["clock"] == "mono",
                  "need a complete single-clock stock Git trace")
    trace.require(info["workspace_inline_completion"] == args.expected,
                  "trace observer reported the wrong inline completion setting")
    trace.require(sample["mode"] == "Y" and sample["affinity"] == sample["initial_affinity"]
                  and sample["clock"]["boot_id"] == info["boot_id"], "need unpinned Git and async RELEASE")
    raw = (args.raw / ".trace-events").read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    trace.require(sha == capture["raw_files_sha256"][".trace-events"], "original trace bytes changed")
    git_pid = run["git_fuse"]["kernel_git_pid"]
    start = sample["clock"]["now_ns"]
    finish = sample["finish_ns"]
    lines = raw.decode().splitlines()
    filtered = "\n".join(row for row in lines if "fuse_request_send:" in row or "fuse_request_end:" in row)
    events, bad, lost, _ = trace.parse_events(filtered)
    relevant = filtered.splitlines()
    trace.require(not bad and not lost, "invalid FUSE lines")

    sends, ends = {}, {}
    by_op = defaultdict(lambda: {"hardirq": [], "other": [], "cpu": Counter()})
    unpaired = Counter()
    for event in events:
        if event.name == "fuse_request_send":
            match = trace.SEND.fullmatch(event.body)
            trace.require(match is not None and match[1] == connection, "invalid FUSE send")
            if start - 1_000 <= event.ns <= finish and event.pid == git_pid:
                trace.require(match[2] not in sends, "duplicate indexed request")
                sends[match[2]] = event, match[4].removeprefix("FUSE_")
        else:
            match = trace.END.fullmatch(event.body)
            trace.require(match is not None and match[1] == connection, "invalid FUSE end")
            trace.require(match[2] not in ends, "duplicate reply")
            flags = FLAGS.match(relevant[event.line - 1])
            trace.require(flags is not None, "missing IRQ trace context")
            ends[match[2]] = event, flags["flags"][2] in "hH", int(match[4])

    for unique, (send, opcode) in sends.items():
        if unique not in ends:
            unpaired[opcode] += 1
            continue
        end, hardirq, error = ends[unique]
        trace.require(send.line < end.line and send.ns <= end.ns, "reply precedes request")
        if opcode in ("OPEN", "READ"):
            trace.require(error == 0, "unexpected error for stock Git request")
        by_op[opcode]["hardirq" if hardirq else "other"].append(end.ns - send.ns)
        if hardirq:
            by_op[opcode]["cpu"][end.cpu] += 1
    for opcode in ("OPEN", "READ"):
        entry = by_op[opcode]
        trace.require(len(entry["hardirq"]) + len(entry["other"]) >= 1058 and not unpaired[opcode],
                      f"incomplete {opcode} coverage")
        trace.require(bool(entry["hardirq"]) == (args.expected == "Y"), f"unexpected IRQ completions for {opcode}")
    trace.require(all(not result["hardirq"] for opcode, result in by_op.items() if opcode not in ("OPEN", "READ")),
                  "unexpected opcode completed in IRQ")
    result = {
        "passed": True, "workspace_inline_completion": args.expected, "raw_sha256": sha,
        "kernel_git_pid": git_pid, "unpinned_affinity": sample["affinity"], "diagnostic_git_ms": sample["status_ms"],
        "loss_counters": trace.loss_stats((args.raw / ".trace-stats").read_text()), "unpaired": dict(unpaired),
        "opcodes": {op: {"all": trace.distribution(row["hardirq"] + row["other"]),
                         "hardirq": trace.distribution(row["hardirq"]), "other": trace.distribution(row["other"]),
                         "hardirq_cpu": dict(row["cpu"])}
                    for op, row in sorted(by_op.items())},
    }
    with args.out.open("x") as output:
        json.dump(result, output, indent=2)
        output.write("\n")


if __name__ == "__main__":
    main()
