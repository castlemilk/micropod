"""Verify the baseline artifacts, every staged workload file and preceding manifests."""
import gzip
import hashlib
import json
from pathlib import Path
import tarfile
import sys

receipts = Path(__file__).resolve().parent
hub = receipts.parent / 'home'
worktree = Path(sys.argv[1]).resolve(strict=True)
reports = worktree / 'docs/benchmarks'
lineage = json.loads((receipts / 'baseline-lineage.json').read_bytes())


def sha(file):
    with file.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


values = {}
historical = lineage['workload_archive']
assert sha(Path(historical['path'])) == historical['sha256']
for entry, expected in historical['file_sha256'].items():
    staged = hub / 'evidence/prior' / entry
    assert staged.resolve(strict=True) == staged and sha(staged) == expected, entry
values['workload_entries'] = len(historical['file_sha256'])
values['workload_archive_sha256'] = historical['sha256']
with gzip.open(reports / '2026-11-21/gamma-vcpu-priority.json.gz', 'rt') as file:
    installation = json.load(file)['installation']
for entry, expected in installation['tools'].items():
    packaged = Path(lineage['tool_bank_source']) / entry
    assert sha(packaged) == expected, entry
    staged = hub / 'artifacts/tools-baseline' / entry
    desired = lineage['artifacts']['job']['sha256'] if entry == 'runner/bin/job' else expected
    assert sha(staged) == desired, entry
values['packaged_tools_entries'] = len(installation['tools'])
values['staged_tools_entries'] = len(installation['tools'])
for role, record in lineage['artifacts'].items():
    assert sha(Path(record['source'])) == sha(Path(record['staged'])) == record['sha256'], role
values['artifact_digests'] = {role: item['sha256'] for role, item in lineage['artifacts'].items()}
image = json.loads((receipts / 'image.json').read_bytes())
assert sha(hub / 'artifacts/seed.tar') == image['seed_sha256']
assert 'sha256:' + sha(receipts / 'image-manifest.json') == image['manifest_digest']
values['matched_image'] = {'seed_sha256': image['seed_sha256'], 'manifest_digest': image['manifest_digest'],
                           'config_digest': image['config_digest']}
prior = lineage['retained_manifest']
assert sha(Path(prior['path'])) == prior['sha256']
retained = json.loads(Path(prior['path']).read_text())
for metadata in (*retained['artifacts'].values(), *retained['production_lineage'].values()):
    assert sha(Path(metadata['path'])) == metadata['sha256']
values['inherited_retained_artifacts'] = len(retained['artifacts']) + len(retained['production_lineage'])
recent = lineage['gamma6_manifest']
recent_path = Path(recent['path'])
assert sha(recent_path) == recent['sha256']
recent_rows = json.loads(recent_path.read_text())['retained']
for row in recent_rows.values():
    file = Path(row['path'])
    assert file.stat().st_size == row['bytes'] and sha(file) == row['sha256']
values['inherited_gamma6_retained_artifacts'] = len(recent_rows)
for artifact in ('public_machine.py', 'probe_virtiofs_sysfs.py'):
    assert artifact in json.loads((receipts/'active-operator-lineage.json').read_bytes())

values['prior_archive_validation'] = {}
for path_text, expected in lineage['prior_products'].items():
    path = Path(path_text)
    assert sha(path) == expected
    if path.name.endswith('.tar.gz'):
        with tarfile.open(path) as archive:
            files = json.load(archive.extractfile('MANIFEST.sha256.json'))
            assert set(archive.getnames()) == set(files) | {'MANIFEST.sha256.json'}
            for name, digest in files.items():
                with archive.extractfile(name) as payload:
                    assert hashlib.file_digest(payload, 'sha256').hexdigest() == digest, name
        values['prior_archive_validation'][path.name] = {'manifest_entries': len(files), 'archive_sha256': expected}
values['passed'] = True
with (receipts / 'baseline-final-rehash.json').open('x') as proof:
    json.dump(values, proof, indent=2)
    proof.write('\n')
