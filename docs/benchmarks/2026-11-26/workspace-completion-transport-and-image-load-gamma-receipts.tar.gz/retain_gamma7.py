"""Retain the exact independently assigned Gamma7 runtime artifacts."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

receipts = Path(__file__).resolve().parent
scope = receipts.parent
hub = scope / 'home'
repo = Path('/Users/benebsworth/projects/micropod')
store = repo / '.build/qualified' / ('micropod-hvf-gamma7-' + scope.name.removeprefix('mp-gamma7.').lower())
roles = {'vmm': 'micropod-vmm', 'job': 'runner-job', 'kernel': 'Image'}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def keep(source, digest, name):
    assert source.resolve(strict=True) == source and source.is_relative_to(hub)
    assert sha(source) == digest
    target = store / f'{name}-{digest[:12]}'
    if not target.exists():
        temporary = target.with_suffix('.writing')
        with source.open('rb') as original, temporary.open('xb') as copy:
            shutil.copyfileobj(original, copy)
        shutil.copystat(source, temporary)
        assert sha(temporary) == digest
        temporary.rename(target)
    assert target.resolve(strict=True) == target and sha(target) == digest
    return target


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--retain', nargs=2, metavar=('WORKER', 'ROLE'), action='append', required=True)
    parser.add_argument('--test', nargs=3, metavar=('WORKER', 'EXECUTABLE', 'SHA256'), action='append', default=[])
    parser.add_argument('--successor', help='Create a named successor manifest while retaining the original')
    args = parser.parse_args()
    assert hub.is_mount()
    store.mkdir(mode=0o755, exist_ok=True)
    current_proof = receipts / 'retained-runtime-manifest.json'
    product = store / 'manifest.json'
    retained = {}
    tests = {}
    previous_manifest = None
    if args.successor:
        assert re.fullmatch(r'[a-z0-9-]{1,22}', args.successor)
        previous = json.loads(current_proof.read_bytes())
        previous_path = Path(previous['path'])
        assert previous_path.resolve(strict=True) == previous_path and previous_path.parent == store
        assert sha(previous_path) == previous['sha256']
        assert json.loads(previous_path.read_bytes()) == previous['manifest']
        product = store / f'manifest-{args.successor}.json'
        previous_manifest = {key: previous[key] for key in ('path', 'sha256')}
        retained.update(previous['manifest']['retained'])
        tests.update(previous['manifest'].get('verified_test_executables', {}))
        for entry in retained.values():
            path = Path(entry['path'])
            assert path.resolve(strict=True) == path and path.parent == store and sha(path) == entry['sha256']
        backup = receipts / f"retained-runtime-manifest-{previous['sha256'][:12]}.json"
        if backup.exists():
            assert backup.read_bytes() == current_proof.read_bytes()
        else:
            with backup.open('xb') as copy:
                copy.write(current_proof.read_bytes())
    else:
        assert not current_proof.exists()
    assert not product.exists()
    for worker, role in args.retain:
        assert role in roles and worker.replace('-', '').isalnum()
        path = receipts / f'{worker}-ready.json'
        data = json.loads(path.read_bytes())
        assert data['label'] == worker
        item = data['owned_artifacts'][role]
        source = Path(item['path'])
        digest = item['sha256']
        target = keep(source, digest, roles[role])
        key = worker + '/' + role
        assert key not in retained
        retained[key] = {'path': str(target), 'sha256': digest, 'bytes': target.stat().st_size,
                         'ready_receipt': path.name}
        if role == 'vmm':
            proof = subprocess.run(['/usr/bin/codesign', '--strict', '--verify', '--verbose=4', target],
                                   check=True, capture_output=True, text=True, timeout=20)
            retained[key]['strict_signature'] = proof.stderr
    for worker, filename, digest in args.test:
        assert re.fullmatch(r'[a-z0-9-]{1,22}', worker) and re.fullmatch(r'[0-9a-f]{64}', digest)
        assert worker not in tests
        check = receipts / f'{worker}-linux-exit.log'
        assert check.read_text().strip() == 'linux_focused=0 linux_full=0'
        target = keep(Path(filename), digest, 'runner-linux-tests')
        tests[worker] = {'path': str(target), 'sha256': digest, 'bytes': target.stat().st_size,
                         'successful_exit_receipt': check.name, 'successful_exit_receipt_sha256': sha(check)}
    lineage = json.loads((receipts / 'baseline-lineage.json').read_bytes())
    parent = lineage['gamma6_manifest']
    assert sha(Path(parent['path'])) == parent['sha256']
    manifest = {'round': scope.name, 'retained': retained, 'baseline_manifest': parent,
                'verified_test_executables': tests}
    if previous_manifest:
        manifest['previous_manifest'] = previous_manifest
    with product.open('x') as output:
        json.dump(manifest, output, indent=2)
        output.write('\n')
    digest = sha(product)
    staging_proof = current_proof.with_suffix('.writing')
    with staging_proof.open('x') as output:
        json.dump({'path': str(product), 'sha256': digest, 'manifest': manifest}, output, indent=2)
        output.write('\n')
    staging_proof.replace(current_proof)
    print(product, digest, flush=True)


if __name__ == '__main__':
    main()
