#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
H="$(dirname "$D")/home"
arm=${1:?owned worker}
mark=${2:-$arm}
phase=${3:-both}
test "$phase" = both || test "$phase" = material || test "$phase" = density
[[ $mark =~ ^[a-z0-9-]+$ && $arm =~ ^[a-z0-9-]{1,22}$ ]]
ready="$D/$arm-ready.json"
sock=$(jq -er .socket "$ready")
work=$(jq -er .workspace "$ready")
image=$(jq -er .benchmark_image "$ready")
orb=/Users/benebsworth/.orbstack/run/docker.sock
test -S "$sock" && test -S "$orb"
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH DOCKER_API_VERSION
docker=(/opt/homebrew/bin/docker --host "unix://$sock")
test -z "$("${docker[@]}" ps -aq)"
"${docker[@]}" run --rm --network=none --pull=never --entrypoint /bin/cat "$image" \
    /sys/module/virtiofs/parameters/workspace_async_release > "$D/$mark-$phase-async-mode.txt"
test "$(cat "$D/$mark-$phase-async-mode.txt")" = Y
result=0
if [[ $phase == both || $phase == material ]]; then
    set +e
    bash "$D/run_gamma4_arm.sh" "$arm" material "$mark"
    material=$?
    set -e
    printf '%s\n' "$material" > "$D/$mark-material.exit"
    if [[ $material != 0 ]]; then result=1; fi
fi
if [[ $phase == both || $phase == density ]]; then
    p="$H/evidence/prior"
    set +e
    python3 -B "$D/with_host_load.py" --out "$D/$mark-density-host-load.jsonl" -- \
        python3 -B "$D/bench_stock_git_density.py" --hvf-socket "$sock" --orbstack-socket "$orb" \
        --workspace "$work" --source "$p/runner-vendored" --helpers "$p/final-harness/scripts" \
        --image "$image" --image-manifest "$D/image-manifest.json" --pairs "${PAIRS:-4}" \
        --out "$D/$mark-density.json" > "$D/$mark-density.log" 2>&1
    density=$?
    set -e
    printf '%s\n' "$density" > "$D/$mark-density.exit"
    if [[ $density != 0 ]]; then result=1; fi
fi
"${docker[@]}" ps --no-trunc -aq > "$D/$mark-$phase-private-cleanup.log"
test ! -s "$D/$mark-$phase-private-cleanup.log"
exit "$result"
