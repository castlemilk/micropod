#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
arm=${1:?owned worker}
label=${2:-$arm}
if bash "$D/probe_quiet_admission.sh" "$label"; then
    PAIRS=4 bash "$D/run_scored_worker.sh" "$arm" "$label" material
fi
