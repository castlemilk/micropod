"""Reduce scoped control receipts without changing raw timing files."""
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
from statistics import median
import sys

receipts=Path(__file__).resolve().parent
reference=receipts/'inherited-gamma6/summarize_gamma6.py'
spec=spec_from_file_location('preceding_reducer', reference)
module=module_from_spec(spec)
spec.loader.exec_module(module)
module.receipts=receipts
label=sys.argv[1]
material_path=receipts/f'{label}-material.json'
density_path=receipts/f'{label}-density.json'
material=module.material(material_path,module.read(material_path))
density=module.density(density_path,module.read(density_path))
for name,key,summary in (('material',label,material),('density',label+'-density',density)):
    path=receipts/f'{key}-preflight.json'
    summary['preflight']={**module.receipt(path), **module.read(path)}
    summary['admission_class']='quiet-admitted' if summary['preflight']['quiet_prestart_observed'] else 'ambient'
size=density['jobs_per_wave']
assert size==8 and len(material['rounds'])==2 and material['pairs']==4
assert density['pass'] and len(density['overlaps']['hvf'])==len(density['overlaps']['orbstack'])==4
assert not (receipts/f'{label}-material-private-cleanup.log').stat().st_size
assert not (receipts/f'{label}-density-private-cleanup.log').stat().st_size
result={'arm':label,'material':material,'density':density,
        'normalized_guest_density':median(density['paired_hvf_to_orbstack']['guest_to_last_ms'])}
print(json.dumps(result,indent=2))
