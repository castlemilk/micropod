"""Summarize Gamma7 checkout, transport, dispatch and stock-engine evidence."""
from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
import gzip
import json
from pathlib import Path
from statistics import median

receipts = Path(__file__).resolve().parent
archive_calculator = receipts / 'inherited-gamma6/summarize_gamma6.py'
spec = spec_from_file_location('baseline_reducer', archive_calculator)
calculator = module_from_spec(spec)
spec.loader.exec_module(calculator)
calculator.receipts = receipts
read, receipt = calculator.read, calculator.receipt


def load_admission(label):
    path = receipts / (label + '-preflight.json')
    if not path.is_file():
        return {'classification': 'ambient', 'preflight': None}
    raw = read(path)
    return {'classification': 'quiet-admitted' if raw['quiet_prestart_observed'] else 'ambient',
            'preflight': {'receipt': receipt(path), **raw}}


def score_alias(name, prefix):
    return name == prefix or name.startswith(prefix + '-retry')


def matched(scorecard, titles):
    arms = {}
    for prefix in titles:
        matching = [label for label in scorecard['material'] if score_alias(label, prefix)
                    and label in scorecard['density'] and scorecard['density'][label]['pass']]
        if not matching:
            return None
        assert len(matching) == 1, matching
        arms[prefix] = matching[0]
    assert len(set(arms.values())) == len(titles)
    assert all(scorecard['boots'][name]['artifacts'] == scorecard['boots'][titles[0]]['artifacts'] for name in titles)
    data = {'arm_receipt_labels': arms, 'material': {}, 'density': {}}
    for name, receipt_label in arms.items():
        ci = scorecard['material'][receipt_label]
        data['material'][name] = {'phase_engine_medians': {stage: row['engines'] for stage, row in ci['rounds'].items()},
                                  'paired_hvf_orb_ratios': {phase: row['median_hvf_to_orbstack_ratio']
                                                           for phase, row in ci['rounds'].items()},
                                  'individual_pairs': ci['individual_pairs'],
                                  'hvf_wins': {phase: row['hvf_wins'] for phase, row in ci['rounds'].items()},
                                  'scored_weighted_idle_pct': ci['load']['weighted_cpu_idle_pct'],
                                  'admission': ci['admission']}
        wave = scorecard['density'][receipt_label]
        ratios = wave['paired_hvf_to_orbstack']['guest_to_last_ms']
        data['density'][name] = {'wave_medians': {engine: item['wave_median'] for engine, item in wave['summary'].items()},
                                 'paired_hvf_orb_guest_ratio': median(ratios), 'individual_pair_ratios': ratios,
                                 'hvf_wins': sum(ratio < 1 for ratio in ratios),
                                 'overlaps_ms': wave['overlaps'],
                                 'scored_weighted_idle_pct': wave['load']['weighted_cpu_idle_pct'],
                                 'admission': wave['admission']}
    return data


def pinned_api():
    result = {}
    for path in sorted(receipts.glob('**/docker-api*1.47.json.gz')):
        with gzip.open(path, 'rt') as stream:
            row = json.load(stream)
        if 'candidate' not in row or 'operations' not in row:
            continue
        state = Counter(case.get('comparison','unclassified') for case in row['candidate'].values())
        ops = sorted({op for case in row['candidate'].values() for op in case.get('operations', [])})
        assert set(ops) <= row['operations'].keys()
        result[path.relative_to(receipts).as_posix()] = {
            'receipt': receipt(path), 'groups': dict(state), 'operations_in_spec': len(row['operations']),
            'exercised_operations': ops}
    return result


def main():
    result = {'host': 'Gamma-128GB.local', 'date_melbourne': '2026-11-26', 'fixture': read(receipts/'baseline-lineage.json'),
              'matched_image': read(receipts/'image.json'), 'boots': {}, 'material': {}, 'density': {},
              'diagnostics': {}, 'linux_tests': {}, 'exceptions': {}, 'recovered_retirements': {}, 'matched_comparisons': {},
              'pinned_api_audits': pinned_api()}
    for path in sorted(receipts.glob('*-ready.json')):
        row = read(path)
        if 'owned_artifacts' not in row:
            continue
        result['boots'][row['label']] = {'receipt':receipt(path), 'artifacts':row['owned_artifacts'],
                                         'virtiofs_sysfs':row['virtiofs_sysfs'],
                                         'requested_kernel_arguments':row['kernel_arguments_requested'],
                                         'requested_workspace_event_idx':row.get('workspace_event_idx_requested')}
    for path in sorted(receipts.glob('*-material.json')):
        row = read(path)
        if row.get('workspace_mode') != 'independent byte-identical raw host checkouts':
            continue
        label = path.stem.removesuffix('-material')
        pairs = {phase: [{engine: pair[phase][engine]['sum_ns']/1e6 for engine in ('hvf','orbstack')}
                         for pair in row['pairs']] for phase in ('warm','incremental')}
        result['material'][label] = calculator.material(path,row) | {'admission':load_admission(label),
                                                                      'individual_pairs': pairs}
    for path in sorted(receipts.glob('*-density.json')):
        row = read(path)
        if row.get('execution') != 'stock unpinned Git':
            continue
        result['density'][path.stem.removesuffix('-density')] = calculator.density(path,row) | {
            'admission':load_admission(path.stem),
            'container_create_and_preparation_ms':{engine: setup['wall_ms'] for engine, setup in row['preparation'].items()}}
    for name, arms in (('event_idx', ('event-off', 'event-on')), ('inline_completion', ('inline-off', 'inline-on'))):
        summary = matched(result,arms)
        if summary:
            result['matched_comparisons'][name] = summary
    bindings = {'control-retry':'control', 'integrated-final':'stopped-health', 'event-off':'event-off',
                'event-on':'event-on', 'inline-off':'inline-off', 'inline-on':'inline-on'}
    result['measurement_worker_bindings'] = {label: result['boots'][arm]['receipt'] for label,arm in bindings.items()
                                             if label in result['material'] and arm in result['boots']}
    final_checks = {'pre_score_scope': 'stopped-health-pre-score-cleanup.json',
                    'independent_docker_operations': 'archive-load/55f2ae-qualification.json',
                    'compose_health_comparison': 'compose-health/final/comparison.json'}
    result['integrated_functional_checks'] = {
        name: {'receipt': receipt(path), 'contents': read(path)}
        for name,relative in final_checks.items() if (path := receipts/relative).is_file()}
    for pattern in ('*-lifecycle.json','*-vmm-metrics.json','*-dispatch.json','*-recovery.json','*-prepare-discrepancy.json',
                    '*-guest-splice.json','*-mmap-exact.json','*-stock-pid1.json'):
        for path in sorted(receipts.glob(pattern)):
            result['diagnostics'][path.stem] = {'receipt': receipt(path), 'contents': read(path)}
    for path in sorted(receipts.glob('*-linux-exit.log')):
        arm = path.name.removesuffix('-linux-exit.log')
        outputs = {stage: receipts/f'{arm}-linux-{stage}.log' for stage in ('focused','full')}
        result['linux_tests'][arm] = {'exit': path.read_text().strip(), 'logs': {
            stage: {'receipt':receipt(log), **calculator.read_linux_test(log)} for stage,log in outputs.items()}}
    for pattern in ('*-material.exit','*-density.exit','*-qualification-exit.log'):
        for path in sorted(receipts.glob(pattern)):
            status = path.read_text().strip()
            if status != '0' and not (status and all(token.endswith('=0') for token in status.split())):
                result['exceptions'][path.name] = {'receipt': receipt(path), 'exit': status}
    for path in sorted(receipts.glob('*-worker.json')):
        row = read(path)
        if row['errors']:
            result['exceptions'][path.name] = {'receipt': receipt(path), 'errors': row['errors']}
        if row.get('recovery'):
            result['recovered_retirements'][path.name] = {'receipt': receipt(path), 'recovery': row['recovery']}
    result['qualification_files'] = calculator.scoped_evidence('archive-load/**/*','transport/**/*','kernel-inline*',
                                                                'inline-*','**/*compose*.json')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
