#!/usr/bin/env python3
"""Run the terminal inline IRQ completion lifecycle proof on one owned diagnostic worker."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import re
import subprocess
from tempfile import NamedTemporaryFile
import time


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def read_results(path):
    fields = {}
    for line in path.read_text().splitlines():
        key, separator, value = line.partition("=")
        require(separator and key and key not in fields, "invalid guest result")
        fields[key] = value
    return fields


def trace_evidence(args, fields, archived):
    sys.path.insert(0, str(args.observer))
    import trace_proof as trace

    paths = {extension: archived / extension for extension in ("trace", "stats")}
    raw = {extension: path.read_bytes() for extension, path in paths.items()}
    stats = trace.loss_stats(raw["stats"].decode())
    events, unreadable, lost, _ = trace.parse_events(raw["trace"].decode())
    require(not unreadable and not lost and all(not any(cpu.values()) for cpu in stats.values()),
            "lost or malformed pressure trace events")
    connection = fields["trace_connection"]
    pids = set(map(int, fields["cancel_target_pids"].split()))
    require(len(pids) == 12 and min(pids) > 1, "invalid cancellation scope")
    sends, ends, signals = {}, {}, {}
    enospc = []
    for event in events:
        if event.name == "fuse_request_send":
            match = trace.SEND.fullmatch(event.body)
            require(match is not None and match[1] == connection, "unexpected pressure request")
            if event.pid in pids and match[4] in ("FUSE_OPEN", "FUSE_READ"):
                require(match[2] not in sends, "duplicate cancel request")
                sends[match[2]] = event, match[4]
        if event.name == "fuse_request_end":
            match = trace.END.fullmatch(event.body)
            require(match is not None and match[1] == connection, "unexpected pressure reply")
            require(match[2] not in ends, "duplicate pressure reply")
            ends[match[2]] = event
        if event.name == "signal_generate":
            match = re.search(r"\bpid=(\d+)\b", event.body)
            if match and int(match[1]) in pids:
                signals[int(match[1])] = event
        if event.name == "enqueue_return" and re.search(r"\bret=-28(?:\s|$)", event.body):
            enospc.append(event)
    active = []
    for unique, (send, opcode) in sends.items():
        signal = signals.get(send.pid)
        end = ends.get(unique)
        if signal and end and send.line < signal.line < end.line and send.ns <= signal.ns <= end.ns:
            active.append({"pid": send.pid, "unique": unique, "opcode": opcode, "send_ns": send.ns,
                           "sigkill_ns": signal.ns, "end_ns": end.ns, "ended_in_hardirq": end.hardirq})
    return {"sha256": {key: hashlib.sha256(contents).hexdigest() for key, contents in raw.items()},
            "loss_counters": stats, "observed_enospc": len(enospc),
            "unique_submitters_reporting_enospc": len({e.pid for e in enospc}),
            "cancellation_signals": len(signals), "requests_in_flight_at_sigkill": active}


def host(args, result):
    protected = Path(__file__).resolve().parent.parent / "home"
    worker = json.loads(args.ready.read_bytes())
    path = Path(worker["workspace"]).resolve(strict=True)
    require(path.parent == protected / "share", "select an owned protected share")
    socket = Path(worker["socket"])
    require(socket.is_socket(), "select a live native Unix socket")
    owner = args.owner.resolve(strict=True)
    require(owner.is_relative_to(protected / "artifacts") and owner.name == ".workspace-inline-completion.owner"
            and owner.stat().st_mode & 0o777 == 0o400, "select a protected owner secret")
    token = owner.read_text()
    require(re.fullmatch("[0-9a-f]{32}\n", token), "invalid owner secret form")
    proof = hashlib.sha256(token.rstrip("\n").encode()).hexdigest()
    env = dict(os.environ)
    for key in ("DOCKER_CONTEXT", "DOCKER_HOST", "DOCKER_API_VERSION", "DOCKER_TLS", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH"):
        env.pop(key, None)
    list_jobs = ["docker", "--host", f"unix://{socket}", "ps", "-aq"]
    active = lambda: subprocess.check_output(list_jobs, env=env, timeout=5).splitlines()
    require(not active(), "the private diagnostic guest has active containers")

    received = path / ".workspace-inline-completion.done"
    requested = path / ".workspace-inline-completion.request"
    trace_files = {extension: path / f".workspace-inline-completion.{extension}" for extension in ("trace", "stats")}
    require(not any(os.path.lexists(leaf) for leaf in (requested, received, *trace_files.values())),
            "terminal scope already used")
    archived = args.out.with_name(args.out.stem + "-raw")
    archived.mkdir()
    before = {item.name for item in path.iterdir()}
    start = time.monotonic_ns()
    try:
        with NamedTemporaryFile("w", dir=path, prefix=".workspace-inline-completion-request-", delete=False) as staged:
            staged.write(token)
        try:
            os.link(staged.name, requested)
        finally:
            os.unlink(staged.name)
        deadline = time.monotonic() + 25
        while not received.is_file():
            require(time.monotonic() < deadline, "no terminal guest result")
            time.sleep(0.05)
        require(not received.is_symlink(), "invalid guest receipt path")
        fields = read_results(received)
        require(fields.get("token_sha256") == proof, "receipt has wrong owner")
        result["guest"] = fields
        require(fields["exit"] == "0" and fields["step"] == "pass"
                and fields["mode_initial"] == args.expected and fields["mode_final"] == args.expected,
                "lifecycle or mode restoration failed")
        require(fields["same_tag_mount"] == "1" and fields["bind_mount"] == "1"
                and fields["concurrent_readers"] == "8" and fields["reads_per_job"] == "128"
                and fields["fsynced_writers"] == "8"
                and all(re.fullmatch(r"\d+:\d+", fields[f"workspace_device_{state}"])
                        for state in ("initial", "remounted", "final")), "incomplete lifecycle evidence")
        require(fields["bulk_readers"] == "24" and fields["bulk_fsynced_writers"] == "4"
                and fields["bulk_each_bytes"] == "4194304" and fields["cancel_started"] == "12"
                and int(fields["cancel_killed"]) > 0 and fields["cancel_recovered"] == "1",
                "incomplete queue-pressure and cancellation workload")
    finally:
        result["elapsed_ms"] = (time.monotonic_ns() - start) / 1e6
        if "guest" in result:
            shutil.copy2(received, archived / "guest.txt")
            received.unlink()
        for extension, leaf in trace_files.items():
            if leaf.is_file() and not leaf.is_symlink() and leaf.stat().st_size <= 32 * 1024 * 1024:
                shutil.copy2(leaf, archived / extension)
                leaf.unlink()
        if requested.is_file() and not requested.is_symlink() and requested.read_text() == token:
            requested.unlink()
        result["workspace_additions"] = sorted({item.name for item in path.iterdir()} - before)
        result["containers_remaining"] = [item.decode() for item in active()]
    require(not result["workspace_additions"] and not result["containers_remaining"], "terminal cleanup incomplete")
    result["trace"] = trace_evidence(args, fields, archived)
    require(fields["queue_pressure_retprobe"] == "1" and result["trace"]["observed_enospc"] > 0,
            "no exact ENOSPC retry proof in pressure trace")
    require(result["trace"]["requests_in_flight_at_sigkill"], "no matched OPEN or READ overlapped SIGKILL")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("ready", "owner", "observer", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    parser.add_argument("--expected", choices=("N", "Y"), required=True)
    args = parser.parse_args()
    require(not args.out.exists(), "use a fresh receipt")
    result = {"passed": False, "expected": args.expected}
    try:
        host(args, result)
        result["passed"] = True
    except Exception as error:
        result["failure"] = str(error)
        raise
    finally:
        with args.out.open("x") as output:
            json.dump(result, output, indent=2)
            output.write("\n")


if __name__ == "__main__":
    main()
