"""Pair workspace FUSE requests by ID and compare submission/completion CPUs."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import sys

receipts = Path(__file__).resolve().parent
observer = receipts.parent / 'home/evidence/prior/trace-proof'


def stats(rows, trace):
    distributions = {}
    for opcode, values in sorted(rows.items()):
        counts = Counter(f'{send.cpu}->{end.cpu}' for send, end in values)
        same = sum(send.cpu == end.cpu for send, end in values)
        distributions[opcode] = {
            'same_cpu': same, 'cross_cpu': len(values) - same, 'same_cpu_pct': 100 * same / len(values),
            'submission_to_completion_cpus': dict(sorted(counts.items())),
            'paired_request_latency': trace.distribution(end.ns - send.ns for send, end in values),
            'same_cpu_request_latency': trace.distribution(end.ns - send.ns for send, end in values if send.cpu == end.cpu),
            'cross_cpu_request_latency': trace.distribution(end.ns - send.ns for send, end in values if send.cpu != end.cpu),
        }
    return distributions


def compare(receipt, trace):
    result = json.loads(receipt.read_text())
    facts = result['capture']
    assert result['passed'] and facts['complete']
    sample = result['traced_sample']
    begin_ns, end_ns = sample['clock']['now_ns'], sample['finish_ns']
    assert sample['clock']['offset_ns'] == 0 and facts['capture']['clock'] == 'mono'
    assert sample['clock']['boot_id'] == facts['capture']['boot_id']
    file = receipt.with_name(receipt.stem + '-raw') / '.trace-events'
    blob = file.read_bytes()
    digest = hashlib.sha256(blob).hexdigest()
    assert digest == facts['raw_files_sha256']['.trace-events']
    events, _unparsed_close, lost, _resolution = trace.parse_events(blob.decode())
    assert not lost
    connection = facts['capture']['connection']
    observer_pid = int(facts['capture']['observer_pid'])
    sends, ends = {}, {}
    for event in events:
        if event.name == 'fuse_request_send':
            record = trace.SEND.fullmatch(event.body)
            assert record
            if record[1] == connection and begin_ns - 1000 <= event.ns <= end_ns and event.pid != observer_pid:
                assert record[2] not in sends
                sends[record[2]] = (record[4].removeprefix('FUSE_'), event)
        elif event.name == 'fuse_request_end':
            record = trace.END.fullmatch(event.body)
            assert record
            if record[1] == connection:
                assert record[2] not in ends
                ends[record[2]] = event

    main_pid = result['git_fuse']['kernel_git_pid']
    rows, main, unpaired = defaultdict(list), defaultdict(list), Counter()
    for key, (opcode, send) in sends.items():
        if key not in ends:
            unpaired[opcode] += 1
            continue
        completed = ends[key]
        assert completed.ns >= send.ns
        rows[opcode].append((send, completed))
        if send.pid == main_pid:
            main[opcode].append((send, completed))
    assert len(main['OPEN']) >= 1058 and len(rows['READ']) >= 1058
    return {'source': receipt.name, 'raw_trace_sha256': digest, 'workspace_connection': int(connection),
            'async_release': facts['capture']['workspace_async_release'],
            'local_completion': facts['capture'].get('workspace_local_completion', 'archived trace'),
            'input_git_ms': sample['status_ms'], 'main_git_pid': main_pid,
            'main_git': stats(main, trace), 'all_workspace_in_git_window': stats(rows, trace),
            'unpaired': dict(unpaired), 'guest_work_dispatch': facts['work_enqueue_to_start_workspace']}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--trace', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args()
    sys.path.insert(0, str(observer))
    import trace_proof as trace

    result = compare(args.trace, trace)
    with args.out.open('x') as file:
        json.dump(result, file, indent=2)
        file.write('\n')


if __name__ == '__main__':
    main()
