#!/usr/bin/env python3
"""Attribute actual workspace Git replies to the IRQ, requested and worker CPUs."""

import argparse
from collections import Counter, defaultdict, deque
import hashlib
import json
from pathlib import Path
import re
import sys


PLACEMENT = re.compile(r" workqueue=([^ ]+) req_cpu=(-?\d+) cpu=(-?\d+)$")
TRACE_FLAGS = re.compile(r"\[\d+\]\s+(\S+)\s+\d+\.")


def analyze(receipt, trace):
    run = json.loads(receipt.read_bytes())
    capture = run["capture"]
    trace.require(run["passed"] and capture["complete"], "need a complete scoped trace")
    metadata = capture["capture"]
    raw = receipt.with_name(receipt.stem + "-raw") / ".trace-events"
    blob = raw.read_bytes()
    raw_sha = hashlib.sha256(blob).hexdigest()
    trace.require(raw_sha == capture["raw_files_sha256"][raw.name], "raw events changed")
    text = blob.decode()
    events, unparsable, loss, _ = trace.parse_events(text)
    trace.require(not loss and len(unparsable) == sum(capture["normalized_close_lines"].values()),
                  "unexpected unparsed or lost lines")
    rows = text.splitlines()
    sample = run["traced_sample"]
    start_ns, end_ns = sample["clock"]["now_ns"], sample["finish_ns"]
    trace.require(metadata["boot_id"] == sample["clock"]["boot_id"]
                  and metadata["clock"] == "mono" and sample["clock"]["offset_ns"] == 0,
                  "capture and Git clocks do not match")
    pid, connection = run["git_fuse"]["kernel_git_pid"], metadata["connection"]
    submits, pending, running = {}, defaultdict(deque), {}
    paired, unmatched = defaultdict(list), Counter()
    active_items = set()
    for event in events:
        name = event.name
        if name == "fuse_request_send" and event.pid == pid and start_ns - 1000 <= event.ns <= end_ns:
            match = trace.SEND.fullmatch(event.body)
            if match[1] == connection:
                trace.require(match[2] not in submits, "duplicate Git request ID")
                submits[match[2]] = (event, match[4].removeprefix("FUSE_"))
        elif name == "fuse_request_end":
            match = trace.END.fullmatch(event.body)
            if match[1] != connection or match[2] not in submits:
                continue
            send, opcode = submits.pop(match[2])
            if event.pid not in running or running[event.pid][1] is None:
                unmatched[opcode] += 1
                continue
            worker, entry, _ = running[event.pid]
            queued, workqueue, requested, pool_cpu, flags = entry
            trace.require(send.ns <= event.ns and queued.ns <= worker.ns <= event.ns,
                          "out-of-order request or workqueue timestamps")
            paired[opcode].append((send, event, worker, queued, workqueue, requested, pool_cpu, flags))
        elif name in ("workqueue_queue_work", "workqueue_execute_start", "workqueue_execute_end"):
            work = trace.WORK.match(event.body)
            if work is None:
                continue
            pointer = work[1]
            if name == "workqueue_queue_work":
                placement = PLACEMENT.search(event.body)
                flags = TRACE_FLAGS.search(rows[event.line - 1])
                trace.require(placement is not None and flags is not None, "missing workqueue placement")
                pending[pointer].append((event, placement[1], int(placement[2]), int(placement[3]), flags[1]))
            elif name == "workqueue_execute_start":
                trace.require(pointer not in active_items and event.pid not in running, "completion work reentered")
                active_items.add(pointer)
                queued = pending[pointer].popleft() if pending[pointer] else None
                running[event.pid] = event, queued, pointer
            elif event.pid in running:
                trace.require(running[event.pid][2] == pointer, "workqueue start and end disagree")
                active_items.remove(pointer)
                running.pop(event.pid)

    trace.require(len(paired["OPEN"]) >= 1058 and len(paired["READ"]) >= 1058, "insufficient content-scan pairs")
    output = {}
    for opcode, replies in sorted(paired.items()):
        placement = Counter(f"{send.cpu}/{irq.cpu}/{target}/{pool}/{work.cpu}/{end.cpu}"
                            for send, end, work, irq, _, target, pool, _ in replies)
        output[opcode] = {
            "count": len(replies),
            "submit_irq_requested_pool_worker_reply": dict(sorted(placement.items())),
            "same_cpu_submit_and_reply": sum(send.cpu == end.cpu for send, end, *_ in replies),
            "hard_irq_queue_count": sum(len(flags) > 2 and flags[2] in "hH" for *_, flags in replies),
            "enqueue_to_work_start": trace.distribution(work.ns - irq.ns for _, _, work, irq, *_ in replies),
            "send_to_fuse_reply": trace.distribution(end.ns - send.ns for send, end, *_ in replies),
            "workqueues": dict(Counter(queue for _, _, _, _, queue, *_ in replies)),
        }
    return {"raw_sha256": raw_sha, "main_git_pid": pid, "main_git_ms": sample["status_ms"],
            "release_mode": metadata["workspace_async_release"],
            "completion_mode": metadata.get("workspace_local_completion", "unavailable"),
            "main_requests_with_dispatch": output, "main_replies_without_dispatch": dict(unmatched),
            "main_requests_without_reply": dict(Counter(opcode for _, opcode in submits.values()))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "home/evidence/prior/trace-proof"))
    import trace_proof as trace

    result = analyze(args.trace, trace)
    with args.out.open("x") as file:
        json.dump(result, file, indent=2)
        file.write("\n")


if __name__ == "__main__":
    main()
