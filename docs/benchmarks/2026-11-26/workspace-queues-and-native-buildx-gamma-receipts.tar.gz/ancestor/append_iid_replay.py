"""Append the final binary's standalone wire receipts without replacing prior observations."""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def observable(cases):
    return {name:{key:case.get(key) for key in ("all","status","raw_roles","cli_roles")}
            for name,case in cases.items()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    wire = args.run
    replay = read(wire/"summary.json")
    bases = read(wire/"base-protection.json")
    commands = read(wire/"commands.json")
    preflight = read(wire/"exact-binary-preflight.json")
    assert bases["passed"] and bases["before"] == bases["after"]
    assert commands["job_sha256"] == replay["job_sha256"] == bases["job_sha256"] == preflight["job_sha256"]
    assert set(commands["runs"]) == {"prepare","reference-ordinary","native-ordinary","native-linked","summary"}
    assert all(stage["exit"] == 0 for stage in commands["runs"].values())
    exact_sha = replay["job_sha256"]

    previous = args.receipt.read_bytes()
    doc = json.loads(gzip.decompress(previous))
    assert doc["summary"]["job_sha256"] == "08487008bc0b1c5535f2b0dfea87e6e62d10d0a8a933f7f73857bb84e508cc8a"
    assert "final_binary_replay" not in doc
    assert doc["summary"]["same_archive_group_counts"] == {"compared":27,"different":2,"matched":25}
    assert replay["same_archive_group_counts"] == {"compared":27,"different":1,"matched":26}
    assert doc["summary"]["native_linked_groups"] == replay["native_linked_groups"] == 27
    previous_differences = doc["summary"]["same_archive_differences"]
    assert set(previous_differences) == {"backend-config-id","backend-manifest-id"}
    assert replay["same_archive_differences"] == {"backend-config-id":previous_differences["backend-config-id"]}
    registered = ("reference-ordinary","native-ordinary","native-linked")
    observations = {name:read(wire/(name+".json")) for name in registered}
    changed_observations = {}
    for arm, data in observations.items():
        assert data["passed"] and data["base_preserved"]
        assert len(data["cleanup"]) == 17 and all(code == 404 for code in data["cleanup"].values())
        old = observable(doc["wire_cases"][arm]["cases"])
        current = observable(data["cases"])
        assert set(old) == set(current)
        changed = {key:{"previous":old[key],"final":value} for key,value in current.items() if old[key] != value}
        expected = set() if arm == "reference-ordinary" else {"backend-manifest-id"}
        assert set(changed) == expected
        changed_observations[arm] = changed
    assert doc["wire_cases"]["native-ordinary"]["run"] != observations["native-ordinary"]["run"]

    doc["final_binary_replay"] = {"job_sha256":exact_sha,"previous_report_sha256":sha(previous),
        "changed_observations":changed_observations,"checksummed_preflight":preflight,
        "base_images":bases,"source_and_commands":commands,"same_archive_summary":replay,
        "standalone_fixture_manifest":read(wire/"ordinary-fixture-manifest.json"),
        "raw_fixture_cases":observations,
        "raw_fixture_receipt_sha256":{name:sha((wire/(name+".json")).read_bytes()) for name in registered}}
    before_payload = json.loads(gzip.decompress(previous))
    assert before_payload == {k:v for k,v in doc.items() if k != "final_binary_replay"}
    with (wire/"before-addendum.json.gz").open("xb") as archived:
        archived.write(previous)
    final = gzip.compress(json.dumps(doc,sort_keys=True,separators=(",",":")).encode(),mtime=0)
    tmp = args.receipt.with_suffix(".gz.tmp")
    with tmp.open("xb") as stream:
        stream.write(final)
    assert json.loads(gzip.decompress(tmp.read_bytes())) == doc
    os.replace(tmp,args.receipt)
    print(json.dumps({"previous_report_sha256":sha(previous),"final_sha256":sha(final),
                      "job_sha256":exact_sha,"fixture_cleanup_verified":sum(len(row["cleanup"]) for row in observations.values()),
                      "base_images_verified":sum(len(rows) for rows in bases["after"].values())}))


if __name__ == "__main__":
    main()
