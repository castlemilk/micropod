"""Stage and build the image ancestry delta over the retained e00d guest."""
import difflib
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

workspace, stage, receipt = map(Path, sys.argv[1:])
changed = {"docker_http_linux.go", "docker_image_ancestor_linux.go", "docker_image_ancestor_linux_test.go"}
expected_base = "e00d6da9b0b2f95fbc0cb9a5609972df2f479ddec8ffb3340e2f7cbb80db2072"
outer_archive = workspace / "docs/benchmarks/2026-11-26/native-push-and-fuse-gamma-receipts.tar.gz"
live = workspace / "guest/runner"
source = stage / "source"
runner = source / "guest/runner"
runner.mkdir(parents=True)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

with tarfile.open(outer_archive) as archive:
    base_build_bytes = archive.extractfile("registry-id-final/build.json").read()
    base_build = json.loads(base_build_bytes)
    prior_manifest_bytes = archive.extractfile("registry-id-final/source.json").read()
    base_manifest = json.loads(prior_manifest_bytes)
    prior_archive_bytes = archive.extractfile("registry-id-final/source.tar.gz").read()
assert base_build["job_sha256"] == expected_base
assert sha(prior_manifest_bytes) == base_build["source_manifest_sha256"]
assert sha(prior_archive_bytes) == base_manifest["source_archive_sha256"]
base = {}
with tarfile.open(fileobj=io.BytesIO(prior_archive_bytes)) as archive:
    for name,digest in base_manifest["source_files"].items():
        orig = archive.extractfile("guest/runner/" + name).read()
        assert sha(orig) == digest, name
        base[name] = orig
        (runner/name).write_bytes(orig)
assert len(base) == 92
frozen = stage.parent / "ancestor-candidate/source/guest/runner"
current = {**base, **{name: ((frozen if name == "docker_http_linux.go" else live) / name).read_bytes()
                       for name in changed}}
assert all(base.get(name) != current[name] for name in changed)
patch_parts = []
for name in sorted(changed):
    stem = f"guest/runner/{name}"
    patch_parts.append(f"diff --git a/{stem} b/{stem}\n".encode())
    if name not in base:
        patch_parts.append(b"new file mode 100644\n")
    old = base.get(name,b"")
    before_path = f"a/{stem}" if name in base else "/dev/null"
    patch_parts.extend(difflib.diff_bytes(difflib.unified_diff, old.splitlines(keepends=True),
        current[name].splitlines(keepends=True), before_path.encode(), f"b/{stem}".encode()))
patch = receipt / "source.patch"
patch.write_bytes(b"".join(patch_parts))
subprocess.run(["git", "apply", "--check", "--whitespace=error-all", str(patch)], cwd=source, check=True)
subprocess.run(["git", "apply", "--whitespace=error-all", str(patch)], cwd=source, check=True)
for name,data in current.items():
    assert (runner/name).read_bytes() == data, name
packed = receipt / "source.tar.gz"
with packed.open("xb") as raw, gzip.GzipFile(fileobj=raw, filename="", mode="wb", mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode="w") as archive:
        for name,data in sorted(current.items()):
            member = tarfile.TarInfo("guest/runner/" + name)
            member.size = len(data)
            archive.addfile(member,io.BytesIO(data))
source_manifest = receipt / "source.json"
write_json(source_manifest, {
    "parent_job_sha256": expected_base, "parent_source_archive_sha256": sha(prior_archive_bytes),
    "patch_sha256": sha(patch.read_bytes()), "source_archive_sha256": sha(packed.read_bytes()),
    "changed": sorted(changed), "source_files": {name:sha(data) for name,data in current.items()},
    "patch_replayed_byte_exact": True,
})
print(f"Frozen {len(current)} inputs, {len(changed)} changes, source {sha(source_manifest.read_bytes())}", flush=True)
goroot = Path("/Users/benebsworth/.local/share/mise/installs/go/1.27.2")
go = goroot/"bin/go"
env = os.environ | {"GOROOT": str(goroot), "GOTOOLCHAIN": "local", "GOOS": "linux", "GOARCH": "arm64",
                    "CGO_ENABLED": "0", "GOFLAGS": "-trimpath"}
config = json.loads(subprocess.check_output([go, "env", "-json", "GOCACHE", "GOFLAGS", "GOVERSION"], env=env, cwd=runner))
assert config == {"GOCACHE": "/Users/benebsworth/Library/Caches/go-build", "GOFLAGS": "-trimpath", "GOVERSION": "go1.27.2"}
job,test = stage/"job.ancestor",stage/"runner.ancestor.test"
flags = ["-mod=readonly","-trimpath","-p=2"]
commands = [
    ("build",["build",*flags,"-o",job,"."]),
    ("test-build",["test",*flags,"-c","-o",test,"."]),
    ("vet",["vet",*flags,"./..."]),
]
for name,args in commands:
    with (receipt/(name+".log")).open("xb") as log:
        subprocess.run([go,*args],cwd=runner,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
manifest = {"go_env": config, "flags": flags, "source_manifest_sha256": sha(source_manifest.read_bytes()),
    "job_sha256": sha(job.read_bytes()),"job_size": job.stat().st_size,"test_sha256": sha(test.read_bytes()),
    "test_size": test.stat().st_size,"changed": sorted(changed)}
write_json(receipt/"build.json",manifest)
print(json.dumps(manifest), flush=True)
