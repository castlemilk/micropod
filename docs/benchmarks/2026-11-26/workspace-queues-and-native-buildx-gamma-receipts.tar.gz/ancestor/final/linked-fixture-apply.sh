#!/bin/sh
set -eu
fixture=$1
ctr=/opt/micropod-oci/runner/bin/ctr
label=org.mobyproject.image.parent
"$ctr" --namespace k8s.io images import --local --digests --platform linux/arm64 "$fixture/images.tar" >&2
target_for_id() {
    printf '%s\n' "$rows" | awk -v name="$1" '$1 == name { print $3 }'
}
wait_for_ids() {
    for image_id in "$@"; do
        target=$(target_for_id "$image_id")
        case "$target" in
            sha256:*) [ "${#target}" -eq 71 ] || return 1 ;;
            *) return 1 ;;
        esac
    done
}
parent_id='sha256:61aa823b922381cf23eed5cabf7dc5fd61c300a8ac46bf5dfe106780e92d7952'
child_id='sha256:aab93b9592ab74e13e5b317d8114f434786561063c40a6d3422b1a58767b3eaa'
grandchild_id='sha256:8f00e06840cf941caf0a80f16b4f66be8b7679752d5357f792735bf793bec980'
sibling_id='sha256:1f00fdce377c6900b4aef6236940cd9a02314438303dc9d45185b0f836fa059f'
lookalike_id='sha256:8bc60590320c3a22d1dd98746c8ad5af8a057af2f5a0fbc568f77b4d361b16fc'
attempts=100
while :; do
    rows=$("$ctr" --namespace k8s.io images list)
    if wait_for_ids "$parent_id" "$child_id" "$grandchild_id" "$sibling_id" "$lookalike_id"; then
        break
    fi
    attempts=$((attempts-1))
    [ "$attempts" -gt 0 ] || exit 1
    sleep .05
done
parent_target=$(target_for_id "$parent_id")
child_target=$(target_for_id "$child_id")
[ "$parent_target" != "$child_target" ] && [ "$child_target" != "$(target_for_id "$grandchild_id")" ]
"$ctr" --namespace k8s.io images label "$child_id" "$label=$parent_target" >&2
"$ctr" --namespace k8s.io images label "$grandchild_id" "$label=$child_target" >&2
rows=$("$ctr" --namespace k8s.io images list)
printf '%s\n' "$rows" | awk -v id="$child_id" -v v="$label=$parent_target" '$1 == id && index($0,v) { found=1 } END { exit !found }'
printf '%s\n' "$rows" | awk -v id="$grandchild_id" -v v="$label=$child_target" '$1 == id && index($0,v) { found=1 } END { exit !found }'
printf 'ancestor fixture verified %s <- %s <- %s\n' "$parent_target" "$child_target" "$(target_for_id "$grandchild_id")" >&2
