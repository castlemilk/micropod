"""Verify the exact merged IID-target binary, ancestor source and seed before live replay."""
import argparse
import hashlib
import json
from pathlib import Path
import tarfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    return digest(path.read_bytes())


def list_section(path):
    return path.read_bytes().split(b"func dockerFilters(",1)[1].split(b"func (s *dockerEngine) wait(",1)[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("build","stage","tools","output"):
        parser.add_argument("--"+name, type=Path, required=True)
    args = parser.parse_args()
    evidence = Path(__file__).resolve().parent
    hub = evidence.parents[1]/"home"
    build = json.loads(args.build.read_bytes())
    runner_sha = build["runner_sha256"]
    assert runner_sha == sha(args.stage/"job.buildkit") == sha(args.tools/"runner/bin/job")
    assert build["test_sha256"] == sha(args.stage/"runner.buildkit.test")
    source_archive = args.build.with_name("source.tar.gz")
    assert build["source_archive_sha256"] == sha(source_archive)
    frozen = hub/"ancestor-candidate-final/source/guest/runner"
    module = args.stage/"source/guest/runner"
    names = ("docker_image_ancestor_linux.go","docker_image_ancestor_linux_test.go","docker_http_linux.go",
             "docker_image_id_delete_linux.go","docker_image_id_delete_linux_test.go",
             "docker_image_tag_linux.go","docker_image_tag_linux_test.go")
    actual = {}
    with tarfile.open(source_archive) as archive:
        for name in names:
            data = (module/name).read_bytes()
            assert data == archive.extractfile("guest/runner/"+name).read()
            assert digest(data) == build["source_files"][name]
            actual[name] = digest(data)
    for name in names[:2]:
        assert sha(frozen/name) == actual[name]
    assert list_section(module/"docker_http_linux.go") == list_section(frozen/"docker_http_linux.go")
    actual["container_list_and_filters_sha256"] = digest(list_section(module/"docker_http_linux.go"))
    linked = hub/"artifacts/tools-ancestor-final/runner/ancestor-fixture"
    added = args.tools/"runner/ancestor-fixture"
    seed={}
    for name in ("images.tar","apply.sh","manifest.json"):
        assert sha(linked/name) == sha(added/name)
        seed[name] = sha(added/name)
    result = {"job_sha256":runner_sha,"test_sha256":build["test_sha256"],"stage":str(args.stage),
              "build_receipt":str(args.build),"build_receipt_sha256":sha(args.build),"source":actual,"linked_fixture":seed}
    with args.output.open("x") as output:
        output.write(json.dumps(result,sort_keys=True,indent=2)+"\n")
    print(runner_sha)


if __name__ == "__main__":
    main()
