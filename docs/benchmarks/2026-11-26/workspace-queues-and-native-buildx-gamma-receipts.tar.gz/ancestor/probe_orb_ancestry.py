from pathlib import Path
from tempfile import TemporaryDirectory
from urllib.parse import urlencode
from uuid import uuid4
import hashlib
import json
import sys

workspace, results = map(Path, sys.argv[1:])
sys.path.insert(0, str(workspace / "scripts"))
from qualify_engine_api import Engine 
from qualify_docker_image_history import tar_bytes

run = uuid4().hex
owner = "io.micropod.fixture.ancestor"
repo = "micropod-qa/anc-" + run
branches = {"parent": [0], "child": [0, 1], "grandchild": [0, 1, 2], "lookalike": [0, 1, 3], "sibling": [0, 4]}
parents = {"child":"parent", "grandchild":"child"}
def idof(data): return "sha256:" + hashlib.sha256(data).hexdigest()
layers = [tar_bytes([(f"fixture-{i}", run.encode())]) for i in range(5)]
entries = [(f"layer-{i}.tar", layer) for i,layer in enumerate(layers)]
members, ids = [], {}
report = {"run": run, "rows": {}, "cleanup": {}}
with TemporaryDirectory(prefix="orb-anc-", dir=results.parent) as directory:
    config_dir = Path(directory)
    (config_dir / "config.json").write_text('{"auths":{"fixture.invalid":{}}}')
    engine = Engine(Path("/Users/benebsworth/.orbstack/run/docker.sock"), "alpine:3.23", None, None, api_version="1.47")
    engine.env["DOCKER_CONFIG"] = directory
    def read(path):
        code, _, data = engine.request("GET", path)
        return code, json.loads(data)
    def cli(*args, data=None, expect=True):
        p = engine.cli(*args, data=data, timeout=20)
        if expect and p.returncode:
            raise RuntimeError(f"docker {args}: {p.stderr.decode(errors='replace')}")
        return p
    info = read("/info")[1]
    report["storage"] = {k:info.get(k) for k in ("ServerVersion","Driver","DriverStatus")}
    for name, idx in branches.items():
        payload = json.dumps({"architecture":"arm64","os":"linux","config":{"Cmd":["/not-run"],"Labels":{owner:run}},
            "rootfs":{"type":"layers","diff_ids":[idof(layers[n]) for n in idx]},
            "history":[{"created_by":f"fixture-{n}"} for n in idx]}, separators=(",",":")).encode()
        id = ids[name] = idof(payload)
        config_name = id[7:] + ".json"
        entries.append((config_name,payload))
        row = {"Config":config_name,"RepoTags":[repo+":"+name],"Layers":[f"layer-{n}.tar" for n in idx]}
        if parent := parents.get(name):
            row["Parent"] = ids[parent]
        members.append(row)
    names = {}
    known_ids = {}
    try:
        cli("image","load","-q",data=tar_bytes([("manifest.json",json.dumps(members).encode()),*entries]))
        for k in branches:
            ref = repo+":"+k
            code, image = read("/images/"+ref+"/json")
            assert code == 200 and image["Config"]["Labels"].get(owner) == run
            known_ids[k] = image["Id"]
            names[k] = "mp-anc-"+run+"-"+k
            cli("create","--pull=never","--name",names[k],"--label",owner+"="+run,"--network=none",ref)
            report["rows"][k] = {"container_name":names[k],"image_id":image["Id"],"expected_config_id":ids[k],
                               "Parent":image.get("Parent"),"RepoDigests":image.get("RepoDigests"),"Layers":image["RootFS"]["Layers"]}
        report["stock"] = {}
        for ref in (repo+":parent", repo+":child", known_ids["parent"], known_ids["parent"][7:19], repo+":missing",
                    "bad reference", ids["parent"], idof(layers[0]), *report["rows"]["parent"]["RepoDigests"]):
            p = cli("ps","-a","--filter","label="+owner+"="+run,"--filter","ancestor="+ref,"--format","{{.Names}}",expect=False)
            report["stock"][ref] = {"exit":p.returncode, "rows":p.stdout.decode().splitlines(), "error":p.stderr.decode()}
        for tag, value in (("empty",{}), ("false",{repo+":parent":False}), ("invalid",7)):
            code, body=read("/containers/json?"+urlencode({"all":1,"filters":json.dumps({"label":[owner+"="+run],"ancestor":value})}))
            report.setdefault("raw_filter_shapes",{})[tag]={"status":code,"rows":[r["Names"][0] for r in body] if isinstance(body,list) else []}
    except Exception as exc:
        report["error"]=str(exc)
    finally:
        for k in reversed(branches):
            if k not in names:
                continue
            code,row=read("/containers/"+names[k]+"/json")
            if code==200:
                assert row["Config"]["Labels"].get(owner)==run
                cli("rm","-f",names[k])
            report["cleanup"][names[k]] = read("/containers/"+names[k]+"/json")[0]
        for k in reversed(branches):
            ref=repo+":"+k
            code,row=read("/images/"+ref+"/json")
            if code==200:
                assert row["Config"]["Labels"].get(owner)==run
                known_ids.setdefault(k,row["Id"])
                cli("image","rm","--no-prune",ref)
            report["cleanup"][ref] = read("/images/"+ref+"/json")[0]
            if k in known_ids:
                id=known_ids[k]
                code,row=read("/images/"+id+"/json")
                if code==200:
                    assert row["Config"]["Labels"].get(owner)==run and not row.get("RepoTags")
                    cli("image","rm","--no-prune","--force",id)
                report["cleanup"][id] = read("/images/"+id+"/json")[0]
    results.write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({"storage": report["storage"], "stock": report.get("stock"), "shapes":report.get("raw_filter_shapes"), "error":report.get("error"), "cleanup_ok":all(v==404 for v in report["cleanup"].values())}))
