"""Inspect genuine containerd classic-builder parent edges on the stock reference."""
import hashlib
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from uuid import uuid4
from urllib.parse import urlencode

workspace, results = map(Path, sys.argv[1:])
sys.path.insert(0, str(workspace / "scripts"))
from qualify_engine_api import Engine
from qualify_docker_image_history import tar_bytes

owner_key = "io.micropod.fixture.ancestor-built"
run = uuid4().hex
label = f"{owner_key}={run}"
repo = "micropod-qa/anc-built-" + run
roles = ("parent", "child", "grandchild")
tags = {role: f"{repo}:{role}" for role in roles}
names = {role: f"mp-anc-built-{run}-{role}" for role in roles}
def digest(data):
    return "sha256:" + hashlib.sha256(data).hexdigest()

with TemporaryDirectory(prefix="stock-parent-graph-", dir=results.parent) as config:
    (Path(config) / "config.json").write_text('{"auths":{"fixture.invalid":{}}}')
    engine = Engine(Path("/Users/benebsworth/.orbstack/run/docker.sock"), "alpine:3.23", None, None, api_version="1.47")
    engine.env.update(DOCKER_CONFIG=config, DOCKER_BUILDKIT="0")
    report = {"run": run, "tags": tags, "rows": {}, "cleanup": {}}
    role_ids = {}
    def read(path):
        code, _, body = engine.request("GET", path)
        return code, json.loads(body)
    def cli(*argv, data=None):
        result = engine.cli(*argv, data=data, timeout=25)
        if result.returncode:
            raise RuntimeError(f"{argv}: {result.stderr.decode(errors='replace')[-2500:]}")
        return result.stdout.decode()
    def inspect_image(role):
        code, image = read("/images/" + tags[role] + "/json")
        assert code == 200 and image["Config"]["Labels"].get(owner_key) == run
        return image

    try:
        base_layer = tar_bytes([("parent-fixture", run.encode())])
        base_config = json.dumps({
            "architecture":"arm64","os":"linux","config":{"Cmd":["/not-run"],"Labels":{owner_key:run}},
            "rootfs":{"type":"layers","diff_ids":[digest(base_layer)]},
            "history":[{"created_by":"COPY parent-fixture /parent-fixture"}],
        }, separators=(",",":")).encode()
        base_file = digest(base_config)[7:]+".json"
        manifest = [{"Config":base_file,"RepoTags":[tags["parent"]],"Layers":["parent.tar"]}]
        cli("image","load","-q",data=tar_bytes([("manifest.json",json.dumps(manifest).encode()),(base_file,base_config),("parent.tar",base_layer)]))
        for index, role in enumerate(roles):
            if index:
                previous=tags[roles[index-1]]
                dockerfile=(f"FROM {previous}\nCOPY fixture-{role} /fixture-{role}\n").encode()
                context=tar_bytes([("Dockerfile",dockerfile),(f"fixture-{role}",run.encode())])
                cli("build","--pull=false","--network=none","--force-rm","-t",tags[role],"-",data=context)
            image=inspect_image(role)
            role_ids[role]=image["Id"]
            report["rows"][role]={"image_id":image["Id"], "parent_id":image.get("Parent"),"layers":image["RootFS"]["Layers"]}
            cli("create","--pull=never","--name",names[role],"--label",label,"--network=none",tags[role])
        report["stock"]={}
        for role in roles:
            selected=cli("ps","-a","--filter","label="+label,"--filter","ancestor="+tags[role],"--format","{{.Names}}")
            report["stock"][role]=[name.removeprefix(f"mp-anc-built-{run}-") for name in selected.splitlines()]
        report["passed"]=report["stock"]=={"parent":["grandchild","child","parent"],"child":["grandchild","child"],"grandchild":["grandchild"]}
    except Exception as exc:
        report["error"]=str(exc)
    finally:
        for role in reversed(roles):
            name=names[role]
            code,row=read("/containers/"+name+"/json")
            if code==200:
                assert row["Config"]["Labels"].get(owner_key)==run
                cli("rm","-f",name)
            report["cleanup"][name]=read("/containers/"+name+"/json")[0]
            name=tags[role]
            code,row=read("/images/"+name+"/json")
            if code==200:
                assert row["Config"]["Labels"].get(owner_key)==run
                role_ids.setdefault(role,row["Id"])
                cli("image","rm","--no-prune",name)
            report["cleanup"][name]=read("/images/"+name+"/json")[0]
        left=cli("image","ls","--all","--quiet","--no-trunc","--filter","label="+label).splitlines()
        for image_id in dict.fromkeys([*reversed(role_ids.values()),*left]):
            code,row=read("/images/"+image_id+"/json")
            if code==200:
                assert row["Config"]["Labels"].get(owner_key)==run and not row.get("RepoTags")
                cli("image","rm","--force","--no-prune",image_id)
            report["cleanup"][image_id]=read("/images/"+image_id+"/json")[0]
    results.write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({**report,"fresh_images_left":cli("image","ls","--all","--quiet","--no-trunc","--filter","label="+label).splitlines()}))
