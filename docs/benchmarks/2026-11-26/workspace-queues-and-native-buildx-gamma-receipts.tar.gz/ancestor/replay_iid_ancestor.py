"""Replay the existing ancestor differential on the exact IID-enabled guest."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from urllib.parse import quote


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ready", type=Path, required=True)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--run-label", default="iid-wire-01")
    parser.add_argument("--preflight", type=Path, required=True)
    args = parser.parse_args()
    receipts = Path(__file__).resolve().parent
    output = receipts/args.run_label
    preflight = json.loads(args.preflight.read_bytes())
    assert sha(Path(preflight["build_receipt"])) == preflight["build_receipt_sha256"]
    ready = json.loads(args.ready.read_bytes())
    expected = preflight["job_sha256"]
    assert ready["owned_artifacts"]["job"]["sha256"] == expected
    native = Path(ready["socket"])
    assert native.is_socket() and args.reference.is_socket() and not native.samefile(args.reference)
    assert not output.exists()

    sys.path.insert(0, str(receipts/"replay-scripts"))
    from qualify_engine_api import Engine
    baseline = ("alpine:3.23", "registry.k8s.io/pause:3.10.2", ready["benchmark_image"])
    assert set(baseline) == {"alpine:3.23", "registry.k8s.io/pause:3.10.2", "micropod-qa/checkout:gamma6-x5vshe"}
    def sample():
        observed = {}
        for side, socket in (("reference", args.reference), ("native", native)):
            engine = Engine(socket, "alpine:3.23", None, None, api_version="1.47")
            rows = {}
            for ref in baseline:
                code, _, wire = engine.request("GET","/images/"+quote(ref,safe=":/")+"/json")
                row = json.loads(wire)
                rows[ref] = {"status":code,"id":row.get("Id"),"architecture":row.get("Architecture"),
                             "layers":row.get("RootFS",{}).get("Layers")}
            observed[side] = rows
        return observed

    before = sample()
    assert all(row["status"]==200 and row["id"] and row["layers"] for engine in before.values() for row in engine.values())
    stage = Path(preflight["stage"])
    command = [sys.executable,"-B",str(receipts/"run_wire_differential.py"),
               "--native-ready",str(args.ready),"--reference",str(args.reference),"--run-label",args.run_label,
               "--scripts",str(receipts/"replay-scripts-target"),
               "--build",preflight["build_receipt"],"--job",str(stage/"job.buildkit"),
               "--module",str(stage/"source/guest/runner")]
    exit_code = subprocess.run(command, check=False).returncode
    after = sample()
    report = {"job_sha256":expected,"ready_sha256":sha(args.ready),"replay_exit":exit_code,
              "before":before,"after":after,"passed":before==after and exit_code==0}
    (output/"exact-binary-preflight.json").write_bytes(args.preflight.read_bytes())
    with (output/"base-protection.json").open("x") as stream:
        stream.write(json.dumps(report,indent=2,sort_keys=True)+"\n")
    print(json.dumps({"passed":report["passed"],"base_images_verified":sum(len(rows) for rows in after.values()),
                      "replay_exit":exit_code, "receipt":str(output/"base-protection.json")}))
    return int(not report["passed"])


if __name__ == "__main__":
    raise SystemExit(main())
