"""Run the same imported fixture on stock and native, then verify native parent metadata."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--native-ready", type=Path, required=True)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--run-label", required=True)
    parser.add_argument("--scripts", type=Path)
    parser.add_argument("--build", type=Path, help="build receipt for a byte-matched derivative")
    parser.add_argument("--job", type=Path, help="built Linux job for a byte-matched derivative")
    parser.add_argument("--module", type=Path, help="frozen Go module for a byte-matched derivative")
    args = parser.parse_args()
    receipts = Path(__file__).resolve().parent
    hub = receipts.parents[1]/"home"
    stage = hub/"ancestor-candidate-final"
    output = receipts/args.run_label
    output.mkdir(mode=0o700, exist_ok=False)
    ordinary = stage/("ordinary-fixture-"+args.run_label)
    linked = hub/"ancestor-candidate/linked-fixture"
    scripts = output/"sources"
    shutil.copytree(args.scripts or receipts/"replay-scripts",scripts)
    recorded = json.loads((scripts/"sha256.json").read_bytes())
    assert all(sha(scripts/name) == value for name,value in recorded.items())
    harness = scripts/"qualify_docker_ancestor.py"
    if any((args.build, args.job, args.module)) and not all((args.build, args.job, args.module)):
        parser.error("--build, --job and --module must be supplied together")
    build = args.build or receipts/"final/build.json"
    frozen_module = stage/"source/guest/runner"
    module = args.module or frozen_module
    file_match = {}
    for name in ("docker_image_ancestor_linux.go", "docker_image_ancestor_linux_test.go"):
        file_match[name] = sha(module/name)
        assert file_match[name] == sha(frozen_module/name)
    def list_section(path):
        source = path.read_text()
        return source.split("func dockerFilters(",1)[1].split("func (s *dockerEngine) wait(",1)[0].encode()
    file_match["docker_http_linux.go:filters-and-list"] = hashlib.sha256(list_section(module/"docker_http_linux.go")).hexdigest()
    assert list_section(module/"docker_http_linux.go") == list_section(frozen_module/"docker_http_linux.go")
    ready = json.loads(args.native_ready.read_bytes())
    build_receipt = json.loads(build.read_bytes())
    job_sha = build_receipt.get("job_sha256") or build_receipt["runner_sha256"]
    assert job_sha == ready["owned_artifacts"]["job"]["sha256"]
    assert job_sha == sha(args.job or stage/"job.ancestor")
    native = Path(ready["socket"])
    assert native.is_socket() and args.reference.is_socket() and not native.samefile(args.reference)

    statuses = {"job_sha256":job_sha,"native_worker_receipt_sha256":sha(args.native_ready),
                "ancestor_source_sha256":file_match,"runs":{}}
    def evaluate(label, script, *argv):
        command = [sys.executable,"-B",str(script),*map(str,argv)]
        details = {"command":command,"start_unix":time.time()}
        statuses["runs"][label] = details
        with (output/(label+".log")).open("xb") as log:
            proc = subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=False,timeout=160)
        details.update(exit=proc.returncode, stop_unix=time.time())
        (output/"commands.json").write_text(json.dumps(statuses,indent=2,sort_keys=True)+"\n")
        return proc.returncode

    prepare = evaluate("prepare", harness,"prepare","--base-archive",hub/"artifacts/seed.tar","--directory",ordinary)
    if prepare:
        return prepare
    (output/"ordinary-fixture-manifest.json").write_bytes((ordinary/"manifest.json").read_bytes())
    args_by_arm = [
        ("reference-ordinary",args.reference,ordinary,[]),
        ("native-ordinary",native,ordinary,["--native"]),
    ]
    exits = [evaluate(label,harness,"probe","--socket",endpoint,"--directory",fixture,
                      "--output",output/(label+".json"),*flags) for label,endpoint,fixture,flags in args_by_arm]
    if any(exits):
        return 1
    if evaluate("native-linked",harness,"probe","--socket",native,"--directory",linked,
                "--output",output/"native-linked.json","--native","--linked"):
        return 1
    return evaluate("summary",receipts/"summarize_differential.py","--reference",output/"reference-ordinary.json",
        "--native",output/"native-ordinary.json","--linked-native",output/"native-linked.json",
        "--linked-reference",receipts/"stock-builder-01.json","--build",build,
        "--output",output/"summary.json")


if __name__ == "__main__":
    raise SystemExit(main())
