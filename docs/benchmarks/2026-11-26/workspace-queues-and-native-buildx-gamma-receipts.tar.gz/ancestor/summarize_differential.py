"""Check both raw replay profiles and genuine parent-graph observations."""
import argparse
import hashlib
import json
from pathlib import Path


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for role in ("reference", "native", "linked-native", "linked-reference", "build", "output"):
        parser.add_argument("--"+role, required=True, type=Path)
    args = parser.parse_args()
    ordinary_stock, ordinary_native = read(args.reference), read(args.native)
    linked_stock, linked_native = read(args.linked_reference), read(args.linked_native)
    assert all(report["passed"] for report in (ordinary_stock, ordinary_native, linked_stock, linked_native))
    assert ordinary_stock["run"] == ordinary_native["run"]
    assert ordinary_native["run"] != linked_native["run"]
    assert ordinary_stock["mode"] == {"native": False, "linked": False}
    assert ordinary_native["mode"] == {"native": True, "linked": False}
    assert linked_native["mode"] == {"native": True, "linked": True}
    assert all(report["base_preserved"] and len(report["cleanup"]) >= 17 and all(code == 404 for code in report["cleanup"].values())
               for report in (ordinary_stock, ordinary_native, linked_native))
    reference_cases, native_cases = ordinary_stock["cases"], ordinary_native["cases"]
    common = sorted(set(reference_cases) & set(native_cases))
    def observation(case):
        return {key: case.get(key) for key in ("all", "status", "raw_roles", "cli_roles")}
    differences = {name: {"reference": observation(reference_cases[name]), "native": observation(native_cases[name])}
                   for name in common if observation(reference_cases[name]) != observation(native_cases[name])}
    allowable = {"backend-config-id", "backend-manifest-id", "wrong-repository-digest"}
    assert set(differences) <= allowable, differences
    stock_rows = linked_stock["rows"]
    assert stock_rows["child"]["parent_id"] == stock_rows["parent"]["image_id"]
    assert stock_rows["grandchild"]["parent_id"] == stock_rows["child"]["image_id"]
    graph = {}
    for role, key in (("parent","tag"), ("child","child"), ("grandchild","grandchild")):
        rows = linked_native["cases"][key]["raw_roles"]
        reduced = [row for row in rows if row != "retained"]
        assert reduced == linked_stock["stock"][role]
        graph[role] = {"reference": linked_stock["stock"][role], "native": rows}
    build = read(args.build)
    metadata = {
        "job_sha256": build.get("job_sha256") or build["runner_sha256"],
        "api_version": "1.47",
        "operations": ["ContainerList"],
        "same_archive_group_counts": {"compared": len(common), "matched": len(common)-len(differences),
                                      "different": len(differences)},
        "same_archive_differences": differences,
        "stock_only_cases": sorted(set(reference_cases).difference(native_cases)),
        "native_only_cases": sorted(set(native_cases).difference(reference_cases)),
        "native_linked_groups": len(linked_native["cases"]),
        "linked_reference_vs_native": graph,
        "inputs_sha256": {path.name: sha(path) for path in (args.reference,args.native,args.linked_native,args.linked_reference,args.build)},
        "cleanup": {arm: {"checked":len(report["cleanup"]), "all_404":all(code == 404 for code in report["cleanup"].values()),
                          "base_preserved": report["base_preserved"]}
                    for arm,report in (("stock",ordinary_stock),("native",ordinary_native),("native_linked",linked_native))},
    }
    with args.output.open("x") as stream:
        stream.write(json.dumps(metadata, indent=2, sort_keys=True)+"\n")
    print(json.dumps(metadata, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
