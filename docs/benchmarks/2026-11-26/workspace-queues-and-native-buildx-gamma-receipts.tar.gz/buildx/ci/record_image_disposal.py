"""Link scoped native CRI inventory remnants to the completed worker retirement."""
from pathlib import Path
import hashlib
import json

folder = Path(__file__).resolve().parent
receipts = folder.parents[1]
evidence = {
    'original_api_rows': folder / 'docker-api-1.47-cleanup-stale-details.json',
    'real_image_removal': folder / 'docker-api-1.47-buildx-owned-id-recovery.json',
    'retirement': receipts / 'buildkit-ci-worker.json',
}
records = {key: json.loads(path.read_bytes()) for key, path in evidence.items()}

api = records['original_api_rows']
recovered = records['real_image_removal']
verified = api['inspect_scoped_rows'][recovered['image_id']]
assert verified['role'] == 'buildx-local-export' and verified['listed_labels_match']
assert verified['config_inspect']['status'] == 200 and verified['tag'] == recovered['tag']
assert recovered['remove_exit'] == 0 and recovered['after']['status'] == recovered['tag_after']['status'] == 404
assert recovered['owner'] == api['audit_scope'] and recovered['base_preserved']

ghosts = {}
for config, row in api['inspect_scoped_rows'].items():
    if config != recovered['image_id']:
        assert row['listed_labels_match'] and row['config_inspect']['status'] == row['tag_inspect']['status'] == 404
        assert len(row['digest_inspects']) == 3 and all(item['status'] == 404 for item in row['digest_inspects'].values())
        ghosts[config] = {'role': row['role'], 'tag': row['tag'], 'all_404_aliases': sorted(row['digest_inspects'])}
assert len(ghosts) == 3

worker = records['retirement']
policy = worker['drive']['detached']['persisted_policy']
assert worker['owned_artifacts']['job']['sha256'] == 'b94297383b7567a330ddb69bb856f0649a8254eee1d0395ffc625b50ac774772'
assert worker['scope_absent'] and worker['machine']['clean_shutdown']
assert worker['machine']['socket_removed'] and worker['machine']['supervisor_lock_released']
assert policy['mounted_read_only'] and policy['raw_disk_unchanged'] and policy['spotlight']['disabled']
assert policy['fsevents']['journal_files'] == policy['fsevents']['journal_bytes'] == 0
assert worker['drive']['detached']['image_absent'] and not Path(worker['image']).exists()
for path in (worker['worker_directory'], worker['socket']):
    assert not Path(path).exists()

summary = {
    'schema': 'gamma6-scoped-cri-inventory-disposal-v1',
    'audit_scope': api['audit_scope'],
    'verified_real_image_removed_by_id': recovered['image_id'],
    'stale_inventory_rows_with_no_public_reference': ghosts,
    'private_disk_retirement_verified': True,
    'raw_read_only_remount_verified': True,
    'inputs': {str(path.relative_to(receipts)): hashlib.sha256(path.read_bytes()).hexdigest()
               for path in evidence.values()},
}
with (folder / 'docker-api-1.47-stale-row-private-disposal.json').open('x') as result:
    json.dump(summary, result, indent=2, sort_keys=True)
    result.write('\n')
