"""Record a combined runner and verify a patch against the previous qualified source tree."""
import argparse
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import tempfile

def sha(path):
    with path.open("rb") as src:
        return hashlib.file_digest(src, "sha256").hexdigest()

p = argparse.ArgumentParser(description=__doc__)
for name in ("base", "phase", "out", "previous"):
    p.add_argument("--"+name, type=Path, required=True)
args = p.parse_args()
base, phase, out = args.base.resolve(), args.phase.resolve(), args.out.resolve()
src = phase / "source/guest/runner"
meta = json.loads(args.previous.read_bytes())
files = {f.name:sha(f) for f in sorted(src.iterdir()) if f.is_file()}
assert set(meta["source_files"]).issubset(files)
changes = [f for f in files if not (base/f).is_file() or sha(base/f) != files[f]]
diff = out/"d6be-to-buildkit.patch"
with diff.open("w") as stream:
    for f in changes:
        before = (base/f).read_text().splitlines(True) if (base/f).exists() else []
        stream.writelines(difflib.unified_diff(before,(src/f).read_text().splitlines(True),
                                               fromfile="a/"+f if (base/f).exists() else "/dev/null", tofile="b/"+f))
with tempfile.TemporaryDirectory(dir=phase) as tmp:
    replay = Path(tmp)/"source"
    shutil.copytree(base,replay)
    subprocess.run(["git","apply","--whitespace=error",str(diff)],cwd=replay,check=True)
    assert files == {f.name:sha(f) for f in replay.iterdir() if f.is_file()}
archive = out/"source.tar.gz"
with archive.open("wb") as f, gzip.GzipFile(filename="",fileobj=f,mode="wb",mtime=0) as gz, tarfile.open(fileobj=gz,mode="w") as tar:
    for name in files:
        data = src/name
        info = tarfile.TarInfo("guest/runner/"+name)
        info.size, info.mode = data.stat().st_size, 0o644
        with data.open("rb") as source:
            tar.addfile(info, source)
meta.update(source_files=files, changed=changes, source_archive_sha256=sha(archive), patch_sha256=sha(diff),
            runner_sha256=sha(phase/"job.buildkit"), test_sha256=sha(phase/"runner.buildkit.test"),
            qualifier_sha256=sha(out/"qualify_native_buildx.py"), patch_replay_all_sources_verified=True)
(out/"source.json").write_text(json.dumps(meta,indent=2)+"\n")
print(f"{len(files)} inputs verified, {len(changes)} changed; runner {meta['runner_sha256']}, tests {meta['test_sha256']}")
