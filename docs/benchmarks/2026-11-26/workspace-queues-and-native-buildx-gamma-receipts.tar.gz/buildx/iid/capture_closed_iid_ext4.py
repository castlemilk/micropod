"""Capture only descriptor-named OCI metadata from a stopped owned Gamma6 disk."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from datetime import datetime, timezone

directory = Path(__file__).resolve().parent
receipts = directory.parents[1]
ready = json.loads((receipts / 'buildkit-iid-retry-ready.json').read_text())
index_digest = '31691f6a3bd8e0f4a6077515fabf6ca948a44396d492f1fc51d2cebf06888582'
attestation_digest = 'e41b6817e061c424656567d10da3373c0e8aeb0461dfbf406f7fd2d4a46be12f'
oci = directory / 'default-native-oci'
scope = Path(ready['public_scope']).resolve(strict=True)
worker = Path(ready['worker_directory']).resolve(strict=True)
volume = worker / 'home'
machine = scope / 'machine'
raw = machine / 'disk.ext4'
socket = Path(ready['socket'])
release = Path(ready['release_file'])
assert (worker.parent == Path('/private/tmp') and worker.name.startswith('mpg6-buildkit-iid-retry-')
        and volume.is_mount() and scope.parent == volume and scope.name.startswith('outer-machine-')
        and raw.is_file() and not raw.is_symlink() and socket == machine / 'run/docker.sock'
        and release == scope / 'release' and not os.path.lexists(release))
native = ready['environment']
assert native['MICROPOD_HVF_ROOT'] == str(machine) and native['HOME'] == str(scope / 'home')
endpoint = 'unix:///Users/benebsworth/.orbstack/run/docker.sock'
docker = '/opt/homebrew/bin/docker'
reference = [docker, '--host', endpoint]
env = {k: v for k, v in os.environ.items() if k not in
       ('DOCKER_CONTEXT', 'DOCKER_HOST', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY',
        'DOCKER_CERT_PATH', 'DOCKER_API_VERSION')}
scope_label = 'io.micropod.qa.debugfs=iid-attestation-x5vshe'
sys.path.insert(0, str(receipts))
import outer_machine_proof as proof

receipt = {'schema': 'gamma6-closed-ext4-oci-attestation-v1',
           'started_utc': datetime.now(timezone.utc).isoformat(), 'worker': str(worker), 'reads': []}


def run(args, environment, timeout=10):
    return subprocess.run(args, env=environment, timeout=timeout, capture_output=True)


def detail(result):
    return {'argv': result.args, 'exit': result.returncode,
            'stdout': result.stdout.decode().strip(), 'stderr': result.stderr.decode().strip()}


def identity(path):
    stat = path.stat()
    return {'device': stat.st_dev, 'inode': stat.st_ino, 'logical_bytes': stat.st_size,
            'mtime_ns': stat.st_mtime_ns, 'ctime_ns': stat.st_ctime_ns}


def read_blob(descriptor):
    digest = descriptor['digest'].removeprefix('sha256:')
    expected_length = descriptor['size']
    assert descriptor['digest'] == 'sha256:' + digest and re.fullmatch(r'[a-f0-9]{64}', digest)
    assert isinstance(expected_length, int) and 0 < expected_length <= 65536
    blob_path = '/var/lib/containerd/io.containerd.content.v1.content/blobs/sha256/' + digest
    image = ready['benchmark_image']
    metadata = run(reference + ['run', '--rm', '--pull=never', '--read-only', '--network=none', '--cap-drop=ALL',
                   '--label', 'io.micropod.qa.round=gamma6-x5vshe', '--label', scope_label,
                   '--mount', f'type=bind,src={raw},dst=/owned.ext4,readonly', '--entrypoint', '/usr/sbin/debugfs',
                   image, '-R', 'cat ' + blob_path, '/owned.ext4'], env, timeout=20)
    actual = hashlib.sha256(metadata.stdout).hexdigest()
    row = {'argv': metadata.args, 'exit': metadata.returncode, 'stderr': metadata.stderr.decode().strip(),
           'expected_digest': digest, 'actual_digest': actual, 'expected_bytes': expected_length,
           'actual_bytes': len(metadata.stdout)}
    receipt['reads'].append(row)
    assert metadata.returncode == 0 and actual == digest and len(metadata.stdout) == expected_length, row
    with (oci / (digest + '.json')).open('xb') as output:
        output.write(metadata.stdout)
    return json.loads(metadata.stdout)


try:
    prior = json.loads((directory / 'default-native-closed-ext4-first-attempt.json').read_text())
    assert prior['native_before_stop']['exit'] == 0 and not prior['native_before_stop']['stdout']
    assert prior['native_graceful_stop']['exit'] == 0 and not os.path.lexists(socket)
    receipt['native_before_stop'] = prior['native_before_stop']
    receipt['native_graceful_stop'] = prior['native_graceful_stop']
    receipt['failed_first_global_lsof_timeout_seconds'] = 35
    status = run([str(scope / 'micropod'), 'machine', 'status', '--json'], native)
    assert status.returncode == 0, detail(status)
    state = json.loads(status.stdout)
    receipt['native_stopped_status'] = state
    assert state['phase'] == 'stopped' and not state['supervisorAlive'] and not os.path.lexists(socket), state
    assert state['state']['lastExitCode'] == 0 and 'exit_reason=poweroff' in state['state']['lastExitReason']
    with (machine / 'run/supervisor.lock').open('rb') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    table = proof.process_table()
    owned_processes = proof.scoped_processes(table, scope)
    assert not owned_processes, owned_processes
    for pid, row in ready['machine']['running_processes'].items():
        assert table.get(pid, {}).get('start') != row['start']
    receipt['owned_disk_writers_after_lock_release'] = owned_processes
    before = identity(raw)
    assert all(before[k] == ready['raw_disk_live'][k] for k in ('device', 'inode', 'logical_bytes'))
    receipt['raw_before'] = before
    index_bytes = (oci / (index_digest + '.json')).read_bytes()
    assert hashlib.sha256(index_bytes).hexdigest() == index_digest and len(index_bytes) == 855
    items = [desc for desc in json.loads(index_bytes)['manifests'] if desc['digest'] == 'sha256:' + attestation_digest]
    assert len(items) == 1
    manifest = read_blob(items[0])
    receipt['attestation_media_type'] = manifest['mediaType']
    receipt['attestation_subject'] = manifest.get('subject')
    receipt['attestation_config'] = manifest['config']
    config = read_blob(manifest['config'])
    receipt['attestation_config_top_level_fields'] = sorted(config)
    assert before == identity(raw), 'Closed disk changed during read'
    receipt['raw_unchanged'] = True
finally:
    clean = run(reference + ['ps', '-aq', '--no-trunc', '--filter', 'label=' + scope_label], env)
    receipt['orb_comparator_cleanup'] = detail(clean)
    receipt['ended_utc'] = datetime.now(timezone.utc).isoformat()
    with (directory / 'default-native-closed-ext4-capture.json').open('x') as output:
        json.dump(receipt, output, indent=2, sort_keys=True)
        output.write('\n')
    assert clean.returncode == 0 and not clean.stdout, 'Scoped read-only comparator remains'

request = {'release': str(release), 'utc': datetime.now(timezone.utc).isoformat(), 'remaining_containers': [],
           'prior_poweroff': True, 'closed_disk_attestation': 'buildx/iid/default-native-closed-ext4-capture.json'}
with (receipts / 'buildkit-iid-retry-release-request.json').open('x') as output:
    json.dump(request, output)
    output.write('\n')
release.open('x').close()
sys.stdout.write(json.dumps({'capture': str(oci), 'reads': receipt['reads'], 'release': str(release)}) + '\n')
