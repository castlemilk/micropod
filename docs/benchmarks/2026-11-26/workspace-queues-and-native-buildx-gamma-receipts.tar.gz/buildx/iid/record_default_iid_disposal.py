"""Tie retired default-provenance images to their verified private disk disposition."""
import hashlib
import json
from pathlib import Path

base = Path(__file__).resolve().parent
receipts = base.parents[1]
inventory_path = base / 'default-native-disposal-inventory.json'
capture_path = base / 'default-native-closed-ext4-capture.json'
worker_path = receipts / 'buildkit-iid-retry-worker.json'

def read(path):
    return json.loads(path.read_bytes())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

inventory = read(inventory_path)
capture = read(capture_path)
worker = read(worker_path)
machine = worker['machine']
policy = worker['drive']['detached']['persisted_policy']
contained = inventory['owned_scoped_images']
assert len(contained) == len({entry['config_id'] for entry in contained}) == 3
assert all(not row['tags'] and not row['digests'] for row in contained)
assert all(inventory['original_tags_absent'].values()) and inventory['capture_alias_cleanup']['absent']
assert capture['raw_unchanged'] and capture['worker'] == worker['worker_directory']
assert not capture['native_before_stop']['stdout'] and not capture['orb_comparator_cleanup']['stdout']
assert machine['clean_shutdown'] and machine['socket_removed'] and machine['supervisor_lock_released']
assert policy['mounted_read_only'] and policy['raw_disk_unchanged']
assert policy['spotlight']['disabled'] and policy['fsevents']['journal_files'] == policy['fsevents']['journal_bytes'] == 0
assert worker['scope_absent'] and worker['drive']['detached']['image_absent']
assert not Path(worker['image']).exists() and not Path(worker['worker_directory']).exists()
receipts_used = {str(path.relative_to(receipts)): sha(path) for path in (inventory_path, capture_path, worker_path)}
evidence = {'fixture_label_key': 'io.micropod.qa.default-buildx', 'verified_fixture_images': contained,
            'cleanup': 'verified destruction of the fixture-owned raw disk after read-only remount',
            'scope_absent': True, 'image_absent': True, 'read_only_remount_verified': True,
            'receipt_sha256': receipts_used}
with (base / 'default-native-private-disposal.json').open('x') as file:
    json.dump(evidence, file, indent=2, sort_keys=True)
    file.write('\n')
