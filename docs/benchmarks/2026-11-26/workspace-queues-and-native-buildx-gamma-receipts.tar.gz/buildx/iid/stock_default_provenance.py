"""Build and run with the stock provenance defaults on a named private fixture."""
import argparse, hashlib, json, os, pathlib, secrets, shutil, subprocess, tempfile
p = argparse.ArgumentParser(description=__doc__)
for option in ("socket", "scratch", "ctr", "plugin", "out"):
    p.add_argument("--" + option, type=pathlib.Path, required=True)
args = p.parse_args()
token = secrets.token_hex(7)
key = "io.micropod.qa.default-buildx"
tag = "micropod-qa/buildx-provenance:" + token
name = "mp-buildx-provenance-" + token
report = dict(calls=[], tag=tag, passed=False)
with tempfile.TemporaryDirectory(dir=args.scratch) as tmp:
    root = pathlib.Path(tmp)
    cfg = root / "docker"
    cfg.mkdir()
    (cfg / "config.json").write_text(json.dumps({"cliPluginsExtraDirs": [str(args.plugin)]}))
    env = {k:v for k,v in os.environ.items() if not k.startswith(("DOCKER_", "BUILDX_", "BUILDKIT_"))}
    env.update(HOME=tmp, DOCKER_CONFIG=str(cfg), BUILDX_CONFIG=str(root/"builder"), DOCKER_HOST="unix://"+str(args.socket))
    def docker(*args, required=True):
        cmd = ["docker",*map(str,args)]
        r = subprocess.run(cmd, capture_output=True, env=env, text=True, timeout=60)
        report["calls"].append(dict(argv=cmd, code=r.returncode, stdout=r.stdout, stderr=r.stderr))
        if required:
            r.check_returncode()
        return r
    ctx = root/"context"
    ctx.mkdir()
    shutil.copy2(args.ctr,ctx/"ctr")
    (ctx/"Dockerfile").write_text('FROM scratch\nCOPY ctr /ctr\nENTRYPOINT ["/ctr"]\n')
    try:
        docker("buildx","inspect","default")
        docker("buildx","build","--builder","default","--progress","plain","--network","none","--load","--tag",tag,
               "--iidfile",root/"iid","--metadata-file",root/"metadata.json","--label",key+"="+token,ctx)
        report["iid"] = (root/"iid").read_text().strip()
        report["metadata"] = json.loads((root/"metadata.json").read_text())
        by_tag, = json.loads(docker("image","inspect",tag).stdout)
        report["tag_id"] = by_tag["Id"]
        if by_tag["Config"]["Labels"].get(key) != token:
            raise ValueError("tag label mismatch")
        by_id, = json.loads(docker("image","inspect",report["iid"]).stdout)
        if by_tag["Id"] != by_id["Id"]:
            raise ValueError("tag and iid resolve to different images")
        val = docker("run","--pull=never","--network","none","--rm","--label",key+"="+token,"--name",name,report["iid"],"--version").stdout
        if "containerd" not in val or "ctr" not in val:
            raise ValueError("runnable entrypoint mismatch")
        report["passed"] = True
    except Exception as err:
        report["error"] = str(err)
    finally:
        remaining = docker("ps","-aq","--filter","label="+key+"="+token).stdout.split()
        if remaining:
            docker("rm","-f",*remaining)
        current = docker("image","inspect",tag,required=False)
        owned = []
        if not current.returncode:
            record = json.loads(current.stdout)[0]
            if (record.get("Config",{}).get("Labels") or {}).get(key) == token:
                owned.append(record["Id"])
        docker("image","rm",tag,required=False)
        for identity in set(owned):
            check = docker("image","inspect",identity,required=False)
            if not check.returncode and (json.loads(check.stdout)[0].get("Config",{}).get("Labels") or {}).get(key) == token:
                docker("image","rm","-f",identity,required=False)
        leftovers = [i for i in owned if docker("image","inspect",i,required=False).returncode == 0]
        report["cleanup_verified"] = not leftovers and not docker("ps","-aq","--filter","label="+key+"="+token).stdout.strip() and docker("image","inspect",tag,required=False).returncode != 0
        args.out.write_text(json.dumps(report,indent=2)+"\n")
raise SystemExit(0 if report["passed"] and report["cleanup_verified"] else 1)
