"""Summarize checked label selection and CLI display counts from the frozen audit."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path

base = Path(__file__).resolve().parent
paths = {
    "audit": base/"docker-api-1.47.json.gz",
    "prior": base.parent/"release/docker-api-1.47.json.gz",
    "cleanup": base/"docker-api-1.47-cleanup.json",
    "alias_witness": base/"docker-api-1.47-cli-alias-differential.json",
    "build": base/"source.json",
}
payload = {name:path.read_bytes() for name,path in paths.items()}
records = {name:json.loads(gzip.decompress(data) if paths[name].suffix==".gz" else data)
           for name,data in payload.items()}
audit, prior, cleanup, evidence, build = (records[key] for key in ("audit","prior","cleanup","alias_witness","build"))
assert audit["version"] == audit["cli_api_version"] == "1.47" and audit["profile"]=="full"
assert audit["spec_sha256"] == prior["spec_sha256"]
assert build["runner_sha256"] == evidence["job_sha256"] == "eb363bff62ac2349f37a71d6a7db3a6ec2b813b0c470adf44b60ef19f41d4ed4"
strict=Counter(row["comparison"] for row in audit["candidate"].values())
assert strict=={"matched":15,"different":12}
assert audit["candidate"]["image-list-labels"]["comparison"]=="different"
assert all(audit[side][key]==value for side in ("reference","candidate") for key,value in prior[side].items())
assert all(set(audit[side])-set(prior[side])=={"image-list-labels"} for side in ("reference","candidate"))
assert all(row=={"status":200,"returned":0,"matching":0} for side in cleanup.values() for row in side.values())
assert set(cleanup)=={"reference","candidate"} and all(set(side)=={"containers","images","networks","volumes"} for side in cleanup.values())
operations={name for name,row in audit["operations"].items() if "cases" in row}
old_operations={name for name,row in prior["operations"].items() if "cases" in row}
assert (len(operations),len(audit["operations"]),operations-old_operations)==(39,107,{"ImageList"})

sides=("reference","candidate")
labels={side:audit[side]["image-list-labels"]["observed"] for side in sides}
matrix={}
role_cases={
    "key-only":["empty","selected"],"exact":["empty","selected"],"conjunction":["selected"],
    "empty-value":["empty"],"absent-is-not-empty":[],"wrong-value":[],"missing-key":[],
}
for name,roles in role_cases.items():
    expected={"status":200,"roles":roles,"rows":len(roles),"unexpected_rows":0}
    cli={}
    for side in sides:
        row=labels[side][name]
        assert {k:v for k,v in row.items() if k not in ("cli","cli_exit")}==expected
        out=row["cli"]
        unique=sorted(set(out["roles"]))
        assert unique==roles and out["unexpected_rows"]==0 and out["rows"]==len(out["roles"])
        line_count=len(roles)*(1 if side=="reference" else 2)
        assert row["cli_exit"]==0 and out["rows"]==line_count
        cli[side]={"exit":row["cli_exit"],"unique_selected_roles":unique,"raw_lines":out["rows"],
                   "unexpected_lines":out["unexpected_rows"]}
    matrix[name]={"api_matches_exactly":True,"api":expected,"stock_cli":cli,"same_unique_selection":True}
for name,expected in {
    "empty-set":{"status":200,"same_as_unfiltered":True},
    **{name:{"status":400,"json_message":True} for name in ("malformed-json","malformed-values","unknown-filter")},
}.items():
    assert labels["reference"][name]==labels["candidate"][name]==expected
    matrix[name]={"api_matches_exactly":True,"api":expected}
assert all(all(snapshot["cleanup"].values()) for snapshot in labels.values())

repositories={}
for side,case in evidence["sides"].items():
    assert all(case["cleanup"].values()) and case["scope_after"]=={"status":200,"rows":0}
    raw,map_style=case["key_only_wire"]["array"],case["key_only_wire"]["cli_set"]
    assert raw["status"]==map_style["status"]==200 and len(raw["body"])==2
    assert sorted(raw["body"],key=lambda row:row["Id"])==sorted(map_style["body"],key=lambda row:row["Id"])
    observed=case["key_only_observed"]
    assert observed==labels[side]["key-only"]
    links=[]
    for row in raw["body"]:
        tag,=row["RepoTags"]
        alias,=row["RepoDigests"]
        tag_repo=tag.rsplit(":",1)[0]
        digest_repo,digest=alias.split("@",1)
        assert (tag_repo==digest_repo)==(side=="reference")
        links.append({"scoped_tag":tag,"advertised_digest":alias,"image_id":row["Id"],
                      "same_repository":tag_repo==digest_repo})
    repositories[side]={"array_and_map_same_rows":True,"rows":links,"raw_cli_lines":observed["cli"]["rows"],
                        "extra_lines_for_distinct_digest_repository":observed["cli"]["rows"]-len(links)}
report={"job_sha256":build["runner_sha256"],"api_version":"1.47","profile":"full","strict_group_counts":dict(strict),
    "total_groups":len(audit["candidate"]),"probed_operations":len(operations),"total_operations":len(audit["operations"]),
    "added_operations":sorted(operations-old_operations),"existing_group_comparison_changes":[],
    "matched_raw_api_probes":len(matrix),"stock_cli_unique_selection_probes":len(role_cases),"label_probes":matrix,
    "strict_scope_cleanup":cleanup,"fixture_cleanup":{side:labels[side]["cleanup"] for side in sides},
    "independent_key_only_alias_witness":repositories,
    "inputs_sha256":{key:hashlib.sha256(data).hexdigest() for key,data in payload.items()}}
with (base/"docker-api-1.47-adjudication.json").open("x") as out:
    out.write(json.dumps(report,indent=2,sort_keys=True)+"\n")
print("15/27 strict, 39/107 operations, 11/11 raw label probes and 7/7 unique stock CLI selections")
