"""Run the pinned full Engine API profile and its strict scoped cleanup."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ready", type=Path, required=True)
    parser.add_argument("--reference", type=Path, required=True)
    args = parser.parse_args()
    folder = Path(__file__).resolve().parent
    receipts = folder.parents[1]
    hub = receipts.parent/"home"
    client = hub/"stock-buildx"
    pack = json.loads((folder/"source.json").read_bytes())
    qualifier = folder/"qualify_engine_api.py"
    helper = receipts/"image-list-labels/post-diagnosis"
    assert sha(qualifier) == sha(helper/"qualify_engine_api.py") == "5d6de4a3bf77de50be4e9db997866679782e33d83f2e5a4ff7aebd83ffeccdee"
    spec = client/"docker-v1.47.yaml"
    assert sha(spec) == "f44c4514b5893e043cbe3e1675b67b9eed86fc26b6c15144bddcb02c46d2ca7e"
    ready = json.loads(args.ready.read_bytes())
    job = pack["runner_sha256"]
    assert job == ready["owned_artifacts"]["job"]["sha256"] == sha(hub/"buildkit-inventory/job.buildkit")
    assert job == "eb363bff62ac2349f37a71d6a7db3a6ec2b813b0c470adf44b60ef19f41d4ed4"
    native = Path(ready["socket"])
    assert native.is_socket() and args.reference.is_socket() and not native.samefile(args.reference)
    builder = client/"api-inventory-buildx"
    builder.mkdir(mode=0o700, exist_ok=False)
    database = client/"api-inventory.sqlite"
    audit = folder/"docker-api-1.47.json.gz"
    cleanup = folder/"docker-api-1.47-cleanup.json"
    assert not audit.exists() and not database.exists() and not cleanup.exists()
    environment = os.environ|{"DOCKER_CONFIG":str(client/"docker"),"BUILDX_CONFIG":str(builder),"PYTHONPATH":str(helper)}
    for name in ("DOCKER_HOST","DOCKER_CONTEXT","DOCKER_TLS","DOCKER_TLS_VERIFY","DOCKER_CERT_PATH","DOCKER_API_VERSION","DOCKER_CUSTOM_HEADERS"):
        environment.pop(name,None)

    subjects = ("--reference",str(args.reference),"--candidate",str(native))
    commands = {
        "audit": [sys.executable,"-B",str(qualifier),*subjects,"--reference-image","alpine:3.23",
                  "--candidate-image","alpine:3.23","--api-version","1.47","--spec",str(spec),"--output",str(audit),
                  "--database",str(database)],
        "cleanup": [sys.executable,"-B",str(folder/"verify_api_cleanup.py"),*subjects,"--audit",str(audit),"--out",str(cleanup)],
        "summary": [sys.executable,"-B",str(receipts/"image-list-labels/summarize_image_list_audit.py"),"--audit",str(audit),
                    "--prior",str(receipts/"buildx/release/docker-api-1.47.json.gz"),"--cleanup",str(cleanup),
                    "--build",str(folder/"source.json"),"--output",str(folder/"docker-api-1.47-summary.json")],
    }
    (folder/"docker-api-1.47-command.json").write_text(json.dumps({"job_sha256":job, "ready_sha256":sha(args.ready),
        "qualifier_sha256":sha(qualifier),"cleanup_driver_sha256":sha(folder/"verify_api_cleanup.py"),
        "profile":"full","buildx_config":str(builder),"argv":commands},indent=2,sort_keys=True)+"\n")
    for stage in ("audit","cleanup","summary"):
        stem = "docker-api-1.47" + ("-"+stage if stage!="audit" else "")
        with (folder/(stem+".log")).open("xb") as log:
            result = subprocess.run(commands[stage],env=environment,stdout=log,stderr=subprocess.STDOUT,check=False)
        (folder/(stem+".exit")).write_text(str(result.returncode)+"\n")
        print(f"{stage} exit={result.returncode}",flush=True)
        if stage == "audit" and result.returncode in (0,1) and audit.exists():
            continue
        if result.returncode:
            return result.returncode
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
