#!/bin/sh
# Run once in a disposable guest's trusted tools bank, after traced and timed work.
set -eu
umask 077

workspace=${MICROPOD_ENGINE_WORKSPACE:?}
request="$workspace/.workspace-local-completion.request"
receipt="$workspace/.workspace-local-completion.done"
owner="$(dirname "$0")/.workspace-local-completion.owner"
setting=/sys/module/virtiofs/parameters/workspace_local_completion
IFS= read -r token < "$owner"
case "$token" in ''|*[!0-9a-f]*) exit 1 ;; esac
[ "${#token}" -eq 32 ]
token_hash=$(printf '%s' "$token" | sha256sum | cut -d ' ' -f 1)
deadline=$(($(cut -d . -f 1 /proc/uptime) + 300))
while [ ! -f "$request" ]; do
    [ "$(cut -d . -f 1 /proc/uptime)" -lt "$deadline" ] || exit 0
    sleep 0.1
done
[ ! -L "$request" ]
[ "$(stat -c %s "$request")" = 33 ]
[ ! -e "$receipt" ]
[ ! -L "$receipt" ]
IFS= read -r provided < "$request"
[ "$provided" = "$token" ]

case "${1:-require-switch}" in require-switch|--allow-unavailable) ;; *) exit 1 ;; esac
if [ "$#" = 1 ] && [ "$1" = --allow-unavailable ] && [ ! -e "$setting" ]; then
    mode=unavailable
else
    mode=$(cat "$setting")
    case "$mode" in N|Y) ;; *) exit 1 ;; esac
fi
[ "$(cat /sys/module/virtiofs/parameters/workspace_async_release)" = Y ]

scratch=$(mktemp -d /run/mp-local-completion.XXXXXX)
mount_a="$scratch/a"
mount_b="$scratch/b"
leaf="local-completion-$(basename "$scratch")"
fixture="$workspace/$leaf"
reason=invalid_workspace
have_a=0 have_b=0 have_fixture=0 restore_workspace=0
children=

workspace_device() {
    awk -v path="$workspace" '
        $5 == path {
            for (i = 7; i <= NF; i++) {
                if ($i != "-") continue
                if ($(i+1) == "virtiofs" && $(i+2) == "workspace" && $3 ~ /^[0-9]+:[0-9]+$/) good = $3
                break
            }
            seen++
        }
        END { if (seen == 1 && good != "") print good; else if (seen != 0) exit 1 }
    ' /proc/self/mountinfo
}

restore_mount() {
    present=$(workspace_device) || return 1
    [ -z "$present" ] || return 1
    timeout 8 mount -t virtiofs -o nosuid,nodev workspace "$workspace"
}

set_mode() {
    case "$1" in N) number=0 ;; Y) number=1 ;; *) return 1 ;; esac
    printf '%s\n' "$number" > "$setting" && [ "$(cat "$setting")" = "$1" ]
}

cleanup() {
    code=$?
    trap - EXIT HUP INT TERM
    set +e
    if [ -n "$children" ]; then
        : > "$scratch/go"
        for child in $children; do wait "$child" || code=1; done
    fi
    restored="$mode"
    if [ "$mode" != unavailable ]; then
        set_mode "$mode" || code=1
        restored=$(cat "$setting") || code=1
    fi
    exec 4<&-
    if [ "$have_b" = 1 ]; then timeout 8 umount "$mount_b" || code=1; fi
    if [ "$have_a" = 1 ]; then timeout 8 umount "$mount_a" || code=1; fi
    if [ "$restore_workspace" = 1 ]; then
        if actual=$(workspace_device) && [ -n "$actual" ]; then timeout 8 umount "$workspace" || code=1; fi
        restore_mount || code=1
    fi
    recovered=$(workspace_device) || code=1
    if [ "$have_fixture" = 1 ] && [ -n "$recovered" ]; then rm -r "$fixture" || code=1; fi
    details=
    if [ -f "$scratch/details" ]; then details=$(cat "$scratch/details"); fi
    rm -f "$scratch/details" "$scratch/expected" "$scratch/go" "$scratch"/ready-* "$scratch"/done-*
    rmdir "$mount_a" "$mount_b" "$scratch" || code=1
    result=$({
        printf 'token_sha256=%s\nmode_initial=%s\nmode_final=%s\nexit=%s\nstep=%s\nworkspace_device_final=%s\n' \
            "$token_hash" "$mode" "$restored" "$code" "$reason" "$recovered"
        if [ -n "$details" ]; then printf '%s\n' "$details"; fi
    })
    printf '[workspace-local-completion-test]\n%s\n' "$result"
    if [ -n "$recovered" ]; then
        pending=$(mktemp "$workspace/.workspace-local-completion.XXXXXX")
        printf '%s\n' "$result" > "$pending" && mv "$pending" "$receipt" || { rm -f "$pending"; code=1; }
    fi
    exit "$code"
}

trap cleanup EXIT
trap 'reason=interrupted; exit 1' HUP INT TERM
initial=$(workspace_device)
[ -n "$initial" ]
mkdir "$mount_a" "$mount_b" "$fixture"
have_fixture=1
printf 'workspace-local-completion-%s\n' "$leaf" > "$scratch/expected"
dd if="$scratch/expected" of="$fixture/original" conv=fsync status=none
ln "$fixture/original" "$fixture/link"

printf 'workspace_device_initial=%s\n' "$initial" > "$scratch/details"
reason=mount_same_tag_again
timeout 8 mount -t virtiofs -o nosuid,nodev workspace "$mount_a"
have_a=1
printf 'same_tag_mount=1\n' >> "$scratch/details"
reason=mount_bind
timeout 8 mount --bind "$fixture" "$mount_b"
have_b=1
printf 'bind_mount=1\n' >> "$scratch/details"

reason=hardlink_metadata
printf 'before_revalidation_original=%s\nbefore_revalidation_link=%s\n' \
    "$(stat -c '%d:%i:%h' "$fixture/original")" "$(stat -c '%d:%i:%h' "$fixture/link")" >> "$scratch/details"
# Both cached aliases must be past the workspace's existing 20ms lifetime.
sleep 0.05
for view in original same_tag bind; do
    case "$view" in
        original) directory=$fixture ;;
        same_tag) directory="$mount_a/$leaf" ;;
        bind) directory=$mount_b ;;
    esac
    ident_original=$(stat -c '%d:%i:%h' "$directory/original")
    ident_link=$(stat -c '%d:%i:%h' "$directory/link")
    printf '%s_original=%s\n%s_link=%s\n' "$view" "$ident_original" "$view" "$ident_link" >> "$scratch/details"
done
for directory in "$fixture" "$mount_a/$leaf" "$mount_b"; do
    identity=$(stat -c '%d:%i:%h' "$directory/original")
    [ "$identity" = "$(stat -c '%d:%i:%h' "$directory/link")" ]
    case "$identity" in *:2) ;; *) exit 1 ;; esac
    cmp "$scratch/expected" "$directory/original"
    cmp "$scratch/expected" "$directory/link"
done

reason=held_and_replaced_handles
exec 4< "$mount_b/link"
printf 'atomic-replacement\n' > "$fixture/next"
mv "$fixture/next" "$fixture/link"
[ "$(cat <&4)" = "$(cat "$scratch/expected")" ]
exec 4<&-
sleep 0.05
[ "$(cat "$mount_a/$leaf/link")" = atomic-replacement ]
cmp "$scratch/expected" "$mount_b/original"

reason=concurrent_open_read_close_and_switch
for slot in 1 2 3 4 5 6 7 8; do
    (
        : > "$scratch/ready-$slot"
        while [ ! -f "$scratch/go" ]; do sleep 0.002; done
        dd if="$scratch/expected" of="$mount_b/writer-$slot" conv=fsync status=none
        cmp "$scratch/expected" "$mount_a/$leaf/writer-$slot"
        n=0
        while [ "$n" -lt 128 ]; do
            cmp "$scratch/expected" "$mount_b/original"
            n=$((n + 1))
        done
        : > "$scratch/done-$slot"
    ) &
    children="$children $!"
done
tries=0
for slot in 1 2 3 4 5 6 7 8; do
    while [ ! -f "$scratch/ready-$slot" ]; do
        [ "$tries" -lt 1000 ]
        tries=$((tries + 1))
        sleep 0.002
    done
done
: > "$scratch/go"
flips=0
all_active=0
current="$mode"
while [ "$current" != unavailable ] && [ "$flips" -lt 32 ]; do
    sleep 0.002
    case "$current" in N) current=Y ;; Y) current=N ;; esac
    set_mode "$current"
    eligible=0
    for slot in 1 2 3 4 5 6 7 8; do
        if [ ! -f "$scratch/done-$slot" ]; then eligible=$((eligible + 1)); fi
    done
    if [ "$eligible" = 8 ]; then all_active=$((all_active + 1)); fi
    flips=$((flips + 1))
done
failed=0
for child in $children; do wait "$child" || failed=1; done
children=
printf 'concurrent_readers=8\nreads_per_job=128\nfsynced_writers=8\nreadback_flips=%s\nflips_while_eight_active=%s\n' \
    "$flips" "$all_active" >> "$scratch/details"
[ "$failed" = 0 ]
[ "$current" = "$mode" ]
if [ "$mode" != unavailable ]; then
    [ "$flips" = 32 ]
    [ "$all_active" -ge 2 ]
fi

reason=last_mount_unmount_and_remount
timeout 8 umount "$mount_b"
have_b=0
timeout 8 umount "$mount_a"
have_a=0
cmp "$scratch/expected" "$fixture/original"
timeout 8 umount "$workspace"
restore_workspace=1
[ -z "$(workspace_device)" ]
restore_mount
restore_workspace=0
first_remount=$(workspace_device)
[ -n "$first_remount" ]
cmp "$scratch/expected" "$fixture/original"
printf 'workspace_device_remounted=%s\n' "$first_remount" >> "$scratch/details"

reason=pass
