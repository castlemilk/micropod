"""Recover owned OCI provenance bytes through the public Docker image export route."""
import hashlib
import json
import os
from pathlib import Path
import re
from secrets import token_hex
import subprocess
import tarfile
from tempfile import TemporaryDirectory

d = Path(__file__).resolve().parent
ready = json.loads((d / 'buildkit-iid-retry-ready.json').read_bytes())
socket = Path(ready['socket'])
assert socket.is_socket() and 'mpg6-buildkit-iid-retry-' in str(socket)
docker = ['/opt/homebrew/bin/docker', '--host', 'unix://' + str(socket)]
env = {k: v for k, v in os.environ.items() if k not in ('DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS',
       'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH', 'DOCKER_API_VERSION')}
location = d / 'buildx/iid'
source = json.loads((location / 'default-native.json').read_bytes())
iid = source['iid']
config = source['tag_id']
assert iid == 'sha256:31691f6a3bd8e0f4a6077515fabf6ca948a44396d492f1fc51d2cebf06888582'
assert config == 'sha256:5449b4a82bb2e426a9dc86e03e4578b76bbe8fb725613b533ae12ff682f3b0c5'
key = 'io.micropod.qa.default-buildx'
report = {'index': iid, 'config': config, 'owned_scoped_images': [], 'original_tags_absent': {},
          'content_capture': {}, 'capture_alias_cleanup': None}


def call(*args, check=False, timeout=15):
    return subprocess.run([*docker, *map(str, args)], capture_output=True, text=True,
                          check=check, env=env, timeout=timeout)


def absent(ref):
    probed = call('image', 'inspect', ref)
    return probed.returncode != 0 and any(word in probed.stderr.lower() for word in ('not found', 'no such'))


def trace(args):
    return {'exit': args.returncode, 'stderr': args.stderr, 'stdout': args.stdout}


def extract(path):
    entries = []
    with tarfile.open(path) as image:
        def blob(digest):
            assert re.fullmatch(r'sha256:[0-9a-f]{64}', digest)
            filename = 'blobs/' + digest.replace(':', '/')
            try:
                member = image.getmember(filename)
            except KeyError:
                entries.append({'digest': digest, 'absent_in_platform_export': True})
                return None
            assert member.isfile() and member.size <= 2 * 2**20
            payload = image.extractfile(member).read()
            assert 'sha256:' + hashlib.sha256(payload).hexdigest() == digest
            dest = location / 'default-native-oci' / (digest.split(':', 1)[1] + '.json')
            dest.parent.mkdir(mode=0o700, exist_ok=True)
            with dest.open('xb') as out:
                out.write(payload)
            entries.append({'digest': digest, 'bytes': len(payload), 'path': dest.relative_to(d).as_posix()})
            return json.loads(payload)

        index = blob(iid)
        if index is not None:
            assert entries[0]['bytes'] == 855 and len(index['manifests']) >= 2
            for manifest in index['manifests']:
                blob(manifest['digest'])
    return entries


try:
    assert not call('ps', '--no-trunc', '-aq', check=True).stdout.strip()
    images = call('image', 'ls', '--all', '--no-trunc', '--quiet', check=True).stdout.splitlines()
    for identity in sorted(set(images) | {config}):
        response = call('image', 'inspect', identity)
        if response.returncode:
            continue
        (image,) = json.loads(response.stdout)
        label = (image.get('Config') or {}).get('Labels') or {}
        if token := label.get(key):
            assert re.fullmatch(r'[0-9a-f]{12,16}', token), token
            report['owned_scoped_images'].append({'config_id': image['Id'], 'fixture_label': token,
                                                 'tags': image.get('RepoTags'), 'digests': image.get('RepoDigests')})
            tag = 'micropod-qa/buildx-provenance:' + token
            report['original_tags_absent'][tag] = absent(tag)
    assert config in [row['config_id'] for row in report['owned_scoped_images']]
    assert report['original_tags_absent'][source['tag']] and all(report['original_tags_absent'].values())
    alias = 'micropod-qa/buildx-probe-export:' + token_hex(6)
    assert absent(alias)
    tagged = call('image', 'tag', config, alias)
    report['content_capture']['tag_result'] = trace(tagged)
    if tagged.returncode == 0:
        try:
            with TemporaryDirectory(prefix='mp-g6-provenance-', dir=d.parent / 'home') as tmp:
                exported = Path(tmp) / 'temp-export.tar'
                saved = call('image', 'save', '--output', exported, alias, timeout=30)
                report['content_capture']['save_result'] = trace(saved)
                if saved.returncode == 0:
                    report['content_capture']['entries'] = extract(exported)
        finally:
            removed = call('image', 'rm', alias)
            report['capture_alias_cleanup'] = {'exit': removed.returncode, 'absent': absent(alias)}
            assert report['capture_alias_cleanup']['absent']
except Exception as error:
    report['failure'] = repr(error)
    raise
finally:
    with (location / 'default-native-disposal-inventory.json').open('x') as file:
        json.dump(report, file, indent=2)
        file.write('\n')
