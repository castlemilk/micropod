"""Check raw Engine v1.47 parity, label controls and strict zero-row cleanup."""
import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path


def load_gzip(path):
    return json.loads(gzip.decompress(path.read_bytes()))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("audit","prior","cleanup","build","output"):
        parser.add_argument("--"+name,type=Path,required=True)
    args = parser.parse_args()
    current, prior = load_gzip(args.audit), load_gzip(args.prior)
    cleanup = json.loads(args.cleanup.read_bytes())
    expected_roles = {"key-only":["empty","selected"],"exact":["empty","selected"],"conjunction":["selected"],
                      "empty-value":["empty"],"absent-is-not-empty":[],"wrong-value":[],"missing-key":[]}
    label_observations = {}
    for side in ("reference","candidate"):
        cases = current[side]["image-list-labels"]
        assert cases["operations"] == ["ImageList"]
        observed = cases["observed"]
        for name, roles in expected_roles.items():
            expected = {"roles":roles,"rows":len(roles),"unexpected_rows":0}
            assert observed[name] == {**expected,"status":200,"cli_exit":0,"cli":expected},(side,name,observed[name])
        assert all(observed[name] == {"status":400,"json_message":True}
                   for name in ("malformed-json","malformed-values","unknown-filter"))
        assert observed["empty-set"] == {"status":200,"same_as_unfiltered":True}
        assert all(observed["cleanup"].values())
        assert set(cleanup[side]) == {"containers","images","volumes","networks"}
        assert all(check == {"status":200,"returned":0,"matching":0} for check in cleanup[side].values())
        label_observations[side] = observed
    assert current["api_version" if "api_version" in current else "version"] == current["cli_api_version"] == "1.47"
    assert current["profile"] == "full" and current["spec_sha256"] == prior["spec_sha256"]
    assert set(current["candidate"]) - set(prior["candidate"]) == {"image-list-labels"}
    modes = Counter(row["comparison"] for row in current["candidate"].values())
    differences = [name for name in prior["candidate"] if current["candidate"][name] != prior["candidate"][name]]
    added_operations = {name for name, row in current["operations"].items() if "cases" in row and "cases" not in prior["operations"][name]}
    assert added_operations == {"ImageList"}
    assert len(current["operations"]) == 107 and not modes.get("reference-failed")
    assert current["candidate"]["image-list-labels"]["comparison"] == "matched"
    report = {"job_sha256":json.loads(args.build.read_bytes())["runner_sha256"],"api_version":"1.47","profile":"full",
              "comparison_counts":dict(modes),"groups":len(current["candidate"]),
              "total_operations":len(current["operations"]),
              "probed_operations":sum("cases" in row for row in current["operations"].values()),
              "added_operations":sorted(added_operations),"existing_candidate_observations_changed":differences,
              "label_observations":label_observations,"strict_scope_cleanup":cleanup,
              "inputs_sha256":{key:sha(getattr(args,key)) for key in ("audit","prior","cleanup","build")}}
    with args.output.open("x") as stream:
        stream.write(json.dumps(report,indent=2,sort_keys=True)+"\n")
    print(json.dumps({key:report[key] for key in ("comparison_counts","groups","probed_operations","existing_candidate_observations_changed")}))
    return int(bool(differences))


if __name__=="__main__":
    raise SystemExit(main())
