"""Stage trusted one-shot FUSE trace and terminal remount operators."""
import hashlib
import json
import os
from pathlib import Path
from secrets import token_hex
import shutil
import subprocess

receipts = Path(__file__).resolve().parent
hub = receipts.parent / 'home'
source = hub / 'kernel-base/controls/qualify_virtiofs_local_completion.sh'
expected = '1dcec6a65633297eb95fe27c9ce49dbe9455fd54eda045c1945f6717246b484f'
old_bank = hub / 'artifacts/tools-release-trace'
bank = hub / 'artifacts/tools-completion-diagnostic'
assert hub.is_mount() and not bank.exists() and hashlib.sha256(source.read_bytes()).hexdigest() == expected
subprocess.run(['/bin/cp', '-cRp', old_bank, bank], check=True)
runner = bank / 'runner'
target = runner / source.name
shutil.copy2(source, target)
target.chmod(0o755)
private = runner / '.workspace-local-completion.owner'
descriptor = os.open(private, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o400)
with os.fdopen(descriptor, 'w') as file:
    file.write(token_hex(16) + '\n')
start = runner / 'start.sh'
text = start.read_text()
original = '"$tools/runner/trace-observer.sh" &\nobserver=$!\n'
chain = '''(
    if ! "$tools/runner/trace-observer.sh"; then
        printf '%s\\n' 'The scoped virtiofs trace failed' >&2
    fi
    exec "$tools/runner/qualify_virtiofs_local_completion.sh" --allow-unavailable
) &
observer=$!
'''
assert text.count(original) == 1
start.write_text(text.replace(original, chain))
sources = (start, runner / 'trace-observer.sh', target)
for script in sources:
    subprocess.run(['/bin/sh', '-n', script], check=True)
manifest = {str(path.relative_to(bank)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sources}
manifest['runner/bin/job'] = hashlib.sha256((runner / 'bin/job').read_bytes()).hexdigest()
(receipts / 'tools-completion-diagnostic-lineage.json').write_text(json.dumps(manifest, indent=2) + '\n')
