"""Run only the terminal lifecycle check on the disposable four-queue proof worker."""
import hashlib
import json
from pathlib import Path
import subprocess

receipts = Path(__file__).resolve().parent
artifacts = receipts.parent / 'home/artifacts'
base = artifacts / 'tools-completion-diagnostic'
target = artifacts / 'tools-q4-terminal'
assert artifacts.parent.is_mount() and not target.exists()
subprocess.run(['/bin/cp', '-cRp', base, target], check=True)
runner = target / 'runner'
start = runner / 'start.sh'
data = start.read_text()
begin = data.index('(\n    if ! "$tools/runner/trace-observer.sh"; then\n')
end = data.index('observer=$!\n', begin)
new = '"$tools/runner/qualify_virtiofs_local_completion.sh" --allow-unavailable &\n'
start.write_text(data[:begin] + new + data[end:])
observer = runner / 'trace-observer.sh'
assert observer.is_file() and not observer.is_symlink()
observer.unlink()
subprocess.run(['/bin/sh', '-n', start], check=True)
paths = (start, runner / 'qualify_virtiofs_local_completion.sh', runner / 'bin/job')
proof = {str(path.relative_to(target)): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
(receipts / 'tools-q4-terminal-lineage.json').write_text(json.dumps(proof, indent=2) + '\n')
