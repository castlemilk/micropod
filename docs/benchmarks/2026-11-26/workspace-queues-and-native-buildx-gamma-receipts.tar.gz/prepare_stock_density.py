"""Reduce the audited eight-job driver to the stock, unpinned Git route."""
from pathlib import Path

folder = Path(__file__).resolve().parent
template = folder / 'gamma4-bench-release-density-wave.py'
text = template.read_text().replace(
    'Measure eight simultaneous Git checks with stock, parallel or CPU-pinned execution.',
    'Compare eight simultaneous unpinned stock Git status jobs on matched engines.')
text = text.replace('HELPER = ROOT / "git_parallel_clean.py"\n', '')
text = text.replace('LABEL = "io.micropod.qa.git-gate-density"', 'LABEL = "io.micropod.gamma6.stock-git-wave"')
text = text.replace('    env = git_env(bench)\n', '''    env = git_env(bench)
    command = ["git", "-C", str(TREE), "--no-optional-locks", "status", "--porcelain=v1", "-z", "--untracked-files=all"]
    allowed_cpus = sorted(os.sched_getaffinity(0))
    bench.require(allowed_cpus == [0, 1, 2, 3], "status job must allow all four vCPUs")
''')
text = text.replace('        from git_parallel_clean import status\n\n', '')
text = text.replace('''        result, used_parallel = status(TREE, 4, env)
        bench.require(used_parallel and result.returncode == 0 and not result.stdout and not result.stderr,
                      f"slot {slot} did not take the clean parallel path")
''', '''        result = bench.call(command, env=env, timeout=20)
        bench.require(not result.stdout and not result.stderr, f"slot {slot} did not return a clean stock status")
''')
text = text.replace('''                          "git_sha256": bench.file_sha(Path(shutil.which("git"))), "python": sys.version.split()[0],
                          "helper_sha256": bench.file_sha(HELPER), "used_parallel": used_parallel}))
''', '''                          "git_sha256": bench.file_sha(Path(shutil.which("git"))), "python": sys.version.split()[0],
                          "allowed_cpus": allowed_cpus}))
''')
a = text.index('    if mode == "cpu0":')
b = text.index('    clock = bench.guest_clock()', a)
text = text[:a] + text[b:]
a = text.index('    command = (["git",')
b = text.index('    before = bench.cpu_accounting()', a)
text = text[:a] + text[b:]
text = text.replace('row["end_ns"] > row["start_ns"] >= clocks[slot]["now_ns"]',
                    'row["allowed_cpus"] == [0, 1, 2, 3]\n                          and row["end_ns"] > row["start_ns"] >= clocks[slot]["now_ns"]')
text = text.replace('    shutil.copyfile(args.helper, shared / HELPER.name)\n', '')
text = text.replace('helper_sha256=bench.file_sha(args.helper), driver_sha256=', 'driver_sha256=')
text = text.replace('''and all(row["cpus"] == 4 and row["head"] == head and row["helper_sha256"] == report["helper_sha256"]
                              and row["used_parallel"] for row in prepared[name])''',
                    '''and all(row["cpus"] == 4 and row["head"] == head
                              and row["allowed_cpus"] == [0, 1, 2, 3] for row in prepared[name])''')
a = text.index('        cells = [(engine, mode)')
b = text.index('        bench.require(all(bench.file_sha(index)', a)
text = text[:a] + '''        for name in ENGINES:
            report["warmup"][name] = wave(arms[name], identities[name], "stock", clocks[name])
        for pair in range(args.pairs):
            order = ENGINES if pair % 2 == 0 else ENGINES[::-1]
            block = {"order": list(order), "waves": {}}
            report["rounds"].append(block)
            for name in order:
                block["waves"][name] = wave(arms[name], identities[name], "stock", clocks[name])
''' + text[b:]
a = text.index('    comparison = report["comparison"]')
b = text.index('\ndef main():', a)
text = text[:a] + '''    cells = {name: [block["waves"][name] for block in report["rounds"]] for name in ENGINES}
    metrics = ("guest_to_last_ms", "host_to_last_ms", "host_with_startup_ms", "overlap_ms", "start_skew_ms")
    report["summary"] = {
        name: {"wave_median": {key: statistics.median(row[key] for row in rows) for key in metrics},
               "guest_job_ms": distribution([job["guest_ms"] for row in rows for job in row["jobs"]]),
               "job_cpu_usage_usec": distribution([job["cgroup_delta"]["usage_usec"] for row in rows for job in row["jobs"]]),
               "job_cpu_throttled_usec": distribution([job["cgroup_delta"]["throttled_usec"] for row in rows for job in row["jobs"]])}
        for name, rows in cells.items()
    }
    report["paired_hvf_to_orbstack"] = {
        key: [a[key] / b[key] for a, b in zip(cells["hvf"], cells["orbstack"])]
        for key in metrics[:3]
    }

''' + text[b:]
text = text.replace('"source", "helpers", "helper", "image-manifest"', '"source", "helpers", "image-manifest"')
text = text.replace('    parser.add_argument("--comparison", choices=("helper", "cpu0"), default="helper")',
                    '    parser.add_argument("--pairs", type=int, choices=(2, 4, 6, 8), default=4)')
text = text.replace('"comparison": args.comparison', '"execution": "stock unpinned Git", "pairs": args.pairs')
assert not any(marker in text for marker in ('HELPER', 'args.helper,', 'args.comparison', 'sched_setaffinity',
                                            'used_parallel', 'helper_sha256'))
output = folder / 'bench_stock_git_density.py'
compile(text, str(output), 'exec')
output.write_text(text)
