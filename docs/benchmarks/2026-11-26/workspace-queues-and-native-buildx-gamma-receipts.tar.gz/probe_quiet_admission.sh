#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
label=${1:?fresh quiet receipt stem}
duration=${2:-3.2}
[[ $label =~ ^[a-z0-9-]+$ && $duration =~ ^[0-9]+(\.[0-9]+)?$ ]]
python3 -B "$D/with_host_load.py" --out "$D/$label-preflight-host-load.jsonl" -- /bin/sleep "$duration"
python3 -B - "$D/$label-preflight-host-load.jsonl" "$D/$label-preflight.json" <<'PY'
from pathlib import Path
import json
import sys

raw, target = (Path(arg) for arg in sys.argv[1:])
rows = [json.loads(line) for line in raw.read_bytes().splitlines()]
idle = [row['cpu_idle_pct'] for row in rows if row['edge'] == 'running']
summary = {'host_observed_idle_pct': idle,
           'quiet_prestart_observed': any(a >= 90 and b >= 90 for a, b in zip(idle, idle[1:])),
           'criterion': 'Two consecutive full 1s samples with at least 90% host CPU idle',
           'criterion_scope': 'Only a qualified preflight admits the separately labelled quiet-only material score.'}
with target.open('x') as stream:
    json.dump(summary, stream, indent=2)
    stream.write('\n')
PY
jq -e '.quiet_prestart_observed' "$D/$label-preflight.json" >/dev/null
