"""Read the kernel's named virtiofs devices and accepted request-queue CPU maps."""
import json
from pathlib import Path

root = Path('/sys/fs/virtiofs')
parameters = Path('/sys/module/virtiofs/parameters')
devices = {}
for path in sorted(root.iterdir()):
    if not (path / 'tag').is_file():
        continue
    tag = (path / 'tag').read_text().strip()
    queues = {}
    for queue in sorted((path / 'mqs').iterdir()):
        label = (queue / 'name').read_text().strip()
        cpus = [int(value.strip()) for value in (queue / 'cpu_list').read_text().strip().split(',') if value.strip()]
        assert label not in queues
        queues[label] = {'index': queue.name, 'cpus': cpus}
    assert tag not in devices
    devices[tag] = {'sysfs': str(path), 'device': str((path / 'device').resolve(strict=True)), 'queues': queues}
facts = {}
for name in ('workspace_async_release', 'workspace_local_completion'):
    parameter = parameters / name
    if parameter.is_file():
        facts[name] = parameter.read_text().strip()
print(json.dumps({'devices': devices, 'parameters': facts}, sort_keys=True))
