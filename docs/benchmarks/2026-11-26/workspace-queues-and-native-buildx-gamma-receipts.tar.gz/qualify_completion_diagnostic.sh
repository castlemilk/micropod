#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
H="$(dirname "$D")/home"
arm=${1:?diagnostic worker}
mode=${2:?expected local completion}
ready="$D/$arm-ready.json"
bash "$D/run_gamma4_arm.sh" "$arm" correctness "$arm"
bash "$D/run_raw_git_completion_trace.sh" "$ready" "$mode" "$arm-cpu1" 1
python3 -B "$D/trigger_local_completion_lifecycle.py" --ready "$ready" \
    --owner "$H/artifacts/tools-completion-diagnostic/runner/.workspace-local-completion.owner" \
    --expected "$mode" --out "$D/$arm-lifecycle.json"
