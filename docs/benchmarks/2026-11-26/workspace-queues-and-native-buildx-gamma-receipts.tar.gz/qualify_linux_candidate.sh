#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
arm=${1:?private functional arm}
exe=${2:?staged Linux test executable}
sha=${3:?expected SHA-256}
focus=${4:?Go filter}
set +e
bash "$D/qualify_guest_binary.sh" "$arm" "$exe" "$sha" "$focus" 45 linux-focused \
    > "$D/$arm-linux-focused.log" 2>&1
focused=$?
bash "$D/qualify_guest_binary.sh" "$arm" "$exe" "$sha" '.' 100 linux-full \
    > "$D/$arm-linux-full.log" 2>&1
full=$?
set -e
printf 'linux_focused=%s linux_full=%s\n' "$focused" "$full" | tee "$D/$arm-linux-exit.log"
(( focused == 0 && full == 0 ))
