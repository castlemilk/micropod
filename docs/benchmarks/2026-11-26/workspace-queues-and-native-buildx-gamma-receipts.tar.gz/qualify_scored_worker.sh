#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
arm=${1:?owned ready worker}
mark=${2:-$arm}
if [[ ! $arm =~ ^[a-z0-9-]{1,22}$ || ! $mark =~ ^[a-z0-9-]+$ ]]; then exit 2; fi
python3 -B "$D/with_host_load.py" --out "$D/$mark-preflight-host-load.jsonl" -- /bin/sleep 3.2
python3 -B - "$D/$mark-preflight-host-load.jsonl" "$D/$mark-preflight.json" <<'PY'
from pathlib import Path
import json
import sys

raw, target = (Path(arg) for arg in sys.argv[1:])
rows = [json.loads(line) for line in raw.read_bytes().splitlines()]
idle = [row['cpu_idle_pct'] for row in rows if row['edge'] == 'running']
record = {'host_observed_idle_pct': idle,
          'quiet_prestart_observed': any(a >= 90 and b >= 90 for a, b in zip(idle, idle[1:])),
          'criterion': 'Two consecutive full 1s samples with at least 90% host CPU idle',
          'criterion_scope': 'Report quiet admission. Ambient timing proceeds when it is below the quiet threshold.'}
with target.open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
PY
set +e
bash "$D/run_gamma6_arm.sh" "$arm" "$mark" both
measurement=$?
bash "$D/run_gamma4_arm.sh" "$arm" correctness "$mark"
correctness=$?
set -e
printf 'scored_material_density=%s ordinary_held_and_stock=%s\n' "$measurement" "$correctness" |
    tee "$D/$mark-qualification-exit.log"
(( measurement == 0 && correctness == 0 ))
