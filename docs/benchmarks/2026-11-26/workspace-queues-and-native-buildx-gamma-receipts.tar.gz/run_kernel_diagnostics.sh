#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
H="$(dirname "$D")/home"
kernel="$H/kernel-base/workspace-local-completion/Image"
bank="$H/artifacts/tools-completion-diagnostic"
test "$(shasum -a 256 "$kernel" | cut -d' ' -f1)" = 220f7580341241f49c94c1530da9d623610728e5f197ce1175d52eb0a99b7a25
jq -e '.errors == {} and .scope_absent and .machine.clean_shutdown and .drive.detached.persisted_policy.mounted_read_only' \
    "$D/kernel-local-on-worker.json" >/dev/null
overall=0
for toggle in off on; do
    label="kernel-$toggle-diag"
    argument=0
    expected=N
    if [[ $toggle == on ]]; then argument=1; expected=Y; fi
    python3 -B "$D/public_machine.py" "$label" --kernel "$kernel" --live-read 1 \
      --kernel-arg virtiofs.workspace_async_release=1 --kernel-arg "virtiofs.workspace_local_completion=$argument" \
      --tools "$bank" > "$D/$label-owner.log" 2>&1 &
    owner=$!
    for attempt in {1..65}; do
        if [[ -s "$D/$label-ready.json" ]]; then break; fi
        kill -0 "$owner" 2>/dev/null || break
        sleep 1
    done
    if [[ ! -s "$D/$label-ready.json" ]]; then
        kill -TERM "$owner" 2>/dev/null || true
        wait "$owner" || true
        exit 1
    fi
    set +e
    bash "$D/qualify_completion_diagnostic.sh" "$label" "$expected" > "$D/$label-qualification.log" 2>&1
    code=$?
    set -e
    printf 'pinned_trace_and_terminal_lifecycle=%s\n' "$code" | tee "$D/$label-qualification-exit.log"
    if (( code != 0 )); then overall=1; fi
    python3 -B "$D/retire_gamma4_worker.py" "$label"
    wait "$owner"
    jq -e '.errors == {} and .scope_absent and .machine.clean_shutdown and .drive.detached.persisted_policy.mounted_read_only' \
        "$D/$label-worker.json" >/dev/null
done
exit "$overall"
