#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
H="$(dirname "$D")/home"
ready=$(realpath ${1:?same arm ready JSON})
local_mode=${2:?expected local completion N Y or unavailable}
base=${3:?fresh receipt stem}
cpu=${4:-1}
[[ $ready == "$D/"*-ready.json && $base =~ ^[a-z0-9-]+$ && $cpu =~ ^[0-3]$ ]]
s=$(jq -er .socket "$ready")
w=$(jq -er .workspace "$ready")
image=$(jq -er .benchmark_image "$ready")
p="$H/evidence/prior"
test -S "$s"
python3 -B "$D/with_host_load.py" --out "$D/$base-host-load.jsonl" -- \
    python3 -B "$D/trace_stock_git_completion.py" --socket "$s" --workspace "$w" --image "$image" \
    --source "$p/runner-vendored" --helpers "$p/final-harness/scripts" --observer "$p/trace-proof" \
    --image-manifest "$D/image-manifest.json" --expected-mode Y --expected-local-mode "$local_mode" \
    --guest-cpu "$cpu" --samples 4 --trace --out "$D/$base.json" > "$D/$base.log" 2>&1
exec python3 -B "$D/analyze_completion_cpus.py" --trace "$D/$base.json" --out "$D/$base-cpus.json"
