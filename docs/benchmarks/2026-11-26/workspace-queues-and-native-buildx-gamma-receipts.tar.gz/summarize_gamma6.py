"""Summarize matched Gamma workspace queue, completion and stock Docker qualification."""
from collections import Counter
import gzip
import hashlib
import json
import re
from pathlib import Path
from statistics import median

receipts = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_bytes())


def receipt(path):
    with path.open('rb') as content:
        digest = hashlib.file_digest(content, 'sha256').hexdigest()
    return {'path': path.relative_to(receipts).as_posix(), 'sha256': digest}


def load(path):
    rows = [json.loads(line) for line in path.read_bytes().splitlines()]
    samples = [row for row in rows if row.get('cpu_idle_pct') is not None]
    ticks = Counter()
    for sample in samples:
        ticks.update(sample['delta_ticks'])
    idle = [sample['cpu_idle_pct'] for sample in samples]
    result = {'receipt': receipt(path), 'samples': len(samples), 'command_exit': rows[-1]['code'],
              'first_utc': rows[0]['utc'], 'last_utc': rows[-2]['utc']}
    if samples:
        result.update(weighted_cpu_idle_pct=100 * ticks['idle'] / ticks.total(),
                      idle_pct_min_median_max=[min(idle), median(idle), max(idle)],
                      load_avg_1m_min_max=[min(row['load_average'][0] for row in samples),
                                          max(row['load_average'][0] for row in samples)])
    return result


def milliseconds(ns):
    return ns / 1e6 if ns is not None else None


def material(path, result):
    records = {'receipt': receipt(path), 'source': result['source'], 'git_commit': result['git_commit'], 'image': result['image'],
               'pairs': len(result['pairs']), 'cpus': result['cpus'], 'memory_mib': result['memory_mib'],
               'timing_scopes': result['timing_scopes'], 'load': load(path.with_name(path.stem + '-host-load.jsonl')),
               'cold_prime': {engine: {'guest_sum_ms': milliseconds(row['sum_ns']),
                                      'phase_ms': {key: milliseconds(value) for key, value in row['phase_ns'].items()},
                                      'stock_docker_transport': row['stock_docker_transport']}
                              for engine, row in result['prime'].items()}, 'rounds': {}}
    for phase in ('warm', 'incremental'):
        paired = [pair[phase] for pair in result['pairs']]
        by_engine = {}
        for engine in ('hvf', 'orbstack'):
            rows = [pair[engine] for pair in paired]
            by_engine[engine] = {'guest_sum_median_ms': result['median_ms'][phase][engine],
                               'guest_phase_medians_ms': {key: milliseconds(median(row['phase_ns'][key] for row in rows))
                                                         for key in rows[0]['phase_ns']},
                               'edit_return_to_matching_ms': result['edit_return_to_correct_median_ms'][phase][engine],
                               'edit_through_verified_build_ms': result['edit_to_completed_build_median_ms'][phase][engine],
                               'all_first_byte_reads_match': all(row['visibility']['observations'][0]['sha256'] ==
                                                                 row['visibility']['expected_sha256'] for row in rows)}
        records['rounds'][phase] = {'engines': by_engine,
                                    'hvf_wins': sum(row['hvf']['sum_ns'] < row['orbstack']['sum_ns'] for row in paired),
                                    'median_hvf_to_orbstack_ratio': median(row['hvf']['sum_ns'] / row['orbstack']['sum_ns'] for row in paired)}
    return records


def receipts_for(*patterns):
    entries = {}
    for pattern in patterns:
        for path in sorted(receipts.glob(pattern)):
            if path.is_file() and path.stat().st_size:
                entries[path.relative_to(receipts).as_posix()] = receipt(path)
    return entries


def density(path, result):
    rounds = result['rounds']
    record = {'receipt': receipt(path), 'pass': result['passed'], 'source': result['source'],
              'driver_sha256': result['driver_sha256'], 'image': result['image'],
              'cpus_per_job': result['cpus_per_job'], 'memory_mib': result['memory_mib'],
              'jobs_per_wave': result['jobs_per_wave'], 'cleanup': result['cleanup'],
              'load': load(path.with_name(path.stem + '-host-load.jsonl'))}
    if not result['passed']:
        return {**record, 'failure': result.get('failure')}
    record.update(summary=result['summary'], balanced_engine_order=[row['order'] for row in rounds],
                  paired_hvf_to_orbstack=result['paired_hvf_to_orbstack'], overlaps={})
    for engine in ('hvf', 'orbstack'):
        row = [pair['waves'][engine] for pair in rounds]
        assert all(len(wave['jobs']) == 8 and wave['overlap_ms'] > 0 and
                   all(job['allowed_cpus'] == [0, 1, 2, 3] and job['exit'] == 0 and not job['stdout_hex']
                       and not job['stderr_hex'] for job in wave['jobs']) for wave in row)
        assert len(record['cleanup'][engine]['removed']) == 8 and not record['cleanup'][engine]['remaining']
        record['overlaps'][engine] = [wave['overlap_ms'] for wave in row]
    return record


def scoped_evidence(*patterns):
    known = {}
    for pattern in patterns:
        for path in sorted(receipts.glob(pattern)):
            if path.is_file() and not path.is_symlink() and path.stat().st_size:
                name = path.relative_to(receipts).as_posix()
                known[name] = receipt(path)
    return known


def read_linux_test(path):
    data = path.read_text()
    statuses = Counter(re.findall(r'^\s*--- (PASS|SKIP|FAIL): ', data, flags=re.M))
    return {'named': len(re.findall(r'^=== RUN   Test', data, flags=re.M)),
            'passed': statuses['PASS'], 'skipped': statuses['SKIP'], 'failed': statuses['FAIL']}


def summarize_api_audits():
    audits = {}
    for path in sorted(receipts.glob('buildx/**/docker-api-1.47.json.gz')):
        with gzip.open(path, 'rt') as data:
            report = json.load(data)
        candidates = report['candidate']
        observed = {op for row in candidates.values() for op in row.get('operations', [])}
        matches = sorted(name for name, row in candidates.items() if row.get('comparison') == 'matched')
        alternatives = sorted(set(candidates) - set(matches))
        assert observed <= report['operations'].keys()
        audits[path.relative_to(receipts).as_posix()] = {
            'receipt': receipt(path), 'version': report['version'], 'spec_sha256': report['spec_sha256'],
            'matched_groups': len(matches), 'comparison_groups': len(candidates), 'matched_group_names': matches,
            'other_group_names': alternatives, 'observed_operations': len(observed),
            'operations_in_specification': len(report['operations']), 'observed_operation_ids': sorted(observed)}
    return audits


def main():
    lineage = read(receipts / 'baseline-lineage.json')
    rows = {'host': 'Gamma-128GB.local', 'date_melbourne': '2026-11-26', 'baseline_lineage': lineage,
            'matching_oci_image': read(receipts / 'image.json'), 'boots': {}, 'material': {}, 'density': {},
            'host_preflight': {}, 'mechanism': {}, 'device_and_stock_correctness': {}, 'exceptions': {}}
    for path in sorted(receipts.glob('*-ready.json')):
        result = read(path)
        rows['boots'][result['label']] = {'receipt': receipt(path), 'artifacts': result['owned_artifacts'],
                                        'kernel_flags': result['kernel_arguments_requested'],
                                        'queues_requested': result.get('workspace_request_queues_requested'),
                                        'virtiofs_sysfs': result.get('virtiofs_sysfs')}
    for path in sorted(receipts.glob('*-material.json')):
        result = read(path)
        if result.get('workspace_mode') == 'independent byte-identical raw host checkouts':
            rows['material'][path.stem.removesuffix('-material')] = material(path, result)
    for path in sorted(receipts.glob('*-density.json')):
        result = read(path)
        if result.get('execution') == 'stock unpinned Git':
            rows['density'][path.stem.removesuffix('-density')] = density(path, result)
    for path in sorted(receipts.glob('*-preflight.json')):
        rows['host_preflight'][path.stem.removesuffix('-preflight')] = {'receipt': receipt(path), **read(path)}
    for pattern in ('*-cpu1-cpus.json', '*-dispatch.json', '*-lifecycle.json', 'archived-release-on-cpu-analysis.json'):
        for path in sorted(receipts.glob(pattern)):
            rows['mechanism'][path.stem] = {'receipt': receipt(path), 'results': read(path)}
    for pattern in ('*-edits.json', '*-mmap-exact.json', '*-guest-splice.json', '*-stock-pid1.json', '*-virtiofs-sysfs.json'):
        for path in sorted(receipts.glob(pattern)):
            rows['device_and_stock_correctness'][path.stem] = {'receipt': receipt(path), 'result': read(path)}
    for name, score in rows['material'].items():
        admission = rows['host_preflight'].get(name)
        score['admission_class'] = 'quiet-admitted' if admission and admission['quiet_prestart_observed'] else 'ambient'
        if admission:
            score['preflight_receipt'] = admission['receipt']
    for name, score in rows['density'].items():
        score['admission_class'] = 'ambient'
        score['quiet_gate_scope'] = 'The arm preflight precedes material. The following density window has separate continuous load.'
    rows['matched_comparisons'] = {}
    for group, before, after in (('vmm_workspace_queues', 'vmm-q1-score', 'vmm-q4-score'),
                                 ('kernel_local_completion', 'kernel-local-off', 'kernel-local-on')):
        if not all(arm in rows[table] for arm in (before, after) for table in ('material', 'density')):
            continue
        assert rows['boots'][before]['artifacts'] == rows['boots'][after]['artifacts'], group
        classes = {name: rows['material'][name]['admission_class'] for name in (before, after)}
        combined = set(classes.values())
        comparison = {'control': before, 'treatment': after, 'material': {}, 'density': {},
                      'material_admission_by_arm': classes,
                      'material_admission': next(iter(combined)) if len(combined) == 1 else 'mixed',
                      'density_admission': 'ambient'}
        for phase in ('warm', 'incremental'):
            arms = {}
            for name in (before, after):
                data = rows['material'][name]
                measured = data['rounds'][phase]
                arms[name] = {'guest_sum_ms': {
                    engine: row['guest_sum_median_ms'] for engine, row in measured['engines'].items()},
                    'hvf_to_orbstack_median_pair_ratio': measured['median_hvf_to_orbstack_ratio'],
                    'host_weighted_idle_pct': data['load']['weighted_cpu_idle_pct']}
            comparison['material'][phase] = arms
        for name in (before, after):
            data = rows['density'][name]
            comparison['density'][name] = {
                'guest_wave_ms': {engine: row['wave_median']['guest_to_last_ms'] for engine, row in data['summary'].items()},
                'host_wave_ms': {engine: row['wave_median']['host_to_last_ms'] for engine, row in data['summary'].items()},
                'hvf_to_orbstack_median_pair_ratio': median(data['paired_hvf_to_orbstack']['guest_to_last_ms']),
                'host_weighted_idle_pct': data['load']['weighted_cpu_idle_pct']}
        rows['matched_comparisons'][group] = comparison
    quiet_arms = ('vmm-q1-quiet', 'vmm-q4-score')
    if all(arm in rows['material'] and rows['material'][arm]['admission_class'] == 'quiet-admitted' for arm in quiet_arms):
        assert rows['boots'][quiet_arms[0]]['artifacts'] == rows['boots'][quiet_arms[1]]['artifacts']
        rows['matched_comparisons']['vmm_workspace_queues_quiet_admitted'] = {
            'control': quiet_arms[0], 'treatment': quiet_arms[1],
            'admission': 'Both material arms met the same 90% preflight gate.',
            'material': {arm: rows['material'][arm]['rounds'] for arm in quiet_arms},
            'scored_host_load': {arm: rows['material'][arm]['load'] for arm in quiet_arms}}
    for pattern in ('*-material.exit', '*-density.exit', '*-qualification-exit.log'):
        for path in sorted(receipts.glob(pattern)):
            value = path.read_text().strip()
            if value != '0' and not (value and all(token.endswith('=0') for token in value.split())):
                rows['exceptions'][path.name] = {'receipt': receipt(path), 'result': value}
    for path in sorted(receipts.glob('*-worker.json')):
        record = read(path)
        if record['errors']:
            rows['exceptions'][path.name] = {'receipt': receipt(path), 'errors': record['errors'],
                                             'drive_removed': record.get('scope_absent', False)}
    rows['linux_candidate_tests'] = {}
    for exit_path in sorted(receipts.glob('*-linux-exit.log')):
        label = exit_path.stem.removesuffix('-linux-exit')
        checks = {}
        for kind in ('focused', 'full'):
            log = receipts / f'{label}-linux-{kind}.log'
            summary = read_linux_test(log)
            checks[kind] = {**summary, 'receipt': receipt(log)}
        rows['linux_candidate_tests'][label] = {'checks': checks, 'exit_receipt': receipt(exit_path)}
    if (receipts / 'baseline-final-rehash.json').is_file():
        rows['baseline_final_rehash'] = read(receipts / 'baseline-final-rehash.json')
    rows['pinned_api_audits'] = summarize_api_audits()
    rows['oci_api_and_build_evidence'] = scoped_evidence('ancestor/**/*', 'buildx/**/*', 'workspace-queues/**/*',
                                                      'workspace-local-completion*', '*buildkit*', '*api-*', 'coordination-build-windows.jsonl')
    print(json.dumps(rows, indent=2))


if __name__ == '__main__':
    main()
