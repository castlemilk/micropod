#!/usr/bin/env python3
"""Run the terminal completion lifecycle proof on one owned diagnostic worker."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
from tempfile import NamedTemporaryFile
import time


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def read_results(path):
    fields = {}
    for line in path.read_text().splitlines():
        key, separator, value = line.partition("=")
        require(separator and key and key not in fields, "invalid guest result")
        fields[key] = value
    return fields


def host(args, result):
    protected = Path(__file__).resolve().parent.parent / "home"
    worker = json.loads(args.ready.read_bytes())
    path = Path(worker["workspace"]).resolve(strict=True)
    require(path.parent == protected / "share", "select an owned protected share")
    socket = Path(worker["socket"])
    require(socket.is_socket(), "select a live native Unix socket")
    owner = args.owner.resolve(strict=True)
    require(owner.is_relative_to(protected / "artifacts") and owner.name == ".workspace-local-completion.owner"
            and owner.stat().st_mode & 0o777 == 0o400, "select a protected owner secret")
    token = owner.read_text()
    require(re.fullmatch("[0-9a-f]{32}\n", token), "invalid owner secret form")
    proof = hashlib.sha256(token.rstrip("\n").encode()).hexdigest()
    env = dict(os.environ)
    for key in ("DOCKER_CONTEXT", "DOCKER_HOST", "DOCKER_API_VERSION", "DOCKER_TLS", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH"):
        env.pop(key, None)
    list_jobs = ["docker", "--host", f"unix://{socket}", "ps", "-aq"]
    active = lambda: subprocess.check_output(list_jobs, env=env, timeout=5).splitlines()
    require(not active(), "the private diagnostic guest has active containers")

    received = path / ".workspace-local-completion.done"
    requested = path / ".workspace-local-completion.request"
    require(not os.path.lexists(requested) and not os.path.lexists(received), "terminal scope already used")
    before = {item.name for item in path.iterdir()}
    start = time.monotonic_ns()
    try:
        with NamedTemporaryFile("w", dir=path, prefix=".workspace-local-completion-request-", delete=False) as staged:
            staged.write(token)
        try:
            os.link(staged.name, requested)
        finally:
            os.unlink(staged.name)
        deadline = time.monotonic() + 20
        while not received.is_file():
            require(time.monotonic() < deadline, "no terminal guest result")
            time.sleep(0.05)
        require(not received.is_symlink(), "invalid guest receipt path")
        fields = read_results(received)
        require(fields.get("token_sha256") == proof, "receipt has wrong owner")
        result["guest"] = fields
        require(fields["exit"] == "0" and fields["step"] == "pass"
                and fields["mode_initial"] == args.expected and fields["mode_final"] == args.expected,
                "lifecycle or mode restoration failed")
        require(fields["same_tag_mount"] == "1" and fields["bind_mount"] == "1"
                and fields["concurrent_readers"] == "8" and fields["reads_per_job"] == "128"
                and fields["fsynced_writers"] == "8"
                and all(re.fullmatch(r"\d+:\d+", fields[f"workspace_device_{state}"])
                        for state in ("initial", "remounted", "final")), "incomplete lifecycle evidence")
        if args.expected == "unavailable":
            require(fields["readback_flips"] == "0", "unexpected mode setting on the stock kernel")
        else:
            require(fields["readback_flips"] == "32" and int(fields["flips_while_eight_active"]) >= 2,
                    "insufficient live-switch overlap")
    finally:
        result["elapsed_ms"] = (time.monotonic_ns() - start) / 1e6
        if "guest" in result:
            received.unlink()
        if requested.is_file() and not requested.is_symlink() and requested.read_text() == token:
            requested.unlink()
        result["workspace_additions"] = sorted({item.name for item in path.iterdir()} - before)
        result["containers_remaining"] = [item.decode() for item in active()]
    require(not result["workspace_additions"] and not result["containers_remaining"], "terminal cleanup incomplete")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("ready", "owner", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    parser.add_argument("--expected", choices=("N", "Y", "unavailable"), required=True)
    args = parser.parse_args()
    require(not args.out.exists(), "use a fresh receipt")
    result = {"passed": False, "expected": args.expected}
    try:
        host(args, result)
        result["passed"] = True
    except Exception as error:
        result["failure"] = str(error)
        raise
    finally:
        with args.out.open("x") as output:
            json.dump(result, output, indent=2)
            output.write("\n")


if __name__ == "__main__":
    main()
