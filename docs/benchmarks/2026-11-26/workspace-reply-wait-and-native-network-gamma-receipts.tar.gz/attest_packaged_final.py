#!/usr/bin/env python3
"""Verify actual packaged payload resolution and work queue negotiation from a live receipt."""

import argparse
import hashlib
import json
from pathlib import Path


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('ready', type=Path)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    ready = json.loads(args.ready.read_bytes())
    manifest = json.loads(args.manifest.read_bytes())
    state = ready['bundled_payload']
    installed = Path(state['installed_app'])
    declared = manifest['artifacts']
    assert ready['label'] == 'packaged-final' and Path(ready['socket']).is_socket()
    assert state['manifest'] == str(args.manifest) and state['manifest_sha256'] == sha(args.manifest)
    assert state['source_app'] == manifest['app'] and state['used_explicit_payload_flags'] is False
    actual = {role: row['sha256'] for role, row in ready['owned_artifacts'].items()}
    assert actual == {role: row['sha256'] for role, row in declared.items()}
    assert actual['job'] == '4d0fb3989ee4e81f6b3f295c9d24b397a158635576019102bd6e558f90fbc812'
    assert all(sha(installed / row['relative_path']) == row['sha256'] for row in declared.values())
    command = ready['machine']['checks']['install separate protected public machine']['command']
    assert command[:3] == [str(installed / declared['cli']['relative_path']), 'machine', 'install']
    assert not {'--vmm', '--kernel', '--initrd', '--tools'}.intersection(command[3:])
    assert ready['vmm_entitlements']['com.apple.security.hypervisor'] is True
    assert ready['guest_tool_probe'][0] == '7.3.5-micropod-b8'
    sysfs = ready['virtiofs_sysfs']
    workspace = sysfs['devices']['workspace']
    assert sysfs['parameters'] == {option: 'Y' for option in (
        'workspace_async_release', 'workspace_inline_completion', 'workspace_compact_requests',
    )}, sysfs['parameters']
    assert workspace['event_idx'] and workspace['negotiated_features'][0] == '1'
    assert {name: queue['index'] for name, queue in workspace['queues'].items()} == {
        'hiprio':'0', 'notification':'1', 'requests.0':'2',
    }
    assert workspace['queues']['requests.0']['cpus'] == [0, 1, 2, 3]
    assert not ready['kernel_arguments_requested'] and ready['environment'].get('MICROPOD_VIRTIOFS_LIVE_READ') is None
    with args.output.open('x') as stream:
        json.dump({'ready_sha256': sha(args.ready), 'manifest_sha256': state['manifest_sha256'],
                   'artifacts': actual, 'actual_install_argv': command, 'recognized': sysfs,
                   'guest_kernel_release': ready['guest_tool_probe'][0], 'admitted_for_strict_smoke': True},
                  stream, indent=2)
        stream.write('\n')


if __name__ == '__main__':
    main()
