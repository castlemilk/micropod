#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd -P)
H=$(dirname "$D")/home
arm=${1:?private label}
mode=${2:?0 or 1}
tools=${3:-$H/artifacts/tools-baseline}
[[ $mode == 0 || $mode == 1 ]]
image="$H/root-candidates/reply-poll/image/Image"
digest=0e05ac3442a22706f62a9e1e47aa056b654a4a4a27993b5cd752bf2e8b065f13
test "$(/usr/bin/shasum -a 256 "$image" | cut -d ' ' -f1)" = "$digest"
exec python3 -B "$D/public_machine.py" "$arm" --workspace-queues 1 --live-read 1 \
    --kernel "$image" --tools "$tools" --kernel-arg virtiofs.workspace_async_release=1 \
    --kernel-arg "virtiofs.workspace_reply_poll=$mode" > "$D/$arm-owner.log" 2>&1
