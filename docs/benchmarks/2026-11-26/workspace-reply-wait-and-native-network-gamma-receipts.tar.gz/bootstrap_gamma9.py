"""Validate Gamma8 and recover immutable Gamma9 runtime, source, and operator inputs."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

receipts = Path(__file__).resolve().parent
scope = receipts.parent
hub = scope / 'home'
repo = Path('/Users/benebsworth/projects/micropod')
reports = repo / 'bench/phase0-host-scheduling/docs/benchmarks/2026-11-26'
base = 'mounted-checkout-concurrency-and-native-compat-gamma'
preceding_archive = reports / (base + '-receipts.tar.gz')
preceding_scorecard = reports / (base + '.json')
preceding_runtime = repo / '.build/qualified/micropod-hvf-gamma8-meb28u/manifest.json'
expected = {
    preceding_archive: '82c13fe60763d663da55922fd2f37f966e41d8abba5f97aa550661cd87128e31',
    preceding_scorecard: 'a4e25f09db9e7e6e48214e6342b7862aa79370af36686f36af00133911c4c194',
    preceding_runtime: '1529b9eb4a243cfab40ff4a96a1eb0324701837e4b5946727b4d3e41ae5d29b6',
}
operators = (
    'worker_apfs_drive.py', 'public_machine.py', 'outer_machine_proof.py', 'probe_virtiofs_sysfs.py',
    'retire_worker.py', 'prepare_image.py', 'with_host_load.py', 'probe_quiet_admission.sh',
    'qualify_workloads.sh', 'run_scored_worker.sh', 'run_gamma4_arm.sh', 'run_public_arm.sh',
    'bench_stock_git_density.py', 'measure_main_ci.py', 'guest_splice_contract.py',
    'mmap_exact_timestamp.py', 'stock_pid1_probe.py', 'prepare_guest_bank.sh', 'qualify_linux_candidate.sh',
    'qualify_guest_binary.sh', 'prepare_terminal_bank.py', 'trigger_local_completion_lifecycle.py',
    'qualify_virtiofs_local_completion.sh', 'trigger_inline_completion_lifecycle.py',
    'collect_vmm_exit_metrics.py', 'trace_stock_git_completion.py', 'diagnose_checkout_prepare.py',
    'profile_git_density.py', 'summarize_git_profiles.py', 'summarize_control.py', 'run_quiet_git_profile.py',
    'inherited-gamma6/summarize_gamma6.py', 'load_ryuk_for_worker.sh', 'prepare_gamma8.py',
    'finalize_gamma8.py', 'summarize_gamma8.py', 'retain_gamma8.py', 'rehash_baseline_gamma8.py',
)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, payload, mode=0o600):
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == payload, path
    else:
        with path.open('xb') as stream:
            stream.write(payload)
    path.chmod(mode)


def record(path, body):
    save(path, (json.dumps(body, indent=2) + '\n').encode())


def files_from_archive(source, destination, hashes):
    entries = {}
    with tarfile.open(source) as archive:
        for item in archive:
            path = Path(item.name)
            assert not path.is_absolute() and '..' not in path.parts and item.isfile()
            assert item.name in hashes and item.name not in entries
            with archive.extractfile(item) as payload:
                save(destination / path, payload.read(), item.mode & 0o777)
            entries[item.name] = sha(destination / path)
    assert entries == hashes
    return entries


def main():
    assert hub.is_mount()
    for path, digest in expected.items():
        assert sha(path) == digest, path
    previous = json.loads(preceding_scorecard.read_bytes())
    assert previous['cleanup']['private_stage_removed']
    assert all(not Path(row['image']).exists() for row in previous['cleanup']['worker_volumes'].values())
    assert not Path('/private/tmp/mp-gamma8.MEb28U').exists()
    for text, digest in previous['prior_preservation'].items():
        assert sha(Path(text)) == digest, text
    runtime = json.loads(preceding_runtime.read_bytes())
    products = {**runtime['retained'], **runtime['verified_test_executables']}
    for key, item in products.items():
        path = Path(item['path'])
        assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256'], key
        if key.endswith('/vmm'):
            subprocess.run(['/usr/bin/codesign', '--verify', '--strict', str(path)], check=True, timeout=20)
    raw = {}
    with tarfile.open(preceding_archive, mode='r|gz') as archive:
        for item in archive:
            path = Path(item.name)
            assert item.isfile() and not path.is_absolute() and '..' not in path.parts
            assert item.name not in raw
            with archive.extractfile(item) as payload:
                raw[item.name] = payload.read()
    manifest = json.loads(raw.pop('MANIFEST.sha256.json'))
    assert {name: hashlib.sha256(payload).hexdigest() for name, payload in raw.items()} == manifest
    assert len(raw) == previous['receipts']['entries'] == 1111
    preservation = json.loads(raw['original-qos-preservation-recheck.json'])
    preserved_manifest = Path(preservation['manifest'])
    assert sha(preserved_manifest) == preservation['manifest_sha256']
    original = json.loads(preserved_manifest.read_bytes())
    assert original['source'] == preservation['source']
    for name, digest in original['sha256'].items():
        assert sha(Path(original['source']) / name) == sha(preserved_manifest.parent / name) == digest, name
    assert len(original['sha256']) == 24
    record(receipts / 'original-qos-preservation-recheck.json', preservation)
    for name in operators:
        save(receipts / 'inherited-gamma8' / name, raw[name])
    for name in operators:
        if name.endswith('gamma8.py'):
            continue
        payload = raw[name]
        if name == 'public_machine.py':
            payload = payload.replace(b"prefix='mpg8-'", b"prefix='mpg9-'")
        elif name in ('retire_worker.py', 'qualify_guest_binary.sh'):
            payload = payload.replace(b'mpg8-', b'mpg9-')
        elif name in ('prepare_terminal_bank.py', 'run_quiet_git_profile.py'):
            payload = payload.replace(b'55f2ae080a601a84fd10123f6a717e880a0da6f1f2d9f827f7bf249fa79ca4d0',
                                      b'0b20a6f006ca61efa323287777e51466833b21c649982d287948d4b1bf506af8')
        elif name == 'prepare_image.py':
            payload = payload.replace(b'gamma8', b'gamma9').replace(b'gamma7-image-reference', b'gamma8-image-reference')
        save(receipts / name, payload)
    save(receipts / 'gamma8-image-reference.json', raw['image.json'])
    save(receipts / 'gamma8-seed-reference.json', raw['frozen-closed-seed.json'])
    save(receipts / 'gamma8-baseline-lineage.json', raw['baseline-lineage.json'])
    source = receipts / 'reference-gamma8'
    for name, payload in raw.items():
        if name.startswith('stock-services/create-conflict-source/'):
            save(source / 'guest' / Path(name).name, payload)
        if name in ('host-coalesce/v2/control-sources.json', 'host-coalesce/v2/candidate-source.tar.gz',
                    'host-coalesce/v2/candidate-source.json', 'host-coalesce/v2/workspace-coalesce.patch'):
            save(source / 'vmm' / Path(name).name, payload)
    protected = hub / 'reference-gamma8'
    guest_file = source / 'guest/source.tar.gz'
    guest_manifest = json.loads((source / 'guest/source.json').read_bytes())
    assert sha(guest_file) == guest_manifest['source_archive_sha256']
    guest = files_from_archive(guest_file, protected / 'source', guest_manifest['source_files'])
    vmm_file = source / 'vmm/candidate-source.tar.gz'
    metadata = json.loads((source / 'vmm/candidate-source.json').read_bytes())
    assert sha(vmm_file) == metadata['archive_sha256']
    assert metadata['archived_binary_sha256'] == products['control/vmm']['sha256']
    vmm = protected / 'vmm'
    files_from_archive(vmm_file, vmm, metadata['source_sha256'])
    patch = source / 'vmm/workspace-coalesce.patch'
    assert sha(patch) == metadata['patch_sha256']
    subprocess.run(['/usr/bin/git', 'apply', '--reverse', str(patch)], cwd=vmm, check=True, timeout=15)
    control = json.loads((source / 'vmm/control-sources.json').read_bytes())
    assert {name: sha(vmm / name) for name in control} == control
    assert len(control) == 42
    record(receipts / 'preceding-gamma8-recheck.json', {
        'rechecked_utc': datetime.now(timezone.utc).isoformat(),
        'products': {str(path): digest for path, digest in expected.items()},
        'preceding_prior_files_preserved': previous['prior_preservation'],
        'receipts_rehashed': len(raw), 'original_files_rehashed': 24, 'preserved_files_rehashed': 24,
        'runtime_binaries_rehashed': {name: item['sha256'] for name, item in products.items()},
        'guest_source': {'path': str(protected / 'source/guest/runner'), 'entries': len(guest),
                         'archive_sha256': guest_manifest['source_archive_sha256'], 'files': guest},
        'f074_source': {'path': str(vmm), 'entries': len(control), 'files': control,
                        'reverse_patch_replay_sha256': sha(patch)},
        'inherited_operator_sha256': {name: manifest[name] for name in operators},
    })
    print('Gamma8 validated, source banks ready', protected)


if __name__ == '__main__':
    main()
