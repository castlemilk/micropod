#!/bin/sh
# Run once in a disposable guest's trusted tools bank, after traced and timed work.
set -eu
umask 077

workspace=${MICROPOD_ENGINE_WORKSPACE:?}
request="$workspace/.workspace-inline-completion.request"
receipt="$workspace/.workspace-inline-completion.done"
owner="$(dirname "$0")/.workspace-inline-completion.owner"
setting=/sys/module/virtiofs/parameters/workspace_reply_poll
IFS= read -r token < "$owner"
case "$token" in ''|*[!0-9a-f]*) exit 1 ;; esac
[ "${#token}" -eq 32 ]
token_hash=$(printf '%s' "$token" | sha256sum | cut -d ' ' -f 1)
deadline=$(($(cut -d . -f 1 /proc/uptime) + 300))
while [ ! -f "$request" ]; do
    [ "$(cut -d . -f 1 /proc/uptime)" -lt "$deadline" ] || exit 0
    sleep 0.1
done
[ ! -L "$request" ]
[ "$(stat -c %s "$request")" = 33 ]
[ ! -e "$receipt" ]
[ ! -L "$receipt" ]
for leaf in .workspace-inline-completion.trace .workspace-inline-completion.stats; do
    [ ! -e "$workspace/$leaf" ] && [ ! -L "$workspace/$leaf" ]
done
IFS= read -r provided < "$request"
[ "$provided" = "$token" ]

mode=$(cat "$setting")
case "$mode" in N|Y) ;; *) exit 1 ;; esac
[ "$(stat -c %a "$setting")" = 444 ]
[ "$(cat /sys/module/virtiofs/parameters/workspace_async_release)" = Y ]

scratch=$(mktemp -d /run/mp-inline-completion.XXXXXX)
mount_a="$scratch/a"
mount_b="$scratch/b"
leaf="inline-completion-$(basename "$scratch")"
fixture="$workspace/$leaf"
reason=invalid_workspace
have_a=0 have_b=0 have_fixture=0 restore_workspace=0
children=
trace_instance=
trace_root=
trace_mounted=0
trace_probe=0

workspace_device() {
    awk -v path="$workspace" '
        $5 == path {
            for (i = 7; i <= NF; i++) {
                if ($i != "-") continue
                if ($(i+1) == "virtiofs" && $(i+2) == "workspace" && $3 ~ /^[0-9]+:[0-9]+$/) good = $3
                break
            }
            seen++
        }
        END { if (seen == 1 && good != "") print good; else if (seen != 0) exit 1 }
    ' /proc/self/mountinfo
}

restore_mount() {
    present=$(workspace_device) || return 1
    [ -z "$present" ] || return 1
    timeout 8 mount -t virtiofs -o nosuid,nodev workspace "$workspace"
}

start_trace() {
    trace_root=/sys/kernel/tracing
    if [ ! -d "$trace_root/instances" ]; then
        trace_root="$scratch/tracefs"
        mkdir "$trace_root"
        mount -t tracefs -o nosuid,nodev,noexec tracefs "$trace_root"
        trace_mounted=1
    fi
    trace_instance="$trace_root/instances/mp-inline-life-$$"
    mkdir "$trace_instance"
    printf '0\n' > "$trace_instance/tracing_on"
    printf '0\n' > "$trace_instance/options/overwrite"
    printf '1024\n' > "$trace_instance/buffer_size_kb"
    printf 'mono\n' > "$trace_instance/trace_clock"
    grep -Fq '[mono]' "$trace_instance/trace_clock"
    for event in fuse_request_send fuse_request_end; do
        printf 'connection == %s\n' "$1" > "$trace_instance/events/fuse/$event/filter"
        printf '1\n' > "$trace_instance/events/fuse/$event/enable"
    done
    printf 'sig == 9\n' > "$trace_instance/events/signal/signal_generate/filter"
    printf '1\n' > "$trace_instance/events/signal/signal_generate/enable"

    if awk '$3 == "virtio_fs_enqueue_req" { ok++ } END { exit ok != 1 }' /proc/kallsyms &&
       printf 'r:mpvirtiofs_inline/enqueue_return virtio_fs_enqueue_req ret=$retval:s32\n' >> "$trace_root/kprobe_events"; then
        trace_probe=1
        group="$trace_instance/events/mpvirtiofs_inline/enqueue_return"
        printf 'ret == -28\n' > "$group/filter"
        printf '1\n' > "$group/enable"
    fi
    printf 'queue_pressure_retprobe=%s\n' "$trace_probe" >> "$scratch/details"
    printf '1\n' > "$trace_instance/tracing_on"
}

stop_trace() {
    if [ -d "$trace_instance" ]; then
        printf '0\n' > "$trace_instance/tracing_on" || return 1
        cat "$trace_instance/trace" > "$scratch/trace" || return 1
        {
            for cpu in "$trace_instance/per_cpu"/cpu*; do
                printf '[%s]\n' "${cpu##*/}"
                cat "$cpu/stats" || return 1
            done
        } > "$scratch/trace-stats" || return 1
        rmdir "$trace_instance" || return 1
        trace_instance=
    fi
    if [ "$trace_probe" = 1 ]; then
        printf '%s\n' '-:mpvirtiofs_inline/enqueue_return' >> "$trace_root/kprobe_events" || return 1
        trace_probe=0
    fi
    if [ "$trace_mounted" = 1 ]; then
        umount "$trace_root" || return 1
        rmdir "$trace_root" || return 1
        trace_mounted=0
    fi
}

publish() {
    pending=$(mktemp "$workspace/.workspace-inline-publish.XXXXXX")
    if cat "$1" > "$pending" && mv "$pending" "$workspace/$2"; then
        return 0
    fi
    rm -f "$pending"
    return 1
}

cleanup() {
    code=$?
    trap - EXIT HUP INT TERM
    set +e
    if [ -n "$children" ]; then
        for child in $children; do kill -KILL "$child" 2>/dev/null; done
        for child in $children; do wait "$child" || :; done
    fi
    stop_trace || code=1
    restored=$(cat "$setting") || code=1
    exec 4<&-
    if [ "$have_b" = 1 ]; then timeout 8 umount "$mount_b" || code=1; fi
    if [ "$have_a" = 1 ]; then timeout 8 umount "$mount_a" || code=1; fi
    if [ "$restore_workspace" = 1 ]; then
        if actual=$(workspace_device) && [ -n "$actual" ]; then timeout 8 umount "$workspace" || code=1; fi
        restore_mount || code=1
    fi
    recovered=$(workspace_device) || code=1
    if [ "$have_fixture" = 1 ] && [ -n "$recovered" ]; then rm -r "$fixture" || code=1; fi
    details=
    if [ -f "$scratch/details" ]; then details=$(cat "$scratch/details"); fi
    if [ -n "$recovered" ] && [ -f "$scratch/trace" ]; then
        publish "$scratch/trace" .workspace-inline-completion.trace || code=1
        publish "$scratch/trace-stats" .workspace-inline-completion.stats || code=1
    fi
    rm -f "$scratch/details" "$scratch/expected" "$scratch/go" "$scratch"/ready-* "$scratch"/done-* \
        "$scratch/bulk" "$scratch"/reader-* "$scratch"/writer-* "$scratch"/cancel-* \
        "$scratch/trace" "$scratch/trace-stats"
    rmdir "$mount_a" "$mount_b" "$scratch" || code=1
    result=$({
        printf 'token_sha256=%s\nmode_initial=%s\nmode_final=%s\nexit=%s\nstep=%s\nworkspace_device_final=%s\n' \
            "$token_hash" "$mode" "$restored" "$code" "$reason" "$recovered"
        if [ -n "$details" ]; then printf '%s\n' "$details"; fi
    })
    printf '[workspace-inline-completion-test]\n%s\n' "$result"
    if [ -n "$recovered" ]; then
        pending=$(mktemp "$workspace/.workspace-inline-completion.XXXXXX")
        printf '%s\n' "$result" > "$pending" && mv "$pending" "$receipt" || { rm -f "$pending"; code=1; }
    fi
    exit "$code"
}

trap cleanup EXIT
trap 'reason=interrupted; exit 1' HUP INT TERM
initial=$(workspace_device)
[ -n "$initial" ]
mkdir "$mount_a" "$mount_b" "$fixture"
have_fixture=1
printf 'workspace-inline-completion-%s\n' "$leaf" > "$scratch/expected"
dd if="$scratch/expected" of="$fixture/original" conv=fsync status=none
ln "$fixture/original" "$fixture/link"

printf 'workspace_device_initial=%s\n' "$initial" > "$scratch/details"
reason=mount_same_tag_again
timeout 8 mount -t virtiofs -o nosuid,nodev workspace "$mount_a"
have_a=1
printf 'same_tag_mount=1\n' >> "$scratch/details"
reason=mount_bind
timeout 8 mount --bind "$fixture" "$mount_b"
have_b=1
printf 'bind_mount=1\n' >> "$scratch/details"

reason=hardlink_metadata
printf 'before_revalidation_original=%s\nbefore_revalidation_link=%s\n' \
    "$(stat -c '%d:%i:%h' "$fixture/original")" "$(stat -c '%d:%i:%h' "$fixture/link")" >> "$scratch/details"
# Both cached aliases must be past the workspace's existing 20ms lifetime.
sleep 0.05
for view in original same_tag bind; do
    case "$view" in
        original) directory=$fixture ;;
        same_tag) directory="$mount_a/$leaf" ;;
        bind) directory=$mount_b ;;
    esac
    ident_original=$(stat -c '%d:%i:%h' "$directory/original")
    ident_link=$(stat -c '%d:%i:%h' "$directory/link")
    printf '%s_original=%s\n%s_link=%s\n' "$view" "$ident_original" "$view" "$ident_link" >> "$scratch/details"
done
for directory in "$fixture" "$mount_a/$leaf" "$mount_b"; do
    identity=$(stat -c '%d:%i:%h' "$directory/original")
    [ "$identity" = "$(stat -c '%d:%i:%h' "$directory/link")" ]
    case "$identity" in *:2) ;; *) exit 1 ;; esac
    cmp "$scratch/expected" "$directory/original"
    cmp "$scratch/expected" "$directory/link"
done

reason=held_and_replaced_handles
exec 4< "$mount_b/link"
printf 'atomic-replacement\n' > "$fixture/next"
mv "$fixture/next" "$fixture/link"
[ "$(cat <&4)" = "$(cat "$scratch/expected")" ]
exec 4<&-
sleep 0.05
[ "$(cat "$mount_a/$leaf/link")" = atomic-replacement ]
cmp "$scratch/expected" "$mount_b/original"

reason=concurrent_open_read_close
for slot in 1 2 3 4 5 6 7 8; do
    (
        : > "$scratch/ready-$slot"
        while [ ! -f "$scratch/go" ]; do sleep 0.002; done
        dd if="$scratch/expected" of="$mount_b/writer-$slot" conv=fsync status=none
        cmp "$scratch/expected" "$mount_a/$leaf/writer-$slot"
        n=0
        while [ "$n" -lt 128 ]; do
            cmp "$scratch/expected" "$mount_b/original"
            n=$((n + 1))
        done
        : > "$scratch/done-$slot"
    ) &
    children="$children $!"
done
tries=0
for slot in 1 2 3 4 5 6 7 8; do
    while [ ! -f "$scratch/ready-$slot" ]; do
        [ "$tries" -lt 1000 ]
        tries=$((tries + 1))
        sleep 0.002
    done
done
: > "$scratch/go"
failed=0
for child in $children; do wait "$child" || failed=1; done
children=
printf 'concurrent_readers=8\nreads_per_job=128\nfsynced_writers=8\n' >> "$scratch/details"
[ "$failed" = 0 ]

reason=queue_pressure_and_cancellation
dd if=/dev/urandom of="$scratch/bulk" bs=256k count=16 status=none
bulk_sha=$(sha256sum "$scratch/bulk" | cut -d ' ' -f 1)
dd if="$scratch/bulk" of="$fixture/bulk" bs=256k conv=fsync status=none
printf 'bulk_sha256=%s\n' "$bulk_sha" >> "$scratch/details"
major=${initial%:*}
minor=${initial#*:}
connection=$((major * 1048576 + minor))
start_trace "$connection"
rm -f "$scratch/go"
for slot in $(seq 1 24); do
    (
        while [ ! -f "$scratch/go" ]; do sleep 0.002; done
        exec dd if="$mount_b/bulk" of="$scratch/reader-$slot" bs=256k status=none
    ) &
    children="$children $!"
done
for slot in $(seq 1 4); do
    (
        while [ ! -f "$scratch/go" ]; do sleep 0.002; done
        exec dd if="$scratch/bulk" of="$mount_b/writer-bulk-$slot" bs=256k conv=fsync status=none
    ) &
    children="$children $!"
done
: > "$scratch/go"
failed=0
for child in $children; do wait "$child" || failed=1; done
children=
[ "$failed" = 0 ]
for file in "$scratch"/reader-* "$mount_a/$leaf"/writer-bulk-*; do
    [ "$(sha256sum "$file" | cut -d ' ' -f 1)" = "$bulk_sha" ]
done
printf 'bulk_readers=24\nbulk_fsynced_writers=4\nbulk_each_bytes=4194304\n' >> "$scratch/details"

rm -f "$scratch/go"
for slot in $(seq 1 12); do
    (
        : > "$scratch/cancel-$slot"
        while [ ! -f "$scratch/go" ]; do sleep 0.002; done
        exec dd if="$mount_b/bulk" of=/dev/null bs=1024 status=none
    ) &
    children="$children $!"
done
for slot in $(seq 1 12); do
    tries=0
    while [ ! -f "$scratch/cancel-$slot" ]; do
        [ "$tries" -lt 100 ]
        tries=$((tries + 1))
        sleep 0.002
    done
done
: > "$scratch/go"
sleep 0.012
printf 'cancel_target_pids=%s\n' "${children# }" >> "$scratch/details"
for child in $children; do
    kill -KILL "$child" 2>/dev/null || :
done
killed=0
for child in $children; do
    status=0
    wait "$child" || status=$?
    if [ "$status" = 137 ]; then killed=$((killed + 1)); fi
done
children=
printf 'cancel_started=12\ncancel_killed=%s\ntrace_connection=%s\n' "$killed" "$connection" >> "$scratch/details"
[ "$killed" -gt 0 ]
[ "$(sha256sum "$mount_a/$leaf/bulk" | cut -d ' ' -f 1)" = "$bulk_sha" ]
stop_trace

reason=last_mount_unmount_and_remount
timeout 8 umount "$mount_b"
have_b=0
timeout 8 umount "$mount_a"
have_a=0
cmp "$scratch/expected" "$fixture/original"
timeout 8 umount "$workspace"
restore_workspace=1
[ -z "$(workspace_device)" ]
restore_mount
restore_workspace=0
first_remount=$(workspace_device)
[ -n "$first_remount" ]
cmp "$scratch/expected" "$fixture/original"
[ "$(sha256sum "$fixture/bulk" | cut -d ' ' -f 1)" = "$bulk_sha" ]
printf 'workspace_device_remounted=%s\ncancel_recovered=1\n' "$first_remount" >> "$scratch/details"

reason=pass
