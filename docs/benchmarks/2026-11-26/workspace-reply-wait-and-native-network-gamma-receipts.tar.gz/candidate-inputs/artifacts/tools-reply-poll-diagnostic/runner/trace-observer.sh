#!/bin/sh
# One shot. Installed only in the isolated worker's trusted, read-only tools.
set -eu
umask 077
workspace=${MICROPOD_ENGINE_WORKSPACE:?}
start="$workspace/.trace-start.request"
finish="$workspace/.trace-finished.request"
token=
instance=
scratch=
owned_mount=
probe_group=
entry_added=0
return_added=0
state=error
reason=unhandled

publish() {
    output=$(mktemp "$workspace/.trace-$token.XXXXXX") || return 1
    if cat "$1" > "$output" && mv -f "$output" "$workspace/$2"; then
        return 0
    fi
    rm -f "$output"
    return 1
}

record_setup() {
    {
        printf '[%s]\n' "$1"
        for leaf in trace_clock available_tracers current_tracer trace_options buffer_size_kb tracing_on; do
            printf '%s\n' "$leaf"
            if [ -r "$2/$leaf" ]; then
                cat "$2/$leaf"
            else
                printf '%s\n' '<unavailable>'
            fi
        done
    } >> "$scratch/setup"
}

cleanup() {
    code=$?
    trap - EXIT HUP INT TERM
    set +e
    if [ -n "$instance" ]; then
        record_setup "exit:$reason" "$instance"
        if ! printf '0\n' > "$instance/tracing_on" || ! rmdir "$instance"; then
            state=error
            reason=remove_trace_instance
            code=1
        fi
    fi
    if [ "$return_added" -eq 1 ] && ! printf -- '-:%s/poll_leave\n' "$probe_group" >> "$root/kprobe_events"; then
        state=error
        reason=remove_poll_return_probe
        code=1
    fi
    if [ "$entry_added" -eq 1 ] && ! printf -- '-:%s/poll_enter\n' "$probe_group" >> "$root/kprobe_events"; then
        state=error
        reason=remove_poll_entry_probe
        code=1
    fi
    if [ -n "$owned_mount" ]; then
        if ! umount "$owned_mount" || ! rmdir "$owned_mount"; then
            state=error
            reason=unmount_private_tracefs
            code=1
        fi
    fi
    if [ -n "$token" ] && [ -n "$scratch" ]; then
        printf '[stderr]\n' >> "$scratch/setup"
        cat "$scratch/stderr" >> "$scratch/setup"
        if ! publish "$scratch/setup" .trace-observer.log; then
            printf '%s\n' '[trace-proof] could not publish .trace-observer.log' >&3
            code=1
        fi
        printf 'schema=1\ntoken=%s\nstatus=%s\nreason=%s\n' "$token" "$state" "$reason" > "$scratch/done"
        if ! publish "$scratch/done" .trace-done; then
            printf '%s\n' '[trace-proof] could not publish .trace-done' >&3
            code=1
        fi
    fi
    if [ -n "$scratch" ]; then
        rm -f "$scratch/started" "$scratch/events" "$scratch/stats" "$scratch/done" "$scratch/setup" "$scratch/stderr"
        rmdir "$scratch" || code=1
    fi
    exit "$code"
}

valid_control() {
    [ ! -L "$1" ] && [ -f "$1" ] && [ "$(stat -c %s "$1")" = 17 ] || return 1
    IFS= read -r control < "$1" || return 1
    case "$control" in ''|*[!0-9a-f]*) return 1 ;; esac
    [ "${#control}" -eq 16 ]
}

uptime_seconds() {
    IFS=' ' read -r uptime _ < /proc/uptime
    printf '%s\n' "${uptime%.*}"
}

trap cleanup EXIT
trap 'reason=interrupted; exit 1' HUP INT TERM
arm_deadline=$(($(uptime_seconds) + 300))
while [ ! -f "$start" ]; do
    [ "$(uptime_seconds)" -lt "$arm_deadline" ] || exit 0
    sleep 0.10
done
valid_control "$start" || { printf '%s\n' '[trace-proof] invalid start request' >&2; exit 1; }
token=$control
scratch=$(mktemp -d /run/mp-trace.XXXXXX)
exec 3>&2 2>"$scratch/stderr"
reason=stale_workspace_control
for leaf in .trace-finished.request .trace-started .trace-events .trace-stats .trace-done .trace-observer.log; do
    [ ! -e "$workspace/$leaf" ] && [ ! -L "$workspace/$leaf" ] || exit 1
done

reason=workspace_mount
device=$(awk '
    {
        for (i = 7; i <= NF; i++) {
            if ($i != "-") continue
            if ($(i + 1) == "virtiofs" && $(i + 2) == "workspace") print $3
            break
        }
    }
' /proc/self/mountinfo | sort -u)
connection=$(printf '%s\n' "$device" | awk -F: '
    /^[0-9]+:[0-9]+$/ && NR == 1 { value = $1 * 1048576 + $2; next }
    { invalid = 1 }
    END { if (!invalid && NR == 1 && value > 0) printf "%.0f\n", value; else exit 1 }
')

reason=mount_tracefs
root=/sys/kernel/tracing
if [ ! -d "$root/instances" ]; then
    root="$scratch/tracefs"
    mkdir "$root"
    if ! mount -t tracefs -o nosuid,nodev,noexec tracefs "$root"; then
        rmdir "$root"
        exit 1
    fi
    owned_mount=$root
fi
record_setup root_before_instance "$root"
reason=mkdir_trace_instance
name="$root/instances/mp-workspace-$token"
mkdir "$name"
instance=$name
record_setup instance_before_config "$instance"
reason=disable_instance
printf '0\n' > "$instance/tracing_on"
reason=select_nop_tracer
if [ -w "$instance/current_tracer" ] && [ "$(cat "$instance/current_tracer")" != nop ]; then
    printf 'nop\n' > "$instance/current_tracer"
fi
reason=set_buffer_capacity
printf '2048\n' > "$instance/buffer_size_kb"
reason=set_overwrite_option
overwrite=kernel-default
if [ -w "$instance/options/overwrite" ]; then
    printf '0\n' > "$instance/options/overwrite"
    overwrite=disabled
elif [ -w "$instance/trace_options" ] && (printf 'nooverwrite\n' > "$instance/trace_options"); then
    overwrite=disabled
fi
reason=select_monotonic_clock
clock=
for candidate in mono global; do
    if (printf '%s\n' "$candidate" > "$instance/trace_clock") &&
       grep -Fq "[$candidate]" "$instance/trace_clock"; then
        clock=$candidate
        break
    fi
done
[ -n "$clock" ] || exit 1
record_setup instance_after_config "$instance"

reason=configure_fuse_events
for event in fuse_request_send fuse_request_end; do
    point="$instance/events/fuse/$event"
    printf 'connection == %s\n' "$connection" > "$point/filter"
    printf '1\n' > "$point/enable"
done

reason=configure_workqueue_events
address=$(awk '$3 == "virtio_fs_requests_done_work" && $1 ~ /[1-9a-f]/ {print $1}' /proc/kallsyms | sort -u)
case "$address" in ''|*[!0-9a-f]*) address= ;; esac
filtered=0
for event in workqueue_queue_work workqueue_execute_start workqueue_execute_end; do
    point="$instance/events/workqueue/$event"
    if [ -n "$address" ] && (printf 'function == 0x%s\n' "$address" > "$point/filter") 2>/dev/null; then
        filtered=$((filtered + 1))
    else
        printf '0\n' > "$point/filter"
    fi
    printf '1\n' > "$point/enable"
done

reason=set_poll_probes
[ -w "$root/kprobe_events" ]
probe_group="mpg9_poll_$token"
printf 'p:%s/poll_enter virtio_fs_poll_reply\n' "$probe_group" >> "$root/kprobe_events"
entry_added=1
printf 'r128:%s/poll_leave virtio_fs_poll_reply\n' "$probe_group" >> "$root/kprobe_events"
return_added=1
for event in poll_enter poll_leave; do
    printf '1\n' > "$instance/events/$probe_group/$event/enable"
done
for event in sys_enter_close sys_exit_close; do
    printf '1\n' > "$instance/events/syscalls/$event/enable"
done
poll_setting=/sys/module/virtiofs/parameters/workspace_reply_poll
poll_mode=$(cat "$poll_setting")
case "$poll_mode" in N|Y) ;; *) exit 1 ;; esac
reason=publish_started
{
    printf 'schema=1\ntoken=%s\ndevice=%s\nconnection=%s\n' "$token" "$device" "$connection"
    printf 'clock=%s\noverwrite=%s\nbuffer_kib_per_cpu=2048\nmax_capture_s=30\nobserver_pid=%s\n' "$clock" "$overwrite" "$$"
    printf 'kernel_work_event_filters=%s\n' "$filtered"
    printf 'kernel_release=%s\n' "$(uname -r)"
    printf 'poll_probe_group=%s\nworkspace_reply_poll=%s\n' "$probe_group" "$poll_mode"
    printf 'workspace_local_completion=unavailable\n'
    printf 'boot_id=%s\n' "$(cat /proc/sys/kernel/random/boot_id)"
} > "$scratch/started"

deadline=$(($(uptime_seconds) + 30))
printf '1\n' > "$instance/tracing_on"
printf 'mp-workspace-start %s\n' "$token" > "$instance/trace_marker"
publish "$scratch/started" .trace-started

reason=finish_timeout
while [ ! -f "$finish" ]; do
    if [ "$(uptime_seconds)" -ge "$deadline" ]; then
        state=timeout
        break
    fi
    sleep 0.05
done

printf 'mp-workspace-finish %s\n' "$token" > "$instance/trace_marker"
printf '0\n' > "$instance/tracing_on"
if [ "$state" != timeout ]; then
    reason=finish_token
    valid_control "$finish" && [ "$control" = "$token" ] || exit 1
    state=ok
    reason=finished
fi

saved_state=$state
saved_reason=$reason
state=error
reason=export_capture
cat "$instance/trace" > "$scratch/events"
{
    printf '[kprobe_profile]\n'
    grep -E '(^|[[:space:]])poll_(enter|leave)([[:space:]]|$)' "$root/kprobe_profile" || :
} >> "$scratch/setup"
{
    for cpu in "$instance"/per_cpu/cpu*; do
        printf '[%s]\n' "${cpu##*/}"
        cat "$cpu/stats"
    done
} > "$scratch/stats"
publish "$scratch/events" .trace-events
publish "$scratch/stats" .trace-stats
state=$saved_state
reason=$saved_reason
[ "$state" = ok ]
