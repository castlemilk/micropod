from pathlib import Path
import hashlib,json,sys
root, frozen, output = map(Path,sys.argv[1:]); manifest=json.loads(frozen.read_bytes()); runner=root/'guest/runner'
def sha(path):
    with path.open('rb') as file: return hashlib.file_digest(file,'sha256').hexdigest()
actual={p.relative_to(root).as_posix():sha(p) for p in sorted(runner.iterdir()) if p.is_file()}
nested={p.relative_to(root).as_posix():sha(p) for p in sorted(runner.rglob('*')) if p.is_file() and p.parent!=runner}
assert actual==manifest['source_files'] and len(nested)==7
receipt={'fields':{'qualified_runner_sha256':manifest['runner_sha256'],'qualified_tests_sha256':manifest['linux_test_sha256'],
                   'qualified_source_archive_sha256':manifest['source_archive_sha256']},'build_sources':actual,'other_preserved_sources':nested}
with output.open('x') as f: f.write(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
