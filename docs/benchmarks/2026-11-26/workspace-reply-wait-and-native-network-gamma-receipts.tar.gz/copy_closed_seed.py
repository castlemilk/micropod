"""Freeze a private read-only template, leaving the pinned cached template unchanged."""
import hashlib
import json
from pathlib import Path
import subprocess

receipts = Path(__file__).resolve().parent
hub = receipts.parent / 'home'
previous = json.loads((receipts/'gamma8-seed-reference.json').read_bytes())
source = Path(previous['source'])
destination = hub/'artifacts/closed-seed.ext4'

def identity(path):
    stat=path.stat()
    return {'device':stat.st_dev,'inode':stat.st_ino,'mtime_ns':stat.st_mtime_ns,'size':stat.st_size}

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

assert hub.is_mount() and source.is_file() and not source.is_symlink()
assert not destination.exists()
start = identity(source)
assert start == previous['source_identity']
subprocess.run(['/bin/cp', '-p', str(source), str(destination)], check=True, timeout=40)
destination.chmod(0o400)
assert identity(source) == start and digest(source) == previous['sha256'] == digest(destination)
assert identity(destination)['device'] == hub.stat().st_dev and identity(destination)['device'] != start['device']
result={'source_is_a_template_copy_only':True,'source':str(source),'source_identity':start,
        'staged':str(destination),'staged_identity':identity(destination),'sha256':previous['sha256']}
with (receipts/'frozen-closed-seed.json').open('x') as output:
    json.dump(result,output,indent=2)
    output.write('\n')
