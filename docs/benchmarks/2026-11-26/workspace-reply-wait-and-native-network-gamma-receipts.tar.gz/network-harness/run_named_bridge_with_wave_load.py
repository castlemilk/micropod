#!/usr/bin/env python3
"""Add per-wave macOS host CPU samples to the frozen named bridge benchmark."""

import ctypes
from datetime import datetime, timezone
import os
import time
from unittest.mock import patch

import bench_named_bridge_ci as benchmark


lib = ctypes.CDLL('/usr/lib/libSystem.B.dylib')
CPU_STATES = ('user', 'system', 'idle', 'nice')
Ticks = ctypes.c_uint32 * len(CPU_STATES)
lib.mach_host_self.restype = ctypes.c_uint32
lib.host_statistics.argtypes = (
    ctypes.c_uint32, ctypes.c_int, ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_uint32),
)
host = lib.mach_host_self()


def probe_host_cpu():
    values, count = Ticks(), ctypes.c_uint32(len(CPU_STATES))
    if lib.host_statistics(host, 3, values, ctypes.byref(count)) != 0 or count.value != len(CPU_STATES):
        raise RuntimeError('Could not sample host CPU states')
    return {
        'monotonic_ns': time.monotonic_ns(),
        'utc': datetime.now(timezone.utc).isoformat(),
        'load_average': os.getloadavg(),
        'cpu_ticks': dict(zip(CPU_STATES, values)),
    }


measure = benchmark.Wave.measure


def measure_with_load(wave):
    before = probe_host_cpu()
    result = measure(wave)
    after = probe_host_cpu()
    deltas = {state: (after['cpu_ticks'][state] - before['cpu_ticks'][state]) % (1 << 32)
              for state in CPU_STATES}
    total = sum(deltas.values())
    result['host_cpu'] = {
        'interval': 'Entire named-bridge wave, including prelaunch setup and scoped cleanup',
        'before': before,
        'after': after,
        'delta_ticks': deltas,
        'cpu_idle_pct': deltas['idle'] * 100 / total if total else None,
    }
    return result


if __name__ == '__main__':
    with patch.object(benchmark.Wave, 'measure', measure_with_load):
        benchmark.main()
