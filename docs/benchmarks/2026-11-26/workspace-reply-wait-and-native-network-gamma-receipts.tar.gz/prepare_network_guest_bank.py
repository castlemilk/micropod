"""Attest the guest's existing iptables-restore version once before its runner starts."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

receipts = Path(__file__).resolve().parent
hub = receipts.parent/'home'
label = sys.argv[1]
assert re.fullmatch(r'[a-z0-9-]{1,22}',label)
start = hub/f'artifacts/tools-{label}/runner/start.sh'
assert start.resolve(strict=True).is_relative_to(hub)
job = start.with_name('bin')/'job'
text = start.read_text()
anchor = '"$tools/runner/bin/job" recover\n'
assert text.count(anchor)==1 and 'gamma9-iptables-restore-version' not in text
probe = '''if command -v iptables-restore >/dev/null; then
    printf 'gamma9-iptables-restore-version %s\\n' "$(iptables-restore -V 2>&1 || true)"
else
    printf 'gamma9-iptables-restore-version unavailable\\n'
fi
'''
start.write_text(text.replace(anchor,probe+anchor))
subprocess.run(['/bin/sh','-n',str(start)],check=True,timeout=10)
proof={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in [('runner/start.sh',start),('runner/bin/job',job)]}
with (receipts/f'{label}-runner-start.sh').open('x') as saved: saved.write(start.read_text())
with (receipts/f'{label}-bank-lineage.json').open('x') as output: json.dump(proof,output,indent=2);output.write('\n')
