"""Own a supervised, public-CLI Micropod machine on a protected disposable APFS drive."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace

import outer_machine_proof as proof
import worker_apfs_drive as apfs

receipts = Path(__file__).resolve().parent
stage = receipts.parent
hub = stage / 'home'
artifacts = hub / 'artifacts'
root = Path('/Users/benebsworth/projects/micropod')
cache_seed = Path('/Users/benebsworth/.micropod/sandbox/images/sha256-469c9ea410b9215eaee7976ba6c0639039b444be8e5d638f7abbada189971eb2-4g.ext4')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('label')
parser.add_argument('--vmm', type=Path, default=artifacts / 'micropod-vmm')
parser.add_argument('--initrd', type=Path, default=artifacts / 'mp-hvf-init.cpio')
parser.add_argument('--kernel', type=Path, default=artifacts / 'Image')
parser.add_argument('--tools', type=Path, default=artifacts / 'tools-baseline')
parser.add_argument('--cli', type=Path, default=artifacts / 'cli-baseline/micropod')
parser.add_argument('--app-manifest', type=Path, help='Verify and use a complete private app with its ordinary bundled payload lookup')
parser.add_argument('--early-irq', choices=('0', '1'))
parser.add_argument('--live-read', choices=('0', '1'))
parser.add_argument('--kernel-arg', action='append', default=[])
parser.add_argument('--workspace-queues', choices=('1', '4'))
parser.add_argument('--workspace-event-idx', choices=('0', '1'))
parser.add_argument('--workspace-coalesce', choices=('0', '1'))
args = parser.parse_args()
assert re.fullmatch('[a-z0-9-]{1,22}', args.label) and hub.is_mount()
assert all(re.fullmatch(r'[^\s\x00]+', argument) for argument in args.kernel_arg)
payload = {'cli':args.cli, 'vmm':args.vmm, 'initrd':args.initrd, 'kernel':args.kernel,
           'job':args.tools/'runner/bin/job'}
packaged = None
if args.app_manifest:
    packaged = json.loads(args.app_manifest.read_bytes())
    app = Path(packaged['app']).resolve(strict=True)
    assert app.is_relative_to(hub) and app.suffix == '.app' and set(packaged['artifacts']) == set(payload)
    for key, row in packaged['artifacts'].items():
        relative = Path(row['relative_path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        payload[key] = app/relative
        assert payload[key].resolve(strict=True).is_relative_to(app) and proof.hash_file(payload[key]) == row['sha256']
    assert payload['job'].relative_to(app).parts[-3:] == ('runner','bin','job')
for path in payload.values():
    assert path.resolve(strict=True).is_relative_to(hub)
lineage = json.loads((receipts / 'image.json').read_text())
ready = receipts / f'{args.label}-ready.json'
result_path = receipts / f'{args.label}-worker.json'
assert not ready.exists() and not result_path.exists()
workspace = hub / 'share' / args.label
workspace.mkdir(mode=0o700)
scope = Path(tempfile.mkdtemp(prefix='mpg9-' + args.label + '-', dir='/private/tmp'))
mount = scope / 'home'
mount.mkdir(mode=0o700)
image = scope / 'worker.sparseimage'
mount_identity = proof.identity(mount)
base = artifacts / 'closed-seed.ext4'
record = {'label': args.label, 'worker_directory': str(scope), 'worker_volume': str(mount), 'image': str(image),
          'workspace': str(workspace), 'owner_pid': os.getpid(), 'drive': {}, 'errors': {}, 'owned_artifacts': {}}
p = None
raw = None


def holder_scan(target, *, volume=False):
    command = ['/usr/sbin/lsof', '-nP']
    command += ['+f', '--', str(target)] if volume else ['-t', str(target)]
    started = time.monotonic()
    scan = subprocess.run(command, timeout=55, text=True, capture_output=True)
    return {'argv': command, 'exit': scan.returncode, 'out': scan.stdout, 'err': scan.stderr,
            'elapsed_seconds': time.monotonic() - started}


def empty_scan(row):
    return row['exit'] == 1 and not row['out'].strip() and not row['err'].strip()


def prepare_seed():
    if base.is_file():
        return
    assert cache_seed.is_file() and not cache_seed.is_symlink()
    scan = holder_scan(cache_seed)
    record['closed_seed_holder_scan'] = scan
    assert empty_scan(scan), 'the cached readonly seed is open elsewhere'
    before = proof.identity(cache_seed)
    temporary = base.with_suffix('.copying')
    subprocess.run(['/bin/cp', '-p', str(cache_seed), str(temporary)], check=True, timeout=60)
    temporary.chmod(0o400)
    assert before == proof.identity(cache_seed)
    assert proof.hash_file(temporary) == proof.hash_file(cache_seed)
    temporary.rename(base)
    record['closed_seed_sha256'] = proof.hash_file(base)


def save():
    proof.record(result_path, record)


def on_signal(signum, _frame):
    raise InterruptedError(f'owner received signal {signum}')


def retire():
    expected = None
    raw_relative_path = 'worker.ext4'
    if p is not None:
        if p.start_attempted:
            p.run(p.binary, 'machine', 'stop', '--timeout', '22', timeout=30, label='graceful stop of owned machine')
            p.result['status_stopped'] = p.status('final machine status')
            final = p.result['status_stopped']
            process_table = proof.process_table()
            running = proof.scoped_processes(process_table, p.scope)
            p.result['scoped_processes_after_stop'] = running
            assert final['phase'] == 'stopped' and not final['supervisorAlive'] and not running, (final, running)
            for pid, row in p.result.get('running_processes', {}).items():
                assert process_table.get(pid, {}).get('start') != row['start']
            assert not p.socket.exists() and not p.socket.is_symlink()
            p.result['socket_removed'] = True
            state = final.get('state', {})
            p.result['clean_shutdown'] = state.get('lastExitCode') == 0 and 'exit_reason=poweroff' in state.get('lastExitReason', '')
            lock = p.machine / 'run/supervisor.lock'
            if lock.is_file():
                with lock.open('r') as fd:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                p.result['supervisor_lock_released'] = True
            for name in ('supervisor', 'console'):
                log = p.machine / 'logs' / f'{name}.log'
                if log.is_file():
                    shutil.copyfile(log, receipts / f'{args.label}-{name}.log')
        if raw is not None and raw.exists():
            end = proof.identity(raw)
            beginning = record['raw_disk_live']
            for key in ('device', 'inode', 'logical_bytes'):
                assert end[key] == beginning[key]
            # Keep the disk in place until the kernel confirms an ordinary detach.
            raw_relative_path = raw.relative_to(mount)
            expected = (end['inode'], end['logical_bytes'])
        current = proof.identity(p.scope)
        assert p.scope.parent == mount and p.scope.name.startswith('outer-machine-') and not p.scope.is_symlink()
        assert all(current[key] == p.scope_identity[key] for key in ('device', 'inode'))
        assert not p.scope.is_mount() and not proof.scoped_processes(proof.process_table(), p.scope)
    if 'created' in record['drive']:
        record['drive']['final_live'] = apfs.verify(record['drive']['created'])
        detached = apfs.detach(record['drive']['created'], remove_image=True, inspect_history=True,
                               expected_raw_identity=expected, raw_relative_path=raw_relative_path)
        record['drive']['detached'] = detached
        assert detached['image_absent'] and detached['mount_restored']
        if p is not None:
            p.result['scope_removed'] = not p.scope.exists()
            assert p.result['scope_removed']
    assert not mount.is_mount() and not image.exists() and not image.with_suffix('.apfs-recovery.json').exists()
    assert proof.identity(mount)['inode'] == mount_identity['inode'] and not any(mount.iterdir())
    mount.rmdir()
    scope.rmdir()
    record['scope_absent'] = not scope.exists()


signal.signal(signal.SIGTERM, on_signal)
try:
    record['drive']['created'] = apfs.create(image, mount, size_gib=32, disabled=True)
    save()
    prepare_seed()
    p = proof.Proof(SimpleNamespace(mount=mount, repo=root, disk_base=base, output=receipts / args.label, hold=True))
    p.workspace = workspace
    if args.early_irq is not None:
        p.env['MICROPOD_VIRTIOFS_EARLY_IRQ'] = args.early_irq
        record['early_irq_requested'] = args.early_irq
    if args.live_read is not None:
        p.env['MICROPOD_VIRTIOFS_LIVE_READ'] = args.live_read
        record['live_read_requested'] = args.live_read
    if args.workspace_queues is not None:
        p.env['MICROPOD_VIRTIOFS_WORKSPACE_QUEUES'] = args.workspace_queues
        record['workspace_request_queues_requested'] = int(args.workspace_queues)
    if args.workspace_event_idx is not None:
        p.env['MICROPOD_VIRTIOFS_WORKSPACE_EVENT_IDX'] = args.workspace_event_idx
        record['workspace_event_idx_requested'] = args.workspace_event_idx == '1'
    if args.workspace_coalesce is not None:
        p.env['MICROPOD_VIRTIOFS_WORKSPACE_COALESCE'] = args.workspace_coalesce
        record['workspace_coalesce_requested'] = args.workspace_coalesce == '1'
    record['machine'] = p.result
    record['public_scope'] = str(p.scope)
    p.result['defaults_before'] = proof.default_state(Path.home())
    p.result['outside_processes_before'] = proof.outside_processes(proof.process_table())
    private_base = p.scope / 'base.ext4'
    p.run('/bin/cp', '-p', base, private_base, timeout=50, label='copy closed seed to owned APFS volume')
    private_base.chmod(0o400)
    assert proof.hash_file(private_base) == proof.hash_file(base)
    record['private_seed_sha256'] = proof.hash_file(private_base)
    if packaged:
        app_copy = p.scope/app.name
        shutil.copytree(app, app_copy, symlinks=True)
        installed_bundle_payload = {role:app_copy/path.relative_to(app) for role,path in payload.items()}
        assert all(proof.hash_file(installed_bundle_payload[key]) == proof.hash_file(path) for key,path in payload.items())
        p.binary = installed_bundle_payload['cli']
        p.env['MICROPOD_CLI'] = str(p.binary)
        p.run('/usr/bin/codesign','--verify','--deep','--strict',app_copy,label='verify isolated app signature')
        record['bundled_payload'] = {'manifest':str(args.app_manifest), 'manifest_sha256':proof.hash_file(args.app_manifest),
                                     'source_app':str(app), 'installed_app':str(app_copy),
                                     'used_explicit_payload_flags':False}
        vmm_for_signature = installed_bundle_payload['vmm']
    else:
        shutil.copy2(args.cli, p.binary)
        for bundle in args.cli.parent.glob('*.bundle'):
            shutil.copytree(bundle, p.scope / bundle.name, symlinks=True)
        vmm_for_signature = args.vmm
    record['cli_entitlements'] = p.signature(p.binary, 'frozen public CLI')
    record['vmm_entitlements'] = p.signature(vmm_for_signature, 'frozen public VMM')
    assert record['vmm_entitlements']['com.apple.security.hypervisor'] is True
    record['owned_artifacts'] = {key:{'path':str(file),'sha256':proof.hash_file(file)} for key,file in payload.items()}
    assert proof.hash_file(p.binary) == record['owned_artifacts']['cli']['sha256']
    explicit = [] if packaged else ['--vmm',args.vmm,'--kernel',args.kernel,'--initrd',args.initrd,'--tools',args.tools]
    p.run(p.binary,'machine','install',*explicit,'--disk-from',private_base,'--cpus','4','--memory-mib','4096',
          '--workspace',workspace,timeout=65,label='install separate protected public machine')
    raw = p.machine / 'disk.ext4'
    record['raw_disk_live'] = proof.identity(raw)
    assert record['raw_disk_live']['device'] == mount.stat().st_dev and raw.stat().st_ino != private_base.stat().st_ino
    for name, installed in {'vmm': 'micropod-vmm', 'initrd': 'mp-hvf-init.cpio', 'kernel': 'Image', 'job': 'tools/runner/bin/job'}.items():
        assert proof.hash_file(p.machine / installed) == record['owned_artifacts'][name]['sha256']
    tracked_tools = ('runner/start.sh', 'runner/trace-observer.sh', 'runner/release-lifecycle-observer.sh',
                     'runner/fixture-certs/gamma-local-test-ca.crt', 'runner/bin/workspace-irq',
                     'runner/qualify_virtiofs_local_completion.sh', 'runner/qualify_virtiofs_inline_completion.sh')
    record['tool_bank_lineage'] = {}
    for name in tracked_tools:
        source = payload['job'].parents[2] / name
        if source.is_file():
            digest = proof.hash_file(source)
            assert proof.hash_file(p.machine / 'tools' / name) == digest
            record['tool_bank_lineage'][name] = digest
    record['kernel_arguments_requested'] = args.kernel_arg
    if args.kernel_arg:
        config = p.machine / 'machine.json'
        contents = json.loads(config.read_bytes())
        previous = contents.get('kernelArguments', [])
        contents['kernelArguments'] = [*previous, *args.kernel_arg]
        temporary = config.with_suffix('.json.writing')
        proof.record(temporary, contents)
        temporary.chmod(config.stat().st_mode & 0o777)
        temporary.replace(config)
        record['kernel_arguments_before'] = previous
        record['machine_config_sha256'] = proof.hash_file(config)
    p.seed = artifacts / 'seed.tar'
    p.start()
    p.run(p.binary, 'runtime', 'enable', 'hvf', label='enable HVF only in private runtime config')
    arm = json.loads(p.run(proof.DOCKER, 'image', 'inspect', lineage['tag'], '--format', '{{json .}}', label='attest offline tools image')['stdout'])
    assert arm['Id'] in (lineage['manifest_digest'], lineage['config_digest']) and arm['Os'] == 'linux' and arm['Architecture'] == 'arm64'
    argv = 'uname -r; uname -m; cat /proc/cmdline; go version; git --version; python3 --version; sha256sum "$(command -v git)" "$(command -v go)" "$(command -v python3)"'
    tools = p.run(proof.DOCKER, 'run', '--rm', '--pull=never', '--network=none', '--entrypoint', 'sh', lineage['tag'], '-ec', argv,
                  label='attest guest kernel and exact tool binaries')['stdout'].splitlines()
    assert tools[3:6] == lineage['versions'][:3] and tools[6:] == lineage['installed_git'][2:]
    assert all(argument in tools[2].split() for argument in args.kernel_arg), tools[2]
    record['guest_tool_probe'] = tools
    sysfs_probe = p.run(proof.DOCKER, 'run', '--rm', '--pull=never', '--network=none', '--entrypoint', 'python3',
                       lineage['tag'], '-B', '-c', (receipts / 'probe_virtiofs_sysfs.py').read_text(),
                       label='attest guest virtiofs queues and kernel parameters')['stdout']
    fs_info = json.loads(sysfs_probe)
    workspace_queues = fs_info['devices']['workspace']['queues']
    observed_requests = sorted(name for name in workspace_queues if name.startswith('requests.'))
    if args.workspace_queues is not None:
        assert observed_requests == [f'requests.{slot}' for slot in range(int(args.workspace_queues))], fs_info
        assert 'hiprio' in workspace_queues and set(cpu for queue in observed_requests
                                                  for cpu in workspace_queues[queue]['cpus']) == {0, 1, 2, 3}, fs_info
        assert all(sum(q.startswith('requests.') for q in device['queues']) == 1
                   for tag, device in fs_info['devices'].items() if tag != 'workspace'), fs_info
    if args.workspace_event_idx is not None:
        assert fs_info['devices']['workspace']['event_idx'] == record['workspace_event_idx_requested'], fs_info
        assert not any(device.get('event_idx') for tag, device in fs_info['devices'].items() if tag != 'workspace')
    for parameter, value in ((arg.split('=', 1)[0].removeprefix('virtiofs.'), arg.split('=', 1)[1])
                             for arg in args.kernel_arg if '=' in arg):
        if parameter in ('workspace_async_release', 'workspace_local_completion', 'workspace_inline_completion',
                         'workspace_compact_requests', 'workspace_reply_poll'):
            assert fs_info['parameters'][parameter] in (value, {'0': 'N', '1': 'Y'}.get(value)), fs_info
    record['virtiofs_sysfs'] = fs_info
    record['drive']['live'] = apfs.verify(record['drive']['created'])
    record['socket'] = str(p.socket)
    record['environment'] = p.env
    record['release_file'] = str(p.release)
    record['benchmark_image'] = lineage['tag']
    save()
    proof.record(ready, record)
    print(p.env['DOCKER_HOST'], workspace, lineage['tag'], flush=True)
    while not p.release.is_file():
        time.sleep(0.25)
except BaseException as exc:
    record['errors']['operation'] = repr(exc)
    raise
finally:
    try:
        retire()
    except BaseException as exc:
        record['errors']['cleanup'] = repr(exc)
        raise
    finally:
        if p is not None:
            p.result['defaults_after'] = proof.default_state(Path.home())
            p.result['defaults_unchanged'] = p.result.get('defaults_before') == p.result['defaults_after']
        save()
