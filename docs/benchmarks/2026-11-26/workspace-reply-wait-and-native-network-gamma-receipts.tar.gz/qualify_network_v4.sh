#!/bin/bash
set -euo pipefail
E=$(cd "$(dirname "$0")" && pwd -P)
H=$(dirname "$E")/home
arm=secondary-network-v4
runner=4d0fb3989ee4e81f6b3f295c9d24b397a158635576019102bd6e558f90fbc812
ready="$E/$arm-ready.json"
socket=$(jq -er .socket "$ready")
image=$(jq -er .benchmark_image "$ready")
client="$H/root-candidates/stock-network-client/client"
expected_ryuk=sha256:f04fd744b5d50f8c88d9d4938c54e05a9adb56d520542f899a7d6873fa7280f2
[[ $(jq -er .owned_artifacts.job.sha256 "$ready") == "$runner" ]]
[[ $(cat "$E/$arm-linux-exit.log") == 'linux_focused=0 linux_full=0' ]]
[[ $(/usr/bin/shasum -a 256 "$client" | cut -d ' ' -f1) == a0747d1ad92d7b13fbf5c8883d8b42e73457083aebc4455a615cdda0f267000e ]]
jq -e --arg id "$expected_ryuk" '.Id == $id' "$E/$arm-ryuk-load-inspect.json" >/dev/null
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_API_VERSION DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH
export DOCKER_CLI_HINTS=false
std=(python3 -B "$E/network-harness/qualify_docker_network_membership.py" --socket "$socket" \
    --image alpine:3.23 --require-bridge-isolation)
tc=(python3 -B "$E/network-harness/qualify_testcontainers_go.py" --socket "$socket" --client "$client" \
    --image alpine:3.23 --preserve-image "$image" --api-version 1.47)
"${std[@]}" --out "$E/network-stock-native-v4.json"
"${std[@]}" --concurrent-only --out "$E/network-race-native-v4.json"
bash "$E/run_network_recovery_witness.sh" "$arm"
"${tc[@]}" --mode multi-network --output "$E/tc-secondary-v4.json"
"${tc[@]}" --mode ryuk-abandon --abandon-resources --ryuk-image-id "$expected_ryuk" --output "$E/tc-ryuk-v4.json"
bash "$E/run_pinned_gamma9.sh" "$arm" "$runner"
