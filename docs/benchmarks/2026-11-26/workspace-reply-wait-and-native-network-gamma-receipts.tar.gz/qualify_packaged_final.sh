#!/bin/bash
set -euo pipefail
E=$(cd "$(dirname "$0")" && pwd -P)
manifest=${1:?final private app manifest}
arm=packaged-final
ready="$E/$arm-ready.json"
socket=$(jq -er .socket "$ready")
kernel=$(jq -er .artifacts.kernel.sha256 "$manifest")
for option in DOCKER_HOST DOCKER_CONTEXT DOCKER_API_VERSION DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH; do
    unset "$option"
done
export DOCKER_CLI_HINTS=false
native=(/opt/homebrew/bin/docker --host "unix://$socket")
python3 -B "$E/attest_packaged_final.py" "$ready" "$manifest" "$E/$arm-virtiofs-attestation.json"
bash "$E/run_gamma4_arm.sh" "$arm" correctness "$arm"
python3 -B "$E/network-harness/qualify_docker_network_membership.py" --socket "$socket" \
    --image alpine:3.23 --require-bridge-isolation --concurrent-only \
    --out "$E/network-packaged-final-stock-smoke.json"
"${native[@]}" ps -aq > "$E/$arm-prescore-private-cleanup.log"
test ! -s "$E/$arm-prescore-private-cleanup.log"

admit_or_label_ambient() {
    local label=$1 status=0
    bash "$E/probe_quiet_admission.sh" "$label" 3.2 || status=$?
    (( status <= 1 ))
    jq -e '(.quiet_prestart_observed | type == "boolean") and (.host_observed_idle_pct | length == 3)' \
       "$E/$label-preflight.json" >/dev/null
}
named=0
bash "$E/run_named_bridge_gamma9.sh" "$arm" "$arm" "$kernel" || named=$?
admit_or_label_ambient "$arm-density"
density=0
PAIRS=4 bash "$E/run_scored_worker.sh" "$arm" "$arm" density || density=$?
admit_or_label_ambient "$arm"
material=0
PAIRS=4 bash "$E/run_scored_worker.sh" "$arm" "$arm" material || material=$?
"${native[@]}" ps -aq > "$E/$arm-postscore-private-cleanup.log"
test ! -s "$E/$arm-postscore-private-cleanup.log"
printf 'ordinary_held_and_stock=0 stock_network=0 named=%s density=%s material=%s\n' "$named" "$density" "$material" |
    tee "$E/$arm-qualification-exit.log"
(( named == 0 && density == 0 && material == 0 ))
