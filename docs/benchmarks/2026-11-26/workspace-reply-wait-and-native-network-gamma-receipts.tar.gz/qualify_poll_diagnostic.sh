#!/bin/bash
set -euo pipefail
E=$(cd "$(dirname "$0")" && pwd -P)
H=$(dirname "$E")/home
arm=${1:?owned diagnostic worker}
mode=${2:?N or Y}
[[ $arm == poll-off-diag || $arm == poll-on-diag ]]
[[ $mode == N || $mode == Y ]]
ready="$E/$arm-ready.json"
socket=$(jq -er .socket "$ready")
workspace=$(jq -er .workspace "$ready")
image=$(jq -er .benchmark_image "$ready")
test "$(jq -er .virtiofs_sysfs.parameters.workspace_reply_poll "$ready")" = "$mode"
test "$(jq -er .virtiofs_sysfs.parameters.workspace_async_release "$ready")" = Y
stage="$E/reply-poll-trace"
trace=0
python3 -B "$E/trace_stock_git_completion.py" --socket "$socket" --workspace "$workspace" \
  --source "$H/evidence/prior/runner-vendored" --helpers "$H/evidence/prior/final-harness/scripts" \
  --observer "$stage" --image-manifest "$E/image-manifest.json" --image "$image" \
  --trace --samples 4 --expected-mode Y --expected-local-mode unavailable --out "$stage/$arm-git.json" \
  > "$stage/$arm-git.log" 2>&1 || trace=$?
analysis=0
pressure=0
if (( trace == 0 )); then
    python3 -B "$stage/analyze_poll.py" --run "$stage/$arm-git.json" --raw "$stage/$arm-git-raw" \
      --mode "$mode" --out "$stage/$arm-dispatch.json" > "$stage/$arm-dispatch.log" 2>&1 || analysis=$?
    python3 -B "$E/trigger_inline_completion_lifecycle.py" --ready "$ready" --observer "$stage" --expected "$mode" \
      --owner "$H/artifacts/tools-reply-poll-diagnostic/runner/.workspace-inline-completion.owner" \
      --out "$E/$arm-lifecycle.json" > "$E/$arm-lifecycle.log" 2>&1 || pressure=$?
else
    analysis=125
    pressure=125
fi
printf 'trace=%s correlation=%s pressure=%s\n' "$trace" "$analysis" "$pressure" | tee "$E/$arm-qualification-exit.log"
(( trace == 0 && analysis == 0 && pressure == 0 ))
