"""Match foreground FUSE polls to the submitting thread's reply timeline."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re

import trace_proof as trace


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ('run', 'raw', 'out'):
        parser.add_argument('--'+arg,type=Path,required=True)
    parser.add_argument('--mode',choices=('N','Y'),required=True)
    args = parser.parse_args()
    run = json.loads(args.run.read_bytes())
    assert run['passed'] and not run['remaining'] and run['capture']['complete']
    capture = run['capture']['capture']
    sample = run['traced_sample']
    clock = sample['clock']
    assert capture['clock'] == 'mono' and clock['offset_ns'] == 0 and capture['boot_id'] == clock['boot_id']
    raw = (args.raw/'.trace-events').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == run['capture']['raw_files_sha256']['.trace-events']
    start = trace.info(args.raw/'.trace-started',capture['token'])
    assert start['workspace_reply_poll'] == args.mode
    file = args.raw/'.trace-observer.log'
    assert hashlib.sha256(file.read_bytes()).hexdigest() == run['capture']['raw_files_sha256'][file.name]
    counters = {}
    for line in file.read_text().splitlines():
        if match := re.fullmatch(r'\s*(?:\w+/)?(poll_enter|poll_leave)\s+(\d+)\s+(\d+)\s*',line):
            counters[match[1]] = {'hits':int(match[2]),'misses':int(match[3])}
    assert not any(row['misses'] for row in counters.values())
    events, _, lost, _ = trace.parse_events(raw.decode())
    assert not lost
    thread = run['git_fuse']['kernel_git_pid']
    conn = capture['connection']
    sends = {}
    last = {}
    ends = {}
    active = {}
    intervals = []
    problems = Counter()
    for event in events:
        if event.name == 'fuse_request_end' and (match := trace.END.fullmatch(event.body)) and match[1] == conn:
            ends[match[2]] = (event.ns,int(match[4]))
        if not clock['now_ns'] <= event.ns <= sample['finish_ns']:
            continue
        if event.name == 'fuse_request_send' and (match := trace.SEND.fullmatch(event.body)) and match[1] == conn:
            operation = match[4].removeprefix('FUSE_')
            sends[match[2]] = (event.ns,operation)
            last[event.pid] = (match[2],operation)
        elif event.name == 'poll_enter':
            recent = last.get(event.pid)
            if recent is None or recent[1] not in ('LOOKUP','OPEN','READ'):
                problems['poll_entries_without_eligible_workspace_send'] += 1
                continue
            if event.pid in active:
                problems['duplicate_inflight_entry'] += 1
            active[event.pid] = (recent[0],event.ns)
        elif event.name == 'poll_leave':
            entry = active.pop(event.pid,None)
            if entry is None:
                problems['return_without_entry'] += 1
                continue
            intervals.append((event.pid,entry[0],entry[1],event.ns))
    summary = {'all_threads':{},'main_git':{}}
    used = set()
    if active:
        problems['entry_without_return'] = len(active)
    buckets = defaultdict(list)
    for tid, unique, enter, leave in intervals:
        if unique in used:
            problems['repeated_poll_for_same_unique'] += 1
        used.add(unique)
        if unique not in ends:
            problems['reply_not_observed'] += 1
            continue
        finished, code = ends[unique]
        sent, operation = sends[unique]
        assert sent <= enter <= leave and sent <= finished
        timing = 'before_entry' if finished < enter else 'after_return' if finished > leave else (
            'timestamp_tie' if finished in (enter,leave) else 'inside_poll')
        row = (timing,leave-enter,finished-sent,finished-enter,code)
        buckets['all_threads',operation].append(row)
        if tid == thread:
            buckets['main_git',operation].append(row)
    for (scope,operation), rows in sorted(buckets.items()):
        phases = Counter(row[0] for row in rows)
        summary[scope][operation] = {'calls':len(rows),'completion_phase':dict(phases),
            'poll_elapsed':trace.distribution([row[1] for row in rows]),
            'fuse_send_to_reply':trace.distribution([row[2] for row in rows]),
            'inside_poll_entry_to_reply':trace.distribution([row[3] for row in rows if row[0]=='inside_poll']),
            'reply_errors':dict(Counter(str(row[4]) for row in rows if row[4]))}
    if args.mode == 'N':
        assert not intervals and not problems
    else:
        assert sum(row['calls'] for row in summary['main_git'].values()) >= 1058
        assert not problems, problems
    result = {'mode':args.mode, 'trace_sha256':hashlib.sha256(raw).hexdigest(), 'kernel_pid':thread,
              'selected_fuse_connection':conn, 'sysfs_mode':start['workspace_reply_poll'],
              'kprobe_profile':counters,'completed_intervals':len(intervals),'correlation_errors':problems,
              'per_operation':summary, 'raw_trace_manifest_sha256':hashlib.sha256(args.run.read_bytes()).hexdigest(),
              'interpretation':'Function entry to return; includes calls returning through an early guard. Equal microsecond timestamps are ties.'}
    with args.out.open('x') as output:
        json.dump(result,output,indent=2)
        output.write('\n')


if __name__ == '__main__':
    main()
