"""Clone current control tools and chain two one-shot, unscored probes."""
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess

from trace_proof import install

stage = Path(__file__).resolve().parent
hub = stage.parents[1]/'home'
bank = hub/'artifacts/tools-reply-poll-diagnostic'
assert hub.is_mount() and not bank.exists()
install(hub/'artifacts/tools-baseline', bank)
runner = bank/'runner'
start = runner/'start.sh'
text = start.read_text()
anchor = '"$tools/runner/trace-observer.sh" &\nobserver=$!\n'
assert text.count(anchor) == 1
start.write_text(text.replace(anchor, '("$tools/runner/trace-observer.sh" && exec "$tools/runner/qualify-reply-poll-pressure.sh") &\nobserver=$!\n'))
pressure = runner/'qualify-reply-poll-pressure.sh'
shutil.copyfile(stage/pressure.name, pressure)
pressure.chmod(0o755)
secret = runner/'.workspace-inline-completion.owner'
with os.fdopen(os.open(secret,os.O_WRONLY|os.O_EXCL|os.O_CREAT,0o400),'w') as output:
    output.write(secrets.token_hex(16)+'\n')
for script in (start, pressure, runner/'trace-observer.sh'):
    subprocess.run(['/bin/sh','-n',script],check=True,timeout=15)
proof = {file.relative_to(bank).as_posix():hashlib.sha256(file.read_bytes()).hexdigest()
         for file in (start,pressure,runner/'trace-observer.sh',runner/'bin/job')}
assert proof['runner/bin/job'] == '0b20a6f006ca61efa323287777e51466833b21c649982d287948d4b1bf506af8'
with (stage/'bank-lineage.json').open('x') as output:
    json.dump(proof,output,indent=2)
    output.write('\n')
