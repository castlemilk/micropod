"""Reconcile saved pressure trace after restoring the inherited hard-IRQ parser field."""
import argparse
import json
from pathlib import Path
import sys
from types import SimpleNamespace

stage = Path(__file__).resolve().parent
sys.path.insert(0, str(stage.parent))
from trigger_inline_completion_lifecycle import trace_evidence

parser = argparse.ArgumentParser(description=__doc__)
for name in ('attempt', 'raw', 'out'):
    parser.add_argument('--'+name,type=Path,required=True)
args = parser.parse_args()
data=json.loads(args.attempt.read_bytes())
assert not data['passed'] and not data['workspace_additions'] and not data['containers_remaining']
assert 'hardirq' in data['failure']
fields=data['guest']
assert fields['exit']=='0' and fields['step']=='pass' and fields['mode_initial']==fields['mode_final']==data['expected']
assert fields['queue_pressure_retprobe']=='1'
evidence=trace_evidence(SimpleNamespace(observer=stage),fields,args.raw)
assert evidence['observed_enospc']>0 and evidence['requests_in_flight_at_sigkill']
out={**data,'passed':True,'initial_analysis_error':data.pop('failure'),'trace':evidence}
out.pop('failure',None)
with args.out.open('x') as stream:
    json.dump(out,stream,indent=2)
    stream.write('\n')
