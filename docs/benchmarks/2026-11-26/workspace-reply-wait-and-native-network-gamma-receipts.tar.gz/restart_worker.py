"""Restart one owned public machine on its existing disk with a verified stopped fixture."""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

from outer_machine_proof import default_state, identity, process_table, scoped_processes

receipts = Path(__file__).resolve().parent


def file_sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def report_witness(docker, state, label, env):
    def with_engine(*args):
        process = subprocess.run([*docker, *args], env=env, text=True, check=True, timeout=12, capture_output=True)
        return process.stdout.strip()

    expected = set(state['containers'].values())
    assert len(expected) == 3 and all(re.fullmatch(r'[a-f0-9]{64}', item) for item in expected)
    assert set(with_engine('ps', '-aq', '--no-trunc').splitlines()) == expected
    assert set(with_engine('ps', '-aq', '--no-trunc', '--filter', f'label={label}').splitlines()) == expected
    witnesses = {}
    for role, name in sorted(state['containers'].items()):
        row = json.loads(with_engine('inspect', '--format', '{{json .}}', name))
        assert row['Id'] == name and row['Config']['Labels'].get(label.split('=', 1)[0]) == state['scope']
        condition = row['State']
        assert condition['Status'] == 'exited' and not condition['Running']
        witnesses[role] = {'id':name, 'name':row['Name'], 'status':condition['Status']}
    networks = set(state['networks'].values())
    assert len(networks) == 2 and all(re.fullmatch(r'[a-f0-9]{64}', item) for item in networks)
    assert set(with_engine('network', 'ls', '-q', '--no-trunc', '--filter', f'label={label}').splitlines()) == networks
    return {'containers':witnesses,'networks':sorted(networks)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('worker')
    parser.add_argument('--state', type=Path, required=True)
    parser.add_argument('--label', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    assert re.fullmatch(r'[a-z0-9-]{1,22}', args.worker)
    assert args.out.resolve().is_relative_to(receipts) and not args.out.exists()
    state = json.loads(args.state.read_bytes())
    assert re.fullmatch(r'[a-z0-9][a-z0-9.-]{4,127}', state['scope'])
    assert '=' in args.label and args.label.split('=', 1)[1] == state['scope']
    ready_path = receipts / f'{args.worker}-ready.json'
    ready = json.loads(ready_path.read_bytes())
    directory = Path(ready['worker_directory']).resolve(strict=True)
    assert directory.parent == Path('/private/tmp') and directory.name.startswith(f'mpg9-{args.worker}-')
    scope = Path(ready['public_scope']).resolve(strict=True)
    assert scope.parent == directory/'home' and scope.parent.is_mount() and scope.name.startswith('outer-machine-')
    machine = scope/'machine'
    socket = machine/'run/docker.sock'
    assert socket.is_socket() and str(socket) == ready['socket'] == state['socket']
    release = Path(ready['release_file'])
    assert release == scope/'release' and not os.path.lexists(release)
    raw = machine/'disk.ext4'
    before_disk = identity(raw)
    identity_fields = ('device','inode','logical_bytes')
    assert all(before_disk[key] == ready['raw_disk_live'][key] for key in identity_fields)
    cli = scope/'micropod'
    env = ready['environment']
    assert env['MICROPOD_HVF_ROOT'] == str(machine) and env['MICROPOD_RUNTIMES_CONFIG'] == str(scope/'runtimes.json')
    assert env['HOME'] == str(scope/'home') and env['CFFIXED_USER_HOME'] == str(scope/'home')
    assert env['DOCKER_HOST'].startswith('unix://') and Path(env['DOCKER_HOST'].removeprefix('unix://')).resolve(strict=True) == socket
    assert file_sha(cli) == ready['owned_artifacts']['cli']['sha256']
    docker = ['/opt/homebrew/bin/docker', '--host', f'unix://{socket}']
    outer_before = default_state(Path.home())
    report = {'passed':False, 'worker':args.worker,'fixture_scope':state['scope'],'socket':str(socket),
              'ready_sha256':file_sha(ready_path),'fixture_state_sha256':file_sha(args.state),
              'disk_before':before_disk,'checks':[]}

    def machine_run(*arguments, timeout=20):
        result = subprocess.run([str(cli), *arguments], cwd=scope, env=env, text=True, timeout=timeout, capture_output=True)
        report['checks'].append({'arguments':arguments, 'exit':result.returncode,'stdout':result.stdout.strip(),
                                 'stderr':result.stderr.strip(),'utc':datetime.now(timezone.utc).isoformat()})
        result.check_returncode()
        return result.stdout

    try:
        report['before'] = report_witness(docker, state, args.label, env)
        before = json.loads(machine_run('--json','machine','status'))
        assert before['phase'] == 'running' and before['supervisorAlive']
        scope_before = scoped_processes(process_table(), scope)
        old_pids = {before['state'][name] for name in ('supervisorPID','vmmPID')}
        assert old_pids <= scope_before.keys()
        machine_run('machine','stop','--timeout','22',timeout=32)
        stopped = json.loads(machine_run('--json','machine','status'))
        assert stopped['phase'] == 'stopped' and not stopped['supervisorAlive']
        last = stopped['state']
        assert last['lastExitCode'] == 0 and 'exit_reason=poweroff' in last['lastExitReason']
        assert not os.path.lexists(socket) and not scoped_processes(process_table(), scope)
        with (machine/'run/supervisor.lock').open('r') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        report['stopped_lock_released'] = True
        after_stop = report['disk_after_stop'] = identity(raw)
        assert all(after_stop[key] == before_disk[key] for key in identity_fields)
        machine_run('machine','start','--timeout','65',timeout=75)
        running = json.loads(machine_run('--json','machine','status'))
        assert running['phase'] == 'running' and running['supervisorAlive'] and socket.is_socket()
        after = scoped_processes(process_table(),scope)
        new_pids = {running['state'][name] for name in ('supervisorPID','vmmPID')}
        assert new_pids <= after.keys() and all(after.get(pid, {}).get('start') != scope_before[pid]['start'] for pid in old_pids)
        endpoint = machine_run('machine','docker-endpoint').strip()
        assert endpoint.startswith('unix://') and Path(endpoint.removeprefix('unix://')).resolve(strict=True) == socket
        report['new_supervisor_pids'] = sorted(new_pids)
        final_disk = report['disk_after_restart'] = identity(raw)
        assert all(final_disk[key] == before_disk[key] for key in identity_fields)
        report['after'] = report_witness(docker,state,args.label,env)
        assert report['before'] == report['after'] and default_state(Path.home()) == outer_before
        report['defaults_unchanged'] = True
        report['passed'] = True
    except Exception as exc:
        report['error'] = repr(exc)
        raise
    finally:
        with args.out.open('x') as stream:
            json.dump(report, stream, indent=2)
            stream.write('\n')
    print('Owned machine restarted on the same ext4; preserved stopped containers and network IDs.', flush=True)


if __name__ == '__main__':
    main()
