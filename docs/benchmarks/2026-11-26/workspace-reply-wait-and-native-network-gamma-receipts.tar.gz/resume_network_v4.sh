#!/bin/bash
set -euo pipefail
E=$(cd "$(dirname "$0")" && pwd -P)
H=$(dirname "$E")/home
arm=secondary-network-v4
runner=4d0fb3989ee4e81f6b3f295c9d24b397a158635576019102bd6e558f90fbc812
ready="$E/$arm-ready.json"
ready_socket=$(jq -er .socket "$ready")
image=$(jq -er .benchmark_image "$ready")
prefix="$E/network-$arm-restart"
client="$H/root-candidates/stock-network-client/client"
expected_ryuk=sha256:f04fd744b5d50f8c88d9d4938c54e05a9adb56d520542f899a7d6873fa7280f2
[[ $(jq -er .owned_artifacts.job.sha256 "$ready") == "$runner" ]]
[[ $(cat "$E/$arm-linux-exit.log") == 'linux_focused=0 linux_full=0' ]]
[[ $(/usr/bin/shasum -a 256 "$client" | cut -d ' ' -f1) == a0747d1ad92d7b13fbf5c8883d8b42e73457083aebc4455a615cdda0f267000e ]]
jq -e --arg id "$expected_ryuk" '.Id == $id' "$E/$arm-ryuk-load-inspect.json" >/dev/null
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_API_VERSION DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH
export DOCKER_CLI_HINTS=false
python3 -B "$E/network-harness/restart-dependencies/qualify_docker_network_restart.py" --phase verify \
    --socket "$ready_socket" --image alpine:3.23 --state "$prefix-state.json" --out "$prefix-verify.json"
jq -e '.passed and (.remaining.containers|length==0) and (.remaining.networks|length==0)' "$prefix-verify.json" >/dev/null
native=(/opt/homebrew/bin/docker --host "unix://$ready_socket")
"${native[@]}" ps -aq > "$prefix-private-cleanup.log"
test ! -s "$prefix-private-cleanup.log"
tc=(python3 -B "$E/network-harness/qualify_testcontainers_go.py" --socket "$ready_socket" --client "$client" \
    --image alpine:3.23 --preserve-image "$image" --api-version 1.47)
"${tc[@]}" --mode multi-network --output "$E/tc-secondary-v4.json"
"${tc[@]}" --mode ryuk-abandon --abandon-resources --ryuk-image-id "$expected_ryuk" --output "$E/tc-ryuk-v4.json"
bash "$E/run_pinned_gamma9.sh" "$arm" "$runner"
