#!/bin/sh
set -eu
stage=${1:?private staging directory}
engine=${2:?explicit unix Docker endpoint}
name=${3:?unique owned container}
trial="$stage/home/root-candidates/reply-poll"
evidence="$stage/receipts/root-candidates"
image=sha256:469c9ea410b9215eaee7976ba6c0639039b444be8e5d638f7abbada189971eb2
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_API_VERSION DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH
docker --host "$engine" run --rm --pull never --name "$name" --label "org.micropod.experiment=$name" \
    --cpus=4 --memory=6g --platform linux/arm64 --env JOBS=4 \
    --mount "type=bind,src=$stage/home/kernel-base/inputs,dst=/inputs,readonly" \
    --mount "type=bind,src=$trial/controls,dst=/controls,readonly" \
    --mount "type=bind,src=$trial,dst=/out" "$image" sh -eu -c '
    apk add --no-cache build-base gcc=15.2.0-r2 binutils=2.45.1-r0 make=4.4.1-r3 \
        bc bison flex perl openssl-dev elfutils-dev linux-headers xz zstd bash \
        coreutils pahole gmp-dev mpc1-dev mpfr-dev cpio python3 gawk perl-utils \
        diffutils findutils file rsync
    { uname -a; gcc --version; ld --version; make --version; apk info -vv; } > /out/toolchain.txt
    sh /controls/build-workspace-reply-poll.sh /inputs /out/image
    ' > "$evidence/build.log" 2>&1
