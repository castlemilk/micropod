"""Exercise the release artifact consumer with the complete qualified local payload."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


root, work, receipt = map(Path, sys.argv[1:])
checkout = subprocess.check_output(["git", "-C", root, "rev-parse", "HEAD"], text=True).strip()
payload = work / "payload"
members = ["micropod-vmm", "vmlinux-hvf", "mp-hvf-init.cpio", "micropod-oci-tools"]
with tempfile.TemporaryDirectory(prefix="fetch-", dir=work) as cache:
    cache = Path(cache)
    archive = cache / "micropod-hvf-runtime.tgz"
    subprocess.run(["/usr/bin/tar", "-czf", archive, "-C", payload, *members], check=True)
    digest = sha(archive)
    fake = cache / "gh"
    fake.write_text('''#!/bin/bash
set -euo pipefail
case "$1" in
api)
    [[ "$2" == "repos/fixture/micropod/actions/runs/417" ]]
    cat "$FIXTURE_METADATA"
    ;;
run)
    [[ "$2:$3:$4:$5:$6:$7:$8" == "download:417:--repo:fixture/micropod:--name:micropod-hvf-runtime:--dir" ]]
    cp "$FIXTURE_ARCHIVE" "$9/micropod-hvf-runtime.tgz"
    ;;
*) exit 2 ;;
esac
''')
    fake.chmod(0o755)
    meta = cache / "run.json"
    target = cache / "installed"
    env = dict(os.environ, PATH=str(cache)+":"+os.environ["PATH"], GITHUB_REPOSITORY="fixture/micropod",
               GITHUB_SHA=checkout, FIXTURE_METADATA=str(meta), FIXTURE_ARCHIVE=str(archive))
    outcomes = {}
    for name, reported_sha, expected_sha, success in [
        ("wrong_source", "0"*40, digest, False), ("wrong_archive", checkout, "0"*64, False),
        ("complete_runtime", checkout, digest, True),
    ]:
        meta.write_text(json.dumps({"head_repository":{"full_name":"fixture/micropod"},
                                    "head_sha":reported_sha, "status":"completed", "conclusion":"success",
                                    "event":"push"}))
        attempt = subprocess.run(["/bin/bash", root/"scripts/fetch_hvf_distribution.sh", "417",
                                  expected_sha, target], env=env, capture_output=True, text=True)
        assert (attempt.returncode == 0) == success, attempt.stderr
        assert target.exists() == success
        outcomes[name] = {"exit": attempt.returncode, "diagnostic": attempt.stderr.strip()}
    paths = [Path("micropod-oci-tools/runner/bin/job"), *map(Path, members[:3])]
    roles = {p.as_posix():sha(target/p) for p in paths}
    assert all(sha(payload/p) == v for p,v in zip(paths,roles.values()))
    checked = {"tar_sha256":digest, "qualified_files":roles, "cases":outcomes,
               "transport":"local gh metadata/download fixture; real tar, digests and macOS VMM codesign"}
    receipt.write_text(json.dumps(checked,indent=2)+"\n")
