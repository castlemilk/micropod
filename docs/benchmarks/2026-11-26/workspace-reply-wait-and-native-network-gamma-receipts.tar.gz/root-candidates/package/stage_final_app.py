"""Combine the tested managed CLI, guest, kernel and entitled VMM in a fresh private package."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


def hash_file(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def tool_inventory(directory):
    entries = {}
    for item in sorted(directory.rglob("*")):
        name = item.relative_to(directory).as_posix()
        if item.is_symlink():
            entries[name] = ["symlink", os.readlink(item)]
        elif item.is_file():
            entries[name] = [item.stat().st_mode & 0o777, hash_file(item)]
    return entries


root = Path.cwd()
here = Path(__file__).resolve().parent
hub = here.parents[2] / "home"
assert hub.is_mount()
work = hub / "root-candidates/package-v4"
cli_sha = "c0e937a023354d5ea964ad61bdeba4c07ec82d1fea4933bab19c10564a95318a"
input_vmm, expected = Path(sys.argv[1]).resolve(strict=True), sys.argv[2]
assert hash_file(input_vmm) == expected and len(expected) == 64
payload = work / "payload"
app = work / "Micropod.app"
bin_dir = app / "Contents/MacOS"
resource_dir = app / "Contents/Resources"
flat = work / "standalone"
flat.mkdir(exist_ok=True)
shutil.copy2(input_vmm, payload/"micropod-vmm")
cli = bin_dir/"micropod-cli"
assert hash_file(cli) == cli_sha
shutil.copy2(cli, flat/"micropod")
with (here/"app-v4-stage.log").open("w") as logfile:
    def checked(*args):
        subprocess.run(list(args), stdout=logfile, stderr=subprocess.STDOUT, check=True)
    checked("bash", root/"scripts/stage_hvf_assets.sh", payload, payload, bin_dir, resource_dir)
    checked("bash", root/"scripts/stage_hvf_assets.sh", bin_dir, resource_dir, flat, flat)
    checked("/usr/bin/codesign", "--force", "--sign", "-", app)
    checked("/usr/bin/codesign", "--verify", "--deep", "--strict", "--verbose=2", app)
roles = {"cli":("Contents/MacOS/micropod-cli","micropod",cli_sha),
         "vmm":("Contents/MacOS/micropod-vmm","micropod-vmm",expected),
         "kernel":("Contents/Resources/vmlinux-hvf","vmlinux-hvf","da6da0bae1db1e5b76754aa8a966b2c6ace66ae049ed0d19f520e2d7a183a43d"),
         "initrd":("Contents/Resources/mp-hvf-init.cpio","mp-hvf-init.cpio","50afc24231a7649990c0b8c6352cf583f51ce2ec4515ad88522a7ab6b9fc9615"),
         "job":("Contents/Resources/micropod-oci-tools/runner/bin/job","micropod-oci-tools/runner/bin/job","4d0fb3989ee4e81f6b3f295c9d24b397a158635576019102bd6e558f90fbc812")}
artifacts = {}
for name,(relative,standalone,digest) in roles.items():
    assert hash_file(app/relative) == hash_file(flat/standalone) == digest, name
    artifacts[name] = {"relative_path":relative, "sha256":digest}
inventory=tool_inventory(payload/"micropod-oci-tools")
assert inventory == tool_inventory(resource_dir/"micropod-oci-tools") == tool_inventory(flat/"micropod-oci-tools")
previous=json.loads((here/"app-v3-manifest.json").read_bytes())
source={s:hash_file(root/s) for s in [*previous["source_sha256"],"scripts/fetch_hvf_distribution.sh"]}
result={"app":str(app),"artifacts":artifacts,"standalone":str(flat),"signature":"ad hoc",
        "scaffold":previous["scaffold"],"repo_head":previous["repo_head"],"source_sha256":source,
        "verified_role_hashes_match_flat_package":True, "verified_tool_entries":len(inventory),
        "tool_inventory_sha256":hashlib.sha256(json.dumps(inventory,sort_keys=True).encode()).hexdigest()}
(here/"app-v4-manifest.json").write_text(json.dumps(result,indent=2)+"\n")
print(here/"app-v4-manifest.json")
