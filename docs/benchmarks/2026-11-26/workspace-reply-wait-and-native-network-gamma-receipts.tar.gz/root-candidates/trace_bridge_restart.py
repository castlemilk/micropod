import json, sys, time
from pathlib import Path
from qualify_docker_network_membership import Engine, Membership, VERSION
socket, outfile = Path(sys.argv[1]), Path(sys.argv[2])
assert socket.is_socket() and not outfile.exists()
q=Membership(Engine(socket, 'alpine:3.23', None, None, api_version=VERSION), 'created')
out={'scope':q.scope,'history':q.history,'observations':{}}
def record(phase):
    rows={}
    for role in ('peer-a','peer-b','service'):
        rc,text=q.cli('exec',q.ids[role],'sh','-c','for i in /sys/class/net/eth*; do printf "%s " "$i"; cat "$i/address"; done; cat /proc/net/arp; ip -4 route',ok=False)
        rows[role]={'rc':rc,'network':text}
    for role,alias in (('peer-a',q.names['service']+'-alias'),('peer-b',q.alias_b())):
        rows[role]['dns']=q.cli('exec',q.ids[role],'nslookup',alias,ok=False,combined=True)
        rows[role]['http']=q.cli('exec',q.ids[role],'wget','-T','2','-t','1','-qO-','http://'+alias+':8080/probe',ok=False,combined=True)
    out['observations'][phase]=rows
try:
    for letter,net in q.nets.items():
        q.cli('network','create','--label',q.label,net)
        q.create('peer-'+letter,letter); q.cli('start',q.ids['peer-'+letter])
    q.create('service','a',publish=True); q.attach(); q.cli('start',q.ids['service'])
    q.published(); q.traffic(); record('before')
    q.cli('stop','-t','1',q.ids['service']); q.cli('start',q.ids['service']); q.published()
    record('after'); time.sleep(3); record('later')
finally:
    out['remaining']=q.cleanup()
    outfile.write_text(json.dumps(out,indent=2)+'\n')
