"""Profile the same matched eight-Git workload after a bounded host-load preflight."""
import argparse
import json
from pathlib import Path
import re
import subprocess
import sys

receipts = Path(__file__).resolve().parent
hub = receipts.parent / 'home'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('worker')
parser.add_argument('--kernel-sha256', default='61b4e143b26039e4642f48b3819e0233f22b44f5c3e88e109cbc9c17508cc85f')
args = parser.parse_args()
assert re.fullmatch('[a-z0-9-]{1,22}', args.worker)
assert re.fullmatch('[a-f0-9]{64}', args.kernel_sha256)
ready = json.loads((receipts/f'{args.worker}-ready.json').read_bytes())
assert ready['label'] == args.worker and Path(ready['socket']).is_socket()
assert ready['owned_artifacts']['vmm']['sha256'] == 'f0747277714ef1520de32e7e5d398a0b88aded8a52c8f8076dc7daaafde1d3c4'
assert ready['owned_artifacts']['job']['sha256'] == '0b20a6f006ca61efa323287777e51466833b21c649982d287948d4b1bf506af8'
assert ready['owned_artifacts']['kernel']['sha256'] == args.kernel_sha256
assert ready['workspace_request_queues_requested'] == 1
assert ready['virtiofs_sysfs']['parameters']['workspace_async_release'] == 'Y'
for attempt in range(1, 4):
    label = f'{args.worker}-profile-admission-{attempt}'
    admission = receipts/f'{label}-preflight.json'
    assert not admission.exists()
    gate = subprocess.run(['bash', str(receipts/'probe_quiet_admission.sh'), label, '3.2'])
    observations = json.loads(admission.read_bytes())
    quiet = observations['quiet_prestart_observed']
    assert len(observations['host_observed_idle_pct']) == 3 and int(not quiet) == gate.returncode
    if quiet:
        break
classification = 'quiet-admitted' if quiet else 'ambient'
print(f'{args.worker} profile {classification}', flush=True)
python = [sys.executable, '-B']
fixture = hub/'evidence/prior'
profile = receipts / f'{args.worker}-{classification}-git-profile.json'
load = receipts / f'{args.worker}-{classification}-git-profile-host-load.jsonl'
subprocess.run([*python, str(receipts/'with_host_load.py'), '--out', str(load), '--', *python,
                str(receipts/'profile_git_density.py'), '--hvf-socket', ready['socket'],
                '--orbstack-socket', '/Users/benebsworth/.orbstack/run/docker.sock', '--workspace', ready['workspace'],
                '--source', str(fixture/'runner-vendored'), '--helpers', str(fixture/'final-harness/scripts'),
                '--image-manifest', str(receipts/'image-manifest.json'), '--image', ready['benchmark_image'],
                '--pairs', '4', '--out', str(profile)], check=True)
subprocess.run([*python, str(receipts/'summarize_git_profiles.py'), '--run', str(profile), '--admission', str(admission),
                '--out', str(profile.with_name(profile.stem+'-summary.json'))], check=True)
