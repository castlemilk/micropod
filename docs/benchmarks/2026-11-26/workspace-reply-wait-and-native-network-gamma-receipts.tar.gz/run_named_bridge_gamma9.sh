#!/bin/bash
set -euo pipefail
E=$(cd "$(dirname "$0")" && pwd -P)
arm=${1:?private worker label}
mark=${2:-$arm}
kernel=${3:-0e05ac3442a22706f62a9e1e47aa056b654a4a4a27993b5cd752bf2e8b065f13}
[[ $arm =~ ^[a-z0-9-]{1,22}$ && $mark =~ ^[a-z0-9-]+$ && $kernel =~ ^[a-f0-9]{64}$ ]]
ready="$E/$arm-ready.json"
socket=$(jq -er .socket "$ready")
orb=/Users/benebsworth/.orbstack/run/docker.sock
test -S "$socket" && test -S "$orb"
jq -e --arg kernel "$kernel" '.owned_artifacts.kernel.sha256==$kernel and
    (.virtiofs_sysfs.parameters.workspace_async_release=="Y") and
    ((.virtiofs_sysfs.parameters.workspace_reply_poll // "N")=="N")' "$ready" >/dev/null
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_API_VERSION DOCKER_CERT_PATH DOCKER_TLS DOCKER_TLS_VERIFY
export DOCKER_CLI_HINTS=false
native=(/opt/homebrew/bin/docker --host "unix://$socket")
test -z "$("${native[@]}" ps -aq)"
gate=0
bash "$E/probe_quiet_admission.sh" "$mark-named-bridge" 3.2 || gate=$?
(( gate <= 1 ))
driver="$E/network-harness/bench_named_bridge_ci.py"
if [[ $arm == packaged-final ]]; then
    driver="$E/network-harness/run_named_bridge_with_wave_load.py"
fi
result=0
python3 -B "$E/with_host_load.py" --out "$E/$mark-named-bridge-host-load.jsonl" -- \
  python3 -B "$driver" --native-socket "$socket" --orb-socket "$orb" \
  --image alpine:3.23 --out "$E/$mark-named-bridge.json" --pairs 4 > "$E/$mark-named-bridge.log" 2>&1 || result=$?
printf '%s\n' "$result" > "$E/$mark-named-bridge.exit"
"${native[@]}" ps -aq > "$E/$mark-named-bridge-private-cleanup.log"
test ! -s "$E/$mark-named-bridge-private-cleanup.log"
cat "$E/$mark-named-bridge.log"
exit "$result"
