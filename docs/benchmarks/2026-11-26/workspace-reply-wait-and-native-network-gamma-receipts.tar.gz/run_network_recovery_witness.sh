#!/bin/bash
set -euo pipefail
E=$(cd "$(dirname "$0")" && pwd -P)
arm=${1:?owned live worker}
[[ $arm =~ ^[a-z0-9-]{1,22}$ ]]
ready="$E/$arm-ready.json"
sock=$(jq -er .socket "$ready")
prefix="$E/network-$arm-restart"
state="$prefix-state.json"
fixture="$E/network-harness/qualify_docker_network_restart.py"
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_API_VERSION DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH
export DOCKER_CLI_HINTS=false
native=(/opt/homebrew/bin/docker --host "unix://$sock")
test -S "$sock" && test -z "$("${native[@]}" ps -aq)"
active=0
cleanup_if_prepared() {
    if (( active == 1 )) && test -S "$sock"; then
        python3 -B "$fixture" --phase cleanup --socket "$sock" --image alpine:3.23 \
            --state "$state" --out "$prefix-emergency-cleanup.json"
    fi
}
trap cleanup_if_prepared EXIT
python3 -B "$fixture" --phase prepare --socket "$sock" --image alpine:3.23 \
    --state "$state" --out "$prefix-prepare.json"
active=1
scope=$(jq -er .scope "$state")
python3 -B "$E/restart_worker.py" "$arm" --state "$state" \
    --label "io.micropod.qualification.bridge-membership=$scope" --out "$prefix-machine.json"
status=0
python3 -B "$fixture" --phase verify --socket "$sock" --image alpine:3.23 \
    --state "$state" --out "$prefix-verify.json" || status=$?
jq -e '(.remaining.containers|length==0) and (.remaining.networks|length==0)' "$prefix-verify.json" >/dev/null
active=0
"${native[@]}" ps -aq > "$prefix-private-cleanup.log"
test ! -s "$prefix-private-cleanup.log"
exit "$status"
