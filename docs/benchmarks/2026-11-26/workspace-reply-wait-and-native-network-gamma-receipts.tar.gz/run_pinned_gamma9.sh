#!/bin/bash
set -euo pipefail
E=$(cd "$(dirname "$0")" && pwd -P)
H=$(dirname "$E")/home
arm=${1:?owned worker label}
digest=${2:?frozen job sha256}
mark=${3:-$arm}
[[ $arm =~ ^[a-z0-9-]{1,22}$ && $digest =~ ^[a-f0-9]{64}$ && $mark =~ ^[a-z0-9-]+$ ]]
ready="$E/$arm-ready.json"
sock=$(jq -er .socket "$ready")
orb=/Users/benebsworth/.orbstack/run/docker.sock
client="$H/pinned-api-$mark"
output="$E/pinned-api/$mark"
test "$(jq -er .owned_artifacts.job.sha256 "$ready")" = "$digest"
test -S "$sock" && test -S "$orb"
mkdir -m 700 "$client" "$output"
mkdir -m 700 "$client/docker" "$client/buildx" "$client/docker/cli-plugins"
plugins=/Applications/Docker.app/Contents/Resources/cli-plugins
for name in docker-compose docker-buildx; do
    test -x "$plugins/$name"
    /bin/ln -s "$plugins/$name" "$client/docker/cli-plugins/$name"
done
/usr/bin/shasum -a 256 "$plugins/docker-compose" "$plugins/docker-buildx" > "$output/client-plugin-sha256.txt"
printf '%s\n' '{"auths":{"fixture.invalid":{}}}' > "$client/docker/config.json"
cp "$E/pinned-api/docker-v1.47.yaml" "$client/docker-v1.47.yaml"
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_API_VERSION DOCKER_CERT_PATH DOCKER_TLS DOCKER_TLS_VERIFY
export DOCKER_CLI_HINTS=false
native=(/opt/homebrew/bin/docker --host "unix://$sock")
test -z "$("${native[@]}" ps -aq)"
python3 -B "$E/pinned-api/drivers/run_final_api_audit.py" --ready "$ready" --reference "$orb" \
    --job-sha "$digest" --client "$client" --output-directory "$output"
"${native[@]}" ps -aq > "$output/native-containers-after-audit.log"
test ! -s "$output/native-containers-after-audit.log"
