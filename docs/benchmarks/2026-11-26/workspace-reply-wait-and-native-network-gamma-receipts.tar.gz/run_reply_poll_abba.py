"""Repeat exact same-image eight-Git waves in four owner-scoped ABBA boots."""
from datetime import datetime, timezone
from importlib.util import module_from_spec, spec_from_file_location
import json
import os
from pathlib import Path
import shutil
from statistics import median
import subprocess
import sys
import time

receipts = Path(__file__).resolve().parent
profile = spec_from_file_location('receipt_reducer',receipts/'inherited-gamma6/summarize_gamma6.py')
calc = module_from_spec(profile)
profile.loader.exec_module(calc)
calc.receipts = receipts


def now():
    return datetime.now(timezone.utc).isoformat()


def checked(*command, timeout=40, env=None):
    return subprocess.run(command, check=True, timeout=timeout, env=env)


def read(path):
    return json.loads(path.read_bytes())


def record(path, value):
    with path.open('x') as out:
        json.dump(value,out,indent=2)
        out.write('\n')


def gate(name):
    results = []
    for number in range(1,4):
        label = f'{name}-density-admission-{number}'
        ran = subprocess.run(['bash',str(receipts/'probe_quiet_admission.sh'),label,'3.2'],timeout=15)
        path = receipts/f'{label}-preflight.json'
        proof = read(path)
        assert len(proof['host_observed_idle_pct'])==3 and ran.returncode==int(not proof['quiet_prestart_observed'])
        results.append(calc.receipt(path) | {'assessment':proof})
        if proof['quiet_prestart_observed']:
            break
    canonical = receipts/f'{name}-density-preflight.json'
    assert not canonical.exists()
    shutil.copyfile(path,canonical)
    return results


def run_arm(name, mode, row):
    ready = receipts/f'{name}-ready.json'
    result = receipts/f'{name}-worker.json'
    row.update(label=name,mode=mode,opened_utc=now())
    owner = subprocess.Popen(['bash',str(receipts/'boot_reply_poll.sh'),name,mode])
    try:
        deadline=time.monotonic()+70
        while not ready.is_file():
            if owner.poll() is not None or time.monotonic() >= deadline:
                raise RuntimeError('owned worker never reached readiness')
            time.sleep(.25)
        live=read(ready)
        assert live['owned_artifacts']['kernel']['sha256']=='0e05ac3442a22706f62a9e1e47aa056b654a4a4a27993b5cd752bf2e8b065f13'
        assert live['owned_artifacts']['vmm']['sha256']=='f0747277714ef1520de32e7e5d398a0b88aded8a52c8f8076dc7daaafde1d3c4'
        assert live['owned_artifacts']['job']['sha256']=='0b20a6f006ca61efa323287777e51466833b21c649982d287948d4b1bf506af8'
        assert live['workspace_request_queues_requested']==1
        assert live['virtiofs_sysfs']['parameters']=={'workspace_async_release':'Y','workspace_reply_poll':{'0':'N','1':'Y'}[mode]}
        row['ready']=calc.receipt(ready)
        row['admission_attempts']=gate(name)
        row['quiet_prestart_observed']=row['admission_attempts'][-1]['assessment']['quiet_prestart_observed']
        checked('bash',str(receipts/'run_scored_worker.sh'),name,name,'density',
                timeout=110,env=dict(os.environ,PAIRS='4'))
        path=receipts/f'{name}-density.json'
        measurement=calc.density(path,read(path))
        assert measurement['pass'] and measurement['jobs_per_wave']==8
        row['load']=measurement['load']
        row['density']=measurement['receipt']
        row['engine_guest_wave_medians_ms']={engine:item['wave_median']['guest_to_last_ms']
                                              for engine,item in measurement['summary'].items()}
        row['pair_ratios']=measurement['paired_hvf_to_orbstack']['guest_to_last_ms']
        row['median_pair_ratio']=median(row['pair_ratios'])
    finally:
        if ready.is_file() and owner.poll() is None:
            checked(sys.executable,'-B',str(receipts/'retire_worker.py'),name,timeout=20)
        stopped=owner.wait(timeout=55)
        shutdown=read(result)
        assert stopped==0 and shutdown['scope_absent'] and shutdown['machine']['clean_shutdown']
        policy=shutdown['drive']['detached']['persisted_policy']
        assert policy['mounted_read_only'] and policy['spotlight']['disabled'] and policy['fsevents']['journal_files']==0
        row['retirement']=calc.receipt(result)
        row['closed_utc']=now()


def main():
    out=receipts/'poll-abba-quiet-repeat.json'
    assert not out.exists()
    order=('0','1','1','0')
    arms=[]
    report={'order':['off','on','on','off'],'arms':arms,'passed':False}
    try:
        for index,mode in enumerate(order,1):
            row={}
            arms.append(row)
            label=f'poll-abba-{index}-'+('on' if mode=='1' else 'off')
            run_arm(label,mode,row)
            print(label,'quiet-admitted' if row['quiet_prestart_observed'] else 'ambient',
                  row['engine_guest_wave_medians_ms'],row['median_pair_ratio'],flush=True)
        report['all_arms_quiet_admitted']=all(row['quiet_prestart_observed'] for row in arms)
        report['paired_medians']={mode:{'hvf_orb_ratio':median(x for row in arms if row['mode']==mode for x in row['pair_ratios']),
            'actual_cpu_idle_pct':[row['load']['weighted_cpu_idle_pct'] for row in arms if row['mode']==mode]} for mode in ('0','1')}
        report['passed']=True
    except Exception as exc:
        report['failure']=repr(exc)
        raise
    finally:
        record(out,report)


if __name__=='__main__':
    main()
