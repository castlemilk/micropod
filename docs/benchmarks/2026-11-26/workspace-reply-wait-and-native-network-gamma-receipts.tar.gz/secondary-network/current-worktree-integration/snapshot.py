from pathlib import Path
import hashlib,json,sys
root,frozen,output = map(Path,sys.argv[1:])
manifest=json.loads(frozen.read_bytes())
def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
actual={p.relative_to(root).as_posix():sha(p) for p in sorted((root/'guest/runner').iterdir()) if p.is_file()}
previous=manifest['source_files']
delta={name:{'qualified':previous.get(name),'current_worktree':actual.get(name)}
       for name in sorted(previous.keys()|actual.keys()) if previous.get(name)!=actual.get(name)}
report={'qualified_base_runner_sha256':manifest['base_runner_sha256'],'qualified_source_archive_sha256':manifest['source_archive_sha256'],
        'source_files':actual,'file_count':len(actual),'delta':delta}
with output.open('x') as f:
    f.write(json.dumps(report,indent=2,sort_keys=True)+'\n')
