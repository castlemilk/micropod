#!/bin/bash
set -euo pipefail
source_dir=$1
record_dir=$2
export GOROOT=/Users/benebsworth/.local/share/mise/installs/go/1.27.2
export GOTOOLCHAIN=local GOFLAGS=-trimpath GOCACHE=/Users/benebsworth/Library/Caches/go-build
export GOOS=linux GOARCH=arm64 CGO_ENABLED=0
cd "$source_dir/source/guest/runner"
date -u +%Y-%m-%dT%H:%M:%SZ > "$record_dir/build-start.txt"
"$GOROOT/bin/go" version | tee "$record_dir/toolchain.log"
"$GOROOT/bin/go" build -mod=readonly -trimpath -p=2 -o "$source_dir/job.secondary" . > "$record_dir/build.log" 2>&1
"$GOROOT/bin/go" test -mod=readonly -trimpath -p=2 -c -o "$source_dir/runner.secondary.test" . > "$record_dir/test-build.log" 2>&1
"$GOROOT/bin/go" vet -mod=readonly -trimpath -p=2 ./... > "$record_dir/vet.log" 2>&1
date -u +%Y-%m-%dT%H:%M:%SZ > "$record_dir/build-end.txt"
shasum -a 256 "$source_dir/job.secondary" "$source_dir/runner.secondary.test" | tee "$record_dir/build.sha256"
