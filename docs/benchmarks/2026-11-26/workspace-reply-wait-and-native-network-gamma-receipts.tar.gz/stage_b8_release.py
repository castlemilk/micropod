"""Freeze only the VMM and kernel from the verified local B8 distribution."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import plistlib
import shutil
import subprocess

receipts = Path(__file__).resolve().parent
hub = receipts.parent/'home'
repo = Path('/Users/benebsworth/projects/micropod')
worktree = repo/'bench/phase0-host-scheduling'
app = worktree/'dist/Micropod.app'
assert hub.is_mount() and app.resolve(strict=True) == app
assert plistlib.loads((app/'Contents/Info.plist').read_bytes())['CFBundleShortVersionString']=='0.1.0-b8'
destination = hub/'independent-b8'
destination.mkdir(mode=0o700)
archive = receipts/'independent-b8'
archive.mkdir(mode=0o700)


def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file,'sha256').hexdigest()


def identity(path):
    current=path.stat()
    return {key:getattr(current,'st_'+key) for key in ('dev','ino','size','mtime_ns')}


def verified_copy(source, target, digest=None):
    assert source.resolve(strict=True)==source and source.is_file()
    before=identity(source)
    original=sha(source)
    assert digest is None or original==digest
    with source.open('rb') as data,target.open('xb') as copied:
        shutil.copyfileobj(data,copied)
    shutil.copystat(source,target)
    assert sha(target)==sha(source)==original and identity(source)==before
    return {'source':str(source),'staged':str(target),'sha256':original,'source_identity':before}


def sign(*args):
    result=subprocess.run(['/usr/bin/codesign',*map(str,args)],text=True,check=True,timeout=30,capture_output=True)
    return {'stdout':result.stdout,'stderr':result.stderr}


whole=sign('--verify','--deep','--strict','--verbose=4',app)
vmm = verified_copy(app/'Contents/MacOS/micropod-vmm',destination/'micropod-vmm',
      'dae33067a0f27f15e4671e11f851b7f4f2468108fed2ec64ebe23fd74b320afc')
kernel = verified_copy(app/'Contents/Resources/vmlinux-hvf',destination/'Image',
      'da6da0bae1db1e5b76754aa8a966b2c6ace66ae049ed0d19f520e2d7a183a43d')
vmm['signature']=sign('--verify','--strict','--verbose=4',destination/'micropod-vmm')
ent=sign('-d','--entitlements','-','--xml',destination/'micropod-vmm')
vmm['entitlements']=plistlib.loads(ent['stdout'].encode())
assert vmm['entitlements']['com.apple.security.hypervisor'] is True
for role,file in [('vmm','micropod-vmm'),('kernel','vmlinux-hvf')]:
    assert sha(worktree/'dist'/file)=={'vmm':vmm,'kernel':kernel}[role]['sha256']
parent_report=worktree/'docs/benchmarks/2026-11-26'
raw='phase-b8-virtiofs-notify-and-keep-cache'
comparators=[verified_copy(parent_report/(raw+ext),archive/(raw+ext)) for ext in ('.md','.json')]
contents=json.loads((archive/(raw+'.json')).read_bytes())
assert contents['checkout_files']==1317
support=[]
for source in (repo/'vmm/crates/vmm-virtio/src/fs_watch.rs', repo/'vmm/crates/vmm-virtio/src/virtiofs.rs',
               worktree/'ci/patches/virtiofs-workspace-notify.patch',worktree/'ci/patches/build-b8-kernel.sh'):
    if source.is_file():
        support.append(verified_copy(source,archive/source.name))
record={'observed_utc':datetime.now(timezone.utc).isoformat(),'source_app':str(app),'bundle_version':'0.1.0-b8',
        'source_app_strict_signature':whole,'release_artifacts':{'vmm':vmm,'kernel':kernel},
        'independent_runner_sha256':'3d0a9a9154a06f0a395dbc762ab2ce83024481404c6a9bb018fca59037da0123',
        'preceding_report_checkout_files':1317,'independent_checkout_files':1058,'preceding_reports':comparators,
        'current_checkout_supporting_files':support,'workspace_live_read_override':False}
with (receipts/'b8-independent-lineage.json').open('x') as out: json.dump(record,out,indent=2);out.write('\n')
print('Verified source B8 app and staged VMM/kernel',destination,flush=True)
