"""Copy and attest the pre-existing pinned Linux input on the private APFS hub."""
import hashlib
import json
from pathlib import Path
import shutil

receipts = Path(__file__).resolve().parent
hub = receipts.parent/'home'
source = Path('/Users/benebsworth/projects/micropod/bench/phase0-host-scheduling/.build/local-kernel-pages/20261124T192542Z-cny_trn8/linux-7.3.5.tar.xz')
target = hub/'kernel-base/inputs/linux-7.3.5.tar.xz'
digest = '8f293f83d54f0b7b9be56863ebc5e4ea79d73e530b4ae55c572be97ef39f0990'

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

assert hub.is_mount() and source.resolve(strict=True) == source
assert sha(source) == digest and not target.exists()
with source.open('rb') as present, target.open('xb') as copied:
    shutil.copyfileobj(present, copied)
assert sha(target) == sha(source) == digest
assert target.stat().st_dev == hub.stat().st_dev
target.chmod(0o400)
inputs = target.parent
proof = {'path':str(target),'local_verified_source':str(source),'sha256':digest,'bytes':target.stat().st_size,
         'original_source_url':'https://cdn.kernel.org/pub/linux/kernel/v7.x/linux-7.3.5.tar.xz',
         'inputs':{path.relative_to(hub).as_posix():sha(path) for path in sorted((hub/'kernel-base').glob('**/*'))
                   if path.is_file() and path != target}}
with (receipts/'kernel-source-inputs.json').open('x') as out:
    json.dump(proof,out,indent=2)
    out.write('\n')
print(target,digest)
