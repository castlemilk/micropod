"""Summarize matched real Gamma9 stock checkout, Git density and owned Docker checks."""
from collections import Counter
import gzip
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
from statistics import median

receipts = Path(__file__).resolve().parent
loader = spec_from_file_location('receipt_reducer', receipts/'inherited-gamma6/summarize_gamma6.py')
calculator = module_from_spec(loader)
loader.loader.exec_module(calculator)
calculator.receipts = receipts
read, receipt = calculator.read, calculator.receipt


def admission(name):
    path = receipts / (name + '-preflight.json')
    raw = read(path)
    return {'classification':'quiet-admitted' if raw['quiet_prestart_observed'] else 'ambient',
            'receipt':receipt(path), **raw}


def read_pinned_api():
    rows = {}
    for file in sorted(receipts.glob('**/docker-api*1.47.json.gz')):
        with gzip.open(file, 'rt') as stream:
            data = json.load(stream)
        if 'operations' not in data or 'candidate' not in data:
            continue
        groups = Counter(case.get('comparison', 'unclassified') for case in data['candidate'].values())
        operations = {name for case in data['candidate'].values() for name in case.get('operations', [])}
        assert operations <= data['operations'].keys()
        rows[file.relative_to(receipts).as_posix()] = {'receipt':receipt(file), 'strict_groups':dict(groups),
            'observed_operation_ids':sorted(operations), 'operations_in_spec':len(data['operations'])}
    return rows


def matched_rows(result):
    match = {}
    for name, data in result['boots'].items():
        if name not in result['material'] or name not in result['density']:
            continue
        material, density = result['material'][name], result['density'][name]
        if not density['pass']:
            continue
        match[name] = {
            'artifacts':data['artifacts'], 'boot':data['receipt'], 'virtiofs':data['virtiofs_sysfs'],
            'material_admission':material['admission']['classification'], 'material_idle_pct':material['load']['weighted_cpu_idle_pct'],
            'phases':{key:{'engines':phase['engines'], 'median_hvf_orb_ratio':phase['median_hvf_to_orbstack_ratio'],
                           'hvf_wins':phase['hvf_wins']} for key,phase in material['rounds'].items()},
            'density_admission':density['admission']['classification'], 'density_idle_pct':density['load']['weighted_cpu_idle_pct'],
            'density_medians':{key:row['wave_median'] for key,row in density['summary'].items()},
            'density_paired_hvf_orb_ratio':median(density['paired_hvf_to_orbstack']['guest_to_last_ms'])}
    return match


def main():
    result = {'host':'Gamma-128GB.local','date_melbourne':'2026-11-26',
        'lineage':read(receipts/'baseline-lineage.json'), 'preceding_gamma8':read(receipts/'preceding-gamma8-recheck.json'),
        'matched_oci_image':read(receipts/'image.json'), 'boots':{},'material':{},'density':{},'profiles':{},
        'correctness':{},'linux_tests':{},'exceptions':{},'pinned_api':read_pinned_api()}
    for file in sorted(receipts.glob('*-ready.json')):
        data = read(file)
        if 'owned_artifacts' not in data:
            continue
        result['boots'][data['label']] = {'receipt':receipt(file),'artifacts':data['owned_artifacts'],
            'virtiofs_sysfs':data['virtiofs_sysfs'],'arguments':data['kernel_arguments_requested'],
            'bundled_payload':data.get('bundled_payload')}
    for file in sorted(receipts.glob('*-material.json')):
        data = read(file)
        if data.get('workspace_mode') == 'independent byte-identical raw host checkouts':
            name = file.stem.removesuffix('-material')
            summary = calculator.material(file,data)
            summary['admission'] = admission(name)
            summary['pairs_guest_wall_ms'] = {phase:[{engine:pair[phase][engine]['sum_ns']/1_000_000
                for engine in ('hvf','orbstack')} for pair in data['pairs']] for phase in ('warm','incremental')}
            result['material'][name] = summary
    for file in sorted(receipts.glob('*-density.json')):
        data = read(file)
        if data.get('execution') == 'stock unpinned Git':
            name = file.stem.removesuffix('-density')
            result['density'][name] = calculator.density(file,data) | {'admission':admission(file.stem)}
    for file in sorted(receipts.glob('*-git-profile-summary.json')):
        data = read(file)
        raw = receipts / data['receipt']
        assert receipt(raw)['sha256'] == data['sha256']
        load = raw.with_name(raw.stem+'-host-load.jsonl')
        result['profiles'][file.stem] = {'receipt':receipt(file), **data,
            'within_work_load':calculator.load(load)}
    for pattern in ('*-mmap-exact.json','*-guest-splice.json','*-stock-pid1*.json','*-lifecycle.json','*-lifecycle-reconciled.json','*-dispatch.json'):
        for file in sorted(receipts.glob(pattern)):
            result['correctness'][file.stem] = {'receipt':receipt(file), 'contents':read(file)}
    for file in sorted(receipts.glob('*-linux-exit.log')):
        worker = file.name.removesuffix('-linux-exit.log')
        logs = {mode:receipts/f'{worker}-linux-{mode}.log' for mode in ('focused','full')}
        result['linux_tests'][worker] = {'exit':file.read_text().strip(), 'status':{
            mode:{'receipt':receipt(log), **calculator.read_linux_test(log)} for mode,log in logs.items()}}
    for pattern in ('*-material.exit','*-density.exit','*-qualification-exit.log'):
        for file in sorted(receipts.glob(pattern)):
            output = file.read_text().strip()
            if output != '0' and not (output and all(token.endswith('=0') for token in output.split())):
                result['exceptions'][file.name] = {'receipt':receipt(file), 'exit':output}
    for file in sorted(receipts.glob('*-worker.json')):
        data = read(file)
        if data['errors']:
            result['exceptions'][file.name] = {'receipt':receipt(file), 'error':data['errors']}
    result['matched_measured_workers'] = matched_rows(result)
    result['reply_poll_experiment'] = {}
    matched = result['matched_measured_workers']
    if 'poll-off' in matched and 'poll-on' in matched:
        assert matched['poll-off']['artifacts'] == matched['poll-on']['artifacts']
        result['reply_poll_experiment']['same_image_scores'] = {label:matched[label] for label in ('poll-off','poll-on')}
    crossover = receipts/'poll-abba-quiet-repeat.json'
    if crossover.is_file():
        result['reply_poll_experiment']['counterbalanced_density'] = {'receipt':receipt(crossover),'contents':read(crossover)}
    for path in sorted((receipts/'reply-poll-trace').glob('*-dispatch.json')):
        result['reply_poll_experiment'][path.stem] = {'receipt':receipt(path),'contents':read(path)}
    result['named_bridge_waves'] = {}
    for path in sorted(receipts.glob('*-named-bridge.json')):
        raw = read(path)
        name = path.stem.removesuffix('-named-bridge')
        record = {'receipt':receipt(path), 'load':calculator.load(path.with_name(path.stem+'-host-load.jsonl')),
                  'admission':admission(path.stem), 'wave_data':raw}
        if 'median_ms' in raw:
            assert len(raw['pairs']) == 4 and all(not any(wave[engine]['remaining'].values())
                for wave in raw['pairs'] for engine in ('native','orb'))
            record['passed'] = True
        else:
            record['passed'] = False
        result['named_bridge_waves'][name] = record
    syscalls = receipts/'syscalls/native-git-attribution-with-context.json'
    if syscalls.is_file():
        result['native_syscall_attribution'] = {'receipt':receipt(syscalls),'contents':read(syscalls)}
    independent = receipts/'b8-independent-lineage.json'
    if independent.is_file():
        abi = receipts/'independent-b8-virtiofs-attestation.json'
        result['independent_b8'] = {'lineage':receipt(independent),'attestation':receipt(abi),
            'content':read(abi),'checked_fixture':result['density']['independent-b8']['source'],
            'strict_exit':(receipts/'independent-b8-correctness-exit.log').read_text().strip(),
            'primary_waves':result['density']['independent-b8']['receipt'],
            'material':result['material'].get('independent-b8',{}).get('receipt')}
    integration = receipts/'packaged-final-integration.json'
    distribution = receipts/'root-candidates/package/standalone-final.json'
    if integration.is_file():
        integration_data = read(integration)
        result['final_packaged_integration'] = {
            'qualification':receipt(integration), 'contents':integration_data,
            'material':result['material']['packaged-final'], 'density':result['density']['packaged-final'],
            'named_bridge':{key:row for key,row in result['named_bridge_waves']['packaged-final'].items()
                            if key != 'wave_data'},
            'distribution_receipt':receipt(distribution), 'local_distribution':read(distribution),
        }
    result['additional_evidence'] = calculator.scoped_evidence('root-candidates/**/*','network*/**/*','tc-*.json',
        '**/*network*.json','**/*kernel*.json','**/*wait*.json','**/*admission*preflight.json',
        '**/*restart*.json','**/*lifecycle-reconciled.json','**/*iptables-restore*.log','**/*quiet-repeat*.json')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
