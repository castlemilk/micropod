"""Attribute stock Git's main-thread syscalls to paths using ftrace and the openat probe."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import posixpath
import re
from statistics import median


ROW = re.compile(r'^\s*.*?-(?P<pid>\d+)\s*(?:\(\s*(?:\d+|-+)\s*\)\s*)?\[\d+\]\s+\S+\s+'
                 r'(?P<sec>\d+)\.(?P<frac>\d+):\s+(?P<body>.*)$')
ENTER = re.compile(r'^sys_([a-z0-9_]+)\((.*)\)$')
EXIT = re.compile(r'^sys_([a-z0-9_]+) -> (-?(?:0x[0-9a-f]+|\d+))$')
PATH_PROBE = re.compile(r'^openat_path:.*\bpath="(.*)"$')
ARG = re.compile(r'\b([a-z0-9_]+): (-?(?:0x[0-9a-f]+|\d+))')
FUSE_READ = re.compile(r'^fuse_request_send: connection (\d+) req (\d+) opcode \d+ \((?:FUSE_)?READ\) len \d+$')
INPUT_CALLS = ('read','pread64','readv','preadv')


def number(text):
    value = int(text, 0)
    return value - (1 << 64) if value >= 1 << 63 else value


def file_descriptor(n):
    value = n & 0xffffffff
    return value - (1 << 32) if value >= 1 << 31 else value


def resolve(cwd, path, dfd, files):
    if posixpath.isabs(path):
        return posixpath.normpath(path)
    base = cwd if file_descriptor(dfd) == -100 else files.get(file_descriptor(dfd))
    return posixpath.normpath(posixpath.join(base, path)) if base else None


def classify(path, repo, tracked, anonymous=False):
    if anonymous:
        return 'anonymous'
    if path is None:
        return 'fd_path_unobserved'
    if path in tracked:
        return 'tracked_file'
    if path == f'{repo}/.git' or path.startswith(f'{repo}/.git/'):
        return 'git_metadata'
    if path == repo or path.startswith(repo + '/'):
        return 'other_checkout_path'
    return 'outside_checkout'


def summarize(calls):
    counts = [row['duration_ns'] for row in calls]
    total = sum(counts)
    return {'calls':len(counts), 'sum_ms':total/1e6, 'median_us':median(counts)/1e3,
            'positive_read_bytes':sum(item.get('read_bytes', 0) for item in calls),
            'mapped_length_bytes':sum(item.get('mapped_bytes', 0) for item in calls),
            'failed_calls':sum(item['error'] for item in calls),
            'distinct_paths':len({row['path'] for row in calls if row['path'] is not None})}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for optional in ('run', 'raw', 'source', 'out'):
        parser.add_argument('--'+optional, type=Path, required=True)
    args = parser.parse_args()
    run = json.loads(args.run.read_bytes())
    assert run['passed'] and not run['remaining'] and run['capture']['complete']
    sample = run['traced_sample']
    clock, finished = sample['clock'], sample['finish_ns']
    assert clock['offset_ns'] == 0 and not sample['stdout_hex'] and not sample['stderr_hex'] and sample['exit'] == 0
    path_source = sample['command'][2].removeprefix('safe.directory=')
    assert sample['command'][2].startswith('safe.directory=') and path_source.startswith('/')
    tracked = {path_source + '/' + entry.relative_to(args.source).as_posix()
               for entry in args.source.rglob('*') if entry.is_file()}
    assert len(tracked) == run['source']['files'] == 1058
    pid = run['git_fuse']['kernel_git_pid']
    raw = (args.raw/'.trace-events').read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == run['capture']['raw_files_sha256']['.trace-events']
    started = dict(row.split('=', 1) for row in (args.raw/'.trace-started').read_text().splitlines())
    assert started['clock'] == 'mono' and started['boot_id'] == clock['boot_id']
    assert started['openat_probe'].endswith('/openat_path') and started['syscalls']
    current, descriptors, groups, errors = None, {}, defaultdict(list), Counter()
    mappings, read_contexts, read_unique = {}, Counter(), set()
    cwd = path_source
    for line in raw.decode().splitlines():
        row = ROW.fullmatch(line)
        if not row or int(row['pid']) != pid:
            continue
        when = int(row['sec'])*1_000_000_000 + int(row['frac'].ljust(9, '0'))
        if not clock['now_ns'] <= when <= finished:
            continue
        text = row['body'].strip()
        if (match := FUSE_READ.fullmatch(text)) and match[1] == started['connection']:
            assert match[2] not in read_unique
            read_unique.add(match[2])
            if current is not None:
                name = current['name']
                group = 'tracked_input_syscall' if name in INPUT_CALLS and current['path'] in tracked else f'other_syscall:{name}'
            else:
                group = 'outside_observed_syscall_with_live_tracked_mapping' if mappings else 'outside_observed_syscall_without_tracked_mapping'
            read_contexts[group] += 1
            continue
        if match := ENTER.fullmatch(text):
            if current:
                errors['entry_without_previous_exit'] += 1
            current = {'name':match[1], 'start_ns':when, 'args':{k:number(v) for k,v in ARG.findall(match[2])}, 'path':None}
            if 'fd' in current['args'] and current['name'] != 'openat':
                current['fd'] = file_descriptor(current['args']['fd'])
                current['path'] = descriptors.get(current['fd'])
        elif match := PATH_PROBE.fullmatch(text):
            if not current or current['name'] != 'openat' or current['path'] is not None:
                errors['probe_without_pending_openat'] += 1
                continue
            current['path'] = resolve(cwd, match[1], current['args'].get('dfd', -100), descriptors)
        elif match := EXIT.fullmatch(text):
            name, ret = match[1], number(match[2])
            if not current or current['name'] != name:
                errors['exit_without_matching_entry'] += 1
                current = None
                continue
            path, parameters = current['path'], current['args']
            if name == 'openat' and ret >= 0:
                descriptors[ret] = path
                if path is None:
                    errors['successful_openat_missing_path'] += 1
            if name == 'close' and ret == 0:
                descriptors.pop(current.get('fd'), None)
            if name == 'dup' and ret >= 0:
                descriptors[ret] = path
            anonymous = name == 'mmap' and current.get('fd') == -1
            group = classify(path, path_source, tracked, anonymous)
            entry = {'duration_ns':when-current['start_ns'], 'path':path, 'error':ret<0}
            if name in ('read','pread64','readv','preadv') and ret > 0:
                entry['read_bytes'] = ret
            if name == 'mmap' and ret >= 0:
                entry['mapped_bytes'] = parameters.get('len', 0)
                if path in tracked:
                    mappings[ret] = (path,entry['mapped_bytes'])
            if name == 'munmap' and ret == 0:
                mappings.pop(parameters.get('addr'),None)
            groups[name, group].append(entry)
            current = None
    assert not current and not errors, errors
    aggregates = defaultdict(dict)
    for (name, group), calls in sorted(groups.items()):
        aggregates[name][group] = summarize(calls)
    assert aggregates['openat']['tracked_file']['distinct_paths'] == 1058
    elapsed = finished-clock['now_ns']
    input_ns = sum(row['duration_ns'] for name in INPUT_CALLS for row in groups[name, 'tracked_file'])
    opens_ns = sum(row['duration_ns'] for row in groups['openat','tracked_file'])
    result = {'raw_sha256':digest, 'trace_manifest_sha256':hashlib.sha256(args.run.read_bytes()).hexdigest(),
              'kernel_pid':pid, 'scope':'instrumented main thread of one actual stock clean Git status',
              'system_calls_traced':started['syscalls'].split(','), 'openat_probe':started['openat_probe'],
              'source':run['source'], 'total_stock_command_wall_ms':elapsed/1e6,
              'tracked_fd_read_syscall_pct_of_wall':100*input_ns/elapsed,
              'tracked_open_and_read_syscall_pct_of_wall':100*(input_ns+opens_ns)/elapsed,
              'syscalls_by_attributed_path':dict(aggregates), 'unmatched':errors,
              'main_thread_workspace_fuse_read_contexts':read_contexts,
              'fuse_context_definition':'Associates one FUSE send with the simultaneously observed syscall or the presence of a live tracked mapping. A live mapping interval alone does not identify the FUSE request inode.',
              'time_definition':'Elapsed syscall entry to exit including blocked time. Memory faults after mmap return are outside the mmap duration.'}
    with args.out.open('x') as out:
        json.dump(result,out,indent=2)
        out.write('\n')


if __name__ == '__main__':
    main()
