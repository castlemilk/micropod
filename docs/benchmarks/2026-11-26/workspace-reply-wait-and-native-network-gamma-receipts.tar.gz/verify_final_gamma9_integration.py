#!/usr/bin/env python3
"""Independently validate the integrated package scores and preserve the exact v1.47 differential."""

from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import shutil
from statistics import median
import sys


receipts = Path(__file__).resolve().parent
label = 'packaged-final'


def read(path):
    return json.loads(path.read_bytes())


def proof(path):
    with path.open('rb') as source:
        digest = hashlib.file_digest(source, 'sha256').hexdigest()
    return {'path': str(path.relative_to(receipts) if path.is_relative_to(receipts) else path),
            'sha256': digest, 'bytes': path.stat().st_size}


def publish_wire_audit(results):
    stage = receipts / 'pinned-api' / 'secondary-network-v4'
    raw = stage / 'docker-api-v1.47.json.gz'
    summary = read(stage / 'summary.json')
    with gzip.open(raw, 'rt') as source:
        audit = json.load(source)
    operation_ids = set().union(*(set(case['operations']) for case in audit['candidate'].values()))
    assert len(audit['candidate']) == 27 and len(operation_ids) == 39 and len(audit['operations']) == 107
    assert operation_ids <= audit['operations'].keys()
    assert Counter(case['comparison'] for case in audit['candidate'].values()) == {'matched': 16, 'different': 11}
    assert summary['audit_sha256'] == proof(raw)['sha256'] and not summary['changed_groups']
    assert summary['exits'] == {'audit': 1, 'cleanup': 0}
    cleanup = stage / 'cleanup.json'
    assert all(scope['status'] == 200 and scope['returned'] == scope['matching'] == 0
               for endpoint in read(cleanup).values() for scope in endpoint.values())
    output = results / 'native-docker-api-v1.47-secondary-networks.json.gz'
    if not output.exists():
        with raw.open('rb') as source, output.open('xb') as target:
            shutil.copyfileobj(source, target)
    assert proof(output)['sha256'] == proof(raw)['sha256']
    return {'raw': proof(raw), 'durable_gzip': proof(output), 'summary': proof(stage / 'summary.json'),
            'cleanup': proof(cleanup), 'strict_groups_matched': 16, 'strict_groups': 27,
            'exercised_operations': 39, 'spec_operations': 107, 'changed_groups_from_v3': []}


def verify_package():
    ready = receipts / f'{label}-ready.json'
    attestation = receipts / f'{label}-virtiofs-attestation.json'
    result = read(attestation)
    assert result['ready_sha256'] == proof(ready)['sha256'] and result['admitted_for_strict_smoke']
    checkout = receipts / f'{label}-material.json'
    git_wave = receipts / f'{label}-density.json'
    named_wave = receipts / f'{label}-named-bridge.json'
    start = receipts / f'{label}-qualification-exit.log'
    assert start.read_text().strip() == 'ordinary_held_and_stock=0 stock_network=0 named=0 density=0 material=0'
    for timing in (checkout, git_wave, named_wave):
        assert (timing.parent / (timing.stem + '.exit')).read_text().strip() == '0'
    for mark in ('prescore', 'postscore'):
        assert (receipts / f'{label}-{mark}-private-cleanup.log').stat().st_size == 0
    edits, held, splice = (receipts / f'{label}-{test}.json' for test in ('edits', 'mmap-exact', 'guest-splice'))
    marks = read(edits)
    assert marks['complete'] and set(marks['samples']) == {'size', 'held', 'replace', 'unlink'}
    assert all(len(samples) == 4 and all(row['result'] == 'observed' for row in samples)
               for samples in marks['samples'].values())
    assert read(held)['success'] and read(splice)['success'] and read(splice)['require_live_splice']
    stock = receipts / f'{label}-stock-pid1.json'
    cases = read(stock)
    assert not cases['errors'] and not cases['remaining_owned'] and len(cases['cases']) == 4
    assert all(case['pass'] for case in cases['cases'].values())
    network = receipts / 'network-packaged-final-stock-smoke.json'
    wave = read(network)['cases']['eight-concurrent']
    assert wave['passed'] and not any(wave['remaining'].values())
    assert read(checkout)['source'] == read(git_wave)['source']
    assert len(read(checkout)['pairs']) == len(read(git_wave)['rounds']) == 4
    assert all(not data['remaining'] for data in read(git_wave)['cleanup'].values())
    return {'app_boot': proof(ready), 'attested_negotiation': proof(attestation),
            'checked_runtime_roles': result['artifacts'], 'strict_edits': proof(edits), 'strict_held': proof(held),
            'strict_splice': proof(splice), 'stock_pid1': proof(stock), 'stock_eight_join': proof(network),
            'passed_exit': proof(start),
            'scores': {'checkout': proof(checkout), 'git8': proof(git_wave), 'named8': proof(named_wave)}}


def verify_named():
    raw = read(receipts / f'{label}-named-bridge.json')
    assert raw['jobs_per_wave'] == 8 and raw['cpus_per_job'] == .5 and raw['memory_mib_per_job'] == 256
    assert len(raw['pairs']) == 4
    hosts = {side: [] for side in ('native', 'orb')}
    times = ('launch_ms', 'all_http_ms', 'through_cleanup_ms')
    paired_ratios = {name: [] for name in times}
    redirects = Counter()
    for index, pair in enumerate(raw['pairs']):
        assert pair['order'] == (['native', 'orb'] if not index % 2 else ['orb', 'native'])
        for side in pair['order']:
            row = pair[side]
            assert 'error' not in row and 'cleanup_error' not in row and not any(row['remaining'].values())
            assert len(set(row['ids'].values())) == len(set(row['bodies'])) == 8
            host = row['host_cpu']
            delta = Counter(host['delta_ticks'])
            assert host['before']['monotonic_ns'] < host['after']['monotonic_ns']
            assert delta.total() > 0 and host['cpu_idle_pct'] == delta['idle'] * 100 / delta.total()
            hosts[side].append(host['cpu_idle_pct'])
        for metric in times:
            paired_ratios[metric].append(pair['native'][metric] / pair['orb'][metric])
        redirect = pair['native']['dns_install_delta']
        assert redirect['attempts'] == 8 and redirect['errors'] == 0 and redirect['usec_total'] > 0
        redirects.update(redirect)
    return {'medians_ms': raw['median_ms'], 'paired_native_over_orbstack': paired_ratios,
            'median_pair_ratios': {metric: median(row) for metric, row in paired_ratios.items()},
            'native_faster_pairs': {metric: sum(value < 1 for value in row) for metric, row in paired_ratios.items()},
            'per_wave_host_idle_pct': hosts, 'native_dns_install_total': dict(redirects),
            'distinct_services_per_engine': 4 * 8, 'all_owned_scopes_empty': True}


def main():
    target = receipts / 'packaged-final-integration.json'
    assert not target.exists()
    package = verify_package()
    package['named8_checks'] = verify_named()
    package['pinned_v4_unpacked_audit'] = publish_wire_audit(Path(sys.argv[1]).resolve(strict=True))
    package['preflight'] = {}
    for suffix in ('', '-density', '-named-bridge'):
        file = receipts / f'{label}{suffix}-preflight.json'
        package['preflight'][suffix.strip('-') or 'material'] = {'receipt': proof(file), **read(file)}
    with target.open('x') as stream:
        json.dump(package, stream, indent=2)
        stream.write('\n')
    print(proof(target))


if __name__ == '__main__':
    main()
